"""
demos_v1/frontend.py - HTML_TEMPLATE (main frontend UI)
"""

# ============================================
# HTML 템플릿
# ============================================
HTML_TEMPLATE = r"""<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Demos V1.0</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.7/dist/chart.umd.min.js"></script>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:#f8f7f4;color:#1a1a1a;display:flex;height:100vh}
.sidebar{width:250px;background:#fff;border-right:1px solid #e5e3de;padding:20px 16px;display:flex;flex-direction:column;overflow-y:auto;transition:width .2s ease,padding .2s ease;flex-shrink:0;scrollbar-width:none}
.sidebar::-webkit-scrollbar{display:none}
.sidebar.collapsed{width:48px;padding:12px 6px;overflow:hidden}
.sidebar.collapsed .sidebar-inner{display:none}
.sidebar.collapsed .sidebar-file-panel{display:none!important}
.sidebar.collapsed .sidebar-logo{display:none}
.sidebar-toggle{position:absolute;top:12px;left:250px;width:24px;height:24px;border-radius:0 6px 6px 0;border:1px solid #e5e3de;border-left:none;background:#fff;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:12px;color:#999;z-index:200;transition:left .2s ease}
.sidebar-toggle:hover{background:#eef2ff;color:#6366f1}
body.sb-collapsed .sidebar-toggle{left:48px}
body.sb-collapsed .chat-box-fixed{left:48px}
.sidebar-toggle-mini{width:100%;padding:6px 0;border:none;background:none;cursor:pointer;font-size:16px;display:none;color:#6366f1}
.sidebar.collapsed .sidebar-toggle-mini{display:block}
.sidebar-logo{font-size:22px;font-weight:700;margin-bottom:24px}.sidebar-logo span{color:#6366f1}
.sidebar-btn{width:100%;padding:10px 14px;border-radius:8px;border:none;cursor:pointer;font-size:14px;text-align:left;margin-bottom:4px;background:transparent;color:#555;transition:all .15s}
.sidebar-btn:hover{background:#f3f2ef}.sidebar-btn.active{background:#6366f1;color:#fff}
.session-item{display:flex;align-items:center;padding:5px 8px;border-radius:6px;cursor:pointer;font-size:12px;color:#555;transition:all .12s;gap:4px;margin:1px 4px}
.session-item:hover{background:#f3f2ef}
.session-item.current{background:#eef2ff;color:#6366f1;font-weight:600}
.session-item .session-name{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.session-item .session-cb{width:14px;height:14px;cursor:pointer;accent-color:#6366f1;flex-shrink:0}
.session-item .session-time{font-size:9px;color:#bbb;flex-shrink:0}
.sidebar-collapse{display:flex;align-items:center;justify-content:space-between;cursor:pointer;padding:4px 0;user-select:none}
.sidebar-collapse:hover{opacity:.8}
.sidebar-collapse .arrow{font-size:10px;color:#999;transition:transform .15s}
.sidebar-collapse .arrow.open{transform:rotate(90deg)}
.sidebar-collapsible{overflow:hidden;transition:max-height .2s ease}
.sidebar-collapsible.collapsed{max-height:0!important}
.session-actions{display:flex;gap:4px;padding:4px 8px}
.session-actions button{flex:1;padding:3px 0;border:1px solid #e5e3de;border-radius:4px;background:#fafaf8;font-size:10px;cursor:pointer;transition:all .12s}
.session-actions button:hover{background:#eef2ff;border-color:#6366f1}
.session-actions button.danger{color:#ef4444;border-color:#fca5a5}
.session-actions button.danger:hover{background:#fef2f2;border-color:#ef4444}
.sidebar-section{font-size:11px;font-weight:600;color:#999;text-transform:uppercase;letter-spacing:.5px;margin:20px 0 8px 8px}
.skill-count{font-size:11px;color:#6366f1;background:#eef2ff;padding:2px 8px;border-radius:10px;margin-left:6px}
.sidebar-footer{margin-top:auto;padding-top:16px;border-top:1px solid #e5e3de}
.credits{font-size:12px;color:#999}
.main{flex:1;display:flex;flex-direction:column;overflow:hidden}
.header{padding:16px 32px;border-bottom:1px solid #e5e3de;background:#fff;display:flex;align-items:center;justify-content:space-between}
.project-title{font-size:20px;font-weight:600}
.content{flex:1;overflow-y:auto;padding:24px 32px}
.content-inner{max-width:800px;margin:0 auto}
.section-label{font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:#555;margin-bottom:10px}
/* Chat - Fixed Bottom */
.chat-box-fixed{position:fixed;bottom:0;left:250px;right:340px;background:#fff;border-top:2px solid #e5e3de;padding:6px 32px;z-index:100;box-shadow:0 -2px 10px rgba(0,0,0,.05);transition:left .2s ease,right .2s ease}
.chat-box-fixed:focus-within{border-top-color:#6366f1}
.chat-box-fixed-inner{max-width:800px;margin:0 auto}
.chat-input{width:100%;border:none;outline:none;font-size:13px;resize:none;min-height:20px;max-height:100px;font-family:inherit;line-height:1.4}
.chat-input::placeholder{color:#aaa;font-size:12px}
.chat-footer{display:flex;justify-content:space-between;align-items:center;margin-top:2px}
.send-btn{width:32px;height:32px;border-radius:50%;border:none;background:#6366f1;color:#fff;cursor:pointer;font-size:14px;transition:background .15s}
.send-btn:hover{background:#4f46e5}
.send-btn:disabled{background:#ccc;cursor:not-allowed}
/* 채팅 첨부파일 */
.attach-btn{width:32px;height:32px;border-radius:50%;border:none;background:transparent;color:#999;cursor:pointer;font-size:18px;transition:all .15s;display:flex;align-items:center;justify-content:center}
.attach-btn:hover{background:#f0f0f0;color:#6366f1}
.chat-dropdown{padding:3px 6px;border-radius:8px;border:1.5px solid #e5e3de;font-size:11px;cursor:pointer;background:#fff;color:#555;outline:none;transition:all .15s;appearance:none;-webkit-appearance:none;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8' viewBox='0 0 8 8'%3E%3Cpath d='M0 2l4 4 4-4z' fill='%23999'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 6px center;padding-right:18px}
.chat-dropdown:hover{border-color:#6366f1}.chat-dropdown:focus{border-color:#6366f1;box-shadow:0 0 0 2px rgba(99,102,241,.15)}
.chat-dropdown option{font-size:12px}
.chat-attach-preview{display:flex;flex-wrap:wrap;gap:6px;padding:4px 0}
.chat-attach-badge{display:inline-flex;align-items:center;gap:4px;background:#eef2ff;border:1px solid #c7d2fe;border-radius:8px;padding:3px 10px;font-size:11px;color:#4f46e5;max-width:200px}
.chat-attach-badge .fname{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.chat-attach-badge .remove-attach{cursor:pointer;font-size:14px;color:#999;margin-left:2px;line-height:1}
.chat-attach-badge .remove-attach:hover{color:#ef4444}
.content{padding-bottom:80px!important}
/* Tags */
.tag-row{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:24px}
.tag{padding:8px 18px;border-radius:20px;border:2px solid #e5e3de;font-size:13px;font-weight:500;cursor:pointer;transition:all .15s;background:#fff;user-select:none}
.tag:hover{border-color:#6366f1}.tag.selected{border-color:var(--c,#6366f1);background:var(--bg,#eef2ff);color:var(--fg,#4f46e5)}
/* Skills */
.skill-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:8px;margin-bottom:24px;max-height:220px;overflow-y:auto;padding:4px}
.skill-card{padding:10px 14px;border-radius:10px;border:2px solid #e5e3de;background:#fff;cursor:pointer;transition:all .15s;font-size:13px;position:relative}
.skill-card:hover{border-color:#6366f1;transform:translateY(-1px)}
.skill-card.selected{border-color:#6366f1;background:#eef2ff}
.skill-card.auto-loaded{border-color:#f59e0b;background:#fffbeb;animation:autoPulse 1.5s ease-in-out}
@keyframes autoPulse{0%{box-shadow:0 0 0 0 rgba(245,158,11,.4)}70%{box-shadow:0 0 0 8px rgba(245,158,11,0)}100%{box-shadow:none}}
.skill-card.unavailable{opacity:.45;cursor:default}
.skill-card .sn{font-weight:600;margin-bottom:2px}.skill-card .sd{font-size:11px;color:#888}
.skill-card .badge{position:absolute;top:6px;right:8px;font-size:10px;background:#10b981;color:#fff;padding:1px 6px;border-radius:8px}
/* Effort */
.effort-section{margin-bottom:24px}
.effort-slider{width:100%;-webkit-appearance:none;appearance:none;height:6px;border-radius:3px;background:linear-gradient(to right,#6366f1 0%,#6366f1 var(--val,66%),#e5e3de var(--val,66%),#e5e3de 100%);outline:none}
.effort-slider::-webkit-slider-thumb{-webkit-appearance:none;width:20px;height:20px;border-radius:50%;background:#6366f1;cursor:pointer;border:3px solid #fff;box-shadow:0 1px 4px rgba(0,0,0,.2)}
.effort-labels{display:flex;justify-content:space-between;font-size:12px;color:#999;margin-top:4px}
.effort-labels span.active{color:#6366f1;font-weight:600}
/* Style */
.style-row{display:flex;gap:16px;margin-bottom:24px}.style-group{flex:1}
.style-group label{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:#999;margin-bottom:8px;display:block}
.style-group textarea{width:100%;border:1px solid #e5e3de;border-radius:10px;padding:10px 12px;font-size:13px;resize:none;height:56px;font-family:inherit;outline:none}
.style-group textarea:focus{border-color:#6366f1}
.fmt-btns{display:flex;flex-wrap:wrap;gap:6px}
.fmt-btn{padding:6px 14px;border-radius:8px;border:2px solid #e5e3de;font-size:12px;cursor:pointer;transition:all .15s;background:#fff}
.fmt-btn:hover{border-color:#6366f1}.fmt-btn.selected{background:#6366f1;color:#fff;border-color:#6366f1}
/* Quick */
.quick-row{display:flex;flex-wrap:wrap;gap:8px;justify-content:center;margin-bottom:20px}
.quick-btn{padding:8px 16px;border-radius:20px;border:1px solid #e5e3de;background:#fff;font-size:13px;cursor:pointer;transition:all .15s}
.quick-btn:hover{border-color:#6366f1;background:#eef2ff}
/* Auto Skill */
.auto-skill-toggle{display:flex;align-items:center;gap:8px;margin-bottom:12px;padding:8px 14px;background:#f8f7ff;border:2px solid #e5e3de;border-radius:12px;cursor:pointer;transition:all .15s;user-select:none}
.auto-skill-toggle:hover{border-color:#6366f1}
.auto-skill-toggle.on{border-color:#6366f1;background:#eef2ff}
.auto-skill-toggle .toggle-dot{width:36px;height:20px;border-radius:10px;background:#ccc;position:relative;transition:all .2s}
.auto-skill-toggle.on .toggle-dot{background:#6366f1}
.auto-skill-toggle .toggle-dot::after{content:'';position:absolute;top:2px;left:2px;width:16px;height:16px;border-radius:50%;background:#fff;transition:all .2s}
.auto-skill-toggle.on .toggle-dot::after{left:18px}
.auto-skill-badge{display:inline-block;padding:2px 8px;border-radius:10px;font-size:11px;background:#eef2ff;color:#6366f1;border:1px solid #c7d2fe;margin:2px}
.auto-skill-preview{padding:6px 10px;background:#f0fdf4;border-bottom:1px solid #a7f3d0;font-size:11px;display:none}
.auto-skill-preview.show{display:block}
/* PPT Suggest Banner */
.ppt-suggest-banner{position:relative;margin:0 auto 8px;max-width:760px;padding:14px 18px 14px 50px;background:linear-gradient(135deg,#eef2ff 0%,#f5f3ff 50%,#fdf2f8 100%);border:1px solid #c7d2fe;border-radius:14px;box-shadow:0 2px 12px rgba(99,102,241,.12);overflow:hidden;animation:pptBannerSlide .5s cubic-bezier(.16,1,.3,1);cursor:default;transition:opacity .4s,transform .4s}
.ppt-suggest-banner.hiding{opacity:0;transform:translateY(-12px)}
.ppt-suggest-banner .ppt-banner-icon{position:absolute;left:14px;top:50%;transform:translateY(-50%);font-size:22px;animation:pptIconPulse 2s ease-in-out infinite}
.ppt-suggest-banner .ppt-banner-title{font-size:13px;font-weight:700;color:#4338ca;margin-bottom:4px}
.ppt-suggest-banner .ppt-banner-hint{font-size:12px;color:#6b7280;line-height:1.5}
.ppt-suggest-banner .ppt-banner-hint em{font-style:normal;color:#6366f1;font-weight:600;cursor:pointer;border-bottom:1px dashed #a5b4fc;transition:color .2s}
.ppt-suggest-banner .ppt-banner-hint em:hover{color:#4338ca}
.ppt-suggest-banner .ppt-banner-close{position:absolute;top:6px;right:10px;background:none;border:none;font-size:14px;color:#a5b4fc;cursor:pointer;padding:2px 6px;border-radius:4px;transition:all .2s}
.ppt-suggest-banner .ppt-banner-close:hover{background:#e0e7ff;color:#4338ca}
@keyframes pptBannerSlide{from{opacity:0;transform:translateY(-20px)}to{opacity:1;transform:translateY(0)}}
@keyframes pptIconPulse{0%,100%{transform:translateY(-50%) scale(1)}50%{transform:translateY(-50%) scale(1.15)}}
/* Messages */
.messages{margin-top:8px}
.msg{margin-bottom:8px;padding:8px 12px;border-radius:10px;line-height:1.5;font-size:13px;word-wrap:break-word;position:relative}
.msg.user{background:#6366f1;color:#fff;margin-left:120px;border-bottom-right-radius:4px;white-space:pre-wrap}
.msg.assistant{background:#fff;border:1px solid #e5e3de;margin-right:120px;border-bottom-left-radius:4px}
.msg pre{background:#f5f5f0;padding:8px;border-radius:6px;overflow-x:auto;margin:4px 0;font-size:12px;white-space:pre-wrap}
.msg code{font-family:'SF Mono','Fira Code',monospace;font-size:12px}
.msg p{margin:0 0 4px 0}.msg p:last-child{margin-bottom:0}
.msg h1,.msg h2,.msg h3,.msg h4{margin:8px 0 4px 0;font-weight:700}
.msg h1{font-size:1.2em;border-bottom:1px solid #e5e3de;padding-bottom:2px}
.msg h2{font-size:1.1em;border-bottom:1px solid #eee;padding-bottom:2px}
.msg h3{font-size:1em}.msg h4{font-size:.95em}
.msg ul,.msg ol{margin:4px 0 4px 16px;padding:0}.msg li{margin:1px 0}
.msg table{border-collapse:collapse;margin:4px 0;width:100%;font-size:12px}
.msg th,.msg td{border:1px solid #ddd;padding:4px 8px;text-align:left}
.msg th{background:#f5f5f0;font-weight:600}
.msg tr:nth-child(even){background:#fafaf8}
.msg hr{border:none;border-top:1px solid #e5e3de;margin:6px 0}
.msg blockquote{border-left:3px solid #6366f1;margin:4px 0;padding:2px 8px;color:#666;background:#fafaf8;border-radius:0 6px 6px 0}
.msg-label{font-size:10px;font-weight:600;color:#999;margin-bottom:3px;text-transform:uppercase;letter-spacing:.5px}
/* 피드백 버튼 */
.msg-del{position:absolute;top:6px;right:6px;background:rgba(255,255,255,.8);border:1px solid #ddd;color:#aaa;cursor:pointer;font-size:10px;padding:1px 6px;border-radius:4px;opacity:0;transition:opacity .15s;z-index:5}
.msg:hover .msg-del{opacity:1}
.msg-del:hover{color:#ef4444;border-color:#ef4444;background:#fef2f2}
.msg-feedback{display:flex;gap:4px;margin-top:6px;justify-content:flex-end}
.msg-feedback button{background:none;border:1px solid #e0e0e0;border-radius:6px;padding:3px 10px;font-size:14px;cursor:pointer;color:#999;transition:all .2s;line-height:1}
.msg-feedback button:hover{background:#f5f5f0;color:#333;border-color:#ccc}
.msg-feedback button.fb-selected-good{background:#e8f5e9;color:#2e7d32;border-color:#81c784}
.msg-feedback button.fb-selected-bad{background:#fce4ec;color:#c62828;border-color:#ef9a9a}
/* 피드백 모달 */
#feedbackModal{display:none;position:fixed;top:0;left:0;width:100%;height:100%;z-index:10000;background:rgba(0,0,0,.5);align-items:center;justify-content:center}
#feedbackModal.show{display:flex}
.fb-modal{background:#fff;border-radius:14px;padding:28px;width:420px;max-width:90vw;box-shadow:0 20px 60px rgba(0,0,0,.3);animation:fbSlideIn .25s ease}
@keyframes fbSlideIn{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}
.fb-modal h3{margin:0 0 6px;font-size:18px;color:#333}
.fb-modal .fb-rating-display{font-size:24px;margin-bottom:12px}
.fb-modal textarea{width:100%;height:100px;border:1.5px solid #ddd;border-radius:10px;padding:10px 12px;font-size:13px;resize:vertical;font-family:inherit;transition:border-color .2s}
.fb-modal textarea:focus{outline:none;border-color:#6366f1}
.fb-modal .fb-hint{font-size:11px;color:#999;margin-top:4px}
.fb-modal .fb-actions{display:flex;gap:8px;margin-top:16px;justify-content:flex-end}
.fb-modal .fb-btn{padding:8px 20px;border-radius:8px;border:none;font-size:13px;font-weight:600;cursor:pointer;transition:all .2s}
.fb-modal .fb-btn-cancel{background:#f0f0f0;color:#666}.fb-modal .fb-btn-cancel:hover{background:#e0e0e0}
.fb-modal .fb-btn-submit{background:#6366f1;color:#fff}.fb-modal .fb-btn-submit:hover{background:#4f46e5}
.msg.user .msg-label{color:rgba(255,255,255,.7)}
.msg .skill-info{font-size:10px;color:#6366f1;margin-top:4px}
.typing{display:inline-flex;gap:4px;padding:8px 14px}
.typing span{width:8px;height:8px;border-radius:50%;background:#ccc;animation:blink 1.4s infinite both}
.typing span:nth-child(2){animation-delay:.2s}.typing span:nth-child(3){animation-delay:.4s}
@keyframes blink{0%,80%,100%{opacity:.3}40%{opacity:1}}
/* Modal */
.modal-bg{position:fixed;inset:0;background:rgba(0,0,0,.4);z-index:100;display:flex;align-items:center;justify-content:center}
.modal-bg.hidden{display:none}
.modal{background:#fff;border-radius:16px;padding:28px;width:500px;max-width:90vw;box-shadow:0 20px 60px rgba(0,0,0,.15)}
.modal h2{font-size:18px;margin-bottom:16px}
.modal label{font-size:13px;font-weight:600;color:#555;display:block;margin-bottom:4px;margin-top:12px}
.modal input{width:100%;padding:10px 12px;border:1px solid #e5e3de;border-radius:8px;font-size:14px;outline:none;font-family:inherit}
.modal input:focus{border-color:#6366f1}
.modal-btns{display:flex;justify-content:flex-end;gap:8px;margin-top:20px}
.modal-btns button{padding:10px 20px;border-radius:8px;border:none;font-size:14px;cursor:pointer}
.btn-ok{background:#6366f1;color:#fff}.btn-ok:hover{background:#4f46e5}
.btn-cancel{background:#f3f2ef;color:#555}
.settings-btn{background:none;border:none;cursor:pointer;font-size:20px;color:#999;padding:4px 8px;border-radius:6px}
.settings-btn:hover{background:#f3f2ef;color:#555}
.status{font-size:12px}
.status.on{color:#10b981}.status.off{color:#999}
/* Env selector */
.env-section{margin-bottom:6px}
.env-section-label{font-size:11px;font-weight:700;color:#6b7280;margin-bottom:3px;padding-left:4px}
.env-toggle{cursor:pointer;user-select:none;padding:6px 8px;border-radius:8px;transition:background .15s}
.env-toggle:hover{background:#f3f4f6}
.env-subsection-label{font-size:10px;color:#9ca3af;margin:3px 0 2px 4px}
.env-row{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:6px}
.env-btn{flex:1 1 90px;max-width:130px;padding:8px 6px;border-radius:10px;border:2px solid #e5e3de;background:#fff;cursor:pointer;text-align:center;transition:all .15s;font-size:11px}
.env-btn:hover{border-color:#6366f1;transform:translateY(-1px)}
.env-btn.selected{border-color:#6366f1;background:#eef2ff}
.env-btn .env-name{font-weight:700;font-size:12px;margin-bottom:1px}
.env-btn .env-model{font-size:10px;color:#888}
.env-btn.selected .env-model{color:#6366f1}
.uio-enter-btn{display:inline-flex;align-items:center;gap:4px;padding:4px 12px;border-radius:8px;font-size:12px;font-weight:600;color:#fff;background:linear-gradient(135deg,#6366f1,#8b5cf6);text-decoration:none;cursor:pointer;transition:all .2s;border:none;box-shadow:0 2px 8px rgba(99,102,241,.3)}
.uio-enter-btn:hover{transform:translateY(-1px);box-shadow:0 4px 12px rgba(99,102,241,.5);background:linear-gradient(135deg,#818cf8,#a78bfa)}
.token-status{font-size:12px;padding:8px 12px;border-radius:8px;margin-bottom:16px}
.token-status.ok{background:#ecfdf5;color:#059669}
.token-status.missing{background:#fef2f2;color:#dc2626}
/* System Prompt */
.sysprompt-section{margin-bottom:24px}
.sysprompt-toggle{display:flex;align-items:center;gap:8px;cursor:pointer;margin-bottom:8px}
.sysprompt-toggle .arrow{font-size:12px;transition:transform .2s;color:#999}
.sysprompt-toggle .arrow.open{transform:rotate(90deg)}
.sysprompt-body{display:none}
.sysprompt-body.show{display:block}
.sysprompt-textarea{width:100%;border:1px solid #e5e3de;border-radius:10px;padding:12px;font-size:13px;resize:vertical;min-height:80px;max-height:300px;font-family:'SF Mono','Fira Code',monospace;line-height:1.5;outline:none;background:#fafaf8}
.sysprompt-textarea:focus{border-color:#6366f1;background:#fff}
.sysprompt-info{font-size:11px;color:#999;margin-top:4px}
.prompt-chip{display:inline-flex;align-items:center;gap:3px;padding:3px 10px;border-radius:12px;font-size:11px;cursor:pointer;border:1px solid #e5e3de;background:#fafaf8;transition:all .15s;white-space:nowrap}
.prompt-chip:hover{background:#eef2ff;border-color:#6366f1}
.prompt-chip.active{background:#6366f1;color:#fff;border-color:#6366f1}
.prompt-chip.saved{border-color:#f59e0b;background:#fffbeb}
.prompt-chip.saved:hover{background:#fef3c7}
.prompt-chip.saved.active{background:#f59e0b;color:#fff}
.sysprompt-preview{font-size:11px;color:#6366f1;background:#eef2ff;padding:6px 10px;border-radius:6px;margin-top:6px;max-height:60px;overflow:hidden;cursor:pointer}
.sysprompt-preview:hover{max-height:200px;overflow-y:auto}
/* PPT 생성 블록 */
.pptx-gen-block{background:#f8f7ff;border:2px solid #a5b4fc;border-radius:12px;margin:12px 0;overflow:hidden}
.pptx-gen-header{display:flex;justify-content:space-between;align-items:center;padding:8px 14px;background:#eef2ff;border-bottom:1px solid #a5b4fc}
.pptx-gen-header span{font-weight:600;font-size:13px;color:#4338ca}
.pptx-gen-actions{display:flex;gap:6px;align-items:center}
.pptx-gen-btn{background:#6366f1;color:#fff;border:none;border-radius:6px;padding:6px 14px;font-size:12px;cursor:pointer;transition:all .2s;font-weight:600}
.pptx-gen-btn:hover{background:#4f46e5;transform:translateY(-1px)}
.pptx-gen-btn:disabled{background:#d1d5db;cursor:not-allowed;transform:none}
.pptx-gen-btn.secondary{background:#e0e7ff;color:#4338ca}
.pptx-gen-btn.secondary:hover{background:#c7d2fe}
.pptx-gen-status{font-size:11px;color:#6b7280}
.pptx-remake-bar{display:flex;align-items:center;gap:6px;padding:8px 12px;background:#f8fafc;border-top:1px solid #e5e7eb;border-radius:0 0 10px 10px;flex-wrap:wrap}
.pptx-remake-label{font-size:11px;color:#6b7280;font-weight:600;white-space:nowrap}
.pptx-remake-btn{background:#fff;color:#4338ca;border:1px solid #c7d2fe;border-radius:16px;padding:4px 12px;font-size:11px;cursor:pointer;transition:all .2s;font-weight:500;white-space:nowrap}
.pptx-remake-btn:hover{background:#eef2ff;border-color:#818cf8;transform:translateY(-1px)}
/* PPT 스타일 드롭다운 */
.ppt-style-drop{display:none}
.ppt-ref-badge{display:inline-flex;align-items:center;gap:3px;padding:2px 8px;border-radius:10px;background:#fef3c7;color:#92400e;font-size:10px;font-weight:600;margin-left:4px}
/* CSV Upload */
.csv-section{margin-bottom:24px}
/* csv-upload-area 제거됨 → 채팅 📎 첨부로 대체 */
.csv-upload-area .icon{font-size:28px;margin-bottom:6px}
.csv-upload-area .label{font-size:13px;color:#888}
.csv-upload-area .sub{font-size:11px;color:#bbb;margin-top:2px}
.csv-info{background:#fff;border:2px solid #10b981;border-radius:12px;padding:14px 18px;position:relative}
.csv-info .fname{font-weight:700;font-size:14px;color:#059669}
.csv-info .fstats{font-size:12px;color:#666;margin-top:4px}
.csv-info .fremove{position:absolute;top:10px;right:12px;background:#fee2e2;color:#dc2626;border:none;border-radius:6px;padding:4px 10px;font-size:11px;cursor:pointer}
.csv-info .fremove:hover{background:#fca5a5}
.csv-preview{margin-top:8px;max-height:160px;overflow:auto;font-size:11px;background:#f9fafb;border-radius:8px;padding:8px}
.csv-preview table{border-collapse:collapse;width:100%}
.csv-preview th,.csv-preview td{border:1px solid #e5e7eb;padding:3px 8px;text-align:left;white-space:nowrap}
.csv-preview th{background:#f3f4f6;font-weight:600;position:sticky;top:0}
/* Skill Detail Panel */
.skill-detail-overlay{position:fixed;inset:0;background:rgba(0,0,0,.4);z-index:200;display:flex;align-items:center;justify-content:center}
.skill-detail-panel{background:#fff;border-radius:16px;width:720px;max-width:92vw;max-height:85vh;display:flex;flex-direction:column;box-shadow:0 20px 60px rgba(0,0,0,.2)}
.sdp-header{padding:18px 24px;border-bottom:1px solid #e5e3de;display:flex;justify-content:space-between;align-items:center}
.sdp-header h2{font-size:18px;margin:0}.sdp-close{background:none;border:none;font-size:22px;cursor:pointer;color:#999;padding:4px 8px}
.sdp-close:hover{color:#333}
.sdp-tabs{display:flex;border-bottom:1px solid #e5e3de;padding:0 24px}
.sdp-tab{padding:10px 18px;font-size:13px;font-weight:600;cursor:pointer;border-bottom:3px solid transparent;color:#888;transition:all .15s}
.sdp-tab:hover{color:#333}.sdp-tab.active{color:#6366f1;border-bottom-color:#6366f1}
.sdp-body{flex:1;overflow-y:auto;padding:18px 24px}
.sdp-file-list{list-style:none;padding:0}
.sdp-file-item{display:flex;align-items:center;gap:10px;padding:10px 14px;border:1px solid #e5e3de;border-radius:10px;margin-bottom:6px;transition:all .15s;cursor:pointer}
.sdp-file-item:hover{border-color:#6366f1;background:#f8f7ff}
.sdp-file-icon{font-size:18px}
.sdp-file-name{font-weight:600;font-size:13px;flex:1}
.sdp-file-size{font-size:11px;color:#999}
.sdp-file-actions{display:flex;gap:4px}
.sdp-btn{padding:4px 12px;border-radius:6px;border:1px solid #e5e3de;font-size:11px;cursor:pointer;background:#fff;transition:all .15s}
.sdp-btn:hover{border-color:#6366f1;background:#eef2ff}
.sdp-btn.run{background:#10b981;color:#fff;border-color:#10b981}.sdp-btn.run:hover{background:#059669}
.sdp-btn.inject{background:#6366f1;color:#fff;border-color:#6366f1}.sdp-btn.inject:hover{background:#4f46e5}
.sdp-code{background:#1e1e1e;color:#d4d4d4;padding:14px;border-radius:10px;font-family:'SF Mono','Fira Code',monospace;font-size:12px;line-height:1.5;overflow:auto;max-height:400px;white-space:pre-wrap;word-break:break-all}
.sdp-result{margin-top:12px;padding:12px;border-radius:10px;font-family:monospace;font-size:12px;line-height:1.4;overflow:auto;max-height:300px;white-space:pre-wrap}
.sdp-result.ok{background:#ecfdf5;border:1px solid #a7f3d0}.sdp-result.err{background:#fef2f2;border:1px solid #fca5a5}
.skill-card .extras{font-size:10px;color:#6366f1;margin-top:3px}
/* Copy button */
.copy-btn{position:absolute;top:4px;right:4px;background:#e5e3de;border:none;border-radius:4px;padding:2px 8px;font-size:11px;cursor:pointer;opacity:.7}
.copy-btn:hover{opacity:1}
.drawio-block{border:2px solid #6366f1;border-radius:10px;overflow:hidden;margin:10px 0;background:#fafaff}
.drawio-header{display:flex;justify-content:space-between;align-items:center;padding:8px 12px;background:#eef2ff;border-bottom:1px solid #d4d8f0;flex-wrap:wrap;gap:6px}
.drawio-header span{font-weight:600;font-size:13px;color:#4338ca}
.drawio-actions{display:flex;gap:6px;flex-wrap:wrap}
.drawio-btn{background:#6366f1;color:#fff;border:none;border-radius:6px;padding:4px 10px;font-size:11px;cursor:pointer;transition:background .2s}
.drawio-btn:hover{background:#4f46e5}
.chart-block{border:2px solid #f59e0b;border-radius:10px;overflow:hidden;margin:10px 0;background:#fffbf0}
.chart-header{display:flex;justify-content:space-between;align-items:center;padding:8px 12px;background:#fef3c7;border-bottom:1px solid #fcd34d;flex-wrap:wrap;gap:6px}
.chart-header span{font-weight:600;font-size:13px;color:#92400e}
.chart-actions{display:flex;gap:6px;flex-wrap:wrap}
.chart-btn{background:#f59e0b;color:#fff;border:none;border-radius:6px;padding:4px 10px;font-size:11px;cursor:pointer;transition:background .2s}
.chart-btn:hover{background:#d97706}
.chart-canvas-wrap{padding:12px;background:#fff;display:flex;justify-content:center;align-items:center;min-height:250px;max-height:450px}
.chart-canvas-wrap canvas{max-width:100%;max-height:420px}
.chart-raw-toggle{padding:0 12px 8px}
.chart-raw-toggle summary{font-size:11px;color:#999;cursor:pointer}
.chart-raw-toggle pre{font-size:10px;max-height:120px;overflow:auto;background:#f5f5f0;padding:8px;border-radius:6px;margin-top:4px}
.md-report-block{background:#f8faf8;border:2px solid #86efac;border-radius:12px;margin:12px 0;overflow:hidden}
.md-report-header{display:flex;justify-content:space-between;align-items:center;padding:8px 14px;background:#ecfdf5;border-bottom:1px solid #86efac}
.md-report-header span{font-weight:600;font-size:13px;color:#166534}
.md-report-actions{display:flex;gap:6px}
.md-report-btn{background:#22c55e;color:#fff;border:none;border-radius:6px;padding:4px 10px;font-size:11px;cursor:pointer;transition:background .2s}
.md-report-btn:hover{background:#16a34a}
.md-report-btn.md-download{background:#6366f1}.md-report-btn.md-download:hover{background:#4f46e5}
.md-report-preview{padding:14px 18px;font-size:13px;line-height:1.7;max-height:500px;overflow-y:auto}
.md-report-preview h1{font-size:20px;margin:12px 0 8px;border-bottom:2px solid #e5e7eb;padding-bottom:4px}
.md-report-preview h2{font-size:17px;margin:10px 0 6px;color:#374151}
.md-report-preview h3{font-size:15px;margin:8px 0 4px;color:#4b5563}
.md-report-preview table{border-collapse:collapse;width:100%;margin:8px 0}
.md-report-preview th,.md-report-preview td{border:1px solid #d1d5db;padding:4px 8px;font-size:12px;text-align:left}
.md-report-preview th{background:#f3f4f6;font-weight:600}
.md-report-preview pre{background:#1e1e2e;color:#cdd6f4;padding:10px;border-radius:8px;overflow-x:auto;font-size:12px}
.md-report-preview blockquote{border-left:3px solid #6366f1;padding-left:12px;color:#6b7280;margin:8px 0}
.md-raw-toggle{margin:0;padding:4px 14px 8px}
.md-raw-toggle summary{font-size:11px;color:#9ca3af;cursor:pointer}
.md-raw-toggle pre{max-height:300px;overflow:auto;font-size:11px;margin-top:6px}
.drawio-preview{max-height:200px;overflow:auto;margin:0;border-radius:0;border:none;font-size:11px}
.drawio-preview code{font-size:11px}
.send-btn.stop-mode{background:#e74c3c;animation:pulse-stop 1.2s infinite}
@keyframes pulse-stop{0%,100%{opacity:1}50%{opacity:.7}}
.sidebar-file-panel{margin-top:auto;padding:8px 8px 0;border-top:1px solid #e5e3de;max-height:220px;overflow-y:auto}
.uploaded-files-header{font-size:11px;font-weight:600;color:#555;padding:4px 0;border-bottom:1px solid #eee;margin-bottom:2px;display:flex;align-items:center;justify-content:space-between}
.uploaded-file-item{display:flex;align-items:center;gap:4px;padding:3px 2px;border-bottom:1px solid #f0f0f0;font-size:11px}
.ufi-icon{font-size:14px;flex-shrink:0}
.ufi-name{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#333;cursor:help}
.ufi-size{color:#999;font-size:10px;flex-shrink:0}
.ufi-remove{background:none;border:none;color:#ccc;cursor:pointer;font-size:12px;padding:0 2px}
.ufi-remove:hover{color:#e74c3c}
.ufi-pending{opacity:.6}
.ufi-drm{opacity:.7;border-left:2px solid #e67e22;padding-left:4px}
.ufi-drm .ufi-name{color:#e67e22}
.think-box{margin:8px 0 12px;border:1px solid #d4c8f0;border-radius:8px;background:#f8f5ff;overflow:hidden}
.think-box summary{cursor:pointer;padding:8px 12px;font-size:12px;font-weight:600;color:#7c5cbf;background:#f0ebfa;user-select:none}
.think-box summary:hover{background:#e8e0f6}
.think-box[open] summary{border-bottom:1px solid #d4c8f0}
.think-content{padding:10px 14px;font-size:12px;color:#555;line-height:1.6;max-height:400px;overflow-y:auto}
pre{position:relative}
/* ===== 오른쪽 코드 어시스턴트 패널 ===== */
.right-panel{width:340px;background:#fff;border-left:1px solid #e5e3de;display:flex;flex-direction:column;overflow:hidden;transition:width .2s ease;flex-shrink:0}
.right-panel.collapsed{width:0;border-left:none;overflow:hidden}
.right-panel-toggle{position:fixed;top:12px;right:340px;width:28px;height:28px;border-radius:6px 0 0 6px;border:1px solid #e5e3de;border-right:none;background:#fff;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:12px;color:#999;z-index:200;transition:right .2s ease}
.right-panel-toggle:hover{background:#eef2ff;color:#6366f1}
body.rp-collapsed .right-panel-toggle{right:0}
body.rp-collapsed .chat-box-fixed{right:0}
.rp-header{padding:14px 16px;border-bottom:1px solid #e5e3de;display:flex;align-items:center;justify-content:space-between}
.rp-header h3{margin:0;font-size:15px;font-weight:700;color:#1a1a1a}
.rp-body{flex:1;overflow-y:auto;padding:12px 14px}
.rp-section{margin-bottom:16px}
.rp-section-title{font-size:11px;font-weight:600;color:#999;text-transform:uppercase;letter-spacing:.5px;margin-bottom:8px}
.rp-file-drop{border:2px dashed #d1d5db;border-radius:10px;padding:24px 16px;text-align:center;cursor:pointer;transition:all .15s;background:#fafaf9;margin-bottom:12px}
.rp-file-drop:hover,.rp-file-drop.dragover{border-color:#6366f1;background:#eef2ff}
.rp-file-drop-icon{font-size:28px;margin-bottom:6px}
.rp-file-drop-text{font-size:12px;color:#888}
.rp-file-list{max-height:120px;overflow-y:auto;margin-bottom:8px}
.rp-file-item{display:flex;align-items:center;gap:6px;padding:5px 8px;background:#f8f7f4;border-radius:6px;margin-bottom:4px;font-size:12px}
.rp-file-item .fname{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#333}
.rp-file-item .fsize{color:#aaa;font-size:11px;flex-shrink:0}
.rp-file-item .fremove{background:none;border:none;cursor:pointer;color:#ef4444;font-size:12px;padding:0 2px}
.rp-action-grid{display:grid;grid-template-columns:1fr 1fr;gap:6px}
.rp-action-btn{padding:10px 8px;border-radius:8px;border:1px solid #e5e3de;background:#fff;cursor:pointer;text-align:center;transition:all .15s;font-size:12px}
.rp-action-btn:hover{border-color:#6366f1;background:#eef2ff}
.rp-action-btn.active{border-color:#6366f1;background:#6366f1;color:#fff}
.rp-action-btn .rp-btn-icon{font-size:18px;display:block;margin-bottom:3px}
.rp-action-btn .rp-btn-label{font-weight:600}
.rp-run-btn{width:100%;padding:10px;border-radius:8px;border:none;background:#6366f1;color:#fff;font-size:14px;font-weight:700;cursor:pointer;margin-top:10px;transition:background .15s}
.rp-run-btn:hover{background:#4f46e5}
.rp-run-btn:disabled{background:#d1d5db;cursor:not-allowed}
.rp-result{margin-top:12px;padding:16px;background:#1e1e2e;color:#cdd6f4;border-radius:10px;font-size:13px;line-height:1.7;overflow-y:auto;display:none}
.rp-result.expanded{max-height:none;position:fixed;top:8px;right:8px;bottom:8px;width:calc(var(--rp-width, 340px) - 16px);z-index:1100;box-shadow:0 8px 32px rgba(0,0,0,.4)}
.rp-result h1,.rp-result h2,.rp-result h3{color:#cba6f7;margin:12px 0 6px}
.rp-result h1{font-size:16px} .rp-result h2{font-size:14px} .rp-result h3{font-size:13px}
.rp-result pre{background:#181825;border-radius:6px;padding:10px;overflow-x:auto;margin:8px 0}
.rp-result code{font-family:'Fira Code',monospace;font-size:12px}
.rp-result p{margin:6px 0}
.rp-result ul,.rp-result ol{padding-left:20px;margin:6px 0}
.rp-result table{border-collapse:collapse;width:100%;margin:8px 0;font-size:12px}
.rp-result th,.rp-result td{border:1px solid #45475a;padding:6px 8px;text-align:left}
.rp-result th{background:#313244;color:#cba6f7}
.rp-result-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;padding-bottom:8px;border-bottom:1px solid #45475a}
.rp-result-header .rp-result-title{font-weight:700;color:#a6e3a1;font-size:14px}
.rp-result-header button{background:none;border:1px solid #45475a;color:#cdd6f4;border-radius:6px;padding:4px 10px;cursor:pointer;font-size:12px}
.rp-result-header button:hover{background:#313244}
.rp-skill-badge{display:inline-block;padding:2px 8px;border-radius:10px;font-size:10px;font-weight:600;background:#eef2ff;color:#6366f1;margin-left:6px}
.rp-model-row{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:8px}
.rp-model-btn{flex:1;min-width:70px;padding:6px 8px;border:1.5px solid #e5e7eb;border-radius:8px;background:#fff;cursor:pointer;font-size:11px;font-weight:600;color:#6b7280;transition:all 0.15s;text-align:center}
.rp-model-btn:hover{border-color:#6366f1;color:#4f46e5}
.rp-model-btn.active{background:#eef2ff;border-color:#6366f1;color:#4f46e5}
.rp-model-btn .icon{font-size:14px;display:block;margin-bottom:2px}
.rp-tree{font-size:12px;max-height:250px;overflow-y:auto;border:1px solid #e5e3de;border-radius:8px;padding:8px;background:#fafaf9;margin-bottom:8px}
.rp-tree-node{padding:2px 0;cursor:pointer;user-select:none;display:flex;align-items:center;gap:2px}
.rp-tree-cb{width:14px;height:14px;cursor:pointer;accent-color:#6366f1;flex-shrink:0}
.rp-select-bar{display:flex;gap:6px;margin-bottom:6px;align-items:center}
.rp-select-btn{background:none;border:1px solid #d1d5db;border-radius:4px;padding:2px 8px;font-size:10px;cursor:pointer;color:#666}
.rp-select-btn:hover{border-color:#6366f1;color:#6366f1}
.rp-checked-count{font-size:11px;color:#6366f1;font-weight:600}
.rp-tree-node:hover{background:#eef2ff;border-radius:4px}
.rp-tree-node-content{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.rp-tree-folder{font-weight:600;color:#555}
.rp-tree-file{color:#333}
.rp-tree-file.active{background:#6366f1;color:#fff;border-radius:4px;padding:1px 4px}
.rp-tree-children{padding-left:16px;border-left:1px solid #e5e3de;margin-left:6px}
.rp-tree-toggle{display:inline-block;width:14px;font-size:10px;color:#999;text-align:center}
.rp-tree-icon{margin-right:4px}
.rp-tree-stats{font-size:11px;color:#888;padding:6px 8px;background:#f0f0ed;border-radius:6px;margin-bottom:8px;display:flex;justify-content:space-between}
.rp-tab-row{display:flex;gap:4px;margin-bottom:8px}
.rp-tab{padding:4px 10px;border-radius:6px;border:1px solid #e5e3de;background:#fff;cursor:pointer;font-size:11px;font-weight:600;color:#888;transition:all .15s}
.rp-tab:hover{border-color:#6366f1;color:#6366f1}
.rp-tab.active{background:#6366f1;color:#fff;border-color:#6366f1}
@media(max-width:768px){.sidebar{display:none}.sidebar-toggle{display:none}.right-panel{display:none}.right-panel-toggle{display:none}.chat-box-fixed{left:0;right:0}.style-row{flex-direction:column}.msg.user{margin-left:16px}.msg.assistant{margin-right:16px}.msg{font-size:12px}}
/* 인트로 비디오 오버레이 */
/* 인트로 제거됨 */
#introVideo{width:100%;height:100%;object-fit:cover}
#introSkip{position:absolute;bottom:40px;right:40px;background:rgba(255,255,255,.15);backdrop-filter:blur(8px);border:1px solid rgba(255,255,255,.3);color:#fff;padding:10px 24px;border-radius:24px;font-size:14px;cursor:pointer;transition:all .2s;z-index:10000}
#introSkip:hover{background:rgba(255,255,255,.3)}
#introProgress{position:absolute;bottom:0;left:0;height:3px;background:linear-gradient(90deg,#6366f1,#a855f7);width:0;transition:width .1s linear}
/* UIO 컨테이너 */
#uioContainer{position:fixed;top:0;left:0;width:100%;height:100%;z-index:9000;display:none;background:#0f151e}
#uioContainer iframe{width:100%;height:100%;border:none}
#uioBackBtn{position:fixed;top:16px;left:16px;z-index:9001;padding:10px 20px;border-radius:10px;border:2px solid rgba(255,255,255,.25);background:rgba(18,27,40,.85);backdrop-filter:blur(8px);color:#fff;font-size:14px;font-weight:600;cursor:pointer;transition:all .2s}
#uioBackBtn:hover{background:rgba(99,102,241,.3);border-color:#6366f1}
</style>
</head>
<body>
<!-- 피드백 모달 -->
<div id="feedbackModal">
  <div class="fb-modal">
    <h3 id="fbModalTitle">피드백</h3>
    <div class="fb-rating-display" id="fbRatingDisplay"></div>
    <textarea id="fbComment" placeholder="어떤 점이 좋았나요? 또는 어떤 점을 개선하면 좋을까요? (선택사항)"></textarea>
    <div class="fb-hint">피드백은 서비스 개선에 활용됩니다</div>
    <div class="fb-actions">
      <button class="fb-btn fb-btn-cancel" onclick="closeFeedbackModal()">취소</button>
      <button class="fb-btn fb-btn-submit" onclick="submitFeedback()">보내기</button>
    </div>
  </div>
</div>

<!-- 인트로 비디오 오버레이 -->
<!-- 인트로 제거됨 - 바로 로그인 -->

<!-- 소개 팝업: /beno/about.html로 분리됨 (openAboutPopup() 함수로 열기) -->
<div id="aboutPopup_removed" style="display:none;">
  <div style="background:linear-gradient(135deg,#0f172a,#1e1b4b);border:1px solid rgba(99,102,241,0.3);border-radius:24px;padding:0;width:90%;max-width:800px;max-height:90vh;overflow-y:auto;box-shadow:0 25px 60px rgba(0,0,0,0.6);scrollbar-width:none;">
    <style>#aboutPopup *::-webkit-scrollbar{display:none}</style>
    <!-- 헤더 -->
    <div style="position:sticky;top:0;background:linear-gradient(135deg,#0f172a,#1e1b4b);padding:24px 32px 16px;border-bottom:1px solid rgba(99,102,241,0.15);z-index:1;display:flex;justify-content:space-between;align-items:center;">
      <div style="display:flex;align-items:center;gap:14px;">
        <div style="width:48px;height:48px;background:linear-gradient(135deg,#6366f1,#a855f7,#ec4899);border-radius:14px;display:flex;align-items:center;justify-content:center;">
          <span style="font-size:22px;color:#fff;font-weight:900;">D</span>
        </div>
        <div>
          <h2 style="margin:0;color:#fff;font-size:22px;font-weight:800;">Demos V1.0</h2>
          <p style="margin:0;color:#64748b;font-size:12px;">AI Scientific Assistant Platform</p>
        </div>
      </div>
      <button onclick="document.getElementById('aboutPopup').style.display='none'" style="background:rgba(255,255,255,0.1);border:none;color:#fff;width:36px;height:36px;border-radius:10px;font-size:18px;cursor:pointer;">✕</button>
    </div>
    <!-- 본문 -->
    <div style="padding:24px 32px 32px;">
      <!-- 소개 배너 -->
      <div style="text-align:center;padding:32px 0;margin-bottom:24px;">
        <h1 style="color:#fff;font-size:32px;font-weight:900;margin:0 0 8px;background:linear-gradient(135deg,#6366f1,#a855f7,#ec4899);-webkit-background-clip:text;-webkit-text-fill-color:transparent;">Next-Gen AI Platform</h1>
        <p style="color:#94a3b8;font-size:15px;margin:0;">355+ 전문 스킬 / 하네스 파이프라인 / 멀티에이전트 시스템</p>
      </div>
      <!-- 핵심 기능 그리드 -->
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px;margin-bottom:28px;">
        <div style="background:rgba(99,102,241,0.08);border:1px solid rgba(99,102,241,0.2);border-radius:16px;padding:20px;">
          <div style="font-size:32px;margin-bottom:10px;">🧬</div>
          <h3 style="color:#fff;font-size:15px;margin:0 0 6px;">355+ 전문 스킬</h3>
          <p style="color:#94a3b8;font-size:12px;margin:0;line-height:1.5;">생물정보학, 화학, 데이터/ML, 금융, 임상의학, 반도체 등 10개+ 도메인을 커버하는 전문 스킬</p>
        </div>
        <div style="background:rgba(34,197,94,0.08);border:1px solid rgba(34,197,94,0.2);border-radius:16px;padding:20px;">
          <div style="font-size:32px;margin-bottom:10px;">🤖</div>
          <h3 style="color:#fff;font-size:15px;margin:0 0 6px;">하네스 파이프라인</h3>
          <p style="color:#94a3b8;font-size:12px;margin:0;line-height:1.5;">Expert Pool 동적 에이전트 선택 + 피드백 루프로 사용할수록 품질 향상</p>
        </div>
        <div style="background:rgba(245,158,11,0.08);border:1px solid rgba(245,158,11,0.2);border-radius:16px;padding:20px;">
          <div style="font-size:32px;margin-bottom:10px;">👔</div>
          <h3 style="color:#fff;font-size:15px;margin:0 0 6px;">CEO 멀티에이전트</h3>
          <p style="color:#94a3b8;font-size:12px;margin:0;line-height:1.5;">병렬 에이전트 실행 + 자체검토 + 크로스리뷰 + CEO 자동 검토/반려/재작업</p>
        </div>
        <div style="background:rgba(168,85,247,0.08);border:1px solid rgba(168,85,247,0.2);border-radius:16px;padding:20px;">
          <div style="font-size:32px;margin-bottom:10px;">📚</div>
          <h3 style="color:#fff;font-size:15px;margin:0 0 6px;">개인 지식 도메인</h3>
          <p style="color:#94a3b8;font-size:12px;margin:0;line-height:1.5;">사용자별 지식 등록/검색. 프론트매터 자동 생성, 카테고리/태그 기반 정확한 검색</p>
        </div>
        <div style="background:rgba(236,72,153,0.08);border:1px solid rgba(236,72,153,0.2);border-radius:16px;padding:20px;">
          <div style="font-size:32px;margin-bottom:10px;">📝</div>
          <h3 style="color:#fff;font-size:15px;margin:0 0 6px;">보고서 자동 생성</h3>
          <p style="color:#94a3b8;font-size:12px;margin:0;line-height:1.5;">PPT / Draw.io / 차트 / MD / HTML 문서 자동 생성 및 다운로드</p>
        </div>
        <div style="background:rgba(14,165,233,0.08);border:1px solid rgba(14,165,233,0.2);border-radius:16px;padding:20px;">
          <div style="font-size:32px;margin-bottom:10px;">🔍</div>
          <h3 style="color:#fff;font-size:15px;margin:0 0 6px;">로그프레소 연동</h3>
          <p style="color:#94a3b8;font-size:12px;margin:0;line-height:1.5;">LPQL 쿼리 자동 생성 + 서버 직접 조회. 자연어로 데이터 검색</p>
        </div>
      </div>
      <!-- 스킬 도메인 -->
      <div style="margin-bottom:28px;">
        <h3 style="color:#fff;font-size:16px;font-weight:700;margin:0 0 14px;">스킬 도메인</h3>
        <div style="display:flex;flex-wrap:wrap;gap:8px;">
          <span style="padding:6px 14px;background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.2);border-radius:20px;color:#fca5a5;font-size:12px;">🧬 생물정보학</span>
          <span style="padding:6px 14px;background:rgba(6,182,212,0.1);border:1px solid rgba(6,182,212,0.2);border-radius:20px;color:#67e8f9;font-size:12px;">⚗️ 화학/신약</span>
          <span style="padding:6px 14px;background:rgba(245,158,11,0.1);border:1px solid rgba(245,158,11,0.2);border-radius:20px;color:#fcd34d;font-size:12px;">📊 데이터/ML</span>
          <span style="padding:6px 14px;background:rgba(139,92,246,0.1);border:1px solid rgba(139,92,246,0.2);border-radius:20px;color:#c4b5fd;font-size:12px;">⚛️ 재료/물리</span>
          <span style="padding:6px 14px;background:rgba(16,185,129,0.1);border:1px solid rgba(16,185,129,0.2);border-radius:20px;color:#6ee7b7;font-size:12px;">💰 금융/경제</span>
          <span style="padding:6px 14px;background:rgba(236,72,153,0.1);border:1px solid rgba(236,72,153,0.2);border-radius:20px;color:#f9a8d4;font-size:12px;">🏥 임상/의학</span>
          <span style="padding:6px 14px;background:rgba(59,130,246,0.1);border:1px solid rgba(59,130,246,0.2);border-radius:20px;color:#93c5fd;font-size:12px;">📝 논문/연구</span>
          <span style="padding:6px 14px;background:rgba(20,184,166,0.1);border:1px solid rgba(20,184,166,0.2);border-radius:20px;color:#5eead4;font-size:12px;">🤖 랩 자동화</span>
          <span style="padding:6px 14px;background:rgba(107,114,128,0.1);border:1px solid rgba(107,114,128,0.2);border-radius:20px;color:#d1d5db;font-size:12px;">🔧 유틸리티</span>
        </div>
      </div>
      <!-- 기술 스택 -->
      <div style="margin-bottom:28px;">
        <h3 style="color:#fff;font-size:16px;font-weight:700;margin:0 0 14px;">기술 스택</h3>
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;">
          <div style="text-align:center;padding:14px;background:rgba(255,255,255,0.03);border-radius:12px;">
            <div style="font-size:24px;margin-bottom:4px;">🐍</div>
            <div style="color:#e2e8f0;font-size:12px;font-weight:600;">Python Flask</div>
          </div>
          <div style="text-align:center;padding:14px;background:rgba(255,255,255,0.03);border-radius:12px;">
            <div style="font-size:24px;margin-bottom:4px;">💻</div>
            <div style="color:#e2e8f0;font-size:12px;font-weight:600;">GGUF Local LLM</div>
          </div>
          <div style="text-align:center;padding:14px;background:rgba(255,255,255,0.03);border-radius:12px;">
            <div style="font-size:24px;margin-bottom:4px;">🔗</div>
            <div style="color:#e2e8f0;font-size:12px;font-weight:600;">Multi-API</div>
          </div>
        </div>
      </div>
      <!-- 하단 -->
      <div style="text-align:center;padding-top:16px;border-top:1px solid rgba(255,255,255,0.05);">
        <p style="color:#475569;font-size:12px;margin:0;">&copy; 2026 Demos Platform &middot; Harness Integrated &middot; Built with Claude Opus 4.6</p>
      </div>
    </div>
  </div>
</div>

<!-- 로그인 오버레이 -->
<div id="loginOverlay" style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;z-index:9998;background:linear-gradient(135deg,#0f172a 0%,#1e1b4b 50%,#0f172a 100%);align-items:center;justify-content:center;overflow:hidden;">
  <!-- 배경 애니메이션 -->
  <div style="position:absolute;top:0;left:0;width:100%;height:100%;overflow:hidden;pointer-events:none;">
    <div style="position:absolute;top:20%;left:10%;width:300px;height:300px;background:radial-gradient(circle,rgba(99,102,241,0.15) 0%,transparent 70%);border-radius:50%;animation:loginFloat 8s ease-in-out infinite;"></div>
    <div style="position:absolute;bottom:20%;right:10%;width:400px;height:400px;background:radial-gradient(circle,rgba(168,85,247,0.1) 0%,transparent 70%);border-radius:50%;animation:loginFloat 10s ease-in-out infinite reverse;"></div>
    <div style="position:absolute;top:50%;left:50%;width:200px;height:200px;background:radial-gradient(circle,rgba(34,197,94,0.08) 0%,transparent 70%);border-radius:50%;animation:loginFloat 6s ease-in-out infinite 2s;"></div>
  </div>
  <style>
    @keyframes loginFloat{0%,100%{transform:translateY(0) scale(1)}50%{transform:translateY(-30px) scale(1.05)}}
    @keyframes loginPulse{0%,100%{box-shadow:0 0 20px rgba(99,102,241,0.3)}50%{box-shadow:0 0 40px rgba(99,102,241,0.5)}}
    @keyframes loginOrbit{0%{transform:rotate(0deg) translateX(180px) rotate(0deg)}100%{transform:rotate(360deg) translateX(180px) rotate(-360deg)}}
    @keyframes loginOrbit2{0%{transform:rotate(0deg) translateX(250px) rotate(0deg)}100%{transform:rotate(-360deg) translateX(250px) rotate(360deg)}}
    @keyframes loginSpin{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}
    @keyframes loginFadeSlide{0%{opacity:0;transform:translateY(20px)}100%{opacity:1;transform:translateY(0)}}
    @keyframes loginTyping{0%,100%{opacity:.3}50%{opacity:1}}
    @keyframes loginLine{0%{transform:translateX(-100%)}100%{transform:translateX(200%)}}
    @keyframes starTwinkle{0%,100%{opacity:.2;transform:scale(.8)}50%{opacity:1;transform:scale(1.2)}}
    #loginOverlay input:focus{border-color:#6366f1!important;box-shadow:0 0 0 3px rgba(99,102,241,0.15)}
    .login-card{animation:loginFadeSlide .8s ease-out}
    .login-particle{position:absolute;border-radius:50%;pointer-events:none}
    .login-star{position:absolute;width:3px;height:3px;background:#fff;border-radius:50%;animation:starTwinkle 2s ease-in-out infinite;pointer-events:none}
    .login-ring{position:absolute;border:1px solid rgba(99,102,241,0.15);border-radius:50%;animation:loginSpin 20s linear infinite;pointer-events:none}
    .login-feature{display:flex;align-items:center;gap:10px;padding:10px 14px;background:rgba(99,102,241,0.06);border:1px solid rgba(99,102,241,0.1);border-radius:10px;margin-bottom:6px;animation:loginFadeSlide .6s ease-out backwards}
    .login-feature:nth-child(1){animation-delay:.2s}.login-feature:nth-child(2){animation-delay:.4s}.login-feature:nth-child(3){animation-delay:.6s}.login-feature:nth-child(4){animation-delay:.8s}
  </style>
  <!-- 별 파티클 -->
  <script>(function(){var o=document.getElementById('loginOverlay');if(!o)return;for(var i=0;i<40;i++){var s=document.createElement('div');s.className='login-star';s.style.left=Math.random()*100+'%';s.style.top=Math.random()*100+'%';s.style.animationDelay=Math.random()*3+'s';s.style.animationDuration=(2+Math.random()*3)+'s';o.querySelector('div').appendChild(s);}})();</script>
  <!-- 궤도 링 -->
  <div class="login-ring" style="width:400px;height:400px;top:50%;left:50%;margin:-200px 0 0 -200px;"></div>
  <div class="login-ring" style="width:600px;height:600px;top:50%;left:50%;margin:-300px 0 0 -300px;animation-direction:reverse;animation-duration:30s;border-color:rgba(168,85,247,0.1);"></div>
  <!-- 궤도 도는 작은 구슬들 -->
  <div style="position:absolute;top:50%;left:50%;width:0;height:0;pointer-events:none;">
    <div style="position:absolute;width:8px;height:8px;background:linear-gradient(135deg,#6366f1,#a855f7);border-radius:50%;box-shadow:0 0 12px #6366f1;animation:loginOrbit 12s linear infinite;"></div>
    <div style="position:absolute;width:6px;height:6px;background:linear-gradient(135deg,#22c55e,#10b981);border-radius:50%;box-shadow:0 0 10px #22c55e;animation:loginOrbit2 18s linear infinite;"></div>
    <div style="position:absolute;width:5px;height:5px;background:linear-gradient(135deg,#f59e0b,#ef4444);border-radius:50%;box-shadow:0 0 8px #f59e0b;animation:loginOrbit 15s linear infinite reverse;"></div>
  </div>
  <div style="position:relative;display:flex;align-items:center;justify-content:center;gap:48px;max-width:900px;width:100%;padding:0 24px;">
  <!-- 왼쪽: 피처 소개 -->
  <div style="flex:1;max-width:360px;display:none;" id="loginFeatures">
    <h2 style="color:#fff;font-size:24px;font-weight:800;margin:0 0 6px;">Welcome</h2>
    <p style="color:#64748b;font-size:13px;margin:0 0 16px;">AI Scientific Assistant Platform</p>
    <button onclick="openAboutPopup()" style="display:inline-flex;align-items:center;gap:6px;padding:10px 24px;background:#fff;border:none;color:#1e1b4b;border-radius:24px;font-size:13px;font-weight:800;cursor:pointer;transition:all .2s;margin-bottom:20px;box-shadow:0 4px 15px rgba(255,255,255,0.2);" onmouseover="this.style.transform='translateY(-2px)';this.style.boxShadow='0 6px 20px rgba(255,255,255,0.3)'" onmouseout="this.style.transform='';this.style.boxShadow='0 4px 15px rgba(255,255,255,0.2)'">✨ 데모스 소개 보기</button>
    <div class="login-feature">
      <span style="font-size:24px;">🧬</span>
      <div><div style="color:#e2e8f0;font-size:13px;font-weight:700;">355+ 전문 스킬</div><div style="color:#64748b;font-size:11px;">과학/개발/AI/인프라/비즈니스</div></div>
    </div>
    <div class="login-feature">
      <span style="font-size:24px;">🤖</span>
      <div><div style="color:#e2e8f0;font-size:13px;font-weight:700;">하네스 파이프라인</div><div style="color:#64748b;font-size:11px;">Expert Pool + 피드백 루프</div></div>
    </div>
    <div class="login-feature">
      <span style="font-size:24px;">📚</span>
      <div><div style="color:#e2e8f0;font-size:13px;font-weight:700;">개인 지식 도메인</div><div style="color:#64748b;font-size:11px;">사용자별 지식 등록/검색</div></div>
    </div>
    <div class="login-feature">
      <span style="font-size:24px;">🔀</span>
      <div><div style="color:#e2e8f0;font-size:13px;font-weight:700;">멀티에이전트 CEO</div><div style="color:#64748b;font-size:11px;">병렬 실행 + LGTM 자동 리뷰</div></div>
    </div>
  </div>
  <!-- 오른쪽: 로그인 카드 -->
  <div style="width:100%;max-width:420px;">
  <script>if(window.innerWidth>768)document.getElementById('loginFeatures').style.display='block';</script>
    <!-- 카드 -->
    <div style="background:rgba(15,23,42,0.8);backdrop-filter:blur(24px);border:1px solid rgba(99,102,241,0.2);border-radius:24px;padding:48px 36px 36px;box-shadow:0 25px 50px rgba(0,0,0,0.5);">
      <!-- 로고 -->
      <div style="text-align:center;margin-bottom:36px;">
        <div style="display:inline-flex;align-items:center;justify-content:center;width:72px;height:72px;background:linear-gradient(135deg,#6366f1,#a855f7,#ec4899);border-radius:20px;margin-bottom:20px;animation:loginPulse 3s ease-in-out infinite;">
          <span style="font-size:32px;color:#fff;font-weight:900;text-shadow:0 2px 8px rgba(0,0,0,0.3);">D</span>
        </div>
        <h1 style="color:#fff;font-size:26px;font-weight:800;margin:0 0 4px;letter-spacing:-0.5px;">Demos V1.0</h1>
        <p style="color:#64748b;font-size:13px;margin:0;">AI Scientific Assistant Platform</p>
        <div style="width:40px;height:3px;background:linear-gradient(90deg,#6366f1,#a855f7);margin:16px auto 0;border-radius:2px;"></div>
      </div>
      <!-- 에러 -->
      <div id="loginError" style="display:none;background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.2);color:#f87171;padding:10px 14px;border-radius:10px;margin-bottom:16px;font-size:13px;text-align:center;"></div>
      <!-- 입력 -->
      <div style="margin-bottom:14px;">
        <label style="display:block;color:#94a3b8;font-size:11px;font-weight:700;margin-bottom:6px;text-transform:uppercase;letter-spacing:1px;">ID</label>
        <div style="position:relative;">
          <span style="position:absolute;left:14px;top:50%;transform:translateY(-50%);color:#475569;font-size:16px;">👤</span>
          <input id="loginId" type="text" placeholder="아이디를 입력하세요" style="width:100%;padding:13px 16px 13px 42px;border:1.5px solid #1e293b;border-radius:12px;background:rgba(30,41,59,0.5);color:#f1f5f9;font-size:14px;box-sizing:border-box;outline:none;transition:all .2s;" onkeydown="if(event.key==='Enter')document.getElementById('loginPw').focus()">
        </div>
      </div>
      <div style="margin-bottom:24px;">
        <label style="display:block;color:#94a3b8;font-size:11px;font-weight:700;margin-bottom:6px;text-transform:uppercase;letter-spacing:1px;">PASSWORD</label>
        <div style="position:relative;">
          <span style="position:absolute;left:14px;top:50%;transform:translateY(-50%);color:#475569;font-size:16px;">🔒</span>
          <input id="loginPw" type="password" placeholder="비밀번호를 입력하세요" style="width:100%;padding:13px 16px 13px 42px;border:1.5px solid #1e293b;border-radius:12px;background:rgba(30,41,59,0.5);color:#f1f5f9;font-size:14px;box-sizing:border-box;outline:none;transition:all .2s;" onkeydown="if(event.key==='Enter')doLogin()">
        </div>
      </div>
      <!-- 버튼 -->
      <button onclick="doLogin()" style="width:100%;padding:14px;background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;border:none;border-radius:12px;font-size:15px;font-weight:700;cursor:pointer;transition:all .2s;box-shadow:0 4px 15px rgba(99,102,241,0.3);" onmouseover="this.style.transform='translateY(-1px)';this.style.boxShadow='0 6px 20px rgba(99,102,241,0.4)'" onmouseout="this.style.transform='';this.style.boxShadow='0 4px 15px rgba(99,102,241,0.3)'">로그인</button>
    </div>
    <!-- 하단 -->
    <p style="text-align:center;margin-top:24px;">
      <button onclick="openAboutPopup()" style="background:none;border:none;color:#6366f1;font-size:12px;cursor:pointer;text-decoration:underline;">소개 페이지</button>
      <span style="color:#334155;font-size:11px;">&middot; &copy; 2026 Demos Platform &middot; Harness Integrated</span>
    </p>
  </div>
  </div>
  </div>
</div>

<!-- ADMIN 사용자 관리 팝업 -->
<div id="adminPopup" style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;z-index:10000;background:rgba(0,0,0,0.7);align-items:center;justify-content:center;">
  <div style="background:#1e1e2e;border:1px solid #333;border-radius:16px;padding:24px;width:480px;max-height:80vh;overflow-y:auto;color:#e2e8f0;">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
      <h3 style="margin:0;color:#f59e0b;">👑 사용자 관리 (ADMIN)</h3>
      <button onclick="closeAdminPopup()" style="background:none;border:none;color:#888;font-size:20px;cursor:pointer;">✕</button>
    </div>
    <div style="background:rgba(99,102,241,0.1);border:1px solid #6366f1;border-radius:10px;padding:14px;margin-bottom:16px;">
      <div style="font-weight:700;margin-bottom:10px;color:#a5b4fc;">➕ 새 사용자 등록</div>
      <div style="display:flex;flex-direction:column;gap:8px;">
        <input id="regName" placeholder="이름" style="padding:8px;border:1px solid #444;border-radius:6px;background:#2a2a3e;color:#fff;font-size:13px;">
        <input id="regId" placeholder="아이디" style="padding:8px;border:1px solid #444;border-radius:6px;background:#2a2a3e;color:#fff;font-size:13px;">
        <input id="regPw" type="password" placeholder="비밀번호" style="padding:8px;border:1px solid #444;border-radius:6px;background:#2a2a3e;color:#fff;font-size:13px;">
        <select id="regRole" style="padding:8px;border:1px solid #444;border-radius:6px;background:#2a2a3e;color:#fff;font-size:13px;">
          <option value="user">일반 사용자</option>
          <option value="admin">관리자</option>
        </select>
        <button onclick="registerUser()" style="padding:10px;background:#6366f1;color:#fff;border:none;border-radius:6px;font-weight:700;cursor:pointer;">등록</button>
      </div>
      <div id="regMsg" style="margin-top:6px;font-size:12px;"></div>
    </div>
    <div style="font-weight:700;margin-bottom:8px;color:#a5b4fc;">📋 등록된 사용자</div>
    <div id="adminUserList"></div>
  </div>
</div>


<!-- 지식 도메인 관리 팝업 -->
<div id="knowledgePopup" style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;z-index:10000;background:rgba(0,0,0,0.7);align-items:center;justify-content:center;">
  <div style="background:#1e1e2e;border:1px solid #333;border-radius:16px;padding:24px;width:560px;max-height:85vh;overflow-y:auto;color:#e2e8f0;">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
      <h3 style="margin:0;color:#22c55e;">📚 내 지식 도메인</h3>
      <button onclick="closeKnowledgePopup()" style="background:none;border:none;color:#888;font-size:20px;cursor:pointer;">✕</button>
    </div>

    <!-- 탭: 파일 업로드 / 수동 입력 -->
    <div style="display:flex;gap:4px;margin-bottom:16px;">
      <button id="kdTabUpload" onclick="switchKdTab('upload')" style="flex:1;padding:8px;background:#6366f1;color:#fff;border:none;border-radius:6px;cursor:pointer;font-weight:600;">📁 파일 업로드</button>
      <button id="kdTabManual" onclick="switchKdTab('manual')" style="flex:1;padding:8px;background:#2a2a3e;color:#888;border:none;border-radius:6px;cursor:pointer;font-weight:600;">✏️ 수동 입력</button>
    </div>

    <!-- 파일 업로드 탭 -->
    <div id="kdUploadTab" style="background:rgba(34,197,94,0.08);border:1px solid rgba(34,197,94,0.3);border-radius:10px;padding:14px;margin-bottom:16px;">
      <div style="text-align:center;padding:20px;border:2px dashed #444;border-radius:8px;cursor:pointer;margin-bottom:10px;" onclick="document.getElementById('kdFileInput').click()" id="kdDropZone">
        <div style="font-size:32px;margin-bottom:8px;">📄</div>
        <div style="color:#94a3b8;font-size:13px;">MD 또는 TXT 파일을 클릭하여 선택</div>
        <div id="kdFileName" style="color:#22c55e;font-size:13px;margin-top:6px;font-weight:600;"></div>
      </div>
      <input type="file" id="kdFileInput" accept=".md,.txt" style="display:none;" onchange="kdFileSelected(this)">
      <button onclick="uploadKdFile()" style="width:100%;padding:10px;background:#22c55e;color:#fff;border:none;border-radius:6px;font-weight:700;cursor:pointer;">📤 업로드 + 프론트매터 자동 생성</button>
      <div id="kdUploadMsg" style="margin-top:6px;font-size:12px;"></div>
    </div>

    <!-- 수동 입력 탭 -->
    <div id="kdManualTab" style="display:none;background:rgba(99,102,241,0.08);border:1px solid rgba(99,102,241,0.3);border-radius:10px;padding:14px;margin-bottom:16px;">
      <input id="kdTitle" placeholder="제목" style="width:100%;padding:8px;border:1px solid #444;border-radius:6px;background:#2a2a3e;color:#fff;font-size:13px;margin-bottom:8px;box-sizing:border-box;">
      <div style="display:flex;gap:6px;margin-bottom:8px;">
        <select id="kdCategory" onchange="if(this.value==='_custom')document.getElementById('kdCategoryCustom').style.display='block'" style="flex:1;padding:8px;border:1px solid #444;border-radius:6px;background:#2a2a3e;color:#fff;font-size:13px;">
          <option value="guide">가이드</option>
          <option value="column_definition">컬럼 사전</option>
          <option value="architecture">아키텍처</option>
          <option value="specification">기술 명세</option>
          <option value="changelog">변경 이력</option>
          <option value="plan">계획 문서</option>
          <option value="etc">기타</option>
          <option value="_custom">+ 직접 입력</option>
        </select>
        <input id="kdCategoryCustom" placeholder="새 카테고리명" style="display:none;flex:1;padding:8px;border:1px solid #6366f1;border-radius:6px;background:#2a2a3e;color:#fff;font-size:13px;">
      </div>
      <input id="kdTags" placeholder="태그 (쉼표 구분: OHT, 반송, M14)" style="width:100%;padding:8px;border:1px solid #444;border-radius:6px;background:#2a2a3e;color:#fff;font-size:13px;margin-bottom:8px;box-sizing:border-box;">
      <textarea id="kdContent" placeholder="내용을 입력하세요..." style="width:100%;height:150px;padding:8px;border:1px solid #444;border-radius:6px;background:#2a2a3e;color:#fff;font-size:13px;margin-bottom:8px;box-sizing:border-box;resize:vertical;"></textarea>
      <button onclick="saveKdManual()" style="width:100%;padding:10px;background:#6366f1;color:#fff;border:none;border-radius:6px;font-weight:700;cursor:pointer;">💾 저장 + 프론트매터 자동 생성</button>
      <div id="kdManualMsg" style="margin-top:6px;font-size:12px;"></div>
    </div>

    <!-- 내 파일 목록 -->
    <div style="font-weight:700;margin-bottom:8px;color:#a5b4fc;">📋 등록된 지식 파일</div>
    <div id="kdFileList" style="font-size:12px;color:#888;">로딩 중...</div>
  </div>
</div>

<!-- UIO 2D 픽셀 컨테이너 -->
<div id="uioContainer">
  <iframe id="uioFrame" src="about:blank"></iframe>
  <button id="uioBackBtn" onclick="toggleUioMode()">← 접기</button>
</div>

<div class="sidebar" id="sidebar">
  <button class="sidebar-toggle-mini" onclick="toggleSidebar()" title="펼치기">☰</button>
  <div class="sidebar-inner">
    <div class="sidebar-logo"><span>D</span>emos <span style="font-size:12px;color:#999">V1.0</span></div>
    <div style="display:flex;gap:4px;margin-bottom:4px;">
      <button class="sidebar-btn active" onclick="createNewSession()" style="flex:1">✨ 새 세션</button>
      <button class="sidebar-btn" onclick="selectAllSessions()" style="flex:0;padding:6px 10px;font-size:11px;" title="전체 선택">☑</button>
      <button class="sidebar-btn" onclick="deleteAllSessions()" style="flex:0;padding:6px 10px;font-size:11px;color:#ef4444;" title="전체 삭제">🗑️</button>
    </div>
    <div class="sidebar-section" ondblclick="openSessionPopup()" style="cursor:pointer;" title="더블클릭으로 전체 보기">세션 목록 <span class="skill-count" id="sessionCount">0</span></div>
    <div id="sessionList" style="max-height:250px;overflow-y:auto;margin-bottom:4px;"></div>
    <div class="session-actions" id="sessionActions" style="display:none">
      <button onclick="archiveSelectedSessions()">📦 보관</button>
      <button class="danger" onclick="deleteSelectedSessions()">🗑️ 삭제</button>
      <button onclick="clearSessionSelection()">취소</button>
    </div>
  </div>
  <div id="fileListPanel" class="sidebar-file-panel" style="display:none"></div>
  <div class="sidebar-footer">
    <div class="credits">🔬 Demos V1.0</div>
  </div>
  </div>
</div>
<!-- 세션 목록 팝업 -->
<div id="sessionPopupOverlay" style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.5);z-index:9999;justify-content:center;align-items:center;" onclick="if(event.target===this)closeSessionPopup()">
  <div style="background:#fff;border-radius:16px;width:90%;max-width:700px;max-height:85vh;display:flex;flex-direction:column;box-shadow:0 20px 60px rgba(0,0,0,0.3);">
    <div style="padding:16px 20px;border-bottom:1px solid #e5e7eb;display:flex;justify-content:space-between;align-items:center;">
      <div style="font-size:16px;font-weight:700;">세션 목록 <span id="popupSessionCount" style="font-size:13px;color:#6366f1;"></span></div>
      <div style="display:flex;gap:6px;">
        <button onclick="selectAllSessionsPopup()" style="padding:6px 12px;border:1px solid #d1d5db;border-radius:8px;background:#fff;cursor:pointer;font-size:12px;">☑ 전체선택</button>
        <button onclick="deleteSelectedSessionsPopup()" style="padding:6px 12px;border:1px solid #fca5a5;border-radius:8px;background:#fff;color:#ef4444;cursor:pointer;font-size:12px;">🗑️ 선택삭제</button>
        <button onclick="deleteAllSessionsPopup()" style="padding:6px 12px;border:1px solid #fca5a5;border-radius:8px;background:#fef2f2;color:#dc2626;cursor:pointer;font-size:12px;">전체삭제</button>
        <button onclick="exportSessionsToMd()" style="padding:6px 12px;border:1px solid #86efac;border-radius:8px;background:#f0fdf4;color:#16a34a;cursor:pointer;font-size:12px;">📄 MD 저장</button>
        <button onclick="openHarnessSessionTab()" style="padding:6px 12px;border:1px solid #c7d2fe;border-radius:8px;background:#eef2ff;color:#6366f1;cursor:pointer;font-size:12px;font-weight:600">💾 하네스 저장</button>
        <button onclick="closeSessionPopup()" style="padding:6px 12px;border:1px solid #d1d5db;border-radius:8px;background:#fff;cursor:pointer;font-size:16px;">✕</button>
      </div>
    </div>
    <div style="padding:8px 20px;border-bottom:1px solid #f3f4f6;">
      <input id="sessionSearchInput" type="text" placeholder="세션 내용 검색... (제목, 대화 내용)" oninput="searchSessionsPopup(this.value)" style="width:100%;padding:8px 12px;border:1px solid #d1d5db;border-radius:8px;font-size:13px;outline:none;box-sizing:border-box;" />
    </div>
    <div id="sessionPopupBody" style="flex:1;overflow-y:auto;padding:12px 16px;"></div>
  </div>
</div>

<button class="sidebar-toggle" id="sidebarToggle" onclick="toggleSidebar()">◀</button>


<div class="main">
  <div class="header">
    <div class="project-title">📁 Demos V1.0 <span style="font-size:12px;color:#6366f1;background:#eef2ff;padding:2px 10px;border-radius:10px;margin-left:8px;font-weight:500;">Opus SKILL 4.6 하네스 사용중</span><span style="font-size:11px;color:#9ca3af;margin-left:6px;">2달에 한번 스킬 업데이트 | 사용을 많이 해줄수록 기능이 업데이트 됩니다</span></div>
    <div style="display:flex;align-items:center;gap:6px;">
      <button id="hdKdBtn" onclick="openKnowledgePopup()" style="font-size:12px;color:#fff;background:#22c55e;border:none;padding:5px 12px;border-radius:8px;cursor:pointer;font-weight:600;">📚 내 지식</button>
      <button id="hdAdminBtn" onclick="openAdminPopup()" style="display:none;font-size:12px;color:#000;background:#f59e0b;border:none;padding:5px 12px;border-radius:8px;cursor:pointer;font-weight:600;">👑 사용자 관리</button>
      <button id="hdLogoutBtn" onclick="doLogout()" style="font-size:12px;color:#888;background:none;border:1px solid #ddd;padding:5px 10px;border-radius:8px;cursor:pointer;">🚪</button>
      <span style="color:#ccc;font-size:10px;">|</span>
      <span id="tokenBadge" class="status off">⏳ 로딩중...</span>
      <button onclick="openHarnessSessionTab()" style="font-size:12px;color:#6366f1;background:#eef2ff;border:1px solid #c7d2fe;padding:4px 12px;border-radius:8px;cursor:pointer;font-weight:500;">💾 저장 세션</button>
      <a href="/uio" target="_blank" class="uio-enter-btn">🎮 2D 오피스</a>
      <span id="status" class="status off">⚪ 환경 미선택</span>
    </div>
  </div>
  <div class="content">
    <div class="content-inner">
      <!-- 환경 선택 -->
      <div class="section-label">LLM 환경 선택 <span id="envStatusBadge" style="font-weight:400;font-size:11px;color:#6366f1"></span></div>
      <div id="tokenStatus" class="token-status missing">⏳ 토큰 상태 확인중...</div>
      <div id="envContainer">
        <div class="env-section">
          <div class="env-row" id="envRowAuto"></div>
        </div>
        <div class="env-section" id="envSectionApi">
          <div class="env-section-label env-toggle" onclick="toggleEnvSection('Api')">
            <span id="envArrowApi">▶</span> API 모델
          </div>
          <div id="envApiInner" style="display:none">
            <div class="env-subsection-label" id="envHighLabel" style="display:none">🚀 고성능 모델 <span style="color:#b0b0b0">- 복잡한 분석, 코드 생성, 논문 작성</span></div>
            <div class="env-row" id="envRowHigh"></div>
            <div class="env-subsection-label" id="envMidLabel" style="display:none">⚡ 범용 모델 <span style="color:#b0b0b0">- 일반 질문, 요약, 간단한 코드</span></div>
            <div class="env-row" id="envRowMid"></div>
            <div class="env-subsection-label" id="envLowLabel" style="display:none">💨 경량 모델 <span style="color:#b0b0b0">- 빠른 응답, 단순 Q&A, 번역</span></div>
            <div class="env-row" id="envRowLow"></div>
            <div class="env-subsection-label" id="envVlLabel" style="display:none">👁️ Vision 모델 <span style="color:#b0b0b0">- 이미지 분석, 스크린샷 해석, 도면 인식</span></div>
            <div class="env-row" id="envRowVl"></div>
          </div>
        </div>
        <div class="env-section" id="envSectionGguf">
          <div class="env-section-label env-toggle" onclick="toggleEnvSection('Gguf')">
            <span id="envArrowGguf">▶</span> GGUF 로컬 모델
          </div>
          <div class="env-row env-collapsible" id="envRowGguf" style="display:none"></div>
        </div>
      </div>

      <!-- 업로드된 파일 목록은 사이드바 하단으로 이동 -->
      <div id="csvInfoPanel" style="display:none"></div>

      <div class="section-label" style="cursor:pointer;user-select:none;" onclick="toggleSection('tagSection','tagArrow')">
        <span class="arrow" id="tagArrow">▶</span> 분야 선택
      </div>
      <div id="tagSection" style="display:none">
        <div class="tag-row" id="tagRow"></div>
      </div>

      <div class="section-label" style="cursor:pointer;user-select:none;display:flex;align-items:center;gap:8px;" onclick="toggleSection('skillSection','skillArrow')">
        <span class="arrow" id="skillArrow">▶</span> 스킬 선택 <span style="font-weight:400;color:#bbb">( ✅ = SKILL.md 로드됨 )</span>
        <button onclick="event.stopPropagation();openSkillCreate()" style="background:#6366f1;color:#fff;border:none;border-radius:4px;padding:3px 10px;font-size:11px;cursor:pointer;margin-left:auto;">➕ 새 스킬</button>
      </div>
      <div id="skillSection" style="display:none">
        <div class="skill-grid" id="skillGrid"></div>
      </div>

      <div class="section-label" style="cursor:pointer;user-select:none;" onclick="toggleSection('comboSection','comboArrow')">
        <span class="arrow" id="comboArrow">▶</span> 스킬 조합 <span style="font-weight:400;color:#bbb">( 여러 조합을 동시에 선택할 수 있습니다 )</span>
      </div>
      <div id="comboSection" style="display:none;padding:4px 0;">
        <div id="comboActiveMsg" style="display:none;margin-bottom:8px;padding:8px 12px;border-radius:8px;background:#6366f110;border:1px solid #6366f130;font-size:12px;color:#6366f1;"></div>
        <div id="comboGrid" style="display:flex;flex-wrap:wrap;gap:6px;"></div>
        <div id="comboClearWrap" style="display:none;margin-top:8px;text-align:right;">
          <button onclick="clearAllCombos()" style="background:#ef4444;color:#fff;border:none;border-radius:6px;padding:6px 16px;font-size:12px;font-weight:700;cursor:pointer;">🗑️ 전체 해제</button>
        </div>
      </div>

      <div class="sysprompt-section">
        <div class="sysprompt-toggle" onclick="toggleSysPrompt()">
          <span class="arrow" id="spArrow">▶</span>
          <div class="section-label" style="margin-bottom:0;cursor:pointer">시스템 프롬프트</div>
          <span id="spPreviewBadge" style="font-size:11px;color:#6366f1;background:#eef2ff;padding:2px 8px;border-radius:10px">기본값</span>
        </div>
        <div class="sysprompt-body" id="spBody">
          <!-- 프리셋/저장 프롬프트 선택 바 -->
          <div id="promptPresets" style="display:flex;flex-wrap:wrap;gap:4px;margin-bottom:8px"></div>
          <textarea class="sysprompt-textarea" id="systemPromptInput" placeholder="시스템 프롬프트를 입력하세요. 비워두면 기본값 사용됩니다.&#10;&#10;아래 프리셋 버튼을 클릭하면 자동으로 채워집니다.&#10;수정 후 '저장' 버튼으로 나만의 프롬프트를 저장하세요."></textarea>
          <div class="sysprompt-info" style="display:flex;align-items:center;flex-wrap:wrap;gap:4px">
            <span>💡 스킬 프롬프트 <strong>앞에</strong> 추가됩니다.</span>
            <button style="background:#6366f1;color:#fff;border:none;border-radius:4px;padding:3px 10px;font-size:11px;cursor:pointer" onclick="saveCurrentPrompt()">💾 저장</button>
            <button style="background:#ef4444;color:#fff;border:none;border-radius:4px;padding:3px 10px;font-size:11px;cursor:pointer" onclick="deleteCurrentPrompt()" id="btnDeletePrompt" title="현재 선택된 저장 프롬프트 삭제">🗑️ 삭제</button>
            <button style="background:#f3f2ef;border:1px solid #e5e3de;border-radius:4px;padding:3px 8px;font-size:11px;cursor:pointer" onclick="resetSysPrompt()">초기화</button>
            <span id="promptSaveStatus" style="font-size:11px;color:#16a34a;display:none">✅ 저장됨!</span>
          </div>
        </div>
      </div>

      <div class="effort-section">
        <div class="section-label">응답 수준</div>
        <input type="range" class="effort-slider" id="effortSlider" min="0" max="3" value="2" oninput="updateEffort()">
        <div class="effort-labels">
          <span id="e0">즉시</span><span id="e1">빠름</span><span id="e2" class="active">표준</span><span id="e3">프로</span>
        </div>
      </div>

      <!-- 작성스타일/출력형식: 채팅창 드롭다운으로 이동, 내부 상태 유지용 hidden -->
      <div style="display:none">
        <div id="styleChips"></div>
        <textarea id="writingStyle"></textarea>
        <div class="fmt-btns">
          <div class="fmt-btn selected" data-f="auto" onclick="selFmt(this)">🤖 자동</div>
          <div class="fmt-btn" data-f="code" onclick="selFmt(this)">코드</div>
          <div class="fmt-btn" data-f="code-fix" onclick="selFmt(this)">코드수정</div>
          <div class="fmt-btn" data-f="analysis" onclick="selFmt(this)">분석</div>
          <div class="fmt-btn" data-f="report" onclick="selFmt(this)">보고서</div>
          <div class="fmt-btn" data-f="step-by-step" onclick="selFmt(this)">단계별</div>
        </div>
      </div>

      <!-- 자동 스킬 선택 -->
      <div class="auto-skill-toggle" id="autoSkillToggle" onclick="toggleAutoSkill()">
        <div class="toggle-dot"></div>
        <div>
          <div style="font-weight:700;font-size:13px">🧠 자동 스킬 선택</div>
          <div style="font-size:11px;color:#888">질문을 분석하여 관련 스킬을 자동으로 로드합니다</div>
        </div>
      </div>
      <div class="quick-row">
        <button class="quick-btn" onclick="qp('이 데이터를 분석해줘')">📊 데이터 분석</button>
        <button class="quick-btn" onclick="qp('업로드된 CSV 데이터의 통계 요약을 보여줘')">📋 CSV 요약</button>
        <button class="quick-btn" onclick="qp('이 데이터로 시각화 코드를 작성해줘')">📈 시각화</button>
        <button class="quick-btn" onclick="qp('Python 코드를 작성해줘')">🐍 코드 작성</button>
        <button class="quick-btn" onclick="qp('이 데이터에서 이상치를 찾아줘')">🔍 이상치 탐색</button>
        <button class="quick-btn" onclick="qp('논문 스타일로 정리해줘')">📝 논문 정리</button>
      </div>

      <div id="pptSuggestArea"></div>
      <div class="messages" id="msgs"></div>
    </div>
  </div>

  <!-- 질문 입력 - 하단 고정 -->
  <div class="chat-box-fixed">
    <div class="chat-box-fixed-inner">
      <div class="auto-skill-preview" id="autoSkillPreview"></div>
      <div class="chat-attach-preview" id="chatAttachPreview" style="display:none"></div>
      <textarea class="chat-input" id="input" placeholder="질문을 하거나 수행하려는 분석을 설명하세요..." onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();handleSendStop()}" oninput="this.style.height='auto';this.style.height=this.scrollHeight+'px';checkPptStyleVisibility()"></textarea>
      <input type="file" id="chatFileInput" multiple style="display:none" onchange="handleChatFileSelect(this.files)">
      <div class="chat-footer">
        <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
          <button class="attach-btn" onclick="document.getElementById('chatFileInput').click()" title="파일 첨부">📎</button>
          <select class="chat-dropdown" id="chatStyleDrop" onchange="applyChatStyle(this.value)" title="작성 스타일">
            <option value="">🤖 자동</option>
            <option value="간결하고 핵심만. 불필요한 설명 생략.">⚡ 간결</option>
            <option value="상세하고 친절하게. 원리, 배경, 예시 포함.">📖 상세</option>
            <option value="바로 복붙해서 쓸 수 있게. 실전 위주, 이론 최소화.">🔨 실용적</option>
            <option value="학술적 톤. 정확한 용어, 인용, 근거 제시.">🎓 학술</option>
            <option value="코드 주석을 상세한 한국어로. 변수명은 영어 유지.">💬 한글주석</option>
            <option value="시니어 개발자 관점. 왜 이렇게 하는지, 대안은 뭔지, 주의점 포함.">👨‍💻 시니어</option>
            <option value="에러 원인 분석 중심. traceback 해석, 재현 조건, 해결책 순서.">🐛 디버그</option>
            <option value="데이터 스토리텔링. 숫자→의미→액션 순서로 해석.">📊 데이터</option>
          </select>
          <select class="chat-dropdown" id="chatFormatDrop" onchange="applyChatFormat(this.value)" title="출력 형식">
            <option value="auto">🤖 자동</option>
            <option value="code">💻 코드</option>
            <option value="code-fix">🔧 수정</option>
            <option value="analysis">📊 분석</option>
            <option value="report">📄 보고서</option>
            <option value="step-by-step">📝 단계별</option>
          </select>
          <select class="chat-dropdown ppt-style-drop" id="pptStyleDrop" onchange="applyPptStyle(this.value)" title="PPT 디자인 스타일">
            <option value="">📽️ PPT:자동</option>
            <option value="minimal">⬜ 미니멀</option>
            <option value="corporate">🏢 기업용</option>
            <option value="colorful">🎨 컬러풀</option>
            <option value="dark">🌙 다크</option>
            <option value="academic">🎓 학술</option>
            <option value="startup">🚀 스타트업</option>
            <option value="ref">📎 참고PPT</option>
          </select><span id="pptRefBadge" class="ppt-ref-badge" style="display:none">📎 참고스타일 적용중</span>
          <label style="display:flex;align-items:center;gap:3px;font-size:11px;color:#888;cursor:pointer;user-select:none" title="체크하면 모델이 답변 전에 깊이 사고합니다 (응답 느림)">
            <input type="checkbox" id="thinkToggle" style="margin:0;accent-color:#7c5cbf">💭사고
          </label>
          <span style="font-size:11px;color:#bbb">Enter 전송</span>
        </div>
        <button class="send-btn" onclick="handleSendStop()" id="sendBtn">▶</button>
      </div>
    </div>
  </div>
</div>

<!-- 오른쪽 코드 어시스턴트 패널 -->
<div class="right-panel" id="rightPanel">
  <div class="rp-header">
    <h3>🖥️ Code Assistant<span class="rp-skill-badge">code-assistant</span></h3>
  </div>
  <div class="rp-body">
    <div class="rp-section">
      <div class="rp-section-title">프로젝트 / 코드 파일</div>
      <div class="rp-tab-row">
        <button class="rp-tab active" onclick="switchUploadMode('folder',this)">📁 폴더 업로드</button>
        <button class="rp-tab" onclick="switchUploadMode('files',this)">📄 파일 업로드</button>
      </div>
      <div id="rpFolderMode">
        <div class="rp-file-drop" id="rpFolderDrop" onclick="document.getElementById('rpFolderInput').click()">
          <div class="rp-file-drop-icon">📁</div>
          <div class="rp-file-drop-text">클릭하여 <strong>프로젝트 폴더</strong> 통째로 업로드<br><span style="font-size:10px;color:#bbb">폴더 선택 시 하위 파일 전체가 트리로 표시됩니다</span></div>
        </div>
        <input type="file" id="rpFolderInput" webkitdirectory directory multiple style="display:none" onchange="handleRpFolderSelect(this.files)">
      </div>
      <div id="rpFileMode" style="display:none">
        <div class="rp-file-drop" id="rpFileDrop" onclick="document.getElementById('rpFileInput').click()">
          <div class="rp-file-drop-icon">📄</div>
          <div class="rp-file-drop-text">클릭 또는 드래그하여 코드 파일 업로드<br><span style="font-size:10px;color:#bbb">.py .js .html .css .java .c .cpp .go .rs .sh .json .yaml .md</span></div>
        </div>
        <input type="file" id="rpFileInput" multiple accept=".py,.js,.html,.css,.json,.xml,.yaml,.yml,.c,.cpp,.h,.java,.go,.rs,.sh,.bat,.md,.txt" style="display:none" onchange="handleRpFileSelect(this.files)">
      </div>
      <div id="rpTreeStats" class="rp-tree-stats" style="display:none">
        <span id="rpStatsInfo">0 파일 / 0 폴더</span>
        <span id="rpStatsSize">0 KB</span>
        <button onclick="clearRpProject()" style="background:none;border:none;color:#ef4444;cursor:pointer;font-size:11px;font-weight:600">전체 삭제</button>
      </div>
      <div id="rpLangDetect" style="display:none;padding:6px 10px;background:#f0f0ff;border-radius:6px;margin-bottom:6px;font-size:11px;">
        <div style="font-weight:600;color:#4f46e5;margin-bottom:3px;">🔍 감지된 언어/도구</div>
        <div id="rpLangTags" style="display:flex;flex-wrap:wrap;gap:4px;"></div>
        <div id="rpAutoSkills" style="margin-top:4px;color:#6b7280;font-size:10px;"></div>
      </div>
      <div class="rp-select-bar" id="rpSelectBar" style="display:none">
        <button class="rp-select-btn" onclick="rpCheckAll(true)">전체 선택</button>
        <button class="rp-select-btn" onclick="rpCheckAll(false)">전체 해제</button>
        <span class="rp-checked-count" id="rpCheckedCount">0개 선택</span>
      </div>
      <div class="rp-tree" id="rpTree" style="display:none"></div>
      <div class="rp-file-list" id="rpFileList"></div>
    </div>

    <!-- 분석 모델 선택 (API 대형 모델) -->
    <div class="rp-section">
      <div class="rp-section-title">분석 모델 <span style="font-size:10px;color:#6b7280">(대형 API)</span></div>
      <div class="rp-model-row" id="rpModelRow">
        <button class="rp-model-btn active" data-model="kimi-k25" onclick="selectRpModel(this)">
          <span class="icon">🔥</span>Kimi-K2.5
        </button>
        <button class="rp-model-btn" data-model="coder-480b" onclick="selectRpModel(this)">
          <span class="icon">🚀</span>Coder-480B
        </button>
        <button class="rp-model-btn" data-model="qwen35-397b" onclick="selectRpModel(this)">
          <span class="icon">🦣</span>Qwen3.5-397B
        </button>
        <button class="rp-model-btn" data-model="qwen35-397b-fp8" onclick="selectRpModel(this)">
          <span class="icon">🦣</span>397B FP8
        </button>
        <button class="rp-model-btn" data-model="glm-5-1" onclick="selectRpModel(this)">
          <span class="icon">💎</span>GLM-5.1
        </button>
      </div>
    </div>

    <div class="rp-section">
      <div class="rp-section-title">분석 모드 선택 <span id="rpModelBadge" style="font-size:10px;color:#6366f1;background:#eef2ff;padding:1px 6px;border-radius:6px;">🔥 Kimi-K2.5</span></div>
      <div class="rp-action-grid">
        <button class="rp-action-btn" data-mode="explain" onclick="selectRpMode(this)">
          <span class="rp-btn-icon">📖</span>
          <span class="rp-btn-label">코드 설명</span>
        </button>
        <button class="rp-action-btn" data-mode="find_bugs" onclick="selectRpMode(this)">
          <span class="rp-btn-icon">🐛</span>
          <span class="rp-btn-label">버그 탐지</span>
        </button>
        <button class="rp-action-btn" data-mode="improve" onclick="selectRpMode(this)">
          <span class="rp-btn-icon">✨</span>
          <span class="rp-btn-label">개선 제안</span>
        </button>
        <button class="rp-action-btn" data-mode="tests" onclick="selectRpMode(this)">
          <span class="rp-btn-icon">🧪</span>
          <span class="rp-btn-label">테스트 생성</span>
        </button>
        <button class="rp-action-btn" data-mode="docstring" onclick="selectRpMode(this)">
          <span class="rp-btn-icon">📝</span>
          <span class="rp-btn-label">문서화</span>
        </button>
        <button class="rp-action-btn" data-mode="refactor" onclick="selectRpMode(this)">
          <span class="rp-btn-icon">🔧</span>
          <span class="rp-btn-label">리팩토링</span>
        </button>
      </div>
    </div>

    <button class="rp-run-btn" id="rpRunBtn" onclick="runCodeAssistant()" disabled>▶ 분석 실행</button>
    <div class="rp-result" id="rpResult" style="display:none"></div>
  </div>
</div>
<button class="right-panel-toggle" id="rightPanelToggle" onclick="toggleRightPanel()">▶</button>

<!-- 스킬 상세 패널 -->
<div id="skillDetailOverlay" class="skill-detail-overlay" style="display:none" onclick="if(event.target===this)closeSkillDetail()">
  <div class="skill-detail-panel">
    <div class="sdp-header">
      <h2 id="sdpTitle">스킬 상세</h2>
      <button class="sdp-close" onclick="closeSkillDetail()">✕</button>
    </div>
    <div class="sdp-tabs" id="sdpTabs"></div>
    <div class="sdp-body" id="sdpBody">로딩중...</div>
  </div>
</div>

<!-- 스킬 생성 모달 -->
<div id="skillCreateOverlay" class="skill-detail-overlay" style="display:none" onclick="if(event.target===this)closeSkillCreate()">
  <div class="skill-detail-panel" style="max-width:800px;max-height:90vh;">
    <div class="sdp-header">
      <h2>➕ 새 스킬 만들기</h2>
      <button class="sdp-close" onclick="closeSkillCreate()">✕</button>
    </div>
    <div class="sdp-tabs" id="scTabs">
      <div class="sdp-tab active" onclick="switchScTab('manual')">✏️ 직접 작성</div>
      <div class="sdp-tab" onclick="switchScTab('llm')">🤖 LLM 자동 생성</div>
      <div class="sdp-tab" onclick="switchScTab('wiki')">📚 LLM Wiki 생성</div>
    </div>
    <div class="sdp-body" id="scBody" style="overflow-y:auto;max-height:calc(90vh - 120px);">
      <!-- 직접 작성 탭 -->
      <div id="scManual">
        <div style="margin-bottom:12px;">
          <label style="font-size:12px;font-weight:700;display:block;margin-bottom:4px;">스킬 이름 <span style="color:#ef4444">*</span></label>
          <input id="scName" type="text" placeholder="my-skill-name (소문자+하이픈)" style="width:100%;padding:8px;border:1px solid #e2e8f0;border-radius:6px;font-size:13px;box-sizing:border-box;" oninput="validateScName()">
          <div id="scNameStatus" style="font-size:11px;margin-top:2px;"></div>
        </div>
        <div style="margin-bottom:12px;">
          <label style="font-size:12px;font-weight:700;display:block;margin-bottom:4px;">Description <span style="color:#ef4444">*</span></label>
          <textarea id="scDesc" rows="3" placeholder="스킬의 용도와 트리거 조건을 명확히 기술 (최소 20자)" style="width:100%;padding:8px;border:1px solid #e2e8f0;border-radius:6px;font-size:13px;resize:vertical;box-sizing:border-box;"></textarea>
        </div>
        <div style="margin-bottom:12px;">
          <label style="font-size:12px;font-weight:700;display:block;margin-bottom:4px;">본문 (마크다운 지시문)</label>
          <textarea id="scBody_manual" rows="15" placeholder="# 스킬 제목&#10;&#10;## Overview&#10;스킬이 하는 일 설명&#10;&#10;## When to Use&#10;- 이 스킬을 사용할 상황 1&#10;- 상황 2&#10;&#10;## Instructions&#10;Claude가 따를 지시문..." style="width:100%;padding:8px;border:1px solid #e2e8f0;border-radius:6px;font-size:12px;font-family:monospace;resize:vertical;box-sizing:border-box;"></textarea>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;">
          <button onclick="validateSkillPreview()" style="background:#6366f1;color:#fff;border:none;border-radius:6px;padding:8px 16px;font-size:13px;cursor:pointer;">🔍 검증</button>
          <button onclick="applySkill()" style="background:#f59e0b;color:#fff;border:none;border-radius:6px;padding:8px 16px;font-size:13px;cursor:pointer;">🚀 스킬 적용</button>
          <button onclick="downloadSkill()" style="background:#16a34a;color:#fff;border:none;border-radius:6px;padding:8px 16px;font-size:13px;cursor:pointer;">📥 다운로드 (.zip)</button>
        </div>
        <div id="scValidateResult" style="margin-top:10px;"></div>
      </div>
      <!-- LLM 자동 생성 탭 -->
      <div id="scLlm" style="display:none;">
        <div style="margin-bottom:12px;">
          <label style="font-size:12px;font-weight:700;display:block;margin-bottom:4px;">스킬 주제 <span style="color:#ef4444">*</span></label>
          <input id="scTopic" type="text" placeholder="예: 반도체 식각 공정 분석, 코드 리뷰어, 논문 검색" style="width:100%;padding:8px;border:1px solid #e2e8f0;border-radius:6px;font-size:13px;box-sizing:border-box;">
        </div>
        <div style="margin-bottom:12px;">
          <label style="font-size:12px;font-weight:700;display:block;margin-bottom:4px;">스킬 유형</label>
          <select id="scType" style="width:100%;padding:8px;border:1px solid #e2e8f0;border-radius:6px;font-size:13px;">
            <option value="분석/도구">🔧 분석/도구형 (데이터 분석, 자동화)</option>
            <option value="에이전트">🤖 역할/에이전트형 (전문가 페르소나)</option>
            <option value="가이드">📖 가이드/지식형 (기법, 지식 제공)</option>
          </select>
        </div>
        <div style="margin-bottom:12px;">
          <label style="font-size:12px;font-weight:700;display:block;margin-bottom:4px;">상세 요구사항 (선택)</label>
          <textarea id="scDetails" rows="4" placeholder="스킬에 포함할 기능, 특수 요구사항 등..." style="width:100%;padding:8px;border:1px solid #e2e8f0;border-radius:6px;font-size:13px;resize:vertical;box-sizing:border-box;"></textarea>
        </div>
        <div style="margin-bottom:12px;">
          <label style="font-size:12px;font-weight:700;display:block;margin-bottom:4px;">생성 언어</label>
          <div style="display:flex;gap:6px;">
            <button id="scLangKo" onclick="setScLang('ko')" style="padding:6px 16px;border-radius:6px;font-size:13px;cursor:pointer;border:2px solid #6366f1;background:#6366f1;color:#fff;font-weight:700;">🇰🇷 한글</button>
            <button id="scLangEn" onclick="setScLang('en')" style="padding:6px 16px;border-radius:6px;font-size:13px;cursor:pointer;border:2px solid #e2e8f0;background:#fff;color:#333;font-weight:700;">🇺🇸 English</button>
          </div>
          <input type="hidden" id="scLang" value="ko">
        </div>
        <div style="margin-bottom:12px;">
          <label style="font-size:12px;font-weight:700;display:block;margin-bottom:4px;">톤(서술 스타일)</label>
          <div style="display:flex;gap:6px;flex-wrap:wrap;">
            <label style="display:inline-flex;align-items:center;gap:5px;padding:6px 12px;border-radius:6px;border:1px solid #e2e8f0;cursor:pointer;font-size:13px;background:#f9fafb;">
              <input type="radio" name="scTone" value="default" checked> 기본 (구조적 지시문)
            </label>
            <label style="display:inline-flex;align-items:center;gap:5px;padding:6px 12px;border-radius:6px;border:1px solid #e2e8f0;cursor:pointer;font-size:13px;background:#f9fafb;">
              <input type="radio" name="scTone" value="karpathy"> 🎯 카파시 톤 (First Principles + 비유)
            </label>
          </div>
          <div style="font-size:11px;color:#64748b;margin-top:4px;line-height:1.4;">
            카파시 톤: SKILL.md 의 본문(특히 Instructions 섹션) 을 카파시 스타일로 — 첫 원리부터, 비유 사용, 짧은 단락.
          </div>
        </div>
        <div style="display:flex;gap:8px;margin-bottom:12px;flex-wrap:wrap;">
          <button onclick="generateSkillLLM()" id="scGenBtn" style="background:#8b5cf6;color:#fff;border:none;border-radius:6px;padding:8px 16px;font-size:13px;cursor:pointer;">🤖 LLM으로 생성</button>
          <button onclick="validateGenerated()" style="background:#6366f1;color:#fff;border:none;border-radius:6px;padding:8px 16px;font-size:13px;cursor:pointer;">🔍 검증</button>
          <button onclick="applyGeneratedSkill()" style="background:#f59e0b;color:#fff;border:none;border-radius:6px;padding:8px 16px;font-size:13px;cursor:pointer;">🚀 스킬 적용</button>
          <button onclick="downloadGeneratedSkill()" style="background:#16a34a;color:#fff;border:none;border-radius:6px;padding:8px 16px;font-size:13px;cursor:pointer;">📥 다운로드 (.zip)</button>
        </div>
        <div id="scGenStatus" style="font-size:12px;color:#6366f1;display:none;margin-bottom:8px;">⏳ 생성 중... (최대 2분)</div>
        <div id="scGenResult" style="display:none;">
          <label style="font-size:12px;font-weight:700;display:block;margin-bottom:4px;">SKILL.md 내용 (LLM 생성 후 편집 가능)</label>
          <textarea id="scGenContent" rows="20" placeholder="🤖 LLM으로 생성 버튼을 클릭하면 여기에 SKILL.md 초안이 생성됩니다.&#10;직접 입력해도 됩니다." style="width:100%;padding:8px;border:1px solid #e2e8f0;border-radius:6px;font-size:12px;font-family:monospace;resize:vertical;box-sizing:border-box;"></textarea>
          <div id="scGenValidateResult" style="margin-top:10px;"></div>
        </div>
      </div>
      <!-- 📚 LLM Wiki 생성 탭 -->
      <div id="scWiki" style="display:none;">
        <div style="margin-bottom:10px;font-size:12px;color:#64748b;line-height:1.5;">
          🎯 글(블로그·논문·노트·gist 등)을 붙여넣으면 <b>카파시 스타일</b>로 wiki MD 를 만들어줘요.
          결과는 클립보드 복사 / 다운로드 / <b>📚 내 지식에 등록</b> 가능 (등록 시 <code>[WIKI]</code> 접두어로 검색·구분 쉬움).
        </div>
        <div style="margin-bottom:10px;">
          <label style="font-size:12px;font-weight:700;display:block;margin-bottom:4px;">원본 본문 <span style="color:#ef4444">*</span></label>
          <textarea id="wikiSource" rows="8" placeholder="블로그/논문/노트/gist 등 어떤 글이든 그대로 붙여넣으세요..." style="width:100%;padding:8px;border:1px solid #e2e8f0;border-radius:6px;font-size:12px;resize:vertical;box-sizing:border-box;"></textarea>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px;">
          <div style="flex:1;min-width:180px;">
            <label style="font-size:12px;font-weight:700;display:block;margin-bottom:4px;">제목 (선택)</label>
            <input id="wikiTitle" type="text" placeholder="비워두면 LLM 이 자동 추출" style="width:100%;padding:7px 8px;border:1px solid #e2e8f0;border-radius:6px;font-size:13px;box-sizing:border-box;">
          </div>
        </div>
        <div style="display:flex;gap:16px;flex-wrap:wrap;margin-bottom:10px;font-size:12px;">
          <div>
            <label style="font-weight:700;display:block;margin-bottom:4px;">스타일</label>
            <label style="display:inline-flex;align-items:center;gap:4px;margin-right:8px;cursor:pointer;"><input type="radio" name="wikiStyle" value="karpathy" checked> 카파시</label>
            <label style="display:inline-flex;align-items:center;gap:4px;margin-right:8px;cursor:pointer;"><input type="radio" name="wikiStyle" value="preserve"> 원문 보존</label>
            <label style="display:inline-flex;align-items:center;gap:4px;cursor:pointer;"><input type="radio" name="wikiStyle" value="concise"> 핵심 요약</label>
          </div>
          <div>
            <label style="font-weight:700;display:block;margin-bottom:4px;">언어</label>
            <label style="display:inline-flex;align-items:center;gap:4px;margin-right:8px;cursor:pointer;"><input type="radio" name="wikiLang" value="ko" checked> 한글</label>
            <label style="display:inline-flex;align-items:center;gap:4px;margin-right:8px;cursor:pointer;"><input type="radio" name="wikiLang" value="en"> English</label>
            <label style="display:inline-flex;align-items:center;gap:4px;cursor:pointer;"><input type="radio" name="wikiLang" value="original"> 원문 그대로</label>
          </div>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px;">
          <button id="wikiGenBtn" onclick="generateWiki()" style="background:#8b5cf6;color:#fff;border:none;border-radius:6px;padding:8px 16px;font-size:13px;cursor:pointer;font-weight:700;">🤖 Wiki 로 변환</button>
        </div>
        <div style="margin-bottom:6px;display:flex;align-items:center;gap:8px;">
          <label style="font-size:12px;font-weight:700;">변환 결과 (편집 가능)</label>
          <span id="wikiResultTitle" style="font-size:11px;color:#16a34a;"></span>
          <span style="flex:1;"></span>
          <span id="wikiFilename" style="font-size:11px;color:#64748b;font-family:monospace;"></span>
        </div>
        <textarea id="wikiResult" rows="14" placeholder="변환된 wiki 마크다운이 여기에 나옵니다 (편집 가능)" style="width:100%;padding:8px;border:1px solid #e2e8f0;border-radius:6px;font-size:12px;font-family:monospace;resize:vertical;box-sizing:border-box;"></textarea>
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px;">
          <button id="wikiCopyBtn" onclick="copyWikiMd()" style="background:#6366f1;color:#fff;border:none;border-radius:6px;padding:8px 16px;font-size:13px;cursor:pointer;">📋 MD 복사</button>
          <button onclick="downloadWikiMd()" style="background:#16a34a;color:#fff;border:none;border-radius:6px;padding:8px 16px;font-size:13px;cursor:pointer;">📥 다운로드 (.md)</button>
          <button id="wikiSaveBtn" onclick="saveWikiToKnowledge()" style="background:#f59e0b;color:#fff;border:none;border-radius:6px;padding:8px 16px;font-size:13px;cursor:pointer;font-weight:700;">📚 내 지식에 등록</button>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
let envs = {};
let hasToken = false;
let selEnvs = ['auto'];  // 배열: ['auto'] 또는 ['gguf-0','gguf-1'] 또는 ['coder-480b','dev']
let selRpModel = 'kimi-k25';  // Code Assistant 패널 전용 모델 (기본: Kimi-K2.5)
let catalog = {};
let selDomains = [];
let selSkills = [];
let autoSkillMode = true;  // 기본 ON
let selFormat = 'auto';
let formatManualOverride = false;  // 사용자가 수동으로 출력형식을 변경했는지
let styleManualOverride = false;   // 사용자가 수동으로 스타일을 변경했는지
let effort = 2;
let history = [];
let maxTokens = 0;  // 0 = 서버 자동 결정 (모델에 맞게)
// ===== 스킬 조합 프리셋 =====
const SKILL_COMBOS = [
  {
    id:'data-analysis', label:'📊 데이터 분석', color:'#6366f1',
    desc:'CSV/엑셀 데이터 탐색, 통계, 시각화 풀세트',
    skills:['exploratory-data-analysis','statistical-analysis','matplotlib','seaborn','plotly','polars','agent-data-scientist','xlsx']
  },
  {
    id:'coding', label:'💻 코딩 개발', color:'#10b981',
    desc:'코드 작성, 리뷰, 디버깅 올인원',
    skills:['agent-python-pro','agent-fullstack-developer','debugging','agent-debugger','code-review','agent-backend-developer','agent-frontend-developer']
  },
  {
    id:'ml-ai', label:'🤖 ML/AI 제작', color:'#f59e0b',
    desc:'머신러닝 모델 학습, 평가, 해석',
    skills:['scikit-learn','pytorch-lightning','shap','umap-learn','statsmodels','agent-data-scientist','statistical-analysis','exploratory-data-analysis']
  },
  {
    id:'report-docs', label:'📝 보고서/문서', color:'#ef4444',
    desc:'Word, PPT, PDF, 마크다운 보고서 생성',
    skills:['docx','pptx','xlsx','pdf','scientific-writing','markdown-mermaid-writing','drawio-diagram']
  },
  {
    id:'literature', label:'📚 논문/문헌', color:'#8b5cf6',
    desc:'논문 검색, 문헌 리뷰, 인용 관리',
    skills:['literature-review','citation-management','scientific-writing','pubmed-database','openalex-database','biorxiv-database','peer-review']
  },
  {
    id:'visualization', label:'📈 시각화 전문', color:'#14b8a6',
    desc:'다양한 차트/다이어그램/인포그래픽 생성',
    skills:['matplotlib','seaborn','plotly','scientific-visualization','scientific-schematics','drawio-diagram','infographics','markdown-mermaid-writing']
  },
  {
    id:'web-fullstack', label:'🌐 웹 풀스택', color:'#0ea5e9',
    desc:'프론트+백엔드+DB+배포 풀세트',
    skills:['agent-fullstack-developer','agent-frontend-developer','agent-backend-developer','agent-react-specialist','agent-nextjs-developer','databases','frontend-development','backend-development']
  },
  {
    id:'devops-cloud', label:'☁️ DevOps/클라우드', color:'#64748b',
    desc:'CI/CD, 도커, 쿠버네티스, 클라우드 아키텍처',
    skills:['devops','agent-cloud-architect','agent-devops-engineer','agent-docker-expert','agent-kubernetes-specialist','agent-terraform-engineer']
  },
  {
    id:'skill-creation', label:'🛠️ 스킬 제작', color:'#a855f7',
    desc:'Claude 스킬 생성 (3개 메타스킬 조합)',
    skills:['skill-creator','anthropic-prompt-engineer','engineer-skill-creator','anthropic-architect']
  },
  {
    id:'timeseries', label:'⏱️ 시계열 분석', color:'#f97316',
    desc:'시계열 데이터 예측, 이상 탐지, 패턴 분석',
    skills:['aeon','timesfm-forecasting','statistical-analysis','statsmodels','matplotlib','exploratory-data-analysis']
  },
  {
    id:'prompt-eng', label:'✍️ 프롬프트 엔지니어링', color:'#7c3aed',
    desc:'Claude/GPT 프롬프트 최적화',
    skills:['anthropic-prompt-engineer','openai-prompt-engineer','anthropic-architect','sequential-thinking']
  },
  {
    id:'fab-semiconductor', label:'🏭 반도체/FAB', color:'#475569',
    desc:'FAB 공정 데이터 분석, 통계, 시각화',
    skills:['exploratory-data-analysis','statistical-analysis','matplotlib','seaborn','polars','agent-data-scientist','scikit-learn']
  },
  {
    id:'knowledge-domain', label:'📖 지식 도메인', color:'#0d9488',
    desc:'도메인 지식/FAB 컬럼/아키텍처 검색',
    skills:['knowledge-search']
  },
  {
    id:'logpresso-query', label:'🔍 로그프레소 쿼리', color:'#2563eb',
    desc:'LPQL 쿼리 생성 전문가',
    skills:['logpresso-query']
  },
  {
    id:'logpresso-search', label:'🔎 로그프레소 조회', color:'#1d4ed8',
    desc:'로그프레소 서버 직접 조회/검색',
    skills:['logpresso-search']
  },
  {
    id:'superpowers', label:'⚡ 슈퍼파워', color:'#eab308',
    desc:'8개 행동 메타 스킬 — 브레인스토밍/TDD/디버깅/검증/리뷰 세트',
    skills:['using-superpowers','brainstorming','writing-plans','test-driven-development','systematic-debugging','verification-before-completion','writing-skills','requesting-code-review']
  },
];

function renderCombos(){
  const grid = document.getElementById('comboGrid');
  if(!grid) return;
  grid.innerHTML = '';
  SKILL_COMBOS.forEach(combo=>{
    const allSelected = combo.skills.every(sid=>selSkills.includes(sid));
    const someSelected = !allSelected && combo.skills.some(sid=>selSkills.includes(sid));
    const borderColor = allSelected ? '#ef4444' : someSelected ? '#f59e0b' : combo.color+'22';
    const bgColor = allSelected ? '#ef444410' : someSelected ? '#f59e0b08' : combo.color+'06';
    const card = document.createElement('div');
    card.style.cssText = `width:calc(50% - 4px);padding:10px 12px;border-radius:8px;border:2px solid ${borderColor};background:${bgColor};cursor:pointer;transition:all .15s;user-select:none;`;
    card.title = allSelected ? '클릭하면 이 조합을 해제합니다' : '클릭하면 이 스킬들이 추가됩니다 (기존 선택 유지)';
    card.onmouseenter = ()=>{ card.style.background=combo.color+'14'; };
    card.onmouseleave = ()=>{ card.style.background=bgColor; };
    card.onclick = ()=>{ applyCombo(combo); };
    const statusBadge = allSelected ? '<span style="font-size:10px;background:#ef4444;color:#fff;padding:1px 6px;border-radius:4px;margin-left:6px;">적용중</span>' : someSelected ? '<span style="font-size:10px;background:#f59e0b;color:#fff;padding:1px 6px;border-radius:4px;margin-left:6px;">일부</span>' : '';
    const skillTags = combo.skills.map(sid=>{
      const koName = _comboSkillNames[sid] || sid;
      const isOn = selSkills.includes(sid);
      const tagBg = isOn ? '#ef444420' : combo.color+'12';
      const tagColor = isOn ? '#ef4444' : combo.color;
      const check = isOn ? '✓ ' : '';
      return `<span style="display:inline-block;background:${tagBg};color:${tagColor};padding:1px 6px;border-radius:4px;font-size:10px;margin:1px;font-weight:${isOn?700:400}">${check}${koName}</span>`;
    }).join('');
    card.innerHTML = `<div style="font-size:13px;font-weight:700;color:${combo.color};margin-bottom:3px;">${combo.label}${statusBadge}</div>
      <div style="font-size:11px;color:#64748b;margin-bottom:5px;">${combo.desc}</div>
      <div style="line-height:1.8;">${skillTags}</div>`;
    grid.appendChild(card);
  });
  updateComboActiveMsg();
}
// 스킬 ID → 짧은 한국어 이름 매핑
const _comboSkillNames = {
  'exploratory-data-analysis':'탐색적분석','statistical-analysis':'통계분석','matplotlib':'Matplotlib','seaborn':'Seaborn',
  'plotly':'Plotly','polars':'Polars','agent-data-scientist':'데이터과학자','xlsx':'엑셀','agent-python-pro':'Python전문가',
  'agent-fullstack-developer':'풀스택','debugging':'디버깅','agent-debugger':'디버거','code-review':'코드리뷰',
  'agent-backend-developer':'백엔드','agent-frontend-developer':'프론트엔드','scikit-learn':'Scikit-learn',
  'pytorch-lightning':'PyTorch','shap':'SHAP해석','umap-learn':'UMAP','statsmodels':'통계모델',
  'docx':'Word','pptx':'PPT','pdf':'PDF','scientific-writing':'논문작성','markdown-mermaid-writing':'마크다운',
  'drawio-diagram':'Draw.io','literature-review':'문헌리뷰','citation-management':'인용관리',
  'pubmed-database':'PubMed','openalex-database':'OpenAlex','biorxiv-database':'bioRxiv','peer-review':'논문심사',
  'scientific-visualization':'과학시각화','scientific-schematics':'과학다이어그램','infographics':'인포그래픽',
  'agent-react-specialist':'React','agent-nextjs-developer':'Next.js','databases':'데이터베이스',
  'frontend-development':'프론트개발','backend-development':'백엔드개발',
  'devops':'DevOps','agent-cloud-architect':'클라우드설계','agent-devops-engineer':'DevOps엔지니어',
  'agent-docker-expert':'Docker','agent-kubernetes-specialist':'K8s','agent-terraform-engineer':'Terraform',
  'skill-creator':'스킬제작','anthropic-prompt-engineer':'Anthropic프롬프트','engineer-skill-creator':'엔지니어스킬',
  'anthropic-architect':'Anthropic설계','aeon':'시계열ML','timesfm-forecasting':'시계열예측',
  'openai-prompt-engineer':'OpenAI프롬프트','sequential-thinking':'순차사고',
  'knowledge-search':'지식검색','logpresso-query':'LPQL쿼리','logpresso-search':'로그조회',
};

function applyCombo(combo){
  const allSelected = combo.skills.every(sid=>selSkills.includes(sid));
  if(allSelected){
    // 이 조합의 스킬만 제거 (다른 조합 스킬은 유지)
    selSkills = selSkills.filter(sid=>!combo.skills.includes(sid));
  } else {
    // 이 조합의 스킬을 기존에 추가 (중복 제거)
    combo.skills.forEach(sid=>{
      if(!selSkills.includes(sid)) selSkills.push(sid);
    });
  }
  // 자동 스킬 선택 OFF + 자동 스킬 비우기
  autoLoadedSkills = [];
  if(autoSkillMode){
    autoSkillMode = false;
    const toggle = document.getElementById('autoSkillToggle');
    if(toggle) toggle.classList.remove('on');
  }
  // 관련 도메인 자동 활성화
  if(catalog){
    Object.keys(catalog).forEach(did=>{
      const domainSkills = (catalog[did].skills||[]).map(s=>s.id);
      if(combo.skills.some(sid=>domainSkills.includes(sid)) && !selDomains.includes(did)){
        selDomains.push(did);
      }
    });
    renderTags();
  }
  renderSkills();
  updateLoaded();
  renderCombos();
  updateComboActiveMsg();
}
function updateComboActiveMsg(){
  const msgEl = document.getElementById('comboActiveMsg');
  const clearWrap = document.getElementById('comboClearWrap');
  if(!msgEl) return;
  const active = SKILL_COMBOS.filter(c=>c.skills.every(sid=>selSkills.includes(sid)));
  const hasAny = selSkills.length > 0;
  if(clearWrap) clearWrap.style.display = hasAny ? 'block' : 'none';
  if(active.length === 0){
    msgEl.style.display = hasAny ? 'block' : 'none';
    if(hasAny) msgEl.innerHTML = `🔗 총 <b>${selSkills.length}개</b> 스킬 선택됨`;
    return;
  }
  const labels = active.map(c=>c.label).join(' + ');
  msgEl.innerHTML = `🔗 <b>${active.length}개 조합 활성:</b> ${labels} — 총 <b>${selSkills.length}개</b> 스킬 선택됨`;
  msgEl.style.display = 'block';
}
function clearAllCombos(){
  selSkills = [];
  renderSkills();
  updateLoaded();
  renderCombos();
}

// 페이지 로드 시 콤보 렌더링
setTimeout(renderCombos, 500);

// 스킬 카드 자동 사용법 툴팁 생성
function _autoTip(id, desc){
  if(!desc) return '클릭하여 선택';
  // 에이전트 스킬: "agent-xxx"
  if(id.startsWith('agent-')){
    const role = id.replace('agent-','').replace(/-/g,' ');
    return `${desc}\n📌 이럴 때: 전문가 수준의 ${role} 작업이 필요할 때\n💡 사용법: "${role} 관점에서 분석해줘"`;
  }
  // 데이터베이스 스킬: "xxx-database"
  if(id.endsWith('-database')){
    const db = id.replace('-database','').replace(/-/g,' ');
    return `${desc}\n📌 이럴 때: ${db} 데이터를 검색하거나 조회할 때\n💡 사용법: "${db}에서 [키워드] 검색해줘"`;
  }
  // 시각화 스킬
  if(['matplotlib','seaborn','plotly','scientific-visualization'].includes(id)){
    return `${desc}\n📌 이럴 때: 데이터를 그래프/차트로 시각화할 때\n💡 사용법: "데이터를 [차트 종류]로 그려줘"`;
  }
  // 문서 생성 스킬
  if(['pptx','docx','xlsx','pdf','markdown-mermaid-writing','scientific-writing'].includes(id)){
    const fmt = {pptx:'PPT',docx:'Word',xlsx:'엑셀',pdf:'PDF'}[id] || '문서';
    const when = {pptx:'발표 자료가 필요할 때',docx:'보고서/문서를 작성할 때',xlsx:'스프레드시트를 만들거나 편집할 때',pdf:'PDF를 읽거나 생성할 때'}[id] || '문서를 작성할 때';
    return `${desc}\n📌 이럴 때: ${when}\n💡 사용법: "[내용]을 ${fmt}로 만들어줘"`;
  }
  // ML/통계 스킬
  if(['scikit-learn','pytorch-lightning','statistical-analysis','shap','umap-learn','statsmodels'].includes(id)){
    const when = {'scikit-learn':'분류/회귀/클러스터링 모델을 만들 때','pytorch-lightning':'딥러닝 모델을 학습할 때','statistical-analysis':'통계 검정/분석이 필요할 때','shap':'모델의 예측 이유를 설명할 때','umap-learn':'고차원 데이터를 2D로 축소할 때','statsmodels':'회귀/시계열 통계 모델링할 때'}[id] || '데이터 분석/모델링할 때';
    return `${desc}\n📌 이럴 때: ${when}\n💡 사용법: "이 데이터로 [분석/모델링] 해줘"`;
  }
  // 데이터 처리 스킬
  if(['polars','dask','vaex','exploratory-data-analysis','networkx'].includes(id)){
    const when = {polars:'대용량 CSV/데이터를 빠르게 처리할 때',dask:'메모리보다 큰 데이터를 처리할 때',vaex:'수억 건 데이터를 탐색할 때','exploratory-data-analysis':'데이터를 처음 받아서 전체 파악할 때',networkx:'관계/네트워크 데이터를 분석할 때'}[id];
    return `${desc}\n📌 이럴 때: ${when}\n💡 사용법: "이 데이터 분석해줘"`;
  }
  // 화학/분자 스킬
  if(['rdkit','datamol','deepchem','molfeat','matchms','medchem','diffdock','molecular-dynamics','torchdrug'].includes(id)){
    return `${desc}\n📌 이럴 때: 분자 구조 분석/약물 설계/화학 데이터 처리할 때\n💡 사용법: "[SMILES/분자명]을 분석해줘"`;
  }
  // 생물정보학 스킬
  if(['biopython','scanpy','pydeseq2','bioservices','anndata','scvelo','scvi-tools','pysam'].includes(id)){
    return `${desc}\n📌 이럴 때: 유전체/단백질/단일세포 데이터를 분석할 때\n💡 사용법: "[유전자명/서열]을 분석해줘"`;
  }
  // 디버깅 스킬
  if(['debugging','agent-debugger'].includes(id)){
    return `${desc}\n📌 이럴 때: 코드 에러를 찾거나 수정할 때\n💡 사용법: "이 에러 원인 찾아줘" + 에러 메시지 붙여넣기`;
  }
  // 가이드/메타 스킬
  if(['skill-creator','anthropic-prompt-engineer','openai-prompt-engineer','anthropic-architect','engineer-skill-creator'].includes(id)){
    const when = {'skill-creator':'새로운 Claude 스킬을 만들 때','anthropic-prompt-engineer':'Claude용 프롬프트를 최적화할 때','openai-prompt-engineer':'GPT용 프롬프트를 작성할 때','anthropic-architect':'AI 시스템 아키텍처를 설계할 때','engineer-skill-creator':'전문가 지식을 스킬로 변환할 때'}[id];
    return `${desc}\n📌 이럴 때: ${when}\n💡 사용법: 관련 요청을 하면 자동 활성화`;
  }
  // 양자 컴퓨팅
  if(['qiskit','cirq','pennylane','qutip'].includes(id)){
    return `${desc}\n📌 이럴 때: 양자 회로/시뮬레이션 작업할 때\n💡 사용법: "양자 회로 만들어줘"`;
  }
  // 기본: description 기반
  return `${desc}\n📌 이럴 때: ${desc} 작업이 필요할 때\n💡 사용법: 관련 질문을 입력하면 자동으로 활성화됩니다`;
}
const _skillTips = {
  'matplotlib':'그래프/차트를 그려줍니다\n예: "데이터를 막대 차트로 그려줘"',
  'seaborn':'예쁜 통계 차트를 만들어줍니다\n예: "상관관계 히트맵 그려줘"',
  'plotly':'인터랙티브 차트를 만듭니다\n예: "줌 가능한 꺾은선 차트 만들어줘"',
  'scikit-learn':'머신러닝 모델을 만들어줍니다\n예: "이 데이터로 예측 모델 만들어줘"',
  'statistical-analysis':'통계 분석을 해줍니다\n예: "평균, 분산, 상관관계 분석해줘"',
  'exploratory-data-analysis':'데이터를 탐색하고 요약합니다\n예: "CSV 데이터 전체 분석해줘"',
  'polars':'대용량 데이터를 빠르게 처리합니다\n예: "CSV 파일 읽고 필터링해줘"',
  'agent-data-scientist':'데이터 분석 전문가처럼 답합니다\n예: "이 데이터의 패턴을 찾아줘"',
  'agent-python-pro':'파이썬 코드를 작성해줍니다\n예: "파일 읽는 함수 만들어줘"',
  'scientific-writing':'논문/보고서를 작성합니다\n예: "분석 결과를 보고서로 정리해줘"',
  'pptx':'PPT 파일을 생성합니다\n예: "분석 결과를 PPT로 만들어줘"',
  'docx':'Word 문서를 만들어줍니다\n예: "보고서를 Word로 만들어줘"',
  'xlsx':'엑셀 파일을 처리합니다\n예: "엑셀 데이터 정리해줘"',
  'drawio-diagram':'다이어그램을 그려줍니다\n예: "시스템 구조도 그려줘"',
  'biopython':'유전자/단백질 분석을 합니다\n예: "DNA 서열 분석해줘"',
  'rdkit':'분자 구조를 분석합니다\n예: "화학 분자 그려줘"',
  'debugging':'에러를 찾아 고쳐줍니다\n예: "이 에러 원인 찾아줘"',
  'agent-debugger':'버그를 추적하고 수정합니다\n예: "traceback 분석해줘"',
  'logpresso-search':'로그프레소 데이터를 조회합니다\n예: "오늘 설비 로그 조회해줘"',
  'knowledge-search':'도메인 지식을 검색합니다\n예: "FAB 컬럼 정보 알려줘"',
  'agent-cloud-architect':'클라우드 아키텍처를 설계합니다\n예: "AWS 배포 구조 설계해줘"',
  'agent-llm-architect':'LLM 시스템을 설계합니다\n예: "RAG 파이프라인 설계해줘"',
  'markdown-mermaid-writing':'마크다운/다이어그램을 작성합니다\n예: "플로우차트 그려줘"',
  'scientific-visualization':'과학 데이터를 시각화합니다\n예: "실험 결과를 그래프로 보여줘"',
  'agent-sql-pro':'SQL 쿼리를 작성해줍니다\n예: "테이블 조인 쿼리 만들어줘"',
  'agent-fullstack-developer':'웹앱을 개발합니다\n예: "로그인 페이지 만들어줘"',
  'pdf':'PDF 파일을 처리합니다\n예: "PDF에서 텍스트 추출해줘"',
  'market-research-reports':'시장조사 보고서를 작성합니다\n예: "시장 트렌드 보고서 만들어줘"',
};
let currentSessionId = null;
let sessions = {};

// ===== Init =====
loadSessions();
// Restore last session or create new
const lastSessions = Object.values(sessions).sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0));
if(lastSessions.length > 0){
  currentSessionId = lastSessions[0].id;
  const s = lastSessions[0];
  history = s.history || [];
  setTimeout(()=>{
    document.getElementById('msgs').innerHTML = s.msgsHtml || '';
    injectDeleteButtons();
    if(s.writingStyle){ document.getElementById('writingStyle').value = s.writingStyle; syncStyleDropToSidebar(); }
    if(s.systemPrompt) document.getElementById('systemPromptInput').value = s.systemPrompt;
    if(s.systemPromptId){ currentPromptId=s.systemPromptId; renderPromptChips(); }
    if(s.thinkMode!==undefined) document.getElementById('thinkToggle').checked=s.thinkMode;
    if(s.selFormat){ selFormat=s.selFormat; formatManualOverride=(selFormat!=='auto'); document.querySelectorAll('.fmt-btn').forEach(b=>{b.classList.toggle('selected',b.dataset.f===selFormat);}); syncFormatDropToChat(); }
    if(s.effort!==undefined){ effort=s.effort; document.getElementById('effortSlider').value=effort; }
    if(s.selEnvs){ selEnvs=s.selEnvs; renderEnvs(); updateStatus(); }
    else if(s.selEnv){ selEnvs=[s.selEnv]; renderEnvs(); updateStatus(); }  // 하위호환
    if(s.selDomains && s.selDomains.length>0){ selDomains=s.selDomains; renderTags(); renderSkills(); }
    if(s.selSkills && s.selSkills.length>0){ selSkills=s.selSkills; renderSkills(); updateLoaded(); }
    renderSessionList();
    // 페이지 로드 시 차트 재렌더링 (Chart.js 로드 대기)
    const _initCharts=()=>{
      document.querySelectorAll('#msgs canvas[data-chart-json]').forEach(cv=>{
        try{renderChartBlock(cv.id, b2u(cv.dataset.chartJson));}
        catch(e){cv.parentElement.innerHTML='<p style="color:red;padding:12px;">차트 렌더링 실패: '+e.message+'</p>';}
      });
    };
    if(typeof Chart!=='undefined') _initCharts();
    else setTimeout(_initCharts, 500);
  }, 100);
} else {
  currentSessionId = 'sess_'+Date.now();
  sessions[currentSessionId] = { id:currentSessionId, name:'새 세션', history:[], msgsHtml:'', updatedAt:Date.now() };
  saveSessions();
}

Promise.all([
  fetch('/api/config').then(r=>r.json()),
  fetch('/api/skills').then(r=>r.json()),
]).then(([cfgData, skillData])=>{
  envs = cfgData.envs || {};
  hasToken = cfgData.has_token;
  catalog = skillData || {};
  try{ renderTokenStatus(); }catch(e){ console.error('renderTokenStatus:',e); }
  try{ renderEnvs(); }catch(e){ console.error('renderEnvs:',e); }
  try{ renderTags(); }catch(e){ console.error('renderTags:',e); }
  try{ renderSkills(); }catch(e){ console.error('renderSkills:',e); }
  try{ renderSessionList(); }catch(e){ console.error('renderSessionList:',e); }
}).catch(err=>{
  console.error('설정 로드 실패:', err);
  document.getElementById('tokenStatus').className='token-status missing';
  document.getElementById('tokenStatus').textContent='❌ 서버 연결 실패 - 새로고침 해주세요';
  document.getElementById('tokenBadge').className='status off';
  document.getElementById('tokenBadge').textContent='❌ 연결 실패';
});

// ===== 환경 선택 =====
function toggleEnvSection(type){
  const target = type==='Api' ? document.getElementById('envApiInner') : document.getElementById('envRowGguf');
  const arrow = document.getElementById('envArrow'+type);
  if(target.style.display==='none'){
    target.style.display='';
    arrow.textContent='▼';
  } else {
    target.style.display='none';
    arrow.textContent='▶';
  }
}
function _envType(id){ return id.startsWith('gguf-') ? 'gguf' : 'api'; }
function _makeEnvBtn(id, env, icons){
  const btn = document.createElement('div');
  const isSel = selEnvs.includes(id);
  btn.className = 'env-btn' + (isSel?' selected':'');
  const idx = isSel ? selEnvs.indexOf(id)+1 : 0;
  const badge = selEnvs.length > 1 && isSel ? `<span style="position:absolute;top:4px;right:6px;background:#6366f1;color:#fff;border-radius:50%;width:20px;height:20px;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:bold">${idx}</span>` : '';
  btn.style.position='relative';
  btn.innerHTML = `${badge}<div class="env-name">${icons[id]||'🔗'} ${env.name}</div><div class="env-model">${env.model}</div>`;
  btn.onclick = ()=>{
    // 단일 선택만 허용 (병렬 제거)
    if(selEnvs.includes(id)){
      selEnvs = ['auto'];
    } else {
      selEnvs = [id];
    }
    renderEnvs(); updateStatus();
  };
  return btn;
}
function renderEnvs(){
  const rowAuto = document.getElementById('envRowAuto');
  const rowHigh = document.getElementById('envRowHigh');
  const rowMid = document.getElementById('envRowMid');
  const rowLow = document.getElementById('envRowLow');
  const rowVl = document.getElementById('envRowVl');
  const rowGguf = document.getElementById('envRowGguf');
  rowAuto.innerHTML=''; rowHigh.innerHTML=''; rowMid.innerHTML=''; rowLow.innerHTML=''; rowVl.innerHTML=''; rowGguf.innerHTML='';
  const icons = {'dev':'🧪','coder-480b':'🚀','coder-next':'⚡','coder-next-common':'⚡','common':'🌐','summary':'📊','vl-medium':'👁️','vl-fast':'👁️','vl-common':'👁️','vl-common-30b':'👁️','vl-small':'👁️'};
  for(const id of Object.keys(envs)){ if(id.startsWith('gguf-')) icons[id]='💻'; }
  // AUTO 버튼
  const autoBtn = document.createElement('div');
  autoBtn.className = 'env-btn' + (selEnvs.includes('auto')?' selected':'');
  autoBtn.style.cssText = 'flex:1 1 100%;max-width:100%';
  autoBtn.innerHTML = '<div class="env-name">🤖 AUTO</div><div class="env-model">자동 모델 선택</div>';
  autoBtn.onclick = ()=>{ selEnvs=['auto']; renderEnvs(); updateStatus(); };
  rowAuto.appendChild(autoBtn);
  // API / GGUF 분류
  // API 모델 tier 분류
  const highIds = new Set(['coder-480b','summary']);
  const lowIds = new Set(['common']);
  let hasApi=false, hasGguf=false, hasHigh=false, hasMid=false, hasLow=false, hasVl=false;
  for(const [id, env] of Object.entries(envs)){
    if(id.startsWith('gguf-')){
      rowGguf.appendChild(_makeEnvBtn(id, env, icons));
      hasGguf = true;
    } else if(id.startsWith('vl-')){
      rowVl.appendChild(_makeEnvBtn(id, env, icons));
      hasVl = true; hasApi = true;
    } else if(highIds.has(id)){
      rowHigh.appendChild(_makeEnvBtn(id, env, icons));
      hasHigh = true; hasApi = true;
    } else if(lowIds.has(id)){
      rowLow.appendChild(_makeEnvBtn(id, env, icons));
      hasLow = true; hasApi = true;
    } else {
      rowMid.appendChild(_makeEnvBtn(id, env, icons));
      hasMid = true; hasApi = true;
    }
  }
  document.getElementById('envHighLabel').style.display = hasHigh ? '' : 'none';
  document.getElementById('envMidLabel').style.display = hasMid ? '' : 'none';
  document.getElementById('envLowLabel').style.display = hasLow ? '' : 'none';
  document.getElementById('envVlLabel').style.display = hasVl ? '' : 'none';
  document.getElementById('envSectionApi').style.display = hasApi ? '' : 'none';
  document.getElementById('envSectionGguf').style.display = hasGguf ? '' : 'none';
}
function renderTokenStatus(){
  const el = document.getElementById('tokenStatus');
  const badge = document.getElementById('tokenBadge');
  if(hasToken){
    el.className='token-status ok';
    el.textContent='🔑 TOKEN.TXT 로드됨 - API 키 자동 적용';
    badge.className='status on';
    badge.textContent='🔑 토큰 OK';
  } else {
    el.className='token-status ok';
    el.textContent='ℹ️ TOKEN.TXT 미설정 - 폐쇄망 API는 토큰 없이 사용 가능합니다';
    badge.className='status on';
    badge.textContent='🔗 토큰 선택';
  }
}
function updateStatus(){
  const st = document.getElementById('status');
  const eb = document.getElementById('envStatusBadge');
  if(selEnvs.includes('auto')){
    st.className='status on';
    st.textContent='🤖 AUTO (자동 선택)';
    if(eb) eb.innerHTML='( 🤖 AUTO - 단일/병렬 자동 결정 )';
  } else if(selEnvs.length >= 2){
    const type = selEnvs[0].startsWith('gguf-') ? 'GGUF' : 'API';
    const names = selEnvs.map(e=> envs[e] ? envs[e].name : e).join(', ');
    st.className='status on';
    st.textContent='🔀 병렬 ' + selEnvs.length + '개 모델';
    if(eb) eb.innerHTML=`( 🔀 병렬 ${selEnvs.length}개 ${type}: ${names} )`;
  } else if(selEnvs.length === 1 && envs[selEnvs[0]]){
    const type = selEnvs[0].startsWith('gguf-') ? 'GGUF' : 'API';
    st.className='status on';
    st.textContent='🟢 ' + envs[selEnvs[0]].name;
    if(eb) eb.innerHTML=`( 🟢 단일 ${type}: ${envs[selEnvs[0]].name} )`;
  } else {
    st.className='status off';
    st.textContent='⚪ 환경 미선택';
    if(eb) eb.innerHTML='';
  }
}

// ===== Tags =====
function renderTags(){
  const row = document.getElementById('tagRow');
  row.innerHTML = '';
  for(const [id, d] of Object.entries(catalog)){
    const t = document.createElement('div');
    t.className = 'tag' + (selDomains.includes(id)?' selected':'');
    t.style.setProperty('--c', d.color);
    t.style.setProperty('--bg', d.color+'18');
    t.style.setProperty('--fg', d.color);
    t.textContent = d.icon + ' ' + d.label;
    t.onclick = ()=>{ toggleDomain(id); t.classList.toggle('selected'); renderSkills(); };
    row.appendChild(t);
  }
}
function toggleDomain(id){
  if(selDomains.includes(id)) selDomains=selDomains.filter(x=>x!==id);
  else selDomains.push(id);
}

// ===== Skills =====
let autoLoadedSkills = [];  // 자동 로드된 스킬 목록 (시각적 표시용)

function renderSkills(){
  const grid = document.getElementById('skillGrid');
  grid.innerHTML = '';
  selDomains.forEach(did=>{
    const d = catalog[did];
    if(!d) return;
    d.skills.forEach(s=>{
      const c = document.createElement('div');
      const isAutoLoaded = autoLoadedSkills.includes(s.id);
      c.className = 'skill-card' + (selSkills.includes(s.id)?' selected':'') + (isAutoLoaded?' auto-loaded':'') + (!s.available?' unavailable':'');
      const desc = s.desc ? s.desc : '';
      const avail = s.available ? '✅' : '❌';
      // extras: 스크립트/레퍼런스 개수
      let extras = [];
      if(s.scripts > 0) extras.push(`🐍${s.scripts}`);
      if(s.references > 0) extras.push(`📄${s.references}`);
      if(s.assets > 0) extras.push(`📦${s.assets}`);
      const extrasHtml = extras.length ? `<div class="extras">${extras.join(' ')}</div>` : '';
      const autoBadge = isAutoLoaded ? '<span class="badge" style="background:#f59e0b">🧠자동</span>' : '';
      const tipText = _skillTips[s.id] || _autoTip(s.id, desc);
      c.title = `${s.name}\n${tipText}\n\n[클릭=선택, Shift+클릭=상세]`;
      c.innerHTML = `<div class="sn">${avail} ${s.name}</div><div class="sd">${desc}</div>${extrasHtml}${autoBadge}`;
      if(s.available){
        c.onclick = (e)=>{
          // Shift+클릭 = 상세 패널
          if(e.shiftKey || (extras.length > 0 && e.detail === 2)){
            openSkillDetail(s.id);
            return;
          }
          if(selSkills.includes(s.id)) selSkills=selSkills.filter(x=>x!==s.id);
          else selSkills.push(s.id);
          // 수동 선택 시 자동 스킬 전부 해제
          if(selSkills.length > 0){ autoLoadedSkills = []; }
          renderSkills();
          updateLoaded();
        };
        // 우클릭 = 상세 패널
        c.oncontextmenu = (e)=>{
          e.preventDefault();
          openSkillDetail(s.id);
        };
      }
      grid.appendChild(c);
    });
  });
  updateLoaded();
}
function updateLoaded(){
  const totalCount = selSkills.length + autoLoadedSkills.length;
  const countEl = document.getElementById('loadedCount');
  if(countEl) countEl.textContent = totalCount;
  const el = document.getElementById('loadedSkillsList');
  if(!el) return;  // 사이드바에서 제거된 경우
  if(totalCount === 0 && dismissedAutoSkills.size === 0){
    el.innerHTML = '<div style="color:#bbb">선택된 스킬 없음</div>';
    return;
  }
  // 수동 선택 스킬 (체크박스로 해제 가능)
  let html = selSkills.map(s =>
    `<label style="display:flex;align-items:center;gap:4px;padding:2px 0;cursor:pointer;">
      <input type="checkbox" checked onchange="unloadSkill('${s}')" style="accent-color:#4f46e5;cursor:pointer;">
      <span style="font-size:12px">✅ ${s}</span>
    </label>`
  ).join('');
  // 자동 추천 스킬 (1회성, 📌으로 수동 고정 / ✕로 해제)
  if(autoLoadedSkills.length > 0){
    html += autoLoadedSkills.map(s =>
      `<div style="display:flex;align-items:center;justify-content:space-between;padding:2px 0;opacity:.8;">
        <span style="font-size:12px">🧠 ${s}</span>
        <span style="display:flex;gap:2px;">
          <button onclick="pinAutoSkill('${s}')" style="background:none;border:none;cursor:pointer;font-size:10px;color:#4f46e5;padding:0 2px;" title="수동 고정">📌</button>
          <button onclick="dismissAutoSkill('${s}')" style="background:none;border:none;cursor:pointer;font-size:10px;color:#ef4444;padding:0 2px;" title="해제 (다시 추천 안함)">✕</button>
        </span>
      </div>`
    ).join('');
  }
  // 해제된 자동 스킬 (블랙리스트) 표시
  if(dismissedAutoSkills.size > 0){
    html += `<div style="margin-top:6px;padding-top:6px;border-top:1px dashed #e5e3de;">
      <div style="font-size:10px;color:#9ca3af;margin-bottom:3px;">🚫 해제됨 (자동추천 제외)</div>`;
    html += [...dismissedAutoSkills].map(s =>
      `<div style="display:flex;align-items:center;justify-content:space-between;padding:1px 0;opacity:.5;">
        <span style="font-size:11px;text-decoration:line-through;color:#9ca3af;">${s}</span>
        <button onclick="restoreDismissedSkill('${s}')" style="background:none;border:none;cursor:pointer;font-size:10px;color:#22c55e;padding:0 2px;" title="복구 (자동추천 허용)">♻️</button>
      </div>`
    ).join('');
    if(dismissedAutoSkills.size >= 2){
      html += `<button onclick="clearDismissed()" style="width:100%;margin-top:3px;padding:2px 0;font-size:10px;background:#fef2f2;border:1px solid #fecaca;border-radius:4px;cursor:pointer;color:#ef4444;">전체 복구</button>`;
    }
    html += `</div>`;
  }
  if(selSkills.length + autoLoadedSkills.length >= 2){
    html += `<button onclick="unloadAllSkills()" style="width:100%;margin-top:4px;padding:3px 0;font-size:11px;background:#f5f5f0;border:1px solid #e5e3de;border-radius:4px;cursor:pointer;color:#888;">전체 해제</button>`;
  }
  el.innerHTML = html;
}
let dismissedAutoSkills = new Set();  // 사용자가 해제한 자동 스킬 (세션 내 재로드 방지)

function unloadSkill(id){
  selSkills = selSkills.filter(x => x !== id);
  // 자동 스킬이면 해제 블랙리스트에 추가
  if(autoLoadedSkills.includes(id)){
    autoLoadedSkills = autoLoadedSkills.filter(x => x !== id);
    dismissedAutoSkills.add(id);
  }
  renderSkills();
  updateLoaded();
}
function unloadAllSkills(){
  // 자동 스킬 모두 블랙리스트에 추가
  autoLoadedSkills.forEach(id => dismissedAutoSkills.add(id));
  selSkills = [];
  autoLoadedSkills = [];
  renderSkills();
  updateLoaded();
}
function pinAutoSkill(id){
  // 자동 스킬을 수동 고정으로 전환 → 블랙리스트에서 제거
  autoLoadedSkills = autoLoadedSkills.filter(x => x !== id);
  dismissedAutoSkills.delete(id);
  if(!selSkills.includes(id)) selSkills.push(id);
  renderSkills();
  updateLoaded();
}
function dismissAutoSkill(id){
  // 자동 스킬을 블랙리스트로 이동 (다시 추천 안함)
  autoLoadedSkills = autoLoadedSkills.filter(x => x !== id);
  dismissedAutoSkills.add(id);
  renderSkills();
  updateLoaded();
}
function dismissPreviewSkill(id, btn){
  // 미리보기에서 자동 스킬 제외 (전송 시 사용 안함)
  dismissedAutoSkills.add(id);
  autoLoadedSkills = autoLoadedSkills.filter(x => x !== id);
  const badge = btn.closest('.auto-skill-badge');
  if(badge) badge.remove();
  const prev = document.getElementById('autoSkillPreview');
  if(prev && prev.querySelectorAll('.auto-skill-badge').length === 0){
    prev.classList.remove('show');
  }
  updateLoaded();
}
function restoreDismissedSkill(id){
  // 블랙리스트에서 복구 (다음 자동 추천 허용)
  dismissedAutoSkills.delete(id);
  updateLoaded();
}
function clearDismissed(){
  // 블랙리스트 전체 초기화
  dismissedAutoSkills.clear();
  updateLoaded();
}

// ===== Effort =====
function updateEffort(){
  const s = document.getElementById('effortSlider');
  effort = parseInt(s.value);
  s.style.setProperty('--val', (effort/3*100)+'%');
  for(let i=0;i<=3;i++) document.getElementById('e'+i).className = i===effort?'active':'';
}
updateEffort();

// ===== Format =====
function selFmt(el){
  document.querySelectorAll('.fmt-btn').forEach(b=>b.classList.remove('selected'));
  el.classList.add('selected');
  selFormat = el.dataset.f;
  formatManualOverride = (selFormat !== 'auto');  // auto 선택 시 자동 모드로 복귀
  syncFormatDropToChat();
}

// ===== Quick prompt =====
function qp(t){ document.getElementById('input').value=t; }

// ===== Auto Skill =====
function toggleAutoSkill(){
  autoSkillMode = !autoSkillMode;
  const el = document.getElementById('autoSkillToggle');
  el.classList.toggle('on', autoSkillMode);
  if(!autoSkillMode){
    document.getElementById('autoSkillPreview').classList.remove('show');
    document.getElementById('autoSkillPreview').innerHTML = '';
  }
}
// 초기 상태 반영
setTimeout(()=>{
  document.getElementById('autoSkillToggle').classList.toggle('on', autoSkillMode);
}, 200);

// 입력 중 자동 스킬 미리보기 (디바운스)
let autoSkillTimer = null;
document.addEventListener('DOMContentLoaded', ()=>{
  const inp = document.getElementById('input');
  if(inp) inp.addEventListener('input', ()=>{
    if(!autoSkillMode || selSkills.length > 0) return;
    clearTimeout(autoSkillTimer);
    autoSkillTimer = setTimeout(async ()=>{
      const q = inp.value.trim();
      if(q.length < 4) { document.getElementById('autoSkillPreview').classList.remove('show'); return; }
      try{
        const r = await fetch('/api/auto-skills',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({query:q,max_skills:3,history:history})});
        const d = await r.json();
        const prev = document.getElementById('autoSkillPreview');
        if(d.skills && d.skills.length > 0){
          prev.innerHTML = '🧠 자동 추천: ' + d.skills.filter(s=>!dismissedAutoSkills.has(s.id)).map(s=>{
            const tip = _skillTips[s.id] || s.desc || s.id;
            return `<span class="auto-skill-badge" title="${tip.replace(/"/g,'&quot;').replace(/\n/g,'&#10;')}">${s.id} (${s.score})<button onclick="dismissPreviewSkill('${s.id}',this)" style="background:none;border:none;cursor:pointer;font-size:10px;color:#ef4444;padding:0 2px;margin-left:4px;" title="제외">✕</button></span>`;
          }).join('');
          prev.classList.add('show');
        } else {
          prev.classList.remove('show');
        }
      }catch(e){}
    }, 500);
  });
});

// ===== Chat =====
let chatAbort = null;  // AbortController for current request
let isSending = false;

function handleSendStop(){
  if(isSending){
    stopGeneration();
  } else {
    send();
  }
}
function stopGeneration(){
  if(chatAbort){
    chatAbort.abort();
    chatAbort = null;
  }
  // 백엔드 GGUF 중단 요청
  fetch('/api/chat/stop',{method:'POST'}).catch(()=>{});
  isSending = false;
  const btn = document.getElementById('sendBtn');
  btn.textContent = '▶';
  btn.classList.remove('stop-mode');
  btn.disabled = false;
  // typing indicator 제거
  document.querySelectorAll('.typing-wrap').forEach(el=>el.remove());
  addMsg('assistant','⏹️ 응답이 중지되었습니다.');
  saveCurrentSession();
}

/* ── PPT 제안 배너 ── */
let _pptBannerShownCount = 0;
const _pptSuggestItems = [
  {icon:'📊', title:'차트/그래프를 포함할까요?', hint:'"매출 데이터를 막대 차트로 넣어줘"', example:'차트/그래프도 포함해서 PPT 만들어줘'},
  {icon:'📝', title:'그래프 없이 깔끔하게?', hint:'"그래프 없이 텍스트와 표로만 PPT 만들어줘"', example:'그래프 없이 텍스트와 표 위주로 PPT 만들어줘'},
  {icon:'📋', title:'표(Table)를 넣어볼까요?', hint:'"비교 데이터를 표로 정리해서 넣어줘"', example:'데이터를 표로 정리해서 PPT에 넣어줘'},
  {icon:'🖼️', title:'이미지/다이어그램도 가능해요!', hint:'"구조도를 슬라이드에 추가해줘"', example:'다이어그램도 포함해서 PPT 만들어줘'},
  {icon:'📈', title:'데이터 시각화를 추가할까요?', hint:'"트렌드를 꺾은선 그래프로 보여줘"', example:'데이터를 시각화해서 PPT에 넣어줘'},
  {icon:'🎨', title:'심플한 디자인으로?', hint:'"심플하게 핵심 내용만 PPT 만들어줘"', example:'디자인 심플하게 핵심만 PPT 만들어줘'},
  {icon:'🍩', title:'원형/도넛 차트는 어때요?', hint:'"비율을 도넛 차트로 만들어줘"', example:'비율 데이터를 원형 차트로 PPT에 넣어줘'},
  {icon:'📉', title:'비교 차트를 넣어볼까요?', hint:'"전년 대비 성장률을 비교 차트로"', example:'비교 차트를 포함해서 PPT 만들어줘'},
];

const _pptNoVisualItems = [
  {icon:'📝', title:'그래프 없이도 만들 수 있어요!', hint:'"그래프 없이 텍스트와 표로만 PPT 만들어줘"', example:'그래프 없이 텍스트와 표 위주로 PPT 다시 만들어줘'},
  {icon:'🎨', title:'심플한 PPT는 어때요?', hint:'"심플하게 핵심 내용만 PPT로"', example:'디자인 심플하게 핵심만 PPT 만들어줘'},
];
const _pptVisualItems = [
  {icon:'📊', title:'그래프를 추가해볼까요?', hint:'"차트/그래프도 포함해서 PPT 만들어줘"', example:'차트/그래프도 포함해서 PPT 다시 만들어줘'},
  {icon:'📈', title:'데이터 시각화는 어때요?', hint:'"데이터를 시각화해서 PPT에 넣어줘"', example:'데이터를 시각화해서 PPT에 넣어줘'},
];

function _showPptSuggestBanner(mode){
  if(_pptBannerShownCount >= 3) return;
  _pptBannerShownCount++;
  const area = document.getElementById('pptSuggestArea');
  if(!area) return;
  let pool;
  if(mode === 'no-visual') pool = _pptNoVisualItems;
  else if(mode === 'visual') pool = _pptVisualItems;
  else pool = _pptSuggestItems;
  const item = pool[Math.floor(Math.random()*pool.length)];
  const banner = document.createElement('div');
  banner.className = 'ppt-suggest-banner';
  banner.innerHTML = `<span class="ppt-banner-icon">${item.icon}</span>`
    + `<div class="ppt-banner-title">${item.title}</div>`
    + `<div class="ppt-banner-hint"><em onclick="_usePptSuggestion(this,'${item.example.replace(/'/g,"\\'")}')">${item.hint}</em> 처럼 말해보세요!</div>`
    + `<button class="ppt-banner-close" onclick="_closePptBanner(this)" title="닫기">✕</button>`;
  area.innerHTML = '';
  area.appendChild(banner);
  setTimeout(()=>{
    if(banner.parentNode){
      banner.classList.add('hiding');
      setTimeout(()=>{ if(banner.parentNode) banner.remove(); }, 400);
    }
  }, 8000);
}

function _closePptBanner(btn){
  const banner = btn.closest('.ppt-suggest-banner');
  if(banner){ banner.classList.add('hiding'); setTimeout(()=>banner.remove(), 400); }
}

function _usePptSuggestion(el, text){
  const input = document.getElementById('input');
  if(input){ input.value = text; input.focus(); input.style.height='auto'; input.style.height=input.scrollHeight+'px'; }
  const banner = el.closest('.ppt-suggest-banner');
  if(banner){ banner.classList.add('hiding'); setTimeout(()=>banner.remove(), 400); }
}

const _pptKeywords = /PPT|ppt|파워포인트|프레젠테이션|발표자료|슬라이드\s*만들|피피티/i;

async function send(){
  if(isSending) return;  // 응답 중이면 중복 전송 차단

  const el=document.getElementById('input');
  const text=el.value.trim();
  if(!text && chatPendingFiles.length === 0) return;

  if(text && _pptKeywords.test(text)){
    const hasVisual = /차트|그래프|표|table|chart|graph|시각화|도넛|원형/i.test(text);
    const hasNoVisual = /그래프\s*없|차트\s*없|텍스트\s*위주|텍스트만|심플하게/i.test(text);
    _showPptSuggestBanner(hasVisual && !hasNoVisual ? 'visual' : hasNoVisual && !hasVisual ? 'no-visual' : null);
  }
  if(!selEnvs||selEnvs.length===0){alert('먼저 위에서 LLM 환경을 선택해주세요.');return;}

  // 매 질문마다 이전 자동 스킬 초기화 → 새 질문/파일에 맞게 재감지
  // 전송 전 사용자가 dismiss한 스킬을 보존 (✕ 클릭한 것 반영)
  const currentDismissed = new Set(dismissedAutoSkills);
  autoLoadedSkills = [];
  dismissedAutoSkills.clear();
  updateLoaded();  // UI도 즉시 초기화

  // 첨부파일이 있으면 먼저 업로드 (파일 확장자 기반 스킬이 autoLoadedSkills에 추가됨)
  let attachedNames = [];
  if(chatPendingFiles.length > 0){
    attachedNames = await uploadChatPendingFiles();
  }

  // 스킬 구성: 수동 선택 시 해당 스킬만 사용, 미선택 시 자동 추천
  let skillsToUse = [...selSkills];
  let autoLoaded = [];

  if(selSkills.length === 0){
    // 수동 선택 없음 → 파일 기반 자동 + 질문 기반 자동 추천
    autoLoaded = [...autoLoadedSkills];
    const manualSet = new Set(skillsToUse);
    autoLoaded = autoLoaded.filter(id => !manualSet.has(id) && !currentDismissed.has(id));
    skillsToUse = [...skillsToUse, ...autoLoaded];

    // 자동 스킬 모드: 질문 분석으로 추가 보충
    if(autoSkillMode){
      try{
        const currentCount = skillsToUse.length;
        const maxAuto = currentCount === 0 ? 7 : Math.max(0, 10 - currentCount);
        if(maxAuto > 0){
          const ar = await fetch('/api/auto-skills',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({query:text,max_skills:maxAuto,history:history})});
          const ad = await ar.json();
          if(ad.skills && ad.skills.length > 0){
            const usedSet = new Set(skillsToUse);
            const newAuto = ad.skills.map(s=>s.id).filter(id=>!usedSet.has(id) && !currentDismissed.has(id));
            autoLoaded = [...autoLoaded, ...newAuto];
            skillsToUse = [...skillsToUse, ...newAuto];
          }
        }
      }catch(e){}
    }
  }
  // 수동 1개 선택 → 단일 에이전트, 수동 2개+ → 병렬 에이전트 (자동 추가 없음)

  // 첨부파일 표시 + 메시지
  let displayText = text || '';
  if(attachedNames.length > 0){
    const attachInfo = '📎 ' + attachedNames.join(', ');
    displayText = displayText ? attachInfo + '\n' + displayText : attachInfo;
  }
  addMsg('user', displayText);
  history.push({role:'user',content: displayText});
  el.value=''; el.style.height='auto';
  document.getElementById('autoSkillPreview').classList.remove('show');

  // 자동 로드 안내 (selSkills에는 추가하지 않음 - 1회성 사용)
  autoLoadedSkills = autoLoaded;
  renderSkills();
  updateLoaded();
  if(autoLoaded.length > 0){
    const manualCount = selSkills.length;
    const info = manualCount > 0 ? ` (수동 ${manualCount}개 + 자동 ${autoLoaded.length}개)` : '';
    addMsg('assistant', '🧠 자동 스킬: ' + autoLoaded.join(', ') + info);
  }

  const typing=addTyping();
  isSending = true;
  const btn = document.getElementById('sendBtn');
  btn.textContent = '⏹';
  btn.classList.add('stop-mode');
  btn.disabled = false;

  chatAbort = new AbortController();

  try{
    const resp=await fetch('/api/chat',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      signal: chatAbort.signal,
      body:JSON.stringify(Object.assign({
        env: selEnvs,
        messages:history, skills:skillsToUse, effort,
        format: formatManualOverride ? selFormat : 'auto',
        writing_style: styleManualOverride ? document.getElementById('writingStyle').value.trim() : 'auto',
        system_prompt:document.getElementById('systemPromptInput').value.trim(),
        think_mode: document.getElementById('thinkToggle').checked,
        ppt_style: activePptStyle ? (PPT_STYLE_PROMPTS[activePptStyle]||'') : '',
        ppt_ref_design: pptRefDesign,
        user_id: currentUser ? currentUser.id : null,
      }, maxTokens > 0 ? {max_tokens: maxTokens} : {}))
    });
    const data=await resp.json();
    typing.remove();

    if(data.error){
      addMsg('assistant','❌ '+data.error);
    } else {
      let info = '';
      // 모델 이름 표시 (auto/수동)
      let _se = selEnvs[0] || 'auto';
      let modelName = data.model_used || (envs[_se] ? envs[_se].name : (selEnvs.length>=2 ? selEnvs.length+'개 병렬' : _se));
      if(data.loaded_skills && data.loaded_skills.length > 0){
        let extra = data.tokens_budget ? ` [${data.tokens_budget}]` : '';
        let mode = autoLoaded.length > 0 ? '🧠자동' : '✅수동';
        info = `\n[${mode} 스킬: ${data.loaded_skills.join(', ')}] [${modelName}] (${data.system_prompt_length ?? 0}자)${extra}`;
      }
      // 자동 라우팅 표시
      if(data.auto_routed){
        info += ` [🤖 자동: ${data.model_used} (${data.route_reason})]`;
      }
      // 폴백 표시
      if(data.fallback_used){
        info += ` [⚠️ 대체: ${data.fallback_from} → ${data.model_used}]`;
      }
      // 병렬 에이전트 표시
      if(data.parallel_agents && data.parallel_agents >= 2){
        let pGroups = (data.parallel_groups || []).join(', ');
        let pModels = (data.parallel_models || []).join(', ');
        let pSynth = data.parallel_synthesis === 'fallback_concat' ? '(단순연결)' : '(합성)';
        info += ` [🔀 병렬 ${data.parallel_agents}에이전트: ${pGroups}] [모델: ${pModels}] ${pSynth}`;
        if(data.parallel_failed > 0) info += ` [⚠️ ${data.parallel_failed}개 실패]`;
      }
      // 자동 형식/스타일 표시
      if(data.auto_format || data.auto_style){
        let fmtNames = {'code':'코드','code-fix':'코드수정','analysis':'분석','report':'보고서','step-by-step':'단계별'};
        let parts = [];
        if(data.auto_format) parts.push('형식:' + (fmtNames[data.auto_format]||data.auto_format));
        if(data.auto_style) parts.push('스타일:자동');
        info += ` [📝 ${parts.join(' / ')}]`;
      }
      let truncWarn = data.truncated ? '\n\n⚠️ **응답이 토큰 한도('+maxTokens+')에 도달하여 잘렸습니다.** "계속 이어서 작성해줘"라고 입력하면 이어서 받을 수 있습니다.' : '';
      const assistantDisplayText = data.content + truncWarn + info;
      const assistantRawForDetect = data.content + truncWarn;
      addMsg('assistant', assistantDisplayText, assistantRawForDetect);
      history.push({role:'assistant',content:data.content});
      // markdown-mermaid-writing 또는 md-to-html 스킬: MD/HTML 다운로드 버튼 추가
      // selSkills(수동) 또는 autoLoadedSkills(자동) 모두 체크
      const _mdSkillActive = ['markdown-mermaid-writing','md-to-html'].some(s => selSkills.includes(s) || autoLoadedSkills.includes(s));
      if(_mdSkillActive && !data.content.includes('```markdown')){
        appendMdDownloadBar(data.content, data.html_download_url);
      }
    }
  }catch(e){
    typing.remove();
    if(e.name === 'AbortError'){
      // 사용자가 중지한 경우 - stopGeneration()에서 이미 처리됨
    } else {
      addMsg('assistant','❌ 서버 연결 실패: '+e.message);
    }
  }
  isSending = false;
  chatAbort = null;
  btn.textContent = '▶';
  btn.classList.remove('stop-mode');
  btn.disabled = false;
  const inp=document.getElementById('input');
  inp.focus();
  inp.style.height='auto';
  saveCurrentSession();
}

function renderMd(text){
  // 0) <think> 블록을 접이식 사고과정 박스로 변환 (HTML escape 전)
  text=text.replace(/<think>([\s\S]*?)<\/think>\s*/g, function(_,content){
    const escaped=content.trim().replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/\n/g,'<br>');
    return `<details class="think-box"><summary>💭 사고 과정</summary><div class="think-content">${escaped}</div></details>`;
  });
  // 닫히지 않은 <think> 태그도 처리 (응답 잘림 대비)
  text=text.replace(/<think>([\s\S]*)$/g, function(_,content){
    const escaped=content.trim().replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/\n/g,'<br>');
    return `<details class="think-box"><summary>💭 사고 과정 (진행중...)</summary><div class="think-content">${escaped}</div></details>`;
  });
  // 1) escape HTML (think-box는 이미 처리했으므로 보호)
  const thinkBlocks=[];
  text=text.replace(/<details class="think-box">[\s\S]*?<\/details>/g, m=>{thinkBlocks.push(m);return `__THINK_${thinkBlocks.length-1}__`;});
  let s=text.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  // 2) code blocks (```lang\n...``` 또는 ```lang코드...``` 모두 지원)
  // 2a) drawio 코드블록은 특별 처리
  s=s.replace(/```drawio\s*([\s\S]*?)```/g,(_,code)=>{
    const escapedXml = code.trim();
    // HTML escape된 상태를 원본 XML로 복원 (btoa용)
    const realXml = escapedXml.replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"');
    const xmlB64 = u2b(realXml);
    return `<div class="drawio-block">
      <div class="drawio-header">
        <span>📐 Draw.io 다이어그램</span>
        <div class="drawio-actions">
          <button class="drawio-btn" onclick="copyDrawioXml(this)" data-xml="${xmlB64}">📋 XML 복사</button>
          <button class="drawio-btn" onclick="downloadDrawio(this)" data-xml="${xmlB64}">💾 .drawio 저장</button>
          <button class="drawio-btn" onclick="openInDrawio(this)" data-xml="${xmlB64}">🔗 Draw.io에서 열기</button>
        </div>
      </div>
      <pre class="drawio-preview"><code class="language-xml">${escapedXml}</code></pre>
    </div>`;
  });
  // 2a-2) chart 코드블록 → Chart.js 인터랙티브 그래프 렌더링
  s=s.replace(/```chart\s*([\s\S]*?)```/g,(_,code)=>{
    const trimmed=code.trim();
    const raw=trimmed.replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"');
    const chartId='chart_'+Math.random().toString(36).substr(2,9);
    const b64=u2b(raw);
    return `<div class="chart-block">
      <div class="chart-header">
        <span>📊 인터랙티브 차트</span>
        <div class="chart-actions">
          <button class="chart-btn" onclick="downloadChartPng('${chartId}')">📥 PNG 저장</button>
          <button class="chart-btn" onclick="copyChartJson(this)" data-chart="${b64}">📋 JSON 복사</button>
        </div>
      </div>
      <div class="chart-canvas-wrap"><canvas id="${chartId}" data-chart-json="${b64}"></canvas></div>
      <details class="chart-raw-toggle"><summary>📝 원본 JSON 보기</summary><pre>${trimmed}</pre></details>
    </div>`;
  });
  // 2b) markdown 코드블록 → MD 다운로드 UI
  s=s.replace(/```markdown\s*([\s\S]*?)```/g,(_,code)=>{
    const trimmed=code.trim();
    const mdB64=u2b(trimmed.replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"'));
    return `<div class="md-report-block">
      <div class="md-report-header">
        <span>📋 마크다운 문서</span>
        <div class="md-report-actions">
          <button class="md-report-btn" onclick="copyMdContent(this)" data-md="${mdB64}">📋 복사</button>
          <button class="md-report-btn md-download" onclick="downloadMarkdown(this)" data-md="${mdB64}">📥 MD 다운로드</button>
        </div>
      </div>
      <div class="md-report-preview">${renderMdPreview(trimmed)}</div>
      <details class="md-raw-toggle"><summary>📝 원본 마크다운 보기</summary><pre><code class="language-markdown">${trimmed}</code></pre></details>
    </div>`;
  });
  // 2c) 일반 코드블록 — xml 블록 안에 mxfile이 있으면 drawio로 자동 변환
  s=s.replace(/```(\w*)\s*([\s\S]*?)```/g,(_,lang,code)=>{
    const trimmed=code.trim();
    // 코드블록 안에 <mxfile 또는 <mxGraphModel 있으면 drawio UI로 변환
    if(trimmed.includes('&lt;mxfile') || trimmed.includes('&lt;mxGraphModel')){
      const realXml=trimmed.replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"');
      const xmlB64=u2b(realXml);
      return `<div class="drawio-block">
        <div class="drawio-header">
          <span>📐 Draw.io 다이어그램</span>
          <div class="drawio-actions">
            <button class="drawio-btn" onclick="copyDrawioXml(this)" data-xml="${xmlB64}">📋 XML 복사</button>
            <button class="drawio-btn" onclick="downloadDrawio(this)" data-xml="${xmlB64}">💾 .drawio 저장</button>
            <button class="drawio-btn" onclick="openInDrawio(this)" data-xml="${xmlB64}">🔗 Draw.io에서 열기</button>
          </div>
        </div>
        <pre class="drawio-preview"><code class="language-xml">${trimmed}</code></pre>
      </div>`;
    }
    const cls=lang?` class="language-${lang}"`:'';
    return `<pre><code${cls}>${trimmed}</code></pre>`;
  });
  // 2c) raw mxfile XML (코드블록 밖) 자동 감지 → drawio UI로 변환
  s=s.replace(/(&lt;mxfile[\s\S]*?&lt;\/mxfile&gt;)/g,(_,xmlEsc)=>{
    const realXml=xmlEsc.replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"');
    const xmlB64=u2b(realXml);
    return `<div class="drawio-block">
      <div class="drawio-header">
        <span>📐 Draw.io 다이어그램 (자동 감지)</span>
        <div class="drawio-actions">
          <button class="drawio-btn" onclick="copyDrawioXml(this)" data-xml="${xmlB64}">📋 XML 복사</button>
          <button class="drawio-btn" onclick="downloadDrawio(this)" data-xml="${xmlB64}">💾 .drawio 저장</button>
          <button class="drawio-btn" onclick="openInDrawio(this)" data-xml="${xmlB64}">🔗 Draw.io에서 열기</button>
        </div>
      </div>
      <pre class="drawio-preview"><code class="language-xml">${xmlEsc}</code></pre>
    </div>`;
  });
  // 3) tables
  s=s.replace(/((?:^\|.+\|[ ]*\n){2,})/gm, function(tbl){
    const rows=tbl.trim().split('\n').filter(r=>r.trim());
    if(rows.length<2) return tbl;
    const parseRow=r=>r.replace(/^\|/,'').replace(/\|$/,'').split('|').map(c=>c.trim());
    const hdr=parseRow(rows[0]);
    // skip separator row
    let startIdx=1;
    if(/^[\s|:-]+$/.test(rows[1])) startIdx=2;
    let h='<table><thead><tr>'+hdr.map(c=>'<th>'+c+'</th>').join('')+'</tr></thead><tbody>';
    for(let i=startIdx;i<rows.length;i++){
      const cells=parseRow(rows[i]);
      h+='<tr>'+cells.map(c=>'<td>'+c+'</td>').join('')+'</tr>';
    }
    return h+'</tbody></table>';
  });
  // 4) headings
  s=s.replace(/^#### (.+)$/gm,'<h4>$1</h4>');
  s=s.replace(/^### (.+)$/gm,'<h3>$1</h3>');
  s=s.replace(/^## (.+)$/gm,'<h2>$1</h2>');
  s=s.replace(/^# (.+)$/gm,'<h1>$1</h1>');
  // 5) hr
  s=s.replace(/^---+$/gm,'<hr>');
  // 6) blockquote
  s=s.replace(/^&gt; (.+)$/gm,'<blockquote>$1</blockquote>');
  // 7) unordered list
  s=s.replace(/(^[\-\*] .+\n?)+/gm, function(block){
    const items=block.trim().split('\n').map(l=>l.replace(/^[\-\*] /,''));
    return '<ul>'+items.map(i=>'<li>'+i+'</li>').join('')+'</ul>';
  });
  // 8) ordered list
  s=s.replace(/(^\d+\. .+\n?)+/gm, function(block){
    const items=block.trim().split('\n').map(l=>l.replace(/^\d+\. /,''));
    return '<ol>'+items.map(i=>'<li>'+i+'</li>').join('')+'</ol>';
  });
  // 9) inline: bold, italic, code
  s=s.replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>');
  s=s.replace(/\*(.+?)\*/g,'<em>$1</em>');
  s=s.replace(/`([^`]+)`/g,'<code>$1</code>');
  // 10) paragraphs: double newline -> <p>
  s=s.split(/\n{2,}/).map(block=>{
    const t=block.trim();
    if(!t) return '';
    if(/^<(pre|div|h[1-4]|ul|ol|table|hr|blockquote)/.test(t)) return t;
    return '<p>'+t.replace(/\n/g,'<br>')+'</p>';
  }).join('\n');
  // single newlines inside remaining text
  // think 블록 복원
  thinkBlocks.forEach((block,i)=>{s=s.replace(`__THINK_${i}__`,block);});
  return s;
}
function addMsg(role,text,rawForDetect){
  const c=document.getElementById('msgs');
  const d=document.createElement('div');
  d.className='msg '+role;
  let html = role==='user' ? text.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;') : renderMd(text);
  d.innerHTML=`<div class="msg-label">${role==='user'?'나':'Demos'}</div>${html}`;
  c.appendChild(d);
  d.querySelectorAll('pre').forEach(pre=>{
    const btn=document.createElement('button');
    btn.className='copy-btn';btn.textContent='복사';
    btn.onclick=()=>{navigator.clipboard.writeText(pre.textContent.replace('복사',''));btn.textContent='✓';setTimeout(()=>btn.textContent='복사',1500);};
    pre.appendChild(btn);
  });
  // PPT 코드 블록 감지 → 생성 & 다운로드 버튼 삽입
  if(role==='assistant') detectAndAddPptxButtons(d, (typeof rawForDetect==='string' ? rawForDetect : text));
  // Chart.js 차트 초기화 (data-chart-json 속성이 있는 canvas 탐색)
  d.querySelectorAll('canvas[data-chart-json]').forEach(cv=>{
    try{renderChartBlock(cv.id, b2u(cv.dataset.chartJson));}
    catch(e){cv.parentElement.innerHTML='<p style="color:red;padding:12px;">차트 렌더링 실패: '+e.message+'</p>';}
  });
  // 피드백 버튼 (assistant 응답에만)
  if(role==='assistant'){
    const fbDiv=document.createElement('div');
    fbDiv.className='msg-feedback';
    fbDiv.innerHTML='<button onclick="openFeedback(this,\'good\')" title="좋아요">👍</button><button onclick="openFeedback(this,\'bad\')" title="별로예요">👎</button>';
    d.appendChild(fbDiv);
  }
  // 삭제 버튼 주입
  d.style.position='relative';
  d.insertAdjacentHTML('afterbegin','<button class="msg-del" onclick="event.stopPropagation();deleteMsg(this)">✕</button>');
  try{ const _ct=document.querySelector('.content'); if(_ct) _ct.scrollTop=_ct.scrollHeight; }catch(e){}
}
function injectDeleteButtons(){
  // 옛날 버튼 강제 제거
  document.querySelectorAll('.msg-delete-btn').forEach(el=>el.remove());
  document.querySelectorAll('#msgs .msg').forEach(msg=>{
    const existing = msg.querySelectorAll('.msg-del');
    if(existing.length > 0){
      for(let i=1;i<existing.length;i++) existing[i].remove();
      return;
    }
    msg.style.position='relative';
    msg.insertAdjacentHTML('afterbegin','<button class="msg-del" onclick="event.stopPropagation();deleteMsg(this)">✕</button>');
  });
}
function deleteMsg(btn){
  if(!confirm('이 메시지를 삭제할까요?')) return;
  const msgEl = btn.closest('.msg');
  if(!msgEl) return;
  const msgIndex = Array.from(msgEl.parentElement.children).filter(c=>c.classList.contains('msg')).indexOf(msgEl);
  msgEl.remove();
  if(msgIndex >= 0 && msgIndex < history.length){
    history.splice(msgIndex, 1);
  }
  saveCurrentSession();
}
function addTyping(){
  const c=document.getElementById('msgs');
  const d=document.createElement('div');
  d.className='msg assistant';
  d.innerHTML='<div class="typing"><span></span><span></span><span></span></div>';
  c.appendChild(d);
  try{ const _ct=document.querySelector('.content'); if(_ct) _ct.scrollTop=_ct.scrollHeight; }catch(e){}
  return d;
}
// ===== Session Management =====
function loadSessions(){
  try{ sessions = JSON.parse(localStorage.getItem('domos_sessions') || '{}'); }catch(e){ sessions={}; }
}
function saveSessions(){
  try {
    localStorage.setItem('domos_sessions', JSON.stringify(sessions));
  } catch(e){
    console.warn('세션 저장 실패 (localStorage 용량 초과 가능):', e);
    // 오래된 세션 자동 정리 후 재시도
    const ids = Object.keys(sessions).sort((a,b)=>(sessions[a].updatedAt||0)-(sessions[b].updatedAt||0));
    while(ids.length > 20){ const old=ids.shift(); delete sessions[old]; }
    try { localStorage.setItem('domos_sessions', JSON.stringify(sessions)); } catch(e2){}
  }
}
function saveCurrentSession(){
  if(!currentSessionId) return;
  sessions[currentSessionId] = {
    id: currentSessionId,
    name: sessions[currentSessionId]?.name || '새 세션',
    history: history,
    selEnvs: selEnvs,
    selDomains: selDomains,
    selSkills: selSkills,
    selFormat: selFormat,
    formatManualOverride: formatManualOverride,
    styleManualOverride: styleManualOverride,
    effort: effort,
    writingStyle: document.getElementById('writingStyle')?.value || '',
    writingStyleId: activeStyleId || '',
    systemPrompt: document.getElementById('systemPromptInput')?.value || '',
    systemPromptId: currentPromptId || '',
    thinkMode: document.getElementById('thinkToggle')?.checked || false,
    msgsHtml: document.getElementById('msgs').innerHTML,
    updatedAt: Date.now()
  };
  // Auto-name from first user message
  if(sessions[currentSessionId].name === '새 세션' && history.length > 0){
    const first = history.find(m=>m.role==='user');
    if(first) sessions[currentSessionId].name = first.content.slice(0,30) + (first.content.length>30?'...':'');
  }
  saveSessions();
  renderSessionList();
}
let selectedSessions = new Set();
let _lastCheckedSessionId = null; // Shift+클릭용

function renderSessionList(){
  const el=document.getElementById('sessionList');
  if(!el) return;
  const sorted = Object.values(sessions).filter(s=>!s.archived).sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0));
  const archived = Object.values(sessions).filter(s=>s.archived).sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0));

  document.getElementById('sessionCount').textContent = sorted.length;

  if(sorted.length===0 && archived.length===0){
    el.innerHTML='<div style="font-size:11px;color:#bbb;padding:4px 8px;">저장된 세션 없음</div>';
    return;
  }

  // 날짜별 그룹핑
  const dateGroups = {};
  sorted.forEach(s=>{
    const d = s.updatedAt ? new Date(s.updatedAt) : new Date();
    const today = new Date();
    const yesterday = new Date(today); yesterday.setDate(yesterday.getDate()-1);
    let label;
    if(d.toDateString()===today.toDateString()) label='오늘';
    else if(d.toDateString()===yesterday.toDateString()) label='어제';
    else label=d.toLocaleDateString('ko',{year:'numeric',month:'long',day:'numeric'});
    if(!dateGroups[label]) dateGroups[label]=[];
    dateGroups[label].push(s);
  });

  // 전체 세션 순서 배열 (shift+click 범위 선택용)
  window._sessionOrder = sorted.map(s=>s.id);

  let html = '';
  for(const [dateLabel, items] of Object.entries(dateGroups)){
    html += `<div style="font-size:10px;color:#999;padding:4px 8px 2px;font-weight:600;border-bottom:1px solid #f0f0f0;margin-top:4px;">${dateLabel} (${items.length})</div>`;
    html += items.map(s=>{
      const checked = selectedSessions.has(s.id) ? 'checked' : '';
      const isCurrent = s.id===currentSessionId;
      const time = s.updatedAt ? new Date(s.updatedAt).toLocaleTimeString('ko',{hour:'2-digit',minute:'2-digit'}) : '';
      return `<div class="session-item${isCurrent?' current':''}" onclick="sessionItemClick('${s.id}',event)">
        <input type="checkbox" class="session-cb" ${checked} onclick="event.stopPropagation();toggleSessionCheck('${s.id}',this,event)">
        <span class="session-name">${s.name||'새 세션'}</span>
        <span class="session-time">${time}</span>
      </div>`;
    }).join('');
  }

  // 보관된 세션
  if(archived.length > 0){
    html += `<div style="padding:4px 8px;margin-top:6px;border-top:1px solid #e5e3de;padding-top:8px;">
      <div style="font-size:10px;color:#999;margin-bottom:4px;font-weight:600;cursor:pointer;" onclick="toggleSection('archivedSection','archivedArrow')">
        <span class="arrow" id="archivedArrow">▶</span> 📦 보관함 (${archived.length})
      </div>
      <div id="archivedSection" style="display:none">
      ${archived.map(s=>{
        const checked = selectedSessions.has(s.id) ? 'checked' : '';
        return `<div class="session-item" style="opacity:.7" onclick="sessionItemClick('${s.id}',event)">
          <input type="checkbox" class="session-cb" ${checked} onclick="event.stopPropagation();toggleSessionCheck('${s.id}',this,event)">
          <span class="session-name">${s.name||'세션'}</span>
        </div>`;
      }).join('')}
      </div>
    </div>`;
  }

  el.innerHTML = html;
  updateSessionActions();
}

function toggleSessionCheck(id, cb, event){
  // Shift+클릭: 범위 선택
  if(event && event.shiftKey && _lastCheckedSessionId && window._sessionOrder){
    const order = window._sessionOrder;
    const startIdx = order.indexOf(_lastCheckedSessionId);
    const endIdx = order.indexOf(id);
    if(startIdx !== -1 && endIdx !== -1){
      const from = Math.min(startIdx, endIdx);
      const to = Math.max(startIdx, endIdx);
      for(let i=from; i<=to; i++){
        selectedSessions.add(order[i]);
      }
      renderSessionList();
      return;
    }
  }
  if(cb.checked) selectedSessions.add(id);
  else selectedSessions.delete(id);
  _lastCheckedSessionId = id;
  updateSessionActions();
}

// ===== 세션 팝업 =====
let _popupSelectedSessions = new Set();
let _popupLastChecked = null;

function openSessionPopup(){
  _popupSelectedSessions = new Set(selectedSessions);
  _popupLastChecked = null;
  const overlay = document.getElementById('sessionPopupOverlay');
  overlay.style.display = 'flex';
  renderSessionPopup();
}

function closeSessionPopup(){
  document.getElementById('sessionPopupOverlay').style.display = 'none';
  selectedSessions = new Set(_popupSelectedSessions);
  renderSessionList();
}

function renderSessionPopup(){
  const body = document.getElementById('sessionPopupBody');
  const sorted = Object.values(sessions).filter(s=>!s.archived).sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0));
  const archived = Object.values(sessions).filter(s=>s.archived).sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0));

  document.getElementById('popupSessionCount').textContent = `(${sorted.length}개)`;
  window._popupSessionOrder = sorted.map(s=>s.id);

  // 날짜별 그룹핑
  const dateGroups = {};
  sorted.forEach(s=>{
    const d = s.updatedAt ? new Date(s.updatedAt) : new Date();
    const today = new Date();
    const yesterday = new Date(today); yesterday.setDate(yesterday.getDate()-1);
    let label;
    if(d.toDateString()===today.toDateString()) label='오늘';
    else if(d.toDateString()===yesterday.toDateString()) label='어제';
    else label=d.toLocaleDateString('ko',{year:'numeric',month:'long',day:'numeric'});
    if(!dateGroups[label]) dateGroups[label]=[];
    dateGroups[label].push(s);
  });

  let html = '';
  for(const [dateLabel, items] of Object.entries(dateGroups)){
    html += `<div style="font-size:12px;color:#6b7280;padding:8px 4px 4px;font-weight:700;border-bottom:2px solid #e5e7eb;margin-top:8px;">${dateLabel} <span style="color:#9ca3af;font-weight:400">(${items.length}개)</span></div>`;
    html += items.map(s=>{
      const checked = _popupSelectedSessions.has(s.id) ? 'checked' : '';
      const isCurrent = s.id===currentSessionId;
      const time = s.updatedAt ? new Date(s.updatedAt).toLocaleTimeString('ko',{hour:'2-digit',minute:'2-digit'}) : '';
      const msgCount = s.history ? s.history.length : 0;
      return `<div style="display:flex;align-items:center;gap:8px;padding:8px 4px;border-bottom:1px solid #f3f4f6;cursor:pointer;${isCurrent?'background:#eef2ff;border-radius:6px;':''}" onclick="popupSessionClick('${s.id}',event)">
        <input type="checkbox" ${checked} onclick="event.stopPropagation();popupToggleCheck('${s.id}',this,event)" style="width:16px;height:16px;cursor:pointer;">
        <div style="flex:1;min-width:0;">
          <div style="font-size:13px;font-weight:${isCurrent?'700':'500'};overflow:hidden;text-overflow:ellipsis;white-space:nowrap;${isCurrent?'color:#4f46e5;':'color:#1f2937;'}">${s.name||'새 세션'}${isCurrent?' (현재)':''}</div>
          <div style="font-size:11px;color:#9ca3af;">${msgCount}개 메시지</div>
        </div>
        <div style="font-size:11px;color:#9ca3af;white-space:nowrap;">${time}</div>
      </div>`;
    }).join('');
  }

  if(archived.length > 0){
    html += `<div style="margin-top:12px;border-top:2px solid #e5e7eb;padding-top:8px;">
      <div style="font-size:12px;color:#9ca3af;font-weight:700;padding:4px;cursor:pointer;" onclick="this.nextElementSibling.style.display=this.nextElementSibling.style.display==='none'?'':'none';this.querySelector('span').textContent=this.nextElementSibling.style.display==='none'?'▶':'▼'">
        <span>▶</span> 📦 보관함 (${archived.length}개)
      </div>
      <div style="display:none">
      ${archived.map(s=>{
        const checked = _popupSelectedSessions.has(s.id) ? 'checked' : '';
        return `<div style="display:flex;align-items:center;gap:8px;padding:6px 4px;opacity:.6;border-bottom:1px solid #f3f4f6;">
          <input type="checkbox" ${checked} onclick="event.stopPropagation();popupToggleCheck('${s.id}',this,event)" style="width:16px;height:16px;">
          <span style="font-size:12px;flex:1;">${s.name||'세션'}</span>
        </div>`;
      }).join('')}
      </div>
    </div>`;
  }

  if(sorted.length===0 && archived.length===0){
    html = '<div style="text-align:center;color:#9ca3af;padding:40px;">저장된 세션이 없습니다.</div>';
  }

  body.innerHTML = html;
}

function popupSessionClick(id, event){
  if(event.shiftKey && _popupLastChecked && window._popupSessionOrder){
    event.preventDefault();
    const order = window._popupSessionOrder;
    const startIdx = order.indexOf(_popupLastChecked);
    const endIdx = order.indexOf(id);
    if(startIdx !== -1 && endIdx !== -1){
      const from = Math.min(startIdx, endIdx);
      const to = Math.max(startIdx, endIdx);
      for(let i=from; i<=to; i++) _popupSelectedSessions.add(order[i]);
      _popupLastChecked = id;
      renderSessionPopup();
      return;
    }
  }
  // 일반 클릭: 세션 로드 후 팝업 닫기
  selectedSessions = new Set(_popupSelectedSessions);
  closeSessionPopup();
  loadSession(id);
}

function popupToggleCheck(id, cb, event){
  if(event && event.shiftKey && _popupLastChecked && window._popupSessionOrder){
    const order = window._popupSessionOrder;
    const startIdx = order.indexOf(_popupLastChecked);
    const endIdx = order.indexOf(id);
    if(startIdx !== -1 && endIdx !== -1){
      const from = Math.min(startIdx, endIdx);
      const to = Math.max(startIdx, endIdx);
      for(let i=from; i<=to; i++) _popupSelectedSessions.add(order[i]);
      renderSessionPopup();
      return;
    }
  }
  if(cb.checked) _popupSelectedSessions.add(id);
  else _popupSelectedSessions.delete(id);
  _popupLastChecked = id;
}

function selectAllSessionsPopup(){
  const all = Object.values(sessions).filter(s=>!s.archived);
  if(_popupSelectedSessions.size === all.length) _popupSelectedSessions.clear();
  else all.forEach(s=> _popupSelectedSessions.add(s.id));
  renderSessionPopup();
}

function deleteSelectedSessionsPopup(){
  if(_popupSelectedSessions.size===0) return;
  if(!confirm(`${_popupSelectedSessions.size}개 세션을 삭제할까요?`)) return;
  let deletedCurrent = false;
  _popupSelectedSessions.forEach(id=>{
    if(id===currentSessionId) deletedCurrent = true;
    delete sessions[id];
  });
  _popupSelectedSessions.clear();
  saveSessions();
  if(deletedCurrent){ currentSessionId = null; createNewSession(); }
  renderSessionPopup();
  renderSessionList();
}

function searchSessionsPopup(query){
  const body = document.getElementById('sessionPopupBody');
  const q = query.trim().toLowerCase();
  if(!q){ renderSessionPopup(); return; }

  const all = Object.values(sessions).sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0));
  const results = [];

  all.forEach(s=>{
    const name = (s.name||'').toLowerCase();
    let matchedMsgs = [];

    // 제목 검색
    const nameMatch = name.includes(q);

    // 대화 내용 검색
    if(s.history){
      s.history.forEach((m, idx)=>{
        const content = typeof m.content === 'string' ? m.content : '';
        if(content.toLowerCase().includes(q)){
          // 매칭된 부분 전후 50자 미리보기
          const pos = content.toLowerCase().indexOf(q);
          const start = Math.max(0, pos - 30);
          const end = Math.min(content.length, pos + q.length + 30);
          let preview = (start > 0 ? '...' : '') + content.slice(start, end) + (end < content.length ? '...' : '');
          // 매칭 부분 하이라이트
          preview = preview.replace(new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'), 'gi'), '<mark style="background:#fef08a;padding:0 1px;border-radius:2px;">$&</mark>');
          matchedMsgs.push({ role: m.role, preview, idx });
        }
      });
    }

    if(nameMatch || matchedMsgs.length > 0){
      results.push({ session: s, nameMatch, matchedMsgs });
    }
  });

  if(results.length === 0){
    body.innerHTML = `<div style="text-align:center;color:#9ca3af;padding:40px;">검색 결과 없음: "${query}"</div>`;
    document.getElementById('popupSessionCount').textContent = `(0건)`;
    return;
  }

  document.getElementById('popupSessionCount').textContent = `(${results.length}건 검색됨)`;

  let html = results.map(r=>{
    const s = r.session;
    const isCurrent = s.id === currentSessionId;
    const time = s.updatedAt ? new Date(s.updatedAt).toLocaleString('ko',{month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'}) : '';
    const archived = s.archived ? ' 📦' : '';

    let nameHtml = s.name || '새 세션';
    if(r.nameMatch){
      nameHtml = nameHtml.replace(new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'), 'gi'), '<mark style="background:#fef08a;padding:0 1px;border-radius:2px;">$&</mark>');
    }

    let msgHtml = '';
    if(r.matchedMsgs.length > 0){
      msgHtml = r.matchedMsgs.slice(0, 3).map(m=>{
        const roleLabel = m.role === 'user' ? '사용자' : 'AI';
        return `<div style="font-size:11px;color:#6b7280;padding:2px 0;"><span style="color:#4f46e5;font-weight:600;">[${roleLabel}]</span> ${m.preview}</div>`;
      }).join('');
      if(r.matchedMsgs.length > 3){
        msgHtml += `<div style="font-size:10px;color:#9ca3af;">...외 ${r.matchedMsgs.length - 3}건 매칭</div>`;
      }
    }

    return `<div style="padding:10px 8px;border-bottom:1px solid #f3f4f6;cursor:pointer;${isCurrent?'background:#eef2ff;border-radius:6px;':''}" onclick="closeSessionPopup();loadSession('${s.id}')">
      <div style="display:flex;justify-content:space-between;align-items:center;">
        <div style="font-size:13px;font-weight:600;${isCurrent?'color:#4f46e5;':''}">${nameHtml}${archived}</div>
        <div style="font-size:11px;color:#9ca3af;">${time}</div>
      </div>
      ${msgHtml}
    </div>`;
  }).join('');

  body.innerHTML = html;
}

function exportSessionsToMd(){
  // 선택된 세션이 있으면 선택된 것만, 없으면 전체
  const targets = _popupSelectedSessions.size > 0
    ? Object.values(sessions).filter(s=> _popupSelectedSessions.has(s.id))
    : Object.values(sessions).filter(s=>!s.archived);
  if(targets.length===0){ alert('저장할 세션이 없습니다.'); return; }

  targets.sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0));

  let md = `# 세션 대화 기록\n\n`;
  md += `> 내보내기 날짜: ${new Date().toLocaleString('ko')}\n`;
  md += `> 세션 수: ${targets.length}개\n\n---\n\n`;

  targets.forEach((s, idx)=>{
    const date = s.updatedAt ? new Date(s.updatedAt).toLocaleString('ko') : '날짜 없음';
    const msgCount = s.history ? s.history.length : 0;
    md += `## ${idx+1}. ${s.name||'새 세션'}\n\n`;
    md += `- 날짜: ${date}\n`;
    md += `- 메시지: ${msgCount}개\n\n`;

    if(s.history && s.history.length > 0){
      s.history.forEach(m=>{
        const role = m.role === 'user' ? '**사용자**' : '**AI**';
        const content = typeof m.content === 'string' ? m.content : JSON.stringify(m.content);
        md += `### ${role}\n\n${content}\n\n`;
      });
    } else {
      md += `_(대화 내용 없음)_\n\n`;
    }
    md += `---\n\n`;
  });

  // 다운로드
  const blob = new Blob([md], {type:'text/markdown;charset=utf-8'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  const dateStr = new Date().toISOString().slice(0,10);
  a.href = url;
  a.download = `sessions_${dateStr}.md`;
  a.click();
  URL.revokeObjectURL(url);
}

function deleteAllSessionsPopup(){
  const all = Object.values(sessions).filter(s=>!s.archived);
  if(all.length===0) return;
  if(!confirm(`전체 ${all.length}개 세션을 삭제할까요?`)) return;
  all.forEach(s=> delete sessions[s.id]);
  _popupSelectedSessions.clear();
  saveSessions();
  currentSessionId = null;
  createNewSession();
  renderSessionPopup();
  renderSessionList();
}

function sessionItemClick(id, event){
  // Shift+클릭: 범위 선택
  if(event.shiftKey && _lastCheckedSessionId && window._sessionOrder){
    event.preventDefault();
    const order = window._sessionOrder;
    const startIdx = order.indexOf(_lastCheckedSessionId);
    const endIdx = order.indexOf(id);
    if(startIdx !== -1 && endIdx !== -1){
      const from = Math.min(startIdx, endIdx);
      const to = Math.max(startIdx, endIdx);
      for(let i=from; i<=to; i++){
        selectedSessions.add(order[i]);
      }
      _lastCheckedSessionId = id;
      renderSessionList();
      return;
    }
  }
  // 일반 클릭: 세션 로드
  loadSession(id);
}

function selectAllSessions(){
  const all = Object.values(sessions).filter(s=>!s.archived);
  if(selectedSessions.size === all.length){
    // 전체 해제
    selectedSessions.clear();
  } else {
    // 전체 선택
    all.forEach(s=> selectedSessions.add(s.id));
  }
  renderSessionList();
}

function deleteAllSessions(){
  const all = Object.values(sessions).filter(s=>!s.archived);
  if(all.length===0) return;
  if(!confirm(`전체 ${all.length}개 세션을 삭제할까요?`)) return;
  all.forEach(s=> delete sessions[s.id]);
  selectedSessions.clear();
  saveSessions();
  currentSessionId = null;
  createNewSession();
}

function updateSessionActions(){
  const el = document.getElementById('sessionActions');
  if(selectedSessions.size === 0){ el.style.display='none'; return; }
  // 체크된 것 중 보관/일반 구분
  let hasArchived=false, hasNormal=false;
  selectedSessions.forEach(id=>{
    if(sessions[id]?.archived) hasArchived=true;
    else hasNormal=true;
  });
  let btns = '';
  if(hasNormal) btns += `<button onclick="archiveSelectedSessions()">📦 보관</button>`;
  if(hasArchived) btns += `<button onclick="restoreSelectedSessions()">↩ 복원</button>`;
  btns += `<button class="danger" onclick="deleteSelectedSessions()">🗑️ 삭제</button>`;
  btns += `<button onclick="clearSessionSelection()">취소</button>`;
  el.innerHTML = btns;
  el.style.display = 'flex';
}

function clearSessionSelection(){
  selectedSessions.clear();
  renderSessionList();
}

function deleteSelectedSessions(){
  if(selectedSessions.size===0) return;
  const count = selectedSessions.size;
  if(!confirm(count + '개 세션을 삭제할까요?')) return;
  let deletedCurrent = false;
  selectedSessions.forEach(id=>{
    if(id===currentSessionId) deletedCurrent = true;
    delete sessions[id];
  });
  selectedSessions.clear();
  saveSessions();
  if(deletedCurrent){
    // createNewSession() 호출 시 saveCurrentSession()이 삭제된 세션을 복원하므로
    // currentSessionId를 먼저 초기화한 후 새 세션 생성
    currentSessionId = null;
    createNewSession();
  } else renderSessionList();
}

function archiveSelectedSessions(){
  if(selectedSessions.size===0) return;
  let archivedCurrent = false;
  selectedSessions.forEach(id=>{
    if(sessions[id]){
      sessions[id].archived = true;
      if(id===currentSessionId) archivedCurrent = true;
    }
  });
  selectedSessions.clear();
  saveSessions();
  if(archivedCurrent){
    currentSessionId = null;
    createNewSession();
  } else renderSessionList();
}

// ===== 사이드바 전체 접기/펼치기 =====
function toggleSidebar(){
  const sb = document.getElementById('sidebar');
  const btn = document.getElementById('sidebarToggle');
  const chatBox = document.querySelector('.chat-box-fixed');
  sb.classList.toggle('collapsed');
  document.body.classList.toggle('sb-collapsed');
  if(sb.classList.contains('collapsed')){
    btn.textContent = '▶';
    btn.title = '사이드바 펼치기';
    if(chatBox) chatBox.style.left = '48px';
  } else {
    btn.textContent = '◀';
    btn.title = '사이드바 접기';
    if(chatBox) chatBox.style.left = '250px';
  }
  // localStorage에 상태 저장
  localStorage.setItem('domos_sidebar_collapsed', sb.classList.contains('collapsed'));
}
// 저장된 상태 복원
(function(){
  const saved = localStorage.getItem('domos_sidebar_collapsed');
  if(saved === 'true'){
    const sb = document.getElementById('sidebar');
    const btn = document.getElementById('sidebarToggle');
    const chatBox = document.querySelector('.chat-box-fixed');
    if(sb){ sb.classList.add('collapsed'); }
    if(btn){ btn.textContent='▶'; btn.title='사이드바 펼치기'; }
    if(chatBox){ chatBox.style.left='48px'; }
    document.body.classList.add('sb-collapsed');
  }
})();
function createNewSession(){
  // Save current before switching
  saveCurrentSession();
  currentSessionId = 'sess_'+Date.now();
  history=[];
  selSkills=[];
  autoLoadedSkills=[];
  dismissedAutoSkills.clear();
  document.getElementById('msgs').innerHTML='';
  document.getElementById('writingStyle').value='';
  document.getElementById('systemPromptInput').value='';
  activeStyleId=null;
  currentPromptId=null;
  selFormat='auto';
  formatManualOverride=false;
  styleManualOverride=false;
  effort=2;
  document.getElementById('effortSlider').value=2;
  document.querySelectorAll('.fmt-btn').forEach(b=>{b.classList.toggle('selected',b.dataset.f==='auto');});
  // 업로드된 파일/CSV 초기화 (이전 세션 데이터 잔류 방지)
  fetch('/api/clear_files', {method:'POST'});
  fetch('/api/clear_csv', {method:'POST'});
  uploadedFilesList = [];
  renderFileList();
  csvLoaded = false;
  csvFilename = '';
  document.getElementById('csvInfoPanel').style.display = 'none';
  chatPendingFiles = [];
  const chatFileWrap = document.getElementById('chatAttachPreview');
  if(chatFileWrap){ chatFileWrap.innerHTML = ''; chatFileWrap.style.display='none'; }
  renderSkills();
  updateLoaded();
  renderStyleChips();
  renderPromptChips();
  updateSpBadge();
  updateEffort();
  sessions[currentSessionId] = { id:currentSessionId, name:'새 세션', history:[], msgsHtml:'', updatedAt:Date.now() };
  saveSessions();
  renderSessionList();
}
function loadSession(id){
  if(id===currentSessionId) return;
  saveCurrentSession();
  const s=sessions[id];
  if(!s) return;
  currentSessionId=id;
  history=s.history||[];
  document.getElementById('msgs').innerHTML=s.msgsHtml||'';
  injectDeleteButtons();
  if(s.writingStyle){ document.getElementById('writingStyle').value=s.writingStyle; syncStyleDropToSidebar(); }
  if(s.writingStyleId){ activeStyleId=s.writingStyleId; renderStyleChips(); }
  styleManualOverride = s.styleManualOverride !== undefined ? s.styleManualOverride : !!s.writingStyle;
  if(s.systemPrompt) document.getElementById('systemPromptInput').value=s.systemPrompt;
  if(s.thinkMode!==undefined) document.getElementById('thinkToggle').checked=s.thinkMode;
  if(s.selFormat){ selFormat=s.selFormat; formatManualOverride=(s.formatManualOverride!==undefined ? s.formatManualOverride : selFormat!=='auto'); document.querySelectorAll('.fmt-btn').forEach(b=>{b.classList.toggle('selected',b.dataset.f===selFormat);}); syncFormatDropToChat(); }
  if(s.effort!==undefined){ effort=s.effort; document.getElementById('effortSlider').value=effort; updateEffort(); }
  // 저장된 수동 스킬 복원
  if(s.selSkills && s.selSkills.length > 0){ selSkills = [...s.selSkills]; }
  else { selSkills = []; }
  // 대화 히스토리 기반 자동 스킬 프리로드
  autoLoadedSkills = [];
  dismissedAutoSkills.clear();
  if(autoSkillMode && history.length > 0){
    const lastUser = [...history].reverse().find(m=>m.role==='user');
    if(lastUser){
      fetch('/api/auto-skills',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({query:lastUser.content,max_skills:5,history:history})})
      .then(r=>r.json()).then(d=>{
        if(d.skills && d.skills.length > 0){
          const manualSet = new Set(selSkills);
          autoLoadedSkills = d.skills.map(s=>s.id).filter(id=>!manualSet.has(id));
          renderSkills();
          updateLoaded();
        }
      }).catch(()=>{});
    }
  }
  renderSkills();
  updateLoaded();
  renderSessionList();
  // 세션 복원 후 차트 재렌더링
  document.querySelectorAll('#msgs canvas[data-chart-json]').forEach(cv=>{
    try{renderChartBlock(cv.id, b2u(cv.dataset.chartJson));}
    catch(e){cv.parentElement.innerHTML='<p style="color:red;padding:12px;">차트 렌더링 실패: '+e.message+'</p>';}
  });
}
function deleteSession(id){
  delete sessions[id];
  saveSessions();
  if(id===currentSessionId) createNewSession();
  else renderSessionList();
}
function restoreArchivedSession(id){
  if(sessions[id]){ sessions[id].archived=false; saveSessions(); renderSessionList(); }
}
function restoreSelectedSessions(){
  if(selectedSessions.size===0) return;
  selectedSessions.forEach(id=>{
    if(sessions[id]) sessions[id].archived=false;
  });
  selectedSessions.clear();
  saveSessions();
  renderSessionList();
}
function newSession(){ createNewSession(); }

// ===== Section Toggle (분야/스킬 접기/펼치기) =====
function toggleSection(sectionId, arrowId){
  const section = document.getElementById(sectionId);
  const arrow = document.getElementById(arrowId);
  if(section.style.display === 'none'){
    section.style.display = '';
    arrow.textContent = '▼';
  } else {
    section.style.display = 'none';
    arrow.textContent = '▶';
  }
}

// ===== System Prompt =====
function toggleSysPrompt(){
  const body = document.getElementById('spBody');
  const arrow = document.getElementById('spArrow');
  body.classList.toggle('show');
  arrow.classList.toggle('open');
  if(body.classList.contains('show')){
    arrow.textContent='▼';
  } else {
    arrow.textContent='▶';
    updateSpBadge();
  }
}
function updateSpBadge(){
  const badge = document.getElementById('spPreviewBadge');
  const val = document.getElementById('systemPromptInput').value.trim();
  if(val){
    badge.textContent = val.length + '자 커스텀';
    badge.style.background='#fef3c7';
    badge.style.color='#d97706';
  } else {
    badge.textContent = '기본값';
    badge.style.background='#eef2ff';
    badge.style.color='#6366f1';
  }
}
function resetSysPrompt(){
  document.getElementById('systemPromptInput').value='';
  currentPromptId = null;
  updateSpBadge();
  renderPromptChips();
}
document.getElementById('systemPromptInput').addEventListener('input', function(){
  updateSpBadge();
  // 수동 편집하면 active 해제
  if(currentPromptId){
    currentPromptId = null;
    renderPromptChips();
  }
});

// ===== 시스템 프롬프트 프리셋/저장 관리 =====
let currentPromptId = null;
let promptList = [];

async function loadPromptList(){
  try {
    const r = await fetch('/api/prompts');
    const d = await r.json();
    promptList = d.prompts || [];
    renderPromptChips();
  } catch(e){ console.error('프롬프트 목록 로드 실패:', e); }
}

function renderPromptChips(){
  const container = document.getElementById('promptPresets');
  if(!container) return;
  container.innerHTML = '';
  promptList.forEach(p => {
    const chip = document.createElement('span');
    chip.className = 'prompt-chip' + (p.type==='saved'?' saved':'') + (currentPromptId===p.id?' active':'');
    chip.innerHTML = p.icon + ' ' + p.name;
    chip.title = p.preview;
    chip.onclick = () => selectPrompt(p.id);
    container.appendChild(chip);
  });
  // 삭제 버튼 표시/숨김
  const delBtn = document.getElementById('btnDeletePrompt');
  if(delBtn) delBtn.style.display = (currentPromptId && currentPromptId.startsWith('saved:')) ? '' : 'none';
}

async function selectPrompt(pid){
  try {
    const r = await fetch('/api/prompts/' + encodeURIComponent(pid));
    const d = await r.json();
    if(d.content){
      document.getElementById('systemPromptInput').value = d.content;
      currentPromptId = pid;
      updateSpBadge();
      renderPromptChips();
    }
  } catch(e){ console.error('프롬프트 로드 실패:', e); }
}

async function saveCurrentPrompt(){
  const content = document.getElementById('systemPromptInput').value.trim();
  if(!content){ alert('저장할 내용이 없습니다.'); return; }
  const name = prompt('프롬프트 이름을 입력하세요:', currentPromptId?.startsWith('saved:') ? currentPromptId.slice(6) : '');
  if(!name) return;
  try {
    const r = await fetch('/api/prompts', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({name, content})
    });
    const d = await r.json();
    if(d.success){
      currentPromptId = d.id;
      const status = document.getElementById('promptSaveStatus');
      status.style.display='inline'; setTimeout(()=>status.style.display='none', 2000);
      await loadPromptList();
    } else { alert(d.error || '저장 실패'); }
  } catch(e){ alert('저장 오류: ' + e); }
}

async function deleteCurrentPrompt(){
  if(!currentPromptId || !currentPromptId.startsWith('saved:')) return;
  const name = currentPromptId.slice(6);
  if(!confirm('"' + name + '" 프롬프트를 삭제하시겠습니까?')) return;
  try {
    const r = await fetch('/api/prompts/' + encodeURIComponent(currentPromptId), {method:'DELETE'});
    const d = await r.json();
    if(d.success){
      document.getElementById('systemPromptInput').value = '';
      currentPromptId = null;
      updateSpBadge();
      await loadPromptList();
    }
  } catch(e){ alert('삭제 오류: ' + e); }
}

// 페이지 로드시 프롬프트 목록 불러오기
loadPromptList();

// ===== 작성 스타일 프리셋 =====
const STYLE_PRESETS = [
  {id:'concise',    icon:'⚡', name:'간결', value:'간결하고 핵심만. 불필요한 설명 생략.'},
  {id:'detailed',   icon:'📖', name:'상세', value:'상세하고 친절하게. 원리, 배경, 예시 포함.'},
  {id:'practical',  icon:'🔨', name:'실용적', value:'실전에서 바로 활용 가능하게. 핵심 요점과 구체적 방법 위주. 선택된 출력형식에 맞춰 답변하세요.'},
  {id:'academic',   icon:'🎓', name:'학술', value:'학술적 톤. 정확한 용어, 인용, 근거 제시.'},
  {id:'comment-kr', icon:'💬', name:'한글주석', value:'코드 주석을 상세한 한국어로. 변수명은 영어 유지.'},
  {id:'senior-dev', icon:'👨‍💻', name:'시니어', value:'시니어 개발자 관점. 왜 이렇게 하는지, 대안은 뭔지, 주의점 포함.'},
  {id:'debug',      icon:'🐛', name:'디버그', value:'에러 원인 분석 중심. traceback 해석, 재현 조건, 해결책 순서.'},
  {id:'data-story', icon:'📊', name:'데이터', value:'데이터 스토리텔링. 숫자→의미→액션 순서로 해석.'},
];
let activeStyleId = null;

function renderStyleChips(){
  const container = document.getElementById('styleChips');
  if(!container) return;
  container.innerHTML = '';
  // 🤖 자동 칩 (맨 앞)
  const autoChip = document.createElement('span');
  autoChip.className = 'prompt-chip' + (!styleManualOverride ? ' active' : '');
  autoChip.innerHTML = '🤖 자동';
  autoChip.title = '채팅 내용에 따라 자동 선택';
  autoChip.onclick = () => {
    activeStyleId = null;
    styleManualOverride = false;
    document.getElementById('writingStyle').value = '';
    renderStyleChips();
  };
  container.appendChild(autoChip);
  STYLE_PRESETS.forEach(s => {
    const chip = document.createElement('span');
    chip.className = 'prompt-chip' + (activeStyleId===s.id ? ' active' : '');
    chip.innerHTML = s.icon + ' ' + s.name;
    chip.title = s.value;
    chip.onclick = () => {
      if(activeStyleId === s.id){
        activeStyleId = null;
        styleManualOverride = false;
        document.getElementById('writingStyle').value = '';
      } else {
        activeStyleId = s.id;
        styleManualOverride = true;
        document.getElementById('writingStyle').value = s.value;
      }
      renderStyleChips();
    };
    container.appendChild(chip);
  });
}
renderStyleChips();

// ===== 채팅창 드롭다운 ↔ 사이드바 동기화 =====
function applyChatStyle(val){
  document.getElementById('writingStyle').value = val;
  const match = STYLE_PRESETS.find(s => s.value === val);
  activeStyleId = match ? match.id : null;
  styleManualOverride = !!val;
  renderStyleChips();
  if(val) syncStyleDropToSidebar();
}
function applyChatFormat(val){
  selFormat = val;
  formatManualOverride = (val !== 'auto');
  // 사이드바 fmt-btn도 동기화
  document.querySelectorAll('.fmt-btn').forEach(b=>{b.classList.toggle('selected',b.dataset.f===val);});
}
function syncStyleDropToSidebar(){
  // 사이드바 변경 → 채팅창 드롭다운 동기화
  const drop = document.getElementById('chatStyleDrop');
  if(!drop) return;
  const val = document.getElementById('writingStyle').value.trim();
  const opts = drop.options;
  let found = false;
  for(let i=0;i<opts.length;i++){
    if(opts[i].value === val){ drop.selectedIndex = i; found = true; break; }
  }
  if(!found) drop.selectedIndex = 0;
}
function syncFormatDropToChat(){
  const drop = document.getElementById('chatFormatDrop');
  if(!drop) return;
  const opts = drop.options;
  for(let i=0;i<opts.length;i++){
    if(opts[i].value === selFormat){ drop.selectedIndex = i; break; }
  }
}

document.getElementById('writingStyle').addEventListener('input', function(){
  // 수동 편집하면 active 해제
  const val = this.value.trim();
  const match = STYLE_PRESETS.find(s => s.value === val);
  activeStyleId = match ? match.id : null;
  renderStyleChips();
});

// ===== Skill Detail Panel =====
let currentSkillDetail = null;

async function openSkillDetail(skillId){
  const overlay = document.getElementById('skillDetailOverlay');
  overlay.style.display = 'flex';
  document.getElementById('sdpTitle').textContent = skillId;
  document.getElementById('sdpBody').innerHTML = '⏳ 로딩중...';

  try{
    const resp = await fetch(`/api/skill/${skillId}`);
    currentSkillDetail = await resp.json();
    renderSdpTabs('scripts');
  }catch(e){
    document.getElementById('sdpBody').innerHTML = `❌ 로딩 실패: ${e.message}`;
  }
}

function closeSkillDetail(){
  document.getElementById('skillDetailOverlay').style.display = 'none';
  currentSkillDetail = null;
}

function renderSdpTabs(active){
  if(!currentSkillDetail) return;
  const d = currentSkillDetail;
  const tabsEl = document.getElementById('sdpTabs');
  const tabs = [
    {id:'scripts', label:`🐍 스크립트 (${(d.scripts||[]).length})`, show: true},
    {id:'references', label:`📄 레퍼런스 (${(d.references||[]).length})`, show: true},
    {id:'assets', label:`📦 에셋 (${(d.assets||[]).length})`, show: (d.assets||[]).length > 0},
    {id:'skillmd', label:'📋 SKILL.md', show: true},
  ];
  tabsEl.innerHTML = '';
  tabs.forEach(t=>{
    if(!t.show) return;
    const el = document.createElement('div');
    el.className = 'sdp-tab' + (active===t.id?' active':'');
    el.textContent = t.label;
    el.onclick = ()=> renderSdpTabs(t.id);
    tabsEl.appendChild(el);
  });
  renderSdpContent(active);
}

function renderSdpContent(tab){
  const body = document.getElementById('sdpBody');
  const d = currentSkillDetail;

  if(tab === 'skillmd'){
    body.innerHTML = `<div class="sdp-code">${esc(d.content || '(내용 없음)')}</div>
      <div style="display:flex;gap:6px;margin-top:10px;flex-wrap:wrap;">
        <button class="sdp-btn inject" onclick="injectToChat('skillmd','')">💬 채팅에 주입</button>
        <button class="sdp-btn" style="background:#16a34a;color:#fff;" onclick="downloadExistingSkill('${d.name}')">📥 다운로드</button>
        <button class="sdp-btn" style="background:#f59e0b;color:#fff;" onclick="editSkillMd('${d.name}')">✏️ 편집</button>
      </div>`;
    return;
  }

  const files = d[tab] || [];
  if(files.length === 0){
    body.innerHTML = '<div style="text-align:center;color:#999;padding:40px">파일 없음</div>';
    return;
  }

  const isPy = tab === 'scripts';
  let html = '<ul class="sdp-file-list">';
  files.forEach(f=>{
    const icon = f.name.endsWith('.py') ? '🐍' : f.name.endsWith('.md') ? '📄' : '📎';
    const sizeKb = (f.size / 1024).toFixed(1);
    html += `<li class="sdp-file-item" onclick="viewSkillFile('${d.name}','${f.path}')">
      <span class="sdp-file-icon">${icon}</span>
      <span class="sdp-file-name">${esc(f.name)}</span>
      <span class="sdp-file-size">${sizeKb} KB</span>
      <div class="sdp-file-actions">
        <button class="sdp-btn" onclick="event.stopPropagation();viewSkillFile('${d.name}','${f.path}')">👁️ 보기</button>
        <button class="sdp-btn inject" onclick="event.stopPropagation();injectToChat('${tab}','${f.path}')">💬 주입</button>
        ${isPy && f.name.endsWith('.py') ? `<button class="sdp-btn run" onclick="event.stopPropagation();runSkillScript('${d.name}','${f.path}')">▶ 실행</button>` : ''}
      </div>
    </li>`;
  });
  html += '</ul><div id="sdpFileContent"></div>';
  body.innerHTML = html;
}

async function viewSkillFile(skillId, filePath){
  const container = document.getElementById('sdpFileContent');
  if(!container) return;
  container.innerHTML = '⏳ 로딩중...';
  try{
    const resp = await fetch(`/api/skill/${skillId}/file?path=${encodeURIComponent(filePath)}`);
    const data = await resp.json();
    if(data.error){
      container.innerHTML = `<div class="sdp-result err">${esc(data.error)}</div>`;
    } else {
      container.innerHTML = `<div style="font-size:12px;font-weight:700;margin:10px 0 6px">${esc(data.name)} (${(data.size/1024).toFixed(1)} KB)</div>
        <div class="sdp-code">${esc(data.content)}</div>`;
    }
  }catch(e){
    container.innerHTML = `<div class="sdp-result err">오류: ${e.message}</div>`;
  }
}

async function runSkillScript(skillId, scriptPath){
  const container = document.getElementById('sdpFileContent');
  if(!container) return;
  container.innerHTML = '⏳ 스크립트 실행 중... (최대 60초)';
  try{
    const resp = await fetch(`/api/skill/${skillId}/run`, {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({script: scriptPath})
    });
    const data = await resp.json();
    if(data.error){
      container.innerHTML = `<div class="sdp-result err">❌ ${esc(data.error)}</div>`;
    } else {
      const cls = data.returncode === 0 ? 'ok' : 'err';
      let output = '';
      if(data.stdout) output += `=== stdout ===\n${data.stdout}\n`;
      if(data.stderr) output += `=== stderr ===\n${data.stderr}\n`;
      output += `\n[종료 코드: ${data.returncode}]`;
      container.innerHTML = `<div style="font-size:12px;font-weight:700;margin:10px 0 6px">▶ ${esc(scriptPath)} 실행 결과</div>
        <div class="sdp-result ${cls}">${esc(output)}</div>`;
    }
  }catch(e){
    container.innerHTML = `<div class="sdp-result err">실행 오류: ${e.message}</div>`;
  }
}

async function injectToChat(type, filePath){
  // 파일 내용을 채팅 입력에 주입
  const input = document.getElementById('input');
  const skillId = currentSkillDetail ? currentSkillDetail.name : '';

  if(type === 'skillmd'){
    input.value += `[${skillId} SKILL.md 참조 중]\n`;
    closeSkillDetail();
    return;
  }

  try{
    const resp = await fetch(`/api/skill/${skillId}/file?path=${encodeURIComponent(filePath)}`);
    const data = await resp.json();
    if(data.content){
      const preview = data.content.length > 500 ? data.content.substring(0,500) + '...' : data.content;
      input.value += `\n--- ${data.name} ---\n${preview}\n---\n`;
    }
  }catch(e){ console.warn('파일 주입 실패:', e); }
  closeSkillDetail();
  input.focus();
}

// ===== 스킬 생성 모달 JS =====
function openSkillCreate(){
  document.getElementById('skillCreateOverlay').style.display = 'flex';
  switchScTab('manual');
}
function closeSkillCreate(){
  document.getElementById('skillCreateOverlay').style.display = 'none';
}
function switchScTab(tab){
  const tabIdx = {manual:0, llm:1, wiki:2}[tab] ?? 0;
  document.querySelectorAll('#scTabs .sdp-tab').forEach((el,i)=>{
    el.className = 'sdp-tab' + (i === tabIdx ? ' active' : '');
  });
  document.getElementById('scManual').style.display = tab==='manual' ? 'block' : 'none';
  document.getElementById('scLlm').style.display = tab==='llm' ? 'block' : 'none';
  const wikiBox = document.getElementById('scWiki');
  if(wikiBox) wikiBox.style.display = tab==='wiki' ? 'block' : 'none';
}

// ===== LLM Wiki (카파시 스타일 변환) =====
async function generateWiki(){
  const src = document.getElementById('wikiSource').value.trim();
  if(!src){ alert('원본 본문을 붙여넣으세요'); return; }
  const title = document.getElementById('wikiTitle').value.trim();
  const style = document.querySelector('input[name="wikiStyle"]:checked')?.value || 'karpathy';
  const language = document.querySelector('input[name="wikiLang"]:checked')?.value || 'ko';
  const btn = document.getElementById('wikiGenBtn');
  const out = document.getElementById('wikiResult');
  const filenameEl = document.getElementById('wikiFilename');
  const titleEl = document.getElementById('wikiResultTitle');
  btn.disabled = true; btn.textContent = '⏳ LLM 변환 중...';
  out.value = '';
  filenameEl.textContent = '';
  titleEl.textContent = '';
  try{
    const r = await fetch('/api/wiki/generate', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ source: src, title, style, language })
    });
    const d = await r.json();
    if(d.error){
      out.value = '❌ 변환 실패: ' + d.error;
    } else {
      out.value = d.content || '';
      filenameEl.textContent = d.suggested_filename || '';
      titleEl.textContent = d.title || '';
    }
  } catch(e){
    out.value = '❌ 네트워크 오류: ' + e.message;
  } finally {
    btn.disabled = false;
    btn.textContent = '🤖 Wiki 로 변환';
  }
}

async function copyWikiMd(){
  const out = document.getElementById('wikiResult');
  if(!out.value.trim()){ alert('변환된 wiki 가 없습니다'); return; }
  try{
    await navigator.clipboard.writeText(out.value);
    const btn = document.getElementById('wikiCopyBtn');
    const orig = btn.textContent;
    btn.textContent = '✅ 복사됨';
    setTimeout(() => { btn.textContent = orig; }, 2000);
  }catch(e){
    // fallback
    out.select();
    document.execCommand('copy');
    alert('클립보드에 복사됨');
  }
}

function downloadWikiMd(){
  const content = document.getElementById('wikiResult').value;
  if(!content.trim()){ alert('변환된 wiki 가 없습니다'); return; }
  const filename = document.getElementById('wikiFilename').textContent.trim() || 'wiki.md';
  const blob = new Blob([content], {type: 'text/markdown'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

async function saveWikiToKnowledge(){
  const content = document.getElementById('wikiResult').value.trim();
  if(!content){ alert('변환된 wiki 가 없습니다'); return; }
  if(!currentUser || !currentUser.id){ alert('로그인이 필요합니다'); return; }
  const rawTitle = document.getElementById('wikiResultTitle').textContent.trim()
                 || document.getElementById('wikiTitle').value.trim()
                 || 'wiki';
  // [WIKI] 접두어로 검색·구분 용이
  const finalTitle = rawTitle.startsWith('[WIKI]') ? rawTitle : `[WIKI] ${rawTitle}`;
  const btn = document.getElementById('wikiSaveBtn');
  btn.disabled = true; btn.textContent = '⏳ 저장 중...';
  try{
    const r = await fetch('/api/knowledge/manual', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({
        user_id: currentUser.id,
        title: finalTitle,
        category: 'wiki',
        content: content,
        tags: 'WIKI,llm-wiki,karpathy-style'
      })
    });
    const d = await r.json();
    if(d.error){
      alert('❌ 저장 실패: ' + d.error);
    } else {
      btn.textContent = '✅ 등록 완료';
      setTimeout(() => { btn.disabled = false; btn.textContent = '📚 내 지식에 등록'; }, 2500);
    }
  }catch(e){
    alert('네트워크 오류: ' + e.message);
    btn.disabled = false;
    btn.textContent = '📚 내 지식에 등록';
  }
}
function validateScName(){
  const name = document.getElementById('scName').value.trim();
  const el = document.getElementById('scNameStatus');
  if(!name){ el.innerHTML=''; return; }
  if(/^[a-z0-9]+(-[a-z0-9]+)*$/.test(name) && name.length<=64){
    el.innerHTML='<span style="color:#16a34a">✅ 유효한 이름</span>';
  } else {
    el.innerHTML='<span style="color:#ef4444">❌ 소문자+숫자+하이픈만, 64자 이내</span>';
  }
}
function _renderValidation(containerId, data){
  const el = document.getElementById(containerId);
  let html = '';
  if(data.errors && data.errors.length > 0){
    html += data.errors.map(e=>`<div style="color:#ef4444;font-size:12px;margin:2px 0;">❌ ${e}</div>`).join('');
  }
  if(data.warnings && data.warnings.length > 0){
    html += data.warnings.map(w=>`<div style="color:#f59e0b;font-size:12px;margin:2px 0;">⚠️ ${w}</div>`).join('');
  }
  if(data.valid){
    html += '<div style="color:#16a34a;font-size:12px;margin:2px 0;">✅ 검증 통과! 다운로드 가능합니다.</div>';
  }
  el.innerHTML = html;
  return data.valid;
}
async function validateSkillPreview(){
  const name = document.getElementById('scName').value.trim();
  const desc = document.getElementById('scDesc').value.trim();
  const body = document.getElementById('scBody_manual').value.trim();
  const content = `---\nname: ${name}\ndescription: >\n  ${desc}\n---\n\n${body}`;
  try{
    const resp = await fetch('/api/skill/validate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({content})});
    const data = await resp.json();
    const valid = _renderValidation('scValidateResult', data);
  }catch(e){
    document.getElementById('scValidateResult').innerHTML = `<div style="color:#ef4444;font-size:12px;">오류: ${e.message}</div>`;
  }
}
async function downloadSkill(){
  const name = document.getElementById('scName').value.trim();
  const desc = document.getElementById('scDesc').value.trim();
  const body = document.getElementById('scBody_manual').value.trim();
  try{
    const resp = await fetch('/api/skill/create',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,description:desc,body})});
    if(!resp.ok){
      const err = await resp.json();
      alert('오류: '+(err.error||'알 수 없는 오류'));
      return;
    }
    const blob = await resp.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `${name}.zip`; a.click();
    URL.revokeObjectURL(url);
    document.getElementById('scValidateResult').innerHTML += '<div style="color:#16a34a;font-size:12px;margin-top:4px;">📥 다운로드 완료!</div>';
  }catch(e){
    alert('다운로드 실패: '+e.message);
  }
}
function setScLang(lang){
  document.getElementById('scLang').value = lang;
  const ko = document.getElementById('scLangKo');
  const en = document.getElementById('scLangEn');
  if(lang==='ko'){
    ko.style.background='#6366f1'; ko.style.color='#fff'; ko.style.borderColor='#6366f1';
    en.style.background='#fff'; en.style.color='#333'; en.style.borderColor='#e2e8f0';
  } else {
    en.style.background='#6366f1'; en.style.color='#fff'; en.style.borderColor='#6366f1';
    ko.style.background='#fff'; ko.style.color='#333'; ko.style.borderColor='#e2e8f0';
  }
}
async function generateSkillLLM(){
  const topic = document.getElementById('scTopic').value.trim();
  if(!topic){ alert('스킬 주제를 입력하세요.'); return; }
  const skill_type = document.getElementById('scType').value;
  const details = document.getElementById('scDetails').value.trim();
  const lang = document.getElementById('scLang').value || 'ko';
  const tone = document.querySelector('input[name="scTone"]:checked')?.value || 'default';
  document.getElementById('scGenStatus').style.display = 'block';
  document.getElementById('scGenBtn').disabled = true;
  try{
  document.getElementById('scGenResult').style.display = 'none';
    const resp = await fetch('/api/skill/generate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({topic,skill_type,details,lang,tone})});
    const data = await resp.json();
    document.getElementById('scGenStatus').style.display = 'none';
    document.getElementById('scGenBtn').disabled = false;
    if(data.error){
      alert('생성 실패: '+data.error);
      return;
    }
    document.getElementById('scGenContent').value = data.content;
    document.getElementById('scGenResult').style.display = 'block';
    if(data.model){
      document.getElementById('scGenStatus').style.display = 'block';
      document.getElementById('scGenStatus').textContent = `✅ ${data.model}로 생성 완료`;
    }
  }catch(e){
    document.getElementById('scGenStatus').style.display = 'none';
    document.getElementById('scGenBtn').disabled = false;
    alert('LLM 호출 실패: '+e.message);
  }
}
async function validateGenerated(){
  const content = document.getElementById('scGenContent').value;
  try{
    const resp = await fetch('/api/skill/validate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({content})});
    const data = await resp.json();
    const valid = _renderValidation('scGenValidateResult', data);
  }catch(e){
    document.getElementById('scGenValidateResult').innerHTML = `<div style="color:#ef4444;font-size:12px;">오류: ${e.message}</div>`;
  }
}
async function downloadGeneratedSkill(){
  const content = document.getElementById('scGenContent').value;
  // frontmatter에서 name 추출
  const m = content.match(/name:\s*(.+)/);
  const name = m ? m[1].trim() : 'generated-skill';
  // frontmatter에서 description 추출
  const dm = content.match(/description:\s*>?\s*\n?\s*(.+)/);
  const desc = dm ? dm[1].trim() : '';
  // body 추출 (frontmatter 이후)
  const fmEnd = content.indexOf('---', 3);
  const body = fmEnd > 0 ? content.substring(fmEnd+3).trim() : '';
  try{
    const resp = await fetch('/api/skill/create',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,description:desc||'Auto-generated skill',body})});
    if(!resp.ok){
      const err = await resp.json();
      alert('오류: '+(err.error||'알 수 없는 오류'));
      return;
    }
    const blob = await resp.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `${name}.zip`; a.click();
    URL.revokeObjectURL(url);
    document.getElementById('scGenValidateResult').innerHTML += '<div style="color:#16a34a;font-size:12px;margin-top:4px;">📥 다운로드 완료!</div>';
  }catch(e){
    alert('다운로드 실패: '+e.message);
  }
}
async function applySkill(){
  const name = document.getElementById('scName').value.trim();
  const desc = document.getElementById('scDesc').value.trim();
  const body = document.getElementById('scBody_manual').value.trim();
  if(!confirm(`스킬 '${name}'을 바로 등록하시겠습니까?\nscientific-skills/${name}/ 폴더에 저장됩니다.`)) return;
  try{
    const resp = await fetch('/api/skill/apply',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,description:desc,body})});
    const data = await resp.json();
    if(data.error){
      document.getElementById('scValidateResult').innerHTML = `<div style="color:#ef4444;font-size:12px;">❌ ${data.error}</div>`;
      if(data.errors) document.getElementById('scValidateResult').innerHTML += data.errors.map(e=>`<div style="color:#ef4444;font-size:11px;">&nbsp;&nbsp;- ${e}</div>`).join('');
    } else {
      document.getElementById('scValidateResult').innerHTML = `<div style="color:#16a34a;font-size:12px;">🚀 ${data.message}</div>`;
      if(data.warnings && data.warnings.length>0) document.getElementById('scValidateResult').innerHTML += data.warnings.map(w=>`<div style="color:#f59e0b;font-size:11px;">⚠️ ${w}</div>`).join('');
      // 스킬 카탈로그 새로고침
      setTimeout(()=>{ loadConfig(); }, 1500);
    }
  }catch(e){
    alert('적용 실패: '+e.message);
  }
}
async function applyGeneratedSkill(){
  const content = document.getElementById('scGenContent').value;
  const m = content.match(/name:\s*(.+)/);
  const name = m ? m[1].trim() : 'generated-skill';
  if(!confirm(`스킬 '${name}'을 바로 등록하시겠습니까?\nscientific-skills/${name}/ 폴더에 저장됩니다.`)) return;
  try{
    const resp = await fetch('/api/skill/apply',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({content})});
    const data = await resp.json();
    if(data.error){
      document.getElementById('scGenValidateResult').innerHTML = `<div style="color:#ef4444;font-size:12px;">❌ ${data.error}</div>`;
      if(data.errors) document.getElementById('scGenValidateResult').innerHTML += data.errors.map(e=>`<div style="color:#ef4444;font-size:11px;">&nbsp;&nbsp;- ${e}</div>`).join('');
    } else {
      document.getElementById('scGenValidateResult').innerHTML = `<div style="color:#16a34a;font-size:12px;">🚀 ${data.message}</div>`;
      if(data.warnings && data.warnings.length>0) document.getElementById('scGenValidateResult').innerHTML += data.warnings.map(w=>`<div style="color:#f59e0b;font-size:11px;">⚠️ ${w}</div>`).join('');
      setTimeout(()=>{ loadConfig(); }, 1500);
    }
  }catch(e){
    alert('적용 실패: '+e.message);
  }
}
function downloadExistingSkill(skillName){
  window.location.href = `/api/skill/${skillName}/download`;
}
async function editSkillMd(skillName){
  const body = document.getElementById('sdpBody');
  const d = currentSkillDetail;
  body.innerHTML = `<textarea id="sdpEditArea" rows="25" style="width:100%;padding:8px;border:1px solid #e2e8f0;border-radius:6px;font-size:12px;font-family:monospace;resize:vertical;box-sizing:border-box;">${esc(d.content||'')}</textarea>
    <div style="display:flex;gap:6px;margin-top:10px;">
      <button class="sdp-btn" style="background:#16a34a;color:#fff;" onclick="saveSkillMd('${skillName}')">💾 저장</button>
      <button class="sdp-btn" onclick="renderSdpTabs('skillmd')">취소</button>
    </div>
    <div id="sdpEditStatus" style="margin-top:6px;"></div>`;
}
async function saveSkillMd(skillName){
  const content = document.getElementById('sdpEditArea').value;
  const statusEl = document.getElementById('sdpEditStatus');
  try{
    const resp = await fetch(`/api/skill/${skillName}/update`,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({content})});
    const data = await resp.json();
    if(data.error){
      statusEl.innerHTML = `<span style="color:#ef4444">❌ ${data.error}</span>`;
      if(data.errors) statusEl.innerHTML += data.errors.map(e=>`<br><span style="color:#ef4444;font-size:11px;">&nbsp;&nbsp;- ${e}</span>`).join('');
    } else {
      statusEl.innerHTML = '<span style="color:#16a34a">✅ 저장 완료!</span>';
      if(data.warnings && data.warnings.length > 0){
        statusEl.innerHTML += data.warnings.map(w=>`<br><span style="color:#f59e0b;font-size:11px;">⚠️ ${w}</span>`).join('');
      }
      // 상세 패널 새로고침
      setTimeout(()=>openSkillDetail(skillName), 1000);
    }
  }catch(e){
    statusEl.innerHTML = `<span style="color:#ef4444">오류: ${e.message}</span>`;
  }
}

// ===== CSV Upload =====
let csvLoaded = false;
let csvFilename = '';

// handleUnifiedDrop/Select → 채팅 입력 📎 첨부로 대체됨
async function uploadCsvFile(file){
  const formData = new FormData();
  formData.append('file', file);

  try{
    const resp = await fetch('/api/upload_csv', {method:'POST', body:formData});
    const data = await resp.json();
    if(data.error) return;

    csvLoaded = true;
    csvFilename = data.filename;

    // 미리보기 테이블 생성
    let tableHtml = '<table><tr>' + data.headers.map(h=>`<th>${esc(h)}</th>`).join('') + '</tr>';
    if(data.sample_rows){
      data.sample_rows.forEach(row=>{
        tableHtml += '<tr>' + data.headers.map(h=>`<td>${esc(row[h]||'')}</td>`).join('') + '</tr>';
      });
    }
    tableHtml += '</table>';
    if(data.rows > 3) tableHtml += `<div style="text-align:center;color:#999;font-size:10px;margin-top:4px">... 총 ${data.rows}행</div>`;

    const panel = document.getElementById('csvInfoPanel');
    panel.style.display = 'block';
    panel.innerHTML = `
      <div class="csv-info">
        <div class="fname">📊 ${esc(data.filename)}</div>
        <div class="fstats">${data.rows}행 × ${data.cols}열</div>
        <button class="fremove" onclick="removeCsv()">✕ 제거</button>
        <div class="csv-preview">${tableHtml}</div>
      </div>`;

  }catch(e){}
}

// ===== XLSX Upload (시트별 파싱 + 이미지) =====
var _xlsxRawFile = null;  // 시트 변경 시 재업로드용

async function uploadXlsxFile(file, sheetIdx){
  _xlsxRawFile = file;
  const formData = new FormData();
  formData.append('file', file);
  if(typeof sheetIdx === 'number') formData.append('sheet', sheetIdx);

  try{
    const resp = await fetch('/api/upload_xlsx', {method:'POST', body:formData});
    const data = await resp.json();
    if(data.error){ addMsg('assistant', '❌ ' + data.error); return; }

    csvLoaded = true;
    csvFilename = data.filename;

    // 시트 선택 탭 (2개 이상일 때만)
    let sheetTabs = '';
    if(data.sheets && data.sheets.length > 1){
      sheetTabs = '<div style="display:flex;gap:4px;margin-bottom:6px;flex-wrap:wrap">';
      data.sheets.forEach(function(s, i){
        var active = i === data.active_sheet;
        sheetTabs += '<button style="padding:3px 10px;border-radius:12px;border:1.5px solid '+(active?'#6366f1':'#ddd')+';background:'+(active?'#6366f1':'#fff')+';color:'+(active?'#fff':'#333')+';font-size:11px;cursor:pointer;font-weight:'+(active?'600':'400')+'" onclick="switchXlsxSheet('+i+')">'+esc(s.name)+' <span style="color:'+(active?'rgba(255,255,255,.7)':'#999')+';font-size:10px">('+s.rows+'행)</span></button>';
      });
      sheetTabs += '</div>';
    }

    // 미리보기 테이블
    let tableHtml = '<table><tr>' + data.headers.map(function(h){return '<th>'+esc(h)+'</th>';}).join('') + '</tr>';
    if(data.sample_rows){
      data.sample_rows.forEach(function(row){
        tableHtml += '<tr>' + data.headers.map(function(h){return '<td>'+esc(row[h]||'')+'</td>';}).join('') + '</tr>';
      });
    }
    tableHtml += '</table>';
    if(data.rows > 3) tableHtml += '<div style="text-align:center;color:#999;font-size:10px;margin-top:4px">... 총 ' + data.rows + '행</div>';

    // 이미지 안내
    var imgInfo = '';
    if(data.images_count > 0){
      imgInfo = '<div style="margin-top:6px;padding:4px 8px;background:#fef3c7;border-radius:6px;font-size:11px;color:#92400e">🖼️ 내장 이미지 ' + data.images_count + '개 감지 (VL 모델로 분석 가능)</div>';
    }

    var sheetInfo = data.sheets && data.sheets.length > 1 ? ' · ' + data.sheets.length + '시트' : '';

    const panel = document.getElementById('csvInfoPanel');
    panel.style.display = 'block';
    panel.innerHTML =
      '<div class="csv-info">' +
        '<div class="fname">📊 ' + esc(data.filename) + ' [' + esc(data.active_sheet_name) + ']</div>' +
        '<div class="fstats">' + data.rows + '행 × ' + data.cols + '열' + sheetInfo + '</div>' +
        '<button class="fremove" onclick="removeCsv()">✕ 제거</button>' +
        sheetTabs +
        '<div class="csv-preview">' + tableHtml + '</div>' +
        imgInfo +
      '</div>';

  }catch(e){ console.warn('XLSX 업로드 실패:', e); }
}

function switchXlsxSheet(idx){
  if(!_xlsxRawFile) return;
  uploadXlsxFile(_xlsxRawFile, idx);
}

function esc(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

// ===== Unicode-safe Base64 유틸 (btoa/atob는 Latin1만 지원) =====
function u2b(str){
  var bytes=new TextEncoder().encode(str);
  var bin='';
  for(var i=0;i<bytes.length;i++) bin+=String.fromCharCode(bytes[i]);
  return btoa(bin);
}
function b2u(b64){
  var bin=atob(b64);
  var bytes=new Uint8Array(bin.length);
  for(var i=0;i<bin.length;i++) bytes[i]=bin.charCodeAt(i);
  return new TextDecoder().decode(bytes);
}

// ===== Draw.io 기능 =====
function decodeDrawioXml(btn){
  return b2u(btn.dataset.xml);
}

// Draw.io XML 자동 수정 (LLM이 생성한 XML의 흔한 오류 교정)
function sanitizeDrawioXml(xml){
  // 허용되는 HTML 태그 목록 (Draw.io value 속성 안에서 허용)
  const allowedHtmlTags = ['br','br/','br /','font','b','i','u','sub','sup','hr','span','div','p','strong','em'];
  const allowedPattern = allowedHtmlTags.map(t => t.replace('/','\\/').replace(' ','')).join('|');

  // value/label 속성값 안의 이스케이프 수정 함수
  function fixAttrValue(val){
    // Step 1: & 이스케이프 (이미 된 건 건드리지 않음)
    let s = val.replace(/&(?!amp;|lt;|gt;|quot;|apos;|#\d+;|#x[0-9a-fA-F]+;)/g, '&amp;');
    // Step 2: 모든 < > 를 임시 치환 후, 허용된 HTML 태그만 복원
    s = s.replace(/</g, '\x00LT\x00').replace(/>/g, '\x00GT\x00');
    // 허용된 여는 태그 복원: <font ...>, <br>, <br/>, <b>, etc.
    for(const tag of allowedHtmlTags){
      const base = tag.replace(/[\s\/]/g,'');
      // 여는 태그 (속성 포함): <font style="...">
      const openRe = new RegExp('\x00LT\x00(' + base + ')(\\s[^\\x00]*?)?\x00GT\x00', 'gi');
      s = s.replace(openRe, '<$1$2>');
      // 닫는 태그: </font>
      const closeRe = new RegExp('\x00LT\x00/' + base + '\x00GT\x00', 'gi');
      s = s.replace(closeRe, '</' + base + '>');
    }
    // self-closing: <br/>, <br />, <hr/>
    s = s.replace(/\x00LT\x00(br|hr)\s*\/?\x00GT\x00/gi, '<$1/>');
    // 남은 \x00LT\x00, \x00GT\x00 는 진짜 이스케이프 대상
    s = s.replace(/\x00LT\x00/g, '&lt;').replace(/\x00GT\x00/g, '&gt;');
    return s;
  }

  // 1) value="..." 속성 수정
  xml = xml.replace(/(value|label)="([^"]*)"/g, (m, attr, val) => {
    const fixed = fixAttrValue(val);
    return fixed !== val ? `${attr}="${fixed}"` : m;
  });

  // 2) 중복 속성 제거: style="..." style="..." → 첫 번째만
  xml = xml.replace(/(\w+="[^"]*")\s+\1/g, '$1');

  // 3) 중첩된 mxCell 분리 (mxCell 안에 mxCell이 있으면 평탄화)
  //    주의: mxCell > mxGeometry 관계는 정상이므로 건드리지 않음
  //    (기존 regex가 자식 mxGeometry 있는 mxCell을 self-closing으로 바꾸는 버그 수정)

  // 4) mxfile 래퍼가 없으면 추가
  if (!xml.includes('<mxfile') && xml.includes('<mxGraphModel')) {
    xml = `<mxfile host="app.diagrams.net" type="device">\n<diagram id="d1" name="Page-1">\n${xml}\n</diagram>\n</mxfile>`;
  }
  if (!xml.includes('<mxfile') && xml.includes('<mxCell')) {
    xml = `<mxfile host="app.diagrams.net" type="device">\n<diagram id="d1" name="Page-1">\n<mxGraphModel dx="1422" dy="762" grid="1" pageWidth="1169" pageHeight="827">\n<root>\n<mxCell id="0"/>\n<mxCell id="1" parent="0"/>\n${xml}\n</root>\n</mxGraphModel>\n</diagram>\n</mxfile>`;
  }

  // 5) 최종 검증: DOMParser로 파싱 시도, 실패하면 단계별 수정
  try {
    let parser = new DOMParser();
    let doc = parser.parseFromString(xml, 'application/xml');
    if (doc.querySelector('parsererror')) {
      // 5a) 속성값 안의 이스케이프 안 된 < > 수정
      xml = xml.replace(/="([^"]*)"/g, (m, val) => {
        if (val.includes('<') && !val.match(/^[^<]*<(mxGeometry|mxPoint|Array)/)) {
          const forced = val.replace(/</g, '&lt;').replace(/>/g, '&gt;');
          return `="${forced}"`;
        }
        return m;
      });

      // 5b) 재검증 - 여전히 실패하면 구조 수정 시도
      doc = parser.parseFromString(xml, 'application/xml');
      if (doc.querySelector('parsererror')) {
        // mxCell 구조 재구성: 모든 mxCell/mxGeometry를 추출해서 올바른 구조로 재조립
        const cellRe = /<mxCell\s[^>]*?\/>/g;
        const cellWithChildRe = /<mxCell\s[^>]*?>[\s\S]*?<\/mxCell>/g;
        const geoRe = /<mxGeometry\s[^>]*?\/>/g;
        const geoWithChildRe = /<mxGeometry\s[^>]*?>[\s\S]*?<\/mxGeometry>/g;

        // mxfile/diagram/mxGraphModel 래퍼 추출
        const wrapMatch = xml.match(/([\s\S]*?<root>)([\s\S]*?)(<\/root>[\s\S]*)/);
        if (wrapMatch) {
          const [, header, body, footer] = wrapMatch;
          // body에서 모든 완전한 요소 추출 (self-closing + with-children 모두)
          const elements = [];
          const allRe = /<(mxCell|mxGeometry|UserObject|Array|mxPoint)\s[^>]*?(?:\/>|>[\s\S]*?<\/\1>)/g;
          // 먼저 mxCell+children 패턴 추출
          const cellFullRe = /<mxCell\s[^>]*?>(?:\s*<mxGeometry[\s\S]*?(?:\/>|<\/mxGeometry>))*\s*<\/mxCell>/g;
          const cellSelfRe = /<mxCell\s[^>]*?\/>/g;
          let match;
          while ((match = cellFullRe.exec(body)) !== null) elements.push(match[0]);
          while ((match = cellSelfRe.exec(body)) !== null) {
            if (!elements.some(e => e.includes(match[0]))) elements.push(match[0]);
          }
          // UserObject 패턴도 포함
          const uoRe = /<UserObject[\s\S]*?<\/UserObject>/g;
          while ((match = uoRe.exec(body)) !== null) elements.push(match[0]);

          if (elements.length > 0) {
            xml = header + '\n' + elements.join('\n') + '\n' + footer;
          }
        }
      }
    }
  } catch(e) {}

  return xml;
}

function copyDrawioXml(btn){
  const xml = sanitizeDrawioXml(decodeDrawioXml(btn));
  navigator.clipboard.writeText(xml).then(()=>{
    const orig = btn.textContent;
    btn.textContent = '✓ 복사됨';
    setTimeout(()=> btn.textContent = orig, 1500);
  });
}
function downloadDrawio(btn){
  const xml = sanitizeDrawioXml(decodeDrawioXml(btn));
  const blob = new Blob([xml], {type:'application/xml'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'diagram.drawio';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
function openInDrawio(btn){
  const xml = sanitizeDrawioXml(decodeDrawioXml(btn));
  const encoded = encodeURIComponent(xml);
  window.open('https://app.diagrams.net/#R' + encoded, '_blank');
}

// ===== Chart.js 인터랙티브 차트 =====
const _chartInstances = {};

function renderChartBlock(canvasId, jsonStr) {
  // jsonStr은 이미 b2u()로 유니코드 디코딩된 상태
  let raw = jsonStr;
  // 한 줄 주석 제거
  raw = raw.replace(/\/\/[^\n]*/g, '');
  let config;
  try {
    config = JSON.parse(raw);
  } catch(e) {
    // JSON5 스타일 허용: trailing comma, 작은따옴표
    raw = raw.replace(/,\s*([\]}])/g, '$1').replace(/'/g, '"');
    config = JSON.parse(raw);
  }

  // 기본값 보강
  if (!config.type) config.type = 'bar';
  if (!config.options) config.options = {};
  if (!config.options.responsive) config.options.responsive = true;
  if (!config.options.maintainAspectRatio) config.options.maintainAspectRatio = true;
  if (!config.options.plugins) config.options.plugins = {};

  // 한글 폰트 기본 설정
  if (!config.options.plugins.legend) config.options.plugins.legend = {};

  const canvas = document.getElementById(canvasId);
  if (!canvas) return;
  const ctx = canvas.getContext('2d');

  // 이전 인스턴스 정리
  if (_chartInstances[canvasId]) {
    _chartInstances[canvasId].destroy();
  }
  _chartInstances[canvasId] = new Chart(ctx, config);
}

function downloadChartPng(canvasId) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;
  const url = canvas.toDataURL('image/png');
  const a = document.createElement('a');
  a.href = url;
  a.download = 'chart.png';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}

function copyChartJson(btn) {
  const b64 = btn.getAttribute('data-chart');
  const json = b2u(b64);
  navigator.clipboard.writeText(json).then(() => {
    const orig = btn.textContent;
    btn.textContent = '✓ 복사됨';
    setTimeout(() => btn.textContent = orig, 1500);
  });
}

// ===== MD 다운로드/복사/미리보기 =====
function decodeMdB64(btn){
  const b64 = btn.getAttribute('data-md');
  return b2u(b64);
}
function downloadMarkdown(btn){
  const md = decodeMdB64(btn);
  // 제목에서 파일명 추출
  const titleMatch = md.match(/^#\s+(.+)$/m);
  let filename = 'report.md';
  if(titleMatch){
    filename = titleMatch[1].replace(/[^\w가-힣\s-]/g,'').trim().replace(/\s+/g,'_').substring(0,50) + '.md';
  }
  const blob = new Blob([md], {type:'text/markdown;charset=utf-8'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
function copyMdContent(btn){
  const md = decodeMdB64(btn);
  navigator.clipboard.writeText(md).then(()=>{
    const orig = btn.textContent;
    btn.textContent = '✅ 복사됨';
    setTimeout(()=>btn.textContent=orig, 1500);
  });
}
function renderMdPreview(escapedMd){
  // HTML escaped 마크다운을 간단히 렌더링 (미리보기용)
  let s = escapedMd;
  // 헤딩
  s = s.replace(/^######\s+(.+)$/gm, '<h6>$1</h6>');
  s = s.replace(/^#####\s+(.+)$/gm, '<h5>$1</h5>');
  s = s.replace(/^####\s+(.+)$/gm, '<h4>$1</h4>');
  s = s.replace(/^###\s+(.+)$/gm, '<h3>$1</h3>');
  s = s.replace(/^##\s+(.+)$/gm, '<h2>$1</h2>');
  s = s.replace(/^#\s+(.+)$/gm, '<h1>$1</h1>');
  // bold / italic
  s = s.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  s = s.replace(/\*(.+?)\*/g, '<em>$1</em>');
  // 체크리스트
  s = s.replace(/^- \[x\]\s+(.+)$/gm, '<div>☑️ $1</div>');
  s = s.replace(/^- \[ \]\s+(.+)$/gm, '<div>⬜ $1</div>');
  // 리스트
  s = s.replace(/^- (.+)$/gm, '<li>$1</li>');
  s = s.replace(/^(\d+)\.\s+(.+)$/gm, '<li>$2</li>');
  // 수평선
  s = s.replace(/^---+$/gm, '<hr>');
  // 블록쿼트
  s = s.replace(/^&gt;\s+(.+)$/gm, '<blockquote>$1</blockquote>');
  // 인라인 코드
  s = s.replace(/`([^`]+)`/g, '<code style="background:#f1f5f9;padding:1px 4px;border-radius:3px;font-size:12px">$1</code>');
  // 테이블 (간단 처리)
  s = s.replace(/((?:^\|.+\|[ ]*\n){2,})/gm, function(tbl){
    const rows = tbl.trim().split('\n').filter(r=>r.trim());
    if(rows.length < 2) return tbl;
    const parseRow = r => r.replace(/^\|/,'').replace(/\|$/,'').split('|').map(c=>c.trim());
    const hdr = parseRow(rows[0]);
    let startIdx = 1;
    if(rows[1] && /^[\s|:-]+$/.test(rows[1])) startIdx = 2;
    let html = '<table><thead><tr>' + hdr.map(h=>`<th>${h}</th>`).join('') + '</tr></thead><tbody>';
    for(let i=startIdx;i<rows.length;i++){
      const cells = parseRow(rows[i]);
      html += '<tr>' + cells.map(c=>`<td>${c}</td>`).join('') + '</tr>';
    }
    return html + '</tbody></table>';
  });
  // 줄바꿈
  s = s.replace(/\n/g, '<br>');
  return s;
}

// ===== 피드백 시스템 =====
var _fbCurrentRating = '';
var _fbCurrentBtn = null;

function openFeedback(btn, rating){
  _fbCurrentRating = rating;
  _fbCurrentBtn = btn;
  var modal = document.getElementById('feedbackModal');
  var title = document.getElementById('fbModalTitle');
  var display = document.getElementById('fbRatingDisplay');
  var ta = document.getElementById('fbComment');
  if(rating === 'good'){
    title.textContent = '어떤 점이 좋았나요?';
    display.textContent = '👍 좋아요';
    ta.placeholder = '좋았던 점을 알려주세요 (선택사항)';
  } else {
    title.textContent = '어떤 점이 아쉬웠나요?';
    display.textContent = '👎 별로예요';
    ta.placeholder = '개선할 점을 알려주세요 (선택사항)';
  }
  ta.value = '';
  modal.classList.add('show');
  setTimeout(function(){ ta.focus(); }, 100);
}

function closeFeedbackModal(){
  document.getElementById('feedbackModal').classList.remove('show');
  _fbCurrentRating = '';
  _fbCurrentBtn = null;
}

async function submitFeedback(){
  var comment = document.getElementById('fbComment').value;
  // 해당 메시지 내용 가져오기
  var msgEl = _fbCurrentBtn ? _fbCurrentBtn.closest('.msg') : null;
  var msgText = msgEl ? (msgEl.textContent || '').slice(0, 500) : '';
  // 직전 유저 메시지
  var userQuery = '';
  if(msgEl){
    var prev = msgEl.previousElementSibling;
    while(prev){
      if(prev.classList.contains('user')){ userQuery = (prev.textContent || '').slice(0, 300); break; }
      prev = prev.previousElementSibling;
    }
  }
  try{
    await fetch('/api/feedback', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ rating: _fbCurrentRating, comment: comment, message: msgText, user_query: userQuery })
    });
  }catch(e){}
  // 버튼 시각 피드백
  if(_fbCurrentBtn){
    var fbDiv = _fbCurrentBtn.parentElement;
    fbDiv.querySelectorAll('button').forEach(function(b){ b.classList.remove('fb-selected-good','fb-selected-bad'); });
    _fbCurrentBtn.classList.add(_fbCurrentRating === 'good' ? 'fb-selected-good' : 'fb-selected-bad');
  }
  closeFeedbackModal();
}

// 모달 바깥 클릭으로 닫기
document.addEventListener('click', function(e){
  var modal = document.getElementById('feedbackModal');
  if(e.target === modal) closeFeedbackModal();
});

// ===== 응답 전체를 MD 다운로드 가능하게 =====
function appendMdDownloadBar(rawContent, htmlDownloadUrl){
  // 마지막 assistant 메시지에 MD/HTML 다운로드 바 추가
  const msgs = document.querySelectorAll('.msg.assistant');
  if(msgs.length === 0) return;
  const lastMsg = msgs[msgs.length - 1];
  const mdB64 = u2b(rawContent);
  const bar = document.createElement('div');
  bar.className = 'md-report-header';
  bar.style.marginTop = '10px';
  bar.style.borderRadius = '8px';
  bar.innerHTML = `<span>📋 마크다운 문서로 저장</span>
    <div class="md-report-actions">
      <button class="md-report-btn" onclick="copyMdContent(this)" data-md="${mdB64}">📋 복사</button>
      <button class="md-report-btn md-download" onclick="downloadMarkdown(this)" data-md="${mdB64}">📥 MD 다운로드</button>
      <button class="md-report-btn" style="background:#6366f1;color:#fff;" onclick="downloadHtmlDoc(this)" data-md="${mdB64}" ${htmlDownloadUrl ? 'data-html-url="'+htmlDownloadUrl+'"' : ''}>📄 HTML 다운로드</button>
    </div>`;
  lastMsg.appendChild(bar);
}

async function downloadHtmlDoc(btn){
  const htmlUrl = btn.dataset.htmlUrl;
  if(htmlUrl){
    const a = document.createElement('a');
    a.href = htmlUrl;
    a.download = 'document.html';
    a.click();
    return;
  }
  // URL 없으면 API로 변환 요청
  const md = b2u(btn.dataset.md);
  btn.disabled = true;
  btn.textContent = '⏳ 변환 중...';
  try{
    const res = await fetch('/api/generate_html',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({markdown:md, title:'문서'})
    });
    const data = await res.json();
    if(data.download_url){
      const a = document.createElement('a');
      a.href = data.download_url;
      a.download = 'document.html';
      a.click();
    } else {
      alert(data.error || 'HTML 변환 실패');
    }
  }catch(e){
    alert('HTML 변환 실패: '+e.message);
  }finally{
    btn.disabled = false;
    btn.textContent = '📄 HTML 다운로드';
  }
}

async function removeCsv(){
  await fetch('/api/clear_csv', {method:'POST'});
  csvLoaded = false;
  csvFilename = '';
  document.getElementById('csvInfoPanel').style.display = 'none';
}

// ===== 파일 관리 =====
let uploadedFilesList = [];

function renderFileList(){
  const panel = document.getElementById('fileListPanel');
  if(uploadedFilesList.length === 0){
    panel.style.display = 'none';
    return;
  }
  panel.style.display = 'block';
  let html = '<div class="uploaded-files-header"><span>📎 첨부 파일 ('+uploadedFilesList.length+')</span><button onclick="clearAllFiles()" style="background:none;border:none;color:#e74c3c;cursor:pointer;font-size:10px;padding:0">전체 제거</button></div>';
  uploadedFilesList.forEach((f,i)=>{
    const sizeStr = f.size > 1048576 ? (f.size/1048576).toFixed(1)+'MB' : (f.size/1024).toFixed(1)+'KB';
    const pendingCls = f.pending ? ' ufi-pending' : (f.drm ? ' ufi-drm' : '');
    const statusLabel = f.pending ? ' ⏳' : (f.drm ? ' 🔒' : '');
    const removeAction = f.pending
      ? `removeChatAttachByName('${esc(f.filename)}')`
      : `removeFile('${esc(f.filename)}',${i})`;
    const titleText = f.drm ? 'DRM 보호 파일 - 내용 분석 불가' : esc(f.preview||'');
    html += `<div class="uploaded-file-item${pendingCls}">
      <span class="ufi-icon">${f.icon}</span>
      <span class="ufi-name" title="${titleText}">${esc(f.filename)}${statusLabel}</span>
      <span class="ufi-size">${sizeStr}</span>
      <button class="ufi-remove" onclick="${removeAction}">✕</button>
    </div>`;
  });
  panel.innerHTML = html;
}

async function removeFile(filename, idx){
  await fetch('/api/remove_file', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({filename})});
  uploadedFilesList.splice(idx, 1);
  renderFileList();
}

async function clearAllFiles(){
  await fetch('/api/clear_files', {method:'POST'});
  uploadedFilesList = [];
  renderFileList();
}

// ===== 채팅 입력 첨부파일 =====
let chatPendingFiles = [];  // [{file:File, name:string}]

// 파일 확장자 → 추천 스킬 매핑 (프론트엔드용)
const fileExtSkillHints = {
  'py':['agent-python-pro'], 'js':['agent-nextjs-developer'], 'ts':['agent-nextjs-developer'], 'tsx':['agent-nextjs-developer'],
  'csv':['exploratory-data-analysis','statistical-analysis'],
  'tsv':['exploratory-data-analysis'], 'xlsx':['exploratory-data-analysis'],
  'docx':['docx'], 'pdf':['pdf'], 'pptx':['pptx'],
  'drawio':['drawio-diagram'], 'xml':['drawio-diagram'],
  'md':['markdown-mermaid-writing'], 'html':['web-artifacts-builder'],
};

function handleChatFileSelect(files){
  let hintSkills = [];
  const iconMap = {py:'🐍',js:'📜',ts:'📘',tsx:'📘',jsx:'📜',html:'🌐',css:'🎨',json:'📋',
    yaml:'📋',yml:'📋',md:'📄',java:'☕',c:'⚙️',cpp:'⚙️',go:'🐹',rs:'🦀',sh:'💻',
    png:'🖼️',jpg:'🖼️',jpeg:'🖼️',gif:'🖼️',bmp:'🖼️',webp:'🖼️',svg:'🖼️',
    docx:'📄',xlsx:'📊',pdf:'📕',pptx:'📽️',csv:'📊',txt:'📝',sql:'🗃️',rb:'💎',php:'🐘',vue:'💚',r:'📈'};
  for(const f of files){
    chatPendingFiles.push({file:f, name:f.name});
    // 파일 확장자로 추천 스킬 수집
    const ext = f.name.split('.').pop().toLowerCase();
    if(fileExtSkillHints[ext]){
      hintSkills.push(...fileExtSkillHints[ext]);
    }
    // 즉시 사이드바에 pending 상태로 표시
    uploadedFilesList.push({
      filename: f.name, type: ext, ext: ext,
      size: f.size, icon: iconMap[ext]||'📎', preview: '', pending: true
    });
  }
  renderChatAttach();
  renderFileList();
  document.getElementById('chatFileInput').value = '';

  // 파일 기반 추천 스킬 프리로드 (수동 선택 없을 때만)
  if(hintSkills.length > 0 && selSkills.length === 0){
    const unique = [...new Set(hintSkills)].filter(id => !selSkills.includes(id));
    autoLoadedSkills = [...new Set([...autoLoadedSkills, ...unique])];
    renderSkills();
    updateLoaded();
  }
}

function removeChatAttach(idx){
  const removed = chatPendingFiles.splice(idx, 1);
  // 사이드바 pending 항목도 함께 제거
  if(removed.length > 0){
    const pi = uploadedFilesList.findIndex(f => f.pending && f.filename === removed[0].name);
    if(pi >= 0) uploadedFilesList.splice(pi, 1);
    renderFileList();
  }
  renderChatAttach();
}
function removeChatAttachByName(name){
  const ci = chatPendingFiles.findIndex(f => f.name === name);
  if(ci >= 0) chatPendingFiles.splice(ci, 1);
  const pi = uploadedFilesList.findIndex(f => f.pending && f.filename === name);
  if(pi >= 0) uploadedFilesList.splice(pi, 1);
  renderChatAttach();
  renderFileList();
}

// 입력창 드래그앤드롭 파일 첨부
(function(){
  const box = document.querySelector('.chat-box-fixed');
  if(!box) return;
  box.addEventListener('dragover', e=>{e.preventDefault();e.stopPropagation();box.style.borderTopColor='#6366f1';});
  box.addEventListener('dragleave', e=>{e.preventDefault();box.style.borderTopColor='';});
  box.addEventListener('drop', e=>{
    e.preventDefault();e.stopPropagation();box.style.borderTopColor='';
    if(e.dataTransfer.files.length > 0) handleChatFileSelect(e.dataTransfer.files);
  });
})();

// Ctrl+V / Cmd+V 이미지 붙여넣기 (스크린샷, 클립보드 이미지)
(function(){
  const input = document.getElementById('input');
  if(!input) return;
  input.addEventListener('paste', function(e){
    const items = e.clipboardData && e.clipboardData.items;
    if(!items) return;
    const imageFiles = [];
    for(let i=0; i<items.length; i++){
      if(items[i].type.startsWith('image/')){
        const blob = items[i].getAsFile();
        if(blob){
          // 파일명 생성: paste_날짜시간.확장자
          const ext = items[i].type.split('/')[1] || 'png';
          const now = new Date();
          const ts = now.getFullYear()+String(now.getMonth()+1).padStart(2,'0')+String(now.getDate()).padStart(2,'0')+'_'+String(now.getHours()).padStart(2,'0')+String(now.getMinutes()).padStart(2,'0')+String(now.getSeconds()).padStart(2,'0');
          const fname = 'paste_'+ts+'.'+ext.replace('jpeg','jpg');
          const file = new File([blob], fname, {type: items[i].type});
          imageFiles.push(file);
        }
      }
    }
    if(imageFiles.length > 0){
      e.preventDefault();  // 텍스트로 붙여넣기 방지
      handleChatFileSelect(imageFiles);
    }
  });
})();

function renderChatAttach(){
  const wrap = document.getElementById('chatAttachPreview');
  if(chatPendingFiles.length === 0){
    wrap.style.display = 'none';
    wrap.innerHTML = '';
    return;
  }
  wrap.style.display = 'flex';
  wrap.innerHTML = chatPendingFiles.map((f,i)=>
    `<span class="chat-attach-badge"><span class="fname">${esc(f.name)}</span><span class="remove-attach" onclick="removeChatAttach(${i})">✕</span></span>`
  ).join('');
}

async function uploadChatPendingFiles(){
  // 첨부된 파일들을 서버로 업로드 (CSV는 csv 엔드포인트, 나머지는 범용)
  // pending 항목을 실제 업로드 결과로 교체
  const results = [];
  for(const pf of chatPendingFiles){
    const ext = pf.name.split('.').pop().toLowerCase();
    const formData = new FormData();
    formData.append('file', pf.file);

    // pending 항목 찾기
    const pendingIdx = uploadedFilesList.findIndex(f => f.pending && f.filename === pf.name);

    // CSV/TSV → CSV 전용 엔드포인트 (데이터 분석용)
    if(['csv','tsv'].includes(ext) && !csvLoaded){
      try{
        await uploadCsvFile(pf.file);
        results.push(pf.name);
        if(pendingIdx >= 0) uploadedFilesList[pendingIdx].pending = false;
      }catch(e){
        if(pendingIdx >= 0) uploadedFilesList.splice(pendingIdx, 1);
      }
      continue;
    }

    // XLSX → 전용 엔드포인트 (시트별 파싱 + 이미지 추출)
    if(ext === 'xlsx' && !csvLoaded){
      try{
        await uploadXlsxFile(pf.file);
        results.push(pf.name);
        if(pendingIdx >= 0) uploadedFilesList[pendingIdx].pending = false;
      }catch(e){
        if(pendingIdx >= 0) uploadedFilesList.splice(pendingIdx, 1);
      }
      continue;
    }

    // 나머지 → 범용 파일 엔드포인트
    try{
      const resp = await fetch('/api/upload_file', {method:'POST', body:formData});
      const data = await resp.json();
      if(!data.error){
        // pending 항목을 실제 데이터로 교체
        const updated = {
          filename: data.filename, type: data.type, ext: data.ext,
          size: data.size, icon: data.icon, preview: data.preview,
          drm: !!data.drm_warning,
        };
        if(pendingIdx >= 0) uploadedFilesList[pendingIdx] = updated;
        else uploadedFilesList.push(updated);
        results.push(data.filename);
        // DRM 보호 파일이면 채팅에 안내 메시지 표시
        if(data.drm_warning){
          addMsg('assistant', `🔒 **DRM 보호 파일 감지**: ${data.filename}\n${data.drm_warning}\n\n파일은 첨부되었지만, DRM 때문에 내용 분석이 불가능합니다.`);
        }
      } else {
        // 업로드 실패 시 pending 제거 + 사용자에게 알림
        if(pendingIdx >= 0) uploadedFilesList.splice(pendingIdx, 1);
        addMsg('assistant', data.error);
      }
    }catch(e){
      if(pendingIdx >= 0) uploadedFilesList.splice(pendingIdx, 1);
    }
  }
  chatPendingFiles = [];
  renderChatAttach();
  renderFileList();
  return results;
}

// ===== 오른쪽 코드 어시스턴트 패널 =====
let rpFiles = [];  // [{name, path, content, ext, size}]
let rpSelectedMode = null;
let rpTreeData = null;  // 트리 구조 데이터
let rpSelectedFile = null;  // 현재 선택된 파일 인덱스
const rpModeLabels = {
  explain:'코드 설명', find_bugs:'버그 탐지', improve:'개선 제안',
  tests:'테스트 생성', docstring:'문서화', refactor:'리팩토링'
};
const rpModePrompts = {
  explain:'[EXPLAIN] 아래 코드를 분석해주세요.\n⚠️ 먼저 코드의 프로그래밍 언어와 프레임워크를 판별한 후, 해당 언어의 관점에서 분석하세요.\n1. 감지된 언어/프레임워크 명시\n2. 전체 목적과 아키텍처\n3. 주요 함수/클래스 구조\n4. 실행 흐름과 핵심 알고리즘\n5. 의존성 분석\n한국어로 설명해주세요.',
  find_bugs:'[FIND_BUGS] 아래 코드에서 버그를 찾아주세요.\n⚠️ 먼저 코드의 프로그래밍 언어를 판별하고, 해당 언어 특유의 버그 패턴을 중점 검토하세요.\n1. 감지된 언어 명시\n2. 언어 특화 버그 패턴 (Python: 인덴트/타입, Java: NPE/동시성, C#: async/dispose, JS: 타입강제/this바인딩)\n3. 로직 오류, 보안 취약점\n4. 심각도 🔴🟡🟢 표시 + 수정 코드 제시\n한국어로 분석해주세요.',
  improve:'[IMPROVE] 아래 코드의 개선점을 제안해주세요.\n⚠️ 먼저 코드의 프로그래밍 언어를 판별하고, 해당 언어의 베스트 프랙티스 기준으로 개선하세요.\n1. 감지된 언어 명시\n2. 언어별 관용적 표현 적용 (Python: PEP8/컴프리헨션, Java: Stream API, C#: LINQ, JS: ES6+)\n3. 가독성, 성능, 유지보수성 개선\n4. 개선 전/후 코드 비교\n한국어로 설명해주세요.',
  tests:'[TESTS] 아래 코드에 대한 테스트 코드를 생성해주세요.\n⚠️ 먼저 코드의 프로그래밍 언어를 판별하고, 해당 언어의 표준 테스트 프레임워크를 사용하세요.\n(Python→pytest, Java→JUnit5, C#→xUnit, JS/TS→Jest, Go→go test, Rust→cargo test)\n1. 감지된 언어/프레임워크 명시\n2. 정상/엣지/에러 케이스\n3. 즉시 실행 가능한 코드\n한국어 주석으로 설명해주세요.',
  docstring:'[DOCSTRING] 아래 코드에 문서화를 추가해주세요.\n⚠️ 먼저 코드의 프로그래밍 언어를 판별하고, 해당 언어의 표준 문서화 스타일을 적용하세요.\n(Python→Google/NumPy docstring, Java→Javadoc, C#→XML 주석, JS/TS→JSDoc)\n1. 감지된 언어 명시\n2. 함수/클래스별 문서화 (파라미터, 반환값, 예외, 예시)\n3. 핵심 로직 인라인 주석 (한국어)\n⚠️ 중요: 전체 파일 내용을 반복하지 말고, 문서화가 추가된 핵심 함수/클래스만 제시하세요.',
  refactor:'[REFACTOR] 아래 코드를 리팩토링해주세요.\n⚠️ 먼저 코드의 프로그래밍 언어를 판별하고, 해당 언어의 디자인 패턴과 관례에 맞게 리팩토링하세요.\n1. 감지된 언어 명시\n2. SOLID 원칙 적용\n3. 언어별 관용 패턴 (Python: 데코레이터/컨텍스트매니저, Java: Builder/DI, C#: async패턴)\n4. 리팩토링 전/후 비교\n한국어로 설명해주세요.'
};

// 코드 어시스턴트 전용 언어/도구 감지 매핑
const rpExtLangMap = {
  'py':'Python','js':'JavaScript','ts':'TypeScript','tsx':'TypeScript(React)','jsx':'JavaScript(React)',
  'java':'Java','c':'C','cpp':'C++','h':'C/C++ Header','cs':'C#',
  'go':'Go','rs':'Rust','rb':'Ruby','php':'PHP','swift':'Swift','kt':'Kotlin',
  'html':'HTML','css':'CSS','json':'JSON','xml':'XML','yaml':'YAML','yml':'YAML',
  'sh':'Shell','bat':'Batch','sql':'SQL','r':'R','scala':'Scala','dart':'Dart',
  'md':'Markdown','dockerfile':'Docker','makefile':'Make','toml':'TOML','cfg':'Config','ini':'Config'
};
const rpExtSkillMap = {
  'py':['agent-python-pro'], 'js':['agent-javascript-pro','agent-nextjs-developer'],
  'ts':['agent-javascript-pro','agent-nextjs-developer'], 'tsx':['agent-javascript-pro','agent-nextjs-developer'],
  'jsx':['agent-javascript-pro','agent-nextjs-developer'],
  'java':['code-assistant'], 'c':['code-assistant'], 'cpp':['code-assistant'], 'cs':['code-assistant'],
  'go':['code-assistant'], 'rs':['code-assistant'], 'rb':['code-assistant'], 'php':['code-assistant'],
  'swift':['code-assistant'], 'kt':['code-assistant'], 'html':['web-artifacts-builder'],
  'css':['web-artifacts-builder'], 'sql':['code-assistant'], 'r':['code-assistant'],
  'dart':['code-assistant'], 'scala':['code-assistant']
};
const rpLangColors = {
  'Python':'#3776ab','JavaScript':'#f7df1e','TypeScript':'#3178c6','TypeScript(React)':'#3178c6',
  'JavaScript(React)':'#61dafb','Java':'#b07219','C':'#555555','C++':'#f34b7d','C#':'#178600',
  'Go':'#00add8','Rust':'#dea584','Ruby':'#701516','PHP':'#4f5d95','Swift':'#f05138','Kotlin':'#a97bff',
  'HTML':'#e34c26','CSS':'#563d7c','Shell':'#89e051','SQL':'#e38c00','R':'#198ce7','Dart':'#00b4ab'
};

// 코드 요약: 큰 파일은 시그니처+핵심부분만 추출
function summarizeCode(content, ext, maxLines){
  maxLines = maxLines || 150;
  const lines = content.split('\n');
  if(lines.length <= maxLines) return content; // 작은 파일은 전체 전달

  const result = [];
  const sigPatterns = {
    'py': /^\s*(class |def |async def |import |from .+ import|@)/,
    'java': /^\s*(public |private |protected |class |interface |import |@|package )/,
    'cs': /^\s*(public |private |protected |internal |class |interface |using |namespace |\[)/,
    'js': /^\s*(function |const |let |var |class |export |import |async |module\.)/,
    'ts': /^\s*(function |const |let |var |class |export |import |async |interface |type |module\.)/,
    'tsx': /^\s*(function |const |let |var |class |export |import |async |interface |type )/,
    'jsx': /^\s*(function |const |let |var |class |export |import |async )/,
    'go': /^\s*(func |type |package |import |var |const )/,
    'rs': /^\s*(fn |pub |struct |enum |impl |use |mod |trait )/,
    'rb': /^\s*(class |def |module |require |include |attr_)/,
    'php': /^\s*(function |class |namespace |use |public |private |protected )/,
    'swift': /^\s*(func |class |struct |enum |protocol |import |var |let )/,
    'kt': /^\s*(fun |class |object |interface |import |val |var |data class)/,
    'c': /^\s*(#include |#define |typedef |struct |int |void |char |float |double |static )/,
    'cpp': /^\s*(#include |#define |typedef |struct |class |template |namespace |int |void )/,
    'h': /^\s*(#include |#define |#ifndef |typedef |struct |class |extern )/,
  };
  const pat = sigPatterns[ext] || /^\s*(function |class |def |import |export |public |private )/;

  // 1) 첫 30줄 (imports, 설정)
  result.push('// === 파일 시작 (첫 30줄) ===');
  result.push(...lines.slice(0, 30));

  // 2) 시그니처 라인 추출 (함수/클래스 정의 + 전후 2줄)
  result.push('');
  result.push('// === 주요 시그니처 & 구조 ===');
  const added = new Set();
  lines.forEach((line, i)=>{
    if(i < 30) return; // 이미 포함됨
    if(pat.test(line)){
      for(let j=Math.max(i-1,30); j<=Math.min(lines.length-1,i+3); j++){
        if(!added.has(j)){
          added.add(j);
          result.push(`[L${j+1}] ${lines[j]}`);
        }
      }
      result.push('  ...');
    }
  });

  // 3) 마지막 10줄
  result.push('');
  result.push('// === 파일 끝 (마지막 10줄) ===');
  result.push(...lines.slice(-10));

  result.push(`\n// [총 ${lines.length}줄 중 시그니처 요약 - 전체 코드 필요시 요청하세요]`);
  return result.join('\n');
}

// catalog에 실제 존재하는 스킬인지 확인
function isSkillInCatalog(skillId){
  for(const did of Object.keys(catalog)){
    const d = catalog[did];
    if(d && d.skills && d.skills.some(s=>s.id===skillId && s.available)) return true;
  }
  return false;
}

function detectRpLanguages(){
  const langCount = {};
  const detectedSkills = new Set();

  rpFiles.forEach(f=>{
    const lang = rpExtLangMap[f.ext];
    if(lang){
      langCount[lang] = (langCount[lang]||0) + 1;
    }
    const skills = rpExtSkillMap[f.ext];
    if(skills) skills.forEach(s=>detectedSkills.add(s));
  });

  const panel = document.getElementById('rpLangDetect');
  const tagsEl = document.getElementById('rpLangTags');
  const autoEl = document.getElementById('rpAutoSkills');

  if(rpFiles.length === 0 || Object.keys(langCount).length === 0){
    panel.style.display = 'none';
    return;
  }
  panel.style.display = 'block';

  // 감지된 언어 태그 렌더링 (파일 수 기준 내림차순)
  const sorted = Object.entries(langCount).sort((a,b)=>b[1]-a[1]);
  const primaryLang = sorted[0][0];
  tagsEl.innerHTML = sorted.map(([lang, cnt])=>{
    const color = rpLangColors[lang] || '#6b7280';
    const isPrimary = lang === primaryLang;
    return `<span style="display:inline-flex;align-items:center;gap:3px;padding:2px 7px;border-radius:10px;background:${color}22;border:${isPrimary?'2':'1'}px solid ${color}${isPrimary?'':'55'};color:${color};font-weight:600;font-size:10px;">${isPrimary?'⭐ ':''}${lang} <span style="font-weight:400;color:#888">${cnt}</span></span>`;
  }).join('');

  // 자동 스킬 로드 - catalog에 실제 있는 것만
  const newSkills = [];
  const loadedNames = [];
  // code-assistant 항상 먼저
  if(isSkillInCatalog('code-assistant') && !selSkills.includes('code-assistant')){
    selSkills.push('code-assistant');
    newSkills.push('code-assistant');
  }
  if(selSkills.includes('code-assistant')) loadedNames.push('code-assistant');

  detectedSkills.forEach(skill=>{
    if(skill === 'code-assistant') return;
    if(isSkillInCatalog(skill)){
      if(!selSkills.includes(skill)){
        selSkills.push(skill);
        newSkills.push(skill);
      }
      loadedNames.push(skill);
    }
  });

  // autoLoadedSkills 업데이트 (UI에서 🧠자동 배지 표시용)
  autoLoadedSkills = [...new Set([...autoLoadedSkills, ...newSkills])];

  if(newSkills.length > 0){
    renderSkills();
    updateLoaded();
  }

  // 상태 표시
  const availableLoaded = loadedNames.filter(s=>s!=='code-assistant');
  if(availableLoaded.length > 0){
    autoEl.innerHTML = '✅ <b>자동 로드:</b> ' + availableLoaded.join(', ') + ' + code-assistant';
  } else {
    autoEl.innerHTML = '✅ <b>주 언어:</b> ' + primaryLang + ' → LLM이 자동 판별하여 분석합니다';
  }
}

function toggleRightPanel(){
  const rp = document.getElementById('rightPanel');
  const btn = document.getElementById('rightPanelToggle');
  rp.classList.toggle('collapsed');
  document.body.classList.toggle('rp-collapsed');
  if(rp.classList.contains('collapsed')){
    btn.textContent = '◀';
    document.querySelector('.chat-box-fixed').style.right = '0';
  } else {
    btn.textContent = '▶';
    document.querySelector('.chat-box-fixed').style.right = '340px';
  }
  localStorage.setItem('demos_rp_collapsed', rp.classList.contains('collapsed'));
}

// 초기 상태 복원
(function(){
  const saved = localStorage.getItem('demos_rp_collapsed');
  if(saved === 'true'){
    const rp = document.getElementById('rightPanel');
    const btn = document.getElementById('rightPanelToggle');
    if(rp){ rp.classList.add('collapsed'); document.body.classList.add('rp-collapsed'); btn.textContent='◀'; }
  }
})();

// 드래그앤드롭
(function(){
  const drop = document.getElementById('rpFileDrop');
  if(!drop) return;
  drop.addEventListener('dragover', e=>{e.preventDefault();e.stopPropagation();drop.classList.add('dragover');});
  drop.addEventListener('dragleave', e=>{e.preventDefault();drop.classList.remove('dragover');});
  drop.addEventListener('drop', e=>{
    e.preventDefault();e.stopPropagation();drop.classList.remove('dragover');
    if(e.dataTransfer.files.length > 0) handleRpFileSelect(e.dataTransfer.files);
  });
})();

function selectRpModel(btn){
  document.querySelectorAll('.rp-model-btn').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  selRpModel = btn.dataset.model;
  const badges = {
    'kimi-k25':'🔥 Kimi-K2.5',
    'coder-480b':'🚀 Coder-480B',
    'qwen35-397b':'🦣 Qwen3.5-397B',
    'qwen35-397b-fp8':'🦣 397B FP8',
    'glm-5-1':'💎 GLM-5.1'
  };
  const badge = document.getElementById('rpModelBadge');
  if(badge) badge.textContent = badges[selRpModel] || selRpModel;
}

function switchUploadMode(mode, btn){
  document.querySelectorAll('.rp-tab').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  document.getElementById('rpFolderMode').style.display = mode==='folder' ? 'block' : 'none';
  document.getElementById('rpFileMode').style.display = mode==='files' ? 'block' : 'none';
}

function handleRpFolderSelect(files){
  const codeExts = ['py','js','html','css','json','xml','yaml','yml','c','cpp','h','java','go','rs','sh','bat','md','txt','ts','tsx','jsx','rb','php','swift','kt','toml','cfg','ini','env','gitignore','dockerfile','makefile'];
  const skipDirs = ['node_modules','.git','__pycache__','.venv','venv','.next','dist','build','.idea','.vscode'];
  let pending = 0;
  let totalSize = 0;

  for(const f of files){
    const path = f.webkitRelativePath || f.name;
    // 불필요한 디렉토리 스킵
    const parts = path.split('/');
    if(parts.some(p => skipDirs.includes(p))) continue;

    const ext = f.name.split('.').pop().toLowerCase();
    if(!codeExts.includes(ext) && f.name.indexOf('.') !== -1) continue;
    if(f.size > 500000) continue; // 500KB 이상 파일 스킵

    pending++;
    totalSize += f.size;
    const reader = new FileReader();
    reader.onload = function(e){
      const newIdx = rpFiles.length;
      rpFiles.push({name:f.name, path:path, content:e.target.result, ext:ext, size:f.size});
      rpCheckedFiles.add(newIdx);  // 업로드 즉시 자동 체크
      pending--;
      if(pending === 0){
        buildRpTree();
        renderRpTree();
        updateRpRunBtn();
        detectRpLanguages();
      }
    };
    reader.readAsText(f);
  }
  document.getElementById('rpFolderInput').value = '';
}

function buildRpTree(){
  rpTreeData = {name:'root', children:{}, files:[]};
  rpFiles.forEach((f,idx)=>{
    const parts = (f.path || f.name).split('/');
    let node = rpTreeData;
    // 첫 번째 파트는 루트 폴더명
    for(let i=0; i<parts.length-1; i++){
      if(!node.children[parts[i]]){
        node.children[parts[i]] = {name:parts[i], children:{}, files:[]};
      }
      node = node.children[parts[i]];
    }
    node.files.push({name:parts[parts.length-1], idx:idx, ext:f.ext, size:f.size});
  });
}

let rpCheckedFiles = new Set();  // 체크된 파일 인덱스

function renderRpTree(){
  const container = document.getElementById('rpTree');
  const stats = document.getElementById('rpTreeStats');
  const selectBar = document.getElementById('rpSelectBar');
  if(rpFiles.length === 0){
    container.style.display = 'none';
    stats.style.display = 'none';
    selectBar.style.display = 'none';
    return;
  }
  container.style.display = 'block';
  stats.style.display = 'flex';
  selectBar.style.display = 'flex';

  // 기본: 전체 체크
  if(rpCheckedFiles.size === 0){
    rpFiles.forEach((_,i)=>rpCheckedFiles.add(i));
  }

  // 통계
  const folders = new Set();
  rpFiles.forEach(f=>{
    const parts = (f.path||f.name).split('/');
    for(let i=1;i<parts.length;i++) folders.add(parts.slice(0,i).join('/'));
  });
  const totalSize = rpFiles.reduce((s,f)=>s+f.size,0);
  const sizeStr = totalSize > 1048576 ? (totalSize/1048576).toFixed(1)+'MB' : (totalSize/1024).toFixed(1)+'KB';
  document.getElementById('rpStatsInfo').textContent = rpFiles.length+' 파일 / '+folders.size+' 폴더';
  document.getElementById('rpStatsSize').textContent = sizeStr;

  container.innerHTML = renderTreeNode(rpTreeData, true);
  updateCheckedCount();
  updateParentFolderChecks();
}

function renderTreeNode(node, isRoot){
  let html = '';
  // 폴더들
  const childKeys = Object.keys(node.children).sort();
  childKeys.forEach(key=>{
    const child = node.children[key];
    const fileCount = countFiles(child);
    const folderIdxs = collectFileIdxs(child);
    const allChecked = folderIdxs.every(i=>rpCheckedFiles.has(i));
    const someChecked = folderIdxs.some(i=>rpCheckedFiles.has(i));
    html += `<div class="rp-tree-node rp-tree-folder">
      <input type="checkbox" class="rp-tree-cb" data-folder-idxs="${folderIdxs.join(',')}" ${allChecked?'checked':''} onclick="event.stopPropagation();toggleFolderCheck(this)" onchange="event.stopPropagation()">
      <span class="rp-tree-node-content" onclick="toggleTreeFolder(this.parentElement)"><span class="rp-tree-toggle">▶</span><span class="rp-tree-icon">📁</span>${esc(key)} <span style="color:#bbb;font-weight:400">(${fileCount})</span></span>
    </div><div class="rp-tree-children" style="display:none">${renderTreeNode(child, false)}</div>`;
  });
  // 파일들
  node.files.sort((a,b)=>a.name.localeCompare(b.name)).forEach(f=>{
    const langIcon = {py:'🐍',js:'📜',html:'🌐',css:'🎨',java:'☕',c:'⚙️',cpp:'⚙️',go:'🐹',rs:'🦀',sh:'💻',json:'📋',yaml:'📋',yml:'📋',md:'📄',ts:'📘',tsx:'📘'}[f.ext]||'📄';
    const checked = rpCheckedFiles.has(f.idx);
    html += `<div class="rp-tree-node rp-tree-file" data-idx="${f.idx}">
      <input type="checkbox" class="rp-tree-cb" data-idx="${f.idx}" ${checked?'checked':''} onclick="event.stopPropagation();toggleFileCheck(${f.idx},this)">
      <span class="rp-tree-node-content" onclick="selectTreeFile(${f.idx},this.parentElement)"><span class="rp-tree-toggle"> </span><span class="rp-tree-icon">${langIcon}</span>${esc(f.name)}</span>
    </div>`;
  });
  return html;
}

function collectFileIdxs(node){
  let idxs = node.files.map(f=>f.idx);
  Object.values(node.children).forEach(ch=>{ idxs = idxs.concat(collectFileIdxs(ch)); });
  return idxs;
}

function toggleFileCheck(idx, cb){
  if(cb.checked) rpCheckedFiles.add(idx);
  else rpCheckedFiles.delete(idx);
  updateCheckedCount();
  updateParentFolderChecks();
}

function toggleFolderCheck(cb){
  const idxs = cb.dataset.folderIdxs.split(',').filter(Boolean).map(Number).filter(n=>!isNaN(n));
  if(cb.checked) idxs.forEach(i=>rpCheckedFiles.add(i));
  else idxs.forEach(i=>rpCheckedFiles.delete(i));
  // 하위 파일 + 하위 폴더 체크박스 모두 동기화
  const parent = cb.closest('.rp-tree-folder');
  const childContainer = parent ? parent.nextElementSibling : null;
  if(childContainer && childContainer.classList.contains('rp-tree-children')){
    childContainer.querySelectorAll('input.rp-tree-cb').forEach(childCb=>{
      childCb.checked = cb.checked;
      childCb.indeterminate = false;
    });
  }
  updateCheckedCount();
  updateParentFolderChecks();
}

function updateParentFolderChecks(){
  document.querySelectorAll('.rp-tree-cb[data-folder-idxs]').forEach(cb=>{
    const idxs = cb.dataset.folderIdxs.split(',').filter(Boolean).map(Number).filter(n=>!isNaN(n));
    const checkedCount = idxs.filter(i=>rpCheckedFiles.has(i)).length;
    cb.checked = checkedCount === idxs.length;
    cb.indeterminate = checkedCount > 0 && checkedCount < idxs.length;
  });
}

function rpCheckAll(checked){
  if(checked) rpFiles.forEach((_,i)=>rpCheckedFiles.add(i));
  else rpCheckedFiles.clear();
  document.querySelectorAll('.rp-tree-cb').forEach(cb=>{ cb.checked=checked; cb.indeterminate=false; });
  updateCheckedCount();
}

function updateCheckedCount(){
  const count = rpCheckedFiles.size;
  document.getElementById('rpCheckedCount').textContent = count+'개 선택';
  updateRpRunBtn();
}

function countFiles(node){
  let c = node.files.length;
  Object.values(node.children).forEach(ch=>{ c += countFiles(ch); });
  return c;
}

function toggleTreeFolder(el){
  const children = el.nextElementSibling;
  const toggle = el.querySelector('.rp-tree-toggle');
  if(children.style.display === 'none'){
    children.style.display = 'block';
    toggle.textContent = '▼';
  } else {
    children.style.display = 'none';
    toggle.textContent = '▶';
  }
}

function selectTreeFile(idx, el){
  document.querySelectorAll('.rp-tree-file').forEach(e=>e.classList.remove('active'));
  if(el) el.classList.add('active');
  rpSelectedFile = idx;
}

function clearRpProject(){
  rpFiles = [];
  rpTreeData = null;
  rpSelectedFile = null;
  rpCheckedFiles.clear();
  document.getElementById('rpTree').style.display = 'none';
  document.getElementById('rpTreeStats').style.display = 'none';
  document.getElementById('rpLangDetect').style.display = 'none';
  document.getElementById('rpSelectBar').style.display = 'none';
  document.getElementById('rpFileList').innerHTML = '';
  updateRpRunBtn();
}

function handleRpFileSelect(files){
  const codeExts = ['py','js','html','css','json','xml','yaml','yml','c','cpp','h','java','go','rs','sh','bat','md','txt','ts','tsx','jsx','rb','php','swift','kt'];
  for(const f of files){
    const ext = f.name.split('.').pop().toLowerCase();
    if(!codeExts.includes(ext)){ alert(f.name+': 지원하지 않는 파일 형식입니다.'); continue; }
    const reader = new FileReader();
    reader.onload = function(e){
      const newIdx = rpFiles.length;
      rpFiles.push({name:f.name, content:e.target.result, ext:ext, size:f.size});
      rpCheckedFiles.add(newIdx);  // 업로드 즉시 자동 체크
      renderRpFiles();
      updateRpRunBtn();
      detectRpLanguages();
    };
    reader.readAsText(f);
  }
  document.getElementById('rpFileInput').value = '';
}

function renderRpFiles(){
  const list = document.getElementById('rpFileList');
  if(rpFiles.length === 0){ list.innerHTML = ''; return; }
  list.innerHTML = rpFiles.map((f,i)=>{
    const sizeStr = f.size > 1048576 ? (f.size/1048576).toFixed(1)+'MB' : (f.size/1024).toFixed(1)+'KB';
    const langIcon = {py:'🐍',js:'📜',html:'🌐',css:'🎨',java:'☕',c:'⚙️',cpp:'⚙️',go:'🐹',rs:'🦀',sh:'💻',json:'📋',yaml:'📋',yml:'📋',md:'📄',ts:'📘',tsx:'📘'}[f.ext] || '📄';
    return `<div class="rp-file-item">
      <span>${langIcon}</span><span class="fname">${esc(f.name)}</span><span class="fsize">${sizeStr}</span>
      <button class="fremove" onclick="event.stopPropagation();removeRpFile(${i})">✕</button>
    </div>`;
  }).join('');
}

function removeRpFile(idx){
  rpFiles.splice(idx, 1);
  renderRpFiles();
  updateRpRunBtn();
}


function selectRpMode(btn){
  document.querySelectorAll('.rp-action-btn').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  rpSelectedMode = btn.dataset.mode;
  updateRpRunBtn();
}

function updateRpRunBtn(){
  const btn = document.getElementById('rpRunBtn');
  const checkedCount = rpCheckedFiles.size;
  if(rpFiles.length > 0 && rpSelectedMode && checkedCount > 0){
    btn.disabled = false;
    btn.textContent = '▶ ' + rpModeLabels[rpSelectedMode] + ' (' + checkedCount + '개 파일)';
  } else if(rpFiles.length > 0 && checkedCount === 0){
    btn.disabled = true;
    btn.textContent = '▶ 분석할 파일을 선택하세요 (체크박스)';
  } else {
    btn.disabled = true;
    btn.textContent = rpFiles.length === 0 ? '▶ 코드 파일을 업로드하세요' : '▶ 분석 모드를 선택하세요';
  }
}

async function runCodeAssistant(){
  if(rpFiles.length === 0 || !rpSelectedMode) return;
  if(!selEnvs||selEnvs.length===0){ alert('먼저 LLM 환경을 선택해주세요.'); return; }

  // code-assistant 스킬 자동 로드
  if(!selSkills.includes('code-assistant')){
    selSkills.push('code-assistant');
    renderSkills();
    updateLoaded();
  }

  // 체크된 파일만 필터링
  const selectedFiles = rpFiles.filter((_,i)=>rpCheckedFiles.has(i));
  if(selectedFiles.length === 0){ alert('분석할 파일을 선택해주세요 (체크박스).'); return; }

  // 프로젝트 트리 구조 생성
  let treeText = '';
  if(rpTreeData){
    treeText = '=== 프로젝트 구조 ===\n' + buildTreeText(rpTreeData, '') + '\n';
    treeText += `\n(전체 ${rpFiles.length}개 중 ${selectedFiles.length}개 파일 선택됨)\n`;
  }

  // 선택된 파일 내용을 스마트하게 추려서 구성
  let codeContent = treeText;
  const maxLinesPerFile = selectedFiles.length <= 3 ? 300 : selectedFiles.length <= 8 ? 150 : 80;

  selectedFiles.forEach(f=>{
    const summarized = summarizeCode(f.content, f.ext, maxLinesPerFile);
    codeContent += `\n--- 파일: ${f.path||f.name} (${f.ext}) ---\n${summarized}\n`;
  });

  const prompt = rpModePrompts[rpSelectedMode] + '\n\n' + codeContent;
  const modeLabel = rpModeLabels[rpSelectedMode] || rpSelectedMode;

  // 모든 분석 모드 → 채팅으로 전송 (대화 이어가기 위해)
  {
    const fileNames = selectedFiles.map(f=>f.name).join(', ');
    const shortLabel = '\u{1f4ca} [' + modeLabel + '] ' + fileNames;
    addMsg('user', shortLabel);
    history.push({role:'user', content:prompt});

    const typing = addTyping();
    isSending = true;
    const btn = document.getElementById('sendBtn');
    btn.textContent = '\u23f9';
    btn.classList.add('stop-mode');
    btn.disabled = false;
    chatAbort = new AbortController();

    // 버튼 비활성화
    const runBtn = document.getElementById('rpRunBtn');
    runBtn.disabled = true;
    const _rpModelLabels = {
      'kimi-k25':'🔥 Kimi-K2.5',
      'coder-480b':'🚀 Coder-480B',
      'qwen35-397b':'🦕 Qwen3.5-397B',
      'qwen35-397b-fp8':'🦕 397B FP8',
      'glm-5-1':'💎 GLM-5.1'
    };
    const _rpModelLabel = _rpModelLabels[selRpModel] || selRpModel;
    const _rpStartTime = Date.now();
    runBtn.textContent = '\u23f3 ' + _rpModelLabel + ' 분석 중... (0초)';
    const _rpTimerInterval = setInterval(()=>{
      const elapsed = Math.floor((Date.now() - _rpStartTime)/1000);
      const min = Math.floor(elapsed/60);
      const sec = elapsed % 60;
      const timeStr = min > 0 ? (min+'분 '+sec+'초') : (sec+'초');
      const note = elapsed > 60 ? ' — 대형 모델은 1~5분 소요' : '';
      runBtn.textContent = '\u23f3 ' + _rpModelLabel + ' 분석 중... ('+timeStr+')'+note;
    }, 1000);

    // SSE 스트리밍 메시지 박스 준비
    typing.remove();
    const _ssMsgs = document.getElementById('msgs');
    const _ssBox = document.createElement('div');
    _ssBox.className = 'msg assistant streaming';
    _ssBox.innerHTML = '<div class="msg-label">Demos <span style="font-size:10px;color:#6366f1;">\u23f5 스트리밍</span></div><div class="streaming-content" style="white-space:pre-wrap;word-break:break-word;"></div>';
    _ssMsgs.appendChild(_ssBox);
    const _ssContent = _ssBox.querySelector('.streaming-content');
    const _ssScroller = document.querySelector('.content');
    if(_ssScroller) _ssScroller.scrollTop = _ssScroller.scrollHeight;

    let _ssFullText = '';
    let _ssMeta = null;
    let _ssError = null;

    try{
      const resp = await fetch('/api/chat/stream',{
        method:'POST',
        headers:{'Content-Type':'application/json'},
        signal: chatAbort.signal,
        body:JSON.stringify({
          env: [selRpModel],
          messages: history,
          skills: [...selSkills],
          effort,
          system_prompt: document.getElementById('systemPromptInput').value.trim(),
          max_tokens: maxTokens,
          disable_fallback: true,  // Code Assistant: 사용자 선택 모델 고정, 폴백 금지
        })
      });
      if(!resp.ok || !resp.body){
        _ssError = '서버 응답 실패: HTTP '+resp.status;
      } else {
        const reader = resp.body.getReader();
        const decoder = new TextDecoder('utf-8');
        let buffer = '';
        while(true){
          const {value, done} = await reader.read();
          if(done) break;
          buffer += decoder.decode(value, {stream:true});
          let idx;
          while((idx = buffer.indexOf('\n\n')) !== -1){
            const evRaw = buffer.slice(0, idx);
            buffer = buffer.slice(idx + 2);
            const lines = evRaw.split('\n');
            for(const ln of lines){
              if(!ln.startsWith('data:')) continue;
              const payload = ln.slice(5).trim();
              if(!payload) continue;
              try{
                const ev = JSON.parse(payload);
                if(ev.error){
                  _ssError = ev.error;
                } else if(typeof ev.delta === 'string'){
                  _ssFullText += ev.delta;
                  _ssContent.textContent = _ssFullText;
                  if(_ssScroller) _ssScroller.scrollTop = _ssScroller.scrollHeight;
                } else if(ev.done){
                  _ssMeta = ev;
                }
              }catch(_e){}
            }
          }
        }
      }

      // 스트리밍 박스 제거 후 정식 마크다운 메시지로 다시 그림
      _ssBox.remove();
      if(_ssError){
        addMsg('assistant','\u274c '+_ssError);
      } else if(_ssFullText){
        let info = '';
        if(_ssMeta){
          if(_ssMeta.loaded_skills && _ssMeta.loaded_skills.length > 0){
            info += '\n[\u2705 '+_ssMeta.loaded_skills.join(', ')+'] ['+(_ssMeta.model_used||selRpModel)+'] ('+(_ssMeta.system_prompt_length ?? 0)+'\uc790)';
          } else if(_ssMeta.model_used){
            info += '\n['+_ssMeta.model_used+']';
          }
          if(_ssMeta.elapsed_ms) info += ' [\u23f1\ufe0f '+(_ssMeta.elapsed_ms/1000).toFixed(1)+'s]';
        }
        addMsg('assistant', _ssFullText + info, _ssFullText);
        history.push({role:'assistant', content:_ssFullText});
      } else {
        addMsg('assistant','\u274c 빈 응답');
      }
    }catch(e){
      // 스트리밍 박스 잔존물 정리
      if(_ssBox && _ssBox.parentElement) _ssBox.remove();
      if(e.name !== 'AbortError'){
        addMsg('assistant','\u274c 서버 연결 실패: '+e.message);
      } else if(_ssFullText){
        // 사용자 취소 — 지금까지 받은 부분 살려서 표시
        addMsg('assistant', _ssFullText + '\n\n[\u23f9 사용자 취소]', _ssFullText);
        history.push({role:'assistant', content:_ssFullText});
      }
    }
    clearInterval(_rpTimerInterval);
    isSending = false;
    chatAbort = null;
    btn.textContent = '\u25b6';
    btn.classList.remove('stop-mode');
    btn.disabled = false;
    document.getElementById('input').focus();
    runBtn.disabled = false;
    updateRpRunBtn();
    saveCurrentSession();
  }
}

let rpLastAnalysisContent = '';

function toggleRpResultExpand(){
  document.getElementById('rpResult').classList.toggle('expanded');
}
function copyRpResult(){
  const body = document.querySelector('.rp-result-body');
  if(body) navigator.clipboard.writeText(body.innerText).then(()=>alert('복사 완료!'));
}
function sendRpResultToChat(){
  if(!rpLastAnalysisContent) return;
  addMsg('assistant', rpLastAnalysisContent);
  history.push({role:'assistant', content: rpLastAnalysisContent});
  saveCurrentSession();
}

function buildTreeText(node, prefix){
  let text = '';
  const childKeys = Object.keys(node.children).sort();
  const allItems = [...childKeys.map(k=>({type:'dir',name:k,node:node.children[k]})), ...node.files.map(f=>({type:'file',name:f.name}))];
  allItems.forEach((item,i)=>{
    const isLast = i === allItems.length - 1;
    const connector = isLast ? '└── ' : '├── ';
    const nextPrefix = prefix + (isLast ? '    ' : '│   ');
    if(item.type === 'dir'){
      text += prefix + connector + '📁 ' + item.name + '/\n';
      text += buildTreeText(item.node, nextPrefix);
    } else {
      text += prefix + connector + item.name + '\n';
    }
  });
  return text;
}

// 폴더 드래그앤드롭
(function(){
  const drop = document.getElementById('rpFolderDrop');
  if(!drop) return;
  drop.addEventListener('dragover', e=>{e.preventDefault();e.stopPropagation();drop.classList.add('dragover');});
  drop.addEventListener('dragleave', e=>{e.preventDefault();drop.classList.remove('dragover');});
  drop.addEventListener('drop', e=>{
    e.preventDefault();e.stopPropagation();drop.classList.remove('dragover');
    // 폴더 드롭은 DataTransferItem으로 처리
    if(e.dataTransfer.items){
      const items = [...e.dataTransfer.items];
      const entries = items.map(i=>i.webkitGetAsEntry&&i.webkitGetAsEntry()).filter(Boolean);
      if(entries.length > 0){
        readEntriesRecursive(entries);
        return;
      }
    }
    if(e.dataTransfer.files.length > 0) handleRpFolderSelect(e.dataTransfer.files);
  });
})();

function readEntriesRecursive(entries){
  const codeExts = ['py','js','html','css','json','xml','yaml','yml','c','cpp','h','java','go','rs','sh','bat','md','txt','ts','tsx','jsx','rb','php','swift','kt','toml','cfg','ini'];
  const skipDirs = ['node_modules','.git','__pycache__','.venv','venv','.next','dist','build','.idea','.vscode'];
  let pending = 0;

  function readEntry(entry, path){
    if(entry.isFile){
      const ext = entry.name.split('.').pop().toLowerCase();
      if(!codeExts.includes(ext)) return;
      pending++;
      entry.file(f=>{
        if(f.size > 500000){ pending--; return; }
        const reader = new FileReader();
        reader.onload = function(e){
          const newIdx = rpFiles.length;
          rpFiles.push({name:f.name, path:path+f.name, content:e.target.result, ext:ext, size:f.size});
          rpCheckedFiles.add(newIdx);  // 업로드 즉시 자동 체크
          pending--;
          if(pending===0){ buildRpTree(); renderRpTree(); updateRpRunBtn(); detectRpLanguages(); }
        };
        reader.readAsText(f);
      });
    } else if(entry.isDirectory){
      if(skipDirs.includes(entry.name)) return;
      const dirReader = entry.createReader();
      dirReader.readEntries(entries=>{
        entries.forEach(e=>readEntry(e, path+entry.name+'/'));
      });
    }
  }
  entries.forEach(e=>readEntry(e, ''));
}

// 초기 실행 버튼 상태
updateRpRunBtn();

// ==================== 인트로 → 모드 선택 시스템 ====================
// ═══ 로그인 시스템 ═══
var currentUser = null; // {id, name, role, token}

function dismissIntroAndShowMode(){
  var ov = document.getElementById('introOverlay');
  if(!ov || ov._gone) return;
  ov._gone = true;
  var vi = document.getElementById('introVideo');
  if(vi) vi.pause();
  ov.classList.add('fade-out');
  setTimeout(function(){
    if(ov.parentNode) ov.parentNode.removeChild(ov);
    // 매번 로그인 필수
    showLoginScreen();
  }, 700);
}

function showLoginScreen(){
  // 메인 UI 숨기기
  document.getElementById('sidebar').style.display='none';
  var mainEl = document.querySelector('.main');
  if(mainEl) mainEl.style.display='none';
  var chatBox = document.querySelector('.chat-box-fixed');
  if(chatBox) chatBox.style.display='none';
  var sideToggle = document.querySelector('.sidebar-toggle');
  if(sideToggle) sideToggle.style.display='none';
  // 로그인 화면 표시
  var lo = document.getElementById('loginOverlay');
  if(lo) lo.style.display='flex';
  var idInput = document.getElementById('loginId');
  if(idInput) idInput.focus();
  // PPT 설계 버튼 숨김 (로그인 전)
  var pptBtn = document.getElementById('pptBuilderBtn');
  if(pptBtn) pptBtn.style.display='none';
}

function showMainUI(){
  var lo = document.getElementById('loginOverlay');
  if(lo) lo.style.display='none';
  document.getElementById('sidebar').style.display='';
  var mainEl = document.querySelector('.main');
  if(mainEl) mainEl.style.display='';
  var chatBox = document.querySelector('.chat-box-fixed');
  if(chatBox) chatBox.style.display='';
  var sideToggle = document.querySelector('.sidebar-toggle');
  if(sideToggle) sideToggle.style.display='';
  // 헤더 버튼 표시/숨김
  var hdAdmin = document.getElementById('hdAdminBtn');
  if(hdAdmin) hdAdmin.style.display = (currentUser && currentUser.role === 'admin') ? '' : 'none';
  // PPT 설계 버튼 노출 (로그인 완료)
  var pptBtn = document.getElementById('pptBuilderBtn');
  if(pptBtn) pptBtn.style.display='flex';
}

async function doLogin(){
  var uid = document.getElementById('loginId').value.trim();
  var pw = document.getElementById('loginPw').value;
  var errEl = document.getElementById('loginError');
  if(!uid || !pw){ errEl.textContent='아이디와 비밀번호를 입력하세요.'; errEl.style.display='block'; return; }
  try {
    var resp = await fetch('/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:uid,password:pw})});
    var data = await resp.json();
    if(data.error){ errEl.textContent=data.error; errEl.style.display='block'; return; }
    currentUser = data;
    localStorage.setItem('demos_user', JSON.stringify(data));
    errEl.style.display='none';
    showMainUI();
  } catch(e){
    errEl.textContent='서버 연결 실패'; errEl.style.display='block';
  }
}

function doLogout(){
  currentUser = null;
  localStorage.removeItem('demos_user');
  var adminBtn = document.getElementById('adminBtn');
  if(adminBtn) adminBtn.remove();
  var logoutBtn = document.getElementById('logoutBtn');
  if(logoutBtn) logoutBtn.remove();
  showLoginScreen();
}

// ═══ ADMIN 사용자 관리 팝업 ═══
function openAdminPopup(){
  document.getElementById('adminPopup').style.display='flex';
  loadAdminUsers();
}
function closeAdminPopup(){
  document.getElementById('adminPopup').style.display='none';
}

async function loadAdminUsers(){
  var list = document.getElementById('adminUserList');
  try {
    var resp = await fetch('/api/auth/users',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({admin_id:currentUser.id})});
    var data = await resp.json();
    if(data.error){ list.innerHTML='<div style="color:#ef4444;">'+data.error+'</div>'; return; }
    list.innerHTML = data.users.map(function(u){
      var isMe = u.id === currentUser.id;
      var roleBadge = u.role==='admin' ? '<span style="background:#f59e0b;color:#000;padding:1px 6px;border-radius:4px;font-size:10px;font-weight:700;">ADMIN</span>' : '<span style="background:#6366f1;color:#fff;padding:1px 6px;border-radius:4px;font-size:10px;">USER</span>';
      var actions = isMe ? '<span style="color:#666;font-size:11px;">현재 사용자</span>' : '<button onclick="deleteUser(\''+u.id+'\')" style="padding:3px 8px;background:#ef4444;color:#fff;border:none;border-radius:4px;cursor:pointer;font-size:11px;">삭제</button>';
      return '<div style="display:flex;justify-content:space-between;align-items:center;padding:8px;background:rgba(255,255,255,0.03);border-radius:6px;margin-bottom:4px;"><div><span style="font-weight:600;">'+u.name+'</span> <span style="color:#888;font-size:12px;">('+u.id+')</span> '+roleBadge+'<br><span style="color:#666;font-size:11px;">등록: '+u.created+'</span></div><div>'+actions+'</div></div>';
    }).join('');
  } catch(e){
    list.innerHTML='<div style="color:#ef4444;">로드 실패</div>';
  }
}

async function registerUser(){
  var msg = document.getElementById('regMsg');
  var name = document.getElementById('regName').value.trim();
  var id = document.getElementById('regId').value.trim();
  var pw = document.getElementById('regPw').value;
  var role = document.getElementById('regRole').value;
  if(!name||!id||!pw){ msg.innerHTML='<span style="color:#ef4444;">모든 항목을 입력하세요.</span>'; return; }
  try {
    var resp = await fetch('/api/auth/register',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({admin_id:currentUser.id,new_id:id,new_name:name,new_password:pw,new_role:role})});
    var data = await resp.json();
    if(data.error){ msg.innerHTML='<span style="color:#ef4444;">'+data.error+'</span>'; return; }
    msg.innerHTML='<span style="color:#22c55e;">✅ '+data.message+'</span>';
    document.getElementById('regName').value='';
    document.getElementById('regId').value='';
    document.getElementById('regPw').value='';
    loadAdminUsers();
  } catch(e){
    msg.innerHTML='<span style="color:#ef4444;">등록 실패</span>';
  }
}

async function deleteUser(targetId){
  if(!confirm(targetId+' 사용자를 삭제하시겠습니까?')) return;
  try {
    await fetch('/api/auth/delete',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({admin_id:currentUser.id,target_id:targetId})});
    loadAdminUsers();
  } catch(e){}
}

// ═══ 소개 페이지 팝업 ═══
function openAboutPopup(){
  var popup = window.open('/beno/about.html', 'aboutDemos', 'width=900,height=700,scrollbars=yes,resizable=yes');
  if(popup) popup.focus();
}

// ═══ 지식 도메인 관리 ═══
function openKnowledgePopup(){
  document.getElementById('knowledgePopup').style.display='flex';
  switchKdTab('upload');
  loadKdFiles();
}
function closeKnowledgePopup(){
  document.getElementById('knowledgePopup').style.display='none';
}
function switchKdTab(tab){
  document.getElementById('kdUploadTab').style.display = tab==='upload' ? 'block' : 'none';
  document.getElementById('kdManualTab').style.display = tab==='manual' ? 'block' : 'none';
  document.getElementById('kdTabUpload').style.background = tab==='upload' ? '#6366f1' : '#2a2a3e';
  document.getElementById('kdTabUpload').style.color = tab==='upload' ? '#fff' : '#888';
  document.getElementById('kdTabManual').style.background = tab==='manual' ? '#6366f1' : '#2a2a3e';
  document.getElementById('kdTabManual').style.color = tab==='manual' ? '#fff' : '#888';
}
function kdFileSelected(input){
  var name = input.files[0]?.name || '';
  document.getElementById('kdFileName').textContent = name ? '선택: '+name : '';
}
async function uploadKdFile(){
  var input = document.getElementById('kdFileInput');
  var msg = document.getElementById('kdUploadMsg');
  if(!input.files[0]){ msg.innerHTML='<span style="color:#ef4444;">파일을 선택하세요.</span>'; return; }
  var fd = new FormData();
  fd.append('file', input.files[0]);
  fd.append('user_id', currentUser.id);
  try {
    var resp = await fetch('/api/knowledge/upload',{method:'POST',body:fd});
    var data = await resp.json();
    if(data.error){ msg.innerHTML='<span style="color:#ef4444;">'+data.error+'</span>'; return; }
    msg.innerHTML='<span style="color:#22c55e;">'+data.message+'</span>';
    input.value='';
    document.getElementById('kdFileName').textContent='';
    loadKdFiles();
  } catch(e){ msg.innerHTML='<span style="color:#ef4444;">업로드 실패</span>'; }
}
async function saveKdManual(){
  var msg = document.getElementById('kdManualMsg');
  var title = document.getElementById('kdTitle').value.trim();
  var cat = document.getElementById('kdCategory').value;
  if(cat==='_custom'){
    cat = document.getElementById('kdCategoryCustom').value.trim();
    if(!cat){ msg.innerHTML='<span style="color:#ef4444;">카테고리명을 입력하세요.</span>'; return; }
  }
  var tags = document.getElementById('kdTags').value.trim();
  var content = document.getElementById('kdContent').value.trim();
  if(!title||!content){ msg.innerHTML='<span style="color:#ef4444;">제목과 내용을 입력하세요.</span>'; return; }
  try {
    var resp = await fetch('/api/knowledge/manual',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({user_id:currentUser.id,title:title,category:cat,content:content,tags:tags})});
    var data = await resp.json();
    if(data.error){ msg.innerHTML='<span style="color:#ef4444;">'+data.error+'</span>'; return; }
    msg.innerHTML='<span style="color:#22c55e;">'+data.message+'</span>';
    document.getElementById('kdTitle').value='';
    document.getElementById('kdContent').value='';
    document.getElementById('kdTags').value='';
    loadKdFiles();
  } catch(e){ msg.innerHTML='<span style="color:#ef4444;">저장 실패</span>'; }
}
async function loadKdFiles(){
  var list = document.getElementById('kdFileList');
  try {
    var resp = await fetch('/api/knowledge/list',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({user_id:currentUser.id})});
    var data = await resp.json();
    if(!data.files||data.files.length===0){ list.innerHTML='<div style="color:#666;padding:8px;">등록된 파일이 없습니다.</div>'; return; }
    var catLabels = {column_definition:'컬럼',architecture:'아키텍처',specification:'명세',changelog:'변경',plan:'계획',guide:'가이드'};
    list.innerHTML = data.files.map(function(f){
      var catBadge = catLabels[f.category]||f.category;
      return '<div style="display:flex;justify-content:space-between;align-items:center;padding:8px;background:rgba(255,255,255,0.03);border-radius:6px;margin-bottom:3px;">'
        +'<div><span style="font-weight:600;color:#e2e8f0;">'+f.title+'</span>'
        +' <span style="background:#334155;color:#94a3b8;padding:1px 6px;border-radius:4px;font-size:10px;">'+catBadge+'</span>'
        +'<br><span style="color:#555;font-size:11px;">'+f.filename+' | '+f.size_kb+'KB | '+f.date+'</span></div>'
        +'<button onclick="deleteKdFile(\''+f.filename+'\')" style="padding:3px 8px;background:#ef4444;color:#fff;border:none;border-radius:4px;cursor:pointer;font-size:11px;">삭제</button></div>';
    }).join('');
  } catch(e){ list.innerHTML='<div style="color:#ef4444;">로드 실패</div>'; }
}
async function deleteKdFile(fname){
  if(!confirm(fname+' 파일을 삭제하시겠습니까?')) return;
  try {
    await fetch('/api/knowledge/delete',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({user_id:currentUser.id,filename:fname})});
    loadKdFiles();
  } catch(e){}
}

var uioCollapsed = false;

function toggleUioMode(){
  var btn = document.getElementById('uioBackBtn');
  if(!uioCollapsed){
    // 접기: UIO 숨기고 메인 UI 복원 (iframe 유지)
    document.getElementById('uioContainer').style.display='none';
    document.getElementById('sidebar').style.display='';
    var mainEl = document.querySelector('.main');
    if(mainEl) mainEl.style.display='';
    var chatBox = document.querySelector('.chat-box-fixed');
    if(chatBox) chatBox.style.display='';
    var sideToggle = document.querySelector('.sidebar-toggle');
    if(sideToggle) sideToggle.style.display='';
    btn.textContent='🎮 UIO 펼치기';
    btn.style.position='fixed';
    btn.style.display='block';
    uioCollapsed = true;
  } else {
    // 펼치기: UIO 다시 전체화면
    document.getElementById('uioContainer').style.display='block';
    document.getElementById('sidebar').style.display='none';
    var mainEl = document.querySelector('.main');
    if(mainEl) mainEl.style.display='none';
    var chatBox = document.querySelector('.chat-box-fixed');
    if(chatBox) chatBox.style.display='none';
    var sideToggle = document.querySelector('.sidebar-toggle');
    if(sideToggle) sideToggle.style.display='none';
    btn.textContent='← 접기';
    uioCollapsed = false;
  }
}

function exitUioMode(){
  document.getElementById('uioContainer').style.display='none';
  document.getElementById('uioFrame').src='about:blank';
  document.getElementById('uioBackBtn').style.display='';
  uioCollapsed = false;
  // 기본 UI 복원
  document.getElementById('sidebar').style.display='';
  var mainEl = document.querySelector('.main');
  if(mainEl) mainEl.style.display='';
  var chatBox = document.querySelector('.chat-box-fixed');
  if(chatBox) chatBox.style.display='';
  var sideToggle = document.querySelector('.sidebar-toggle');
  if(sideToggle) sideToggle.style.display='';
}

(function(){
  // 메인 UI를 처음에 숨기기 (로그인 전)
  document.getElementById('sidebar').style.display='none';
  var mainEl = document.querySelector('.main');
  if(mainEl) mainEl.style.display='none';
  var chatBox = document.querySelector('.chat-box-fixed');
  if(chatBox) chatBox.style.display='none';
  var sideToggle = document.querySelector('.sidebar-toggle');
  if(sideToggle) sideToggle.style.display='none';

  // 바로 로그인 화면 표시
  showLoginScreen();
})();

// ==================== PPT 코드 감지 & 생성 ====================
function detectAndAddPptxButtons(msgEl, rawText){
  // python-pptx 코드 블록 감지 (from pptx import ... 또는 python-pptx 패턴)
  const codeBlockRegex = /```(?:python|py)?\s*\n([\s\S]*?)```/gi;
  let match;
  const pptxCodes = [];
  while((match = codeBlockRegex.exec(rawText)) !== null){
    const code = match[1];
    if(code.includes('from pptx') || code.includes('import pptx') || code.includes('Presentation(') || code.includes('add_slide')){
      pptxCodes.push(code.trim());
    }
  }
  if(pptxCodes.length === 0) return;

  // 각 PPT 코드 블록 아래에 생성 버튼 삽입
  const allPre = msgEl.querySelectorAll('pre');
  let codeIdx = 0;
  allPre.forEach(pre => {
    const preText = pre.textContent;
    if((preText.includes('from pptx') || preText.includes('import pptx') || preText.includes('Presentation(') || preText.includes('add_slide')) && codeIdx < pptxCodes.length){
      const code = pptxCodes[codeIdx];
      codeIdx++;
      const block = document.createElement('div');
      block.className = 'pptx-gen-block';
      block.innerHTML = `
        <div class="pptx-gen-header">
          <span>📽️ PowerPoint 생성</span>
          <div class="pptx-gen-actions">
            <span class="pptx-gen-status"></span>
            <button class="pptx-gen-btn secondary" onclick="copyPptxCode(this)">📋 실행용 코드 복사</button>
            <button class="pptx-gen-btn" onclick="generatePptx(this)">📽️ PPT 생성 & 다운로드</button>
          </div>
        </div>
        <div class="pptx-remake-bar">
          <span class="pptx-remake-label">🔄 다시 만들기:</span>
          <button class="pptx-remake-btn" onclick="_remakePpt('그래프/차트 없이 텍스트와 표 위주로 PPT 다시 만들어줘')">📝 그래프 없이</button>
          <button class="pptx-remake-btn" onclick="_remakePpt('그래프와 차트를 포함해서 PPT 다시 만들어줘')">📊 그래프 포함</button>
          <button class="pptx-remake-btn" onclick="_remakePpt('디자인을 더 심플하게 PPT 다시 만들어줘')">🎨 심플하게</button>
          <button class="pptx-remake-btn" onclick="_remakePpt('슬라이드 수를 줄여서 핵심만 PPT 다시 만들어줘')">✂️ 핵심만</button>
        </div>`;
      block.dataset.pptxCode = u2b(code);
      pre.parentNode.insertBefore(block, pre.nextSibling);
    }
  });
}

async function copyPptxCode(btn){
  const block = btn.closest('.pptx-gen-block');
  const rawCode = b2u(block.dataset.pptxCode);
  let codeToCopy = rawCode;

  try{
    const resp = await fetch('/api/prepare_pptx_code', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({code: rawCode})
    });
    if(resp.ok){
      const data = await resp.json();
      if(data && data.code) codeToCopy = data.code;
    }
  }catch(e){}

  navigator.clipboard.writeText(codeToCopy);
  btn.textContent = '✓ 복사됨';
  setTimeout(()=>{ btn.textContent = '📋 실행용 코드 복사'; }, 1500);
}

async function generatePptx(btn){
  const block = btn.closest('.pptx-gen-block');
  const code = b2u(block.dataset.pptxCode);
  const status = block.querySelector('.pptx-gen-status');

  btn.disabled = true;
  btn.textContent = '⏳ 생성 중...';
  status.textContent = 'python-pptx 코드 실행 중...';

  try{
    const resp = await fetch('/api/generate_pptx', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({code, filename:'presentation.pptx'})
    });

    if(!resp.ok){
      const err = await resp.json();
      status.textContent = '❌ ' + (err.error || '생성 실패');
      btn.textContent = '📽️ 재시도';
      btn.disabled = false;
      return;
    }

    const json = await resp.json();
    if(json.download_url){
        window.location.href = json.download_url;
        status.textContent = '✅ 다운로드 완료!';
    } else if(json.message) {
        status.textContent = '✅ ' + json.message;
    } else {
        status.textContent = '❌ 파일 응답 형식 오류';
    }
    btn.textContent = '📽️ 다시 생성';
    btn.disabled = false;
  }catch(e){
    status.textContent = '❌ 네트워크 오류';
    btn.textContent = '📽️ 재시도';
    btn.disabled = false;
  }
}

function _remakePpt(text){
  const input = document.getElementById('input');
  if(input){ input.value = text; input.focus(); input.style.height='auto'; input.style.height=input.scrollHeight+'px'; }
  // 자동 전송
  setTimeout(()=>send(), 100);
}

// ===== PPT 디자인 스타일 시스템 =====
const PPT_STYLE_PROMPTS = {
  minimal: '미니멀 디자인: 흰 배경(#FFFFFF), 검정/회색 텍스트, 여백 충분히, 장식 최소화, sans-serif 폰트(맑은 고딕/Arial), 깔끔한 선 구분. 색상은 #333333(제목), #666666(본문), #E0E0E0(구분선) 위주.',
  corporate: '기업 프레젠테이션: 네이비(#1B2A4A) 상단 바 + 화이트 배경, 포인트 색상 #2563EB, 각 슬라이드에 상단 컬러 스트라이프, 표와 차트 적극 활용, 깔끔하고 전문적인 톤.',
  colorful: '컬러풀 디자인: 슬라이드마다 다양한 밝은 배경 그라데이션, 색상 팔레트(#FF6B6B, #4ECDC4, #45B7D1, #FFA07A, #98D8C8, #F7DC6F), 둥근 도형과 카드형 레이아웃, 생동감 있는 구성.',
  dark: '다크 테마: 어두운 배경(#1A1A2E 또는 #0F0F1F), 밝은 텍스트(#FFFFFF, #E0E0E0), 네온 포인트 컬러(#6366F1 메인, #A855F7 보조, #22D3EE 강조), 고급스럽고 세련된 느낌.',
  academic: '학술 발표: 깔끔한 흰 배경, 보수적 배색(#2C3E50 제목, #34495E 본문), 번호 매긴 섹션 구조, 참고문헌 슬라이드 포함, 데이터는 차트/표 중심으로 시각화, 최소 장식.',
  startup: '스타트업 피치덱: 대담한 헤드라인(큰 폰트), 핵심 숫자 크게 강조, 카드형 레이아웃, 모던 색상(#6366F1 메인, #EC4899 보조), 마지막에 CTA(Call-to-Action) 슬라이드 포함.',
};
var activePptStyle = '';
var pptRefDesign = '';

function applyPptStyle(val){
  if(val === 'ref'){
    var inp = document.createElement('input');
    inp.type='file'; inp.accept='.pptx';
    inp.onchange = function(){ if(inp.files[0]) uploadPptRef(inp.files[0]); };
    inp.click();
    document.getElementById('pptStyleDrop').value = activePptStyle;
    return;
  }
  activePptStyle = val;
  pptRefDesign = '';
  document.getElementById('pptRefBadge').style.display = 'none';
}

async function uploadPptRef(file){
  var fd = new FormData(); fd.append('file', file);
  try{
    var resp = await fetch('/api/analyze_ppt_style', {method:'POST', body:fd});
    var data = await resp.json();
    if(data.error){
      addMsg('assistant', '❌ PPT 스타일 분석 실패: ' + data.error);
      return;
    }
    if(data.design){
      pptRefDesign = data.design;
      activePptStyle = '';
      document.getElementById('pptStyleDrop').value = '';
      document.getElementById('pptRefBadge').style.display = 'inline-flex';
      addMsg('assistant', '📎 참고 PPT 스타일 분석 완료: **' + file.name + '**\n' + data.summary + '\n\n새 PPT 생성 시 이 스타일을 반영합니다.');
    }
  }catch(e){
    addMsg('assistant', '❌ PPT 스타일 분석 중 오류 발생');
  }
}

function checkPptStyleVisibility(){
  var drop = document.getElementById('pptStyleDrop');
  if(!drop) return;
  var text = (document.getElementById('input').value || '').toLowerCase();
  var isPpt = /ppt|피피티|파워포인트|프레젠테이션|슬라이드|발표자료/.test(text);
  var hasPptxSkill = selSkills.includes('pptx') || autoLoadedSkills.includes('pptx');
  drop.style.display = (isPpt || hasPptxSkill) ? 'inline-block' : 'none';
}

/* ── 하네스 저장 세션 (기존 팝업에 통합) ── */
function openHarnessSessionTab(){
  const overlay=document.getElementById('sessionPopupOverlay');
  overlay.style.display='flex';
  /* 하네스 탭 내용을 팝업 body에 로드 */
  const body=document.getElementById('sessionPopupBody');
  if(!body)return;
  body.innerHTML='<div style="text-align:center;color:#999;padding:20px">하네스 저장 세션 불러오는 중...</div>';
  fetch('/api/harness/session/list')
    .then(r=>r.json())
    .then(data=>{
      if(!data.sessions||data.sessions.length===0){
        body.innerHTML='<div style="text-align:center;color:#999;padding:30px">하네스 저장 세션이 없습니다.</div>';
        return;
      }
      let html='<div style="padding:4px 0;font-size:12px;color:#6366f1;font-weight:600;margin-bottom:8px;">💾 하네스 자동 저장 세션 ('+data.sessions.length+'개)</div>';
      data.sessions.forEach(s=>{
        const d=new Date(s.timestamp*1000);
        const dateStr=d.toLocaleDateString('ko-KR',{month:'short',day:'numeric'})+' '+d.toLocaleTimeString('ko-KR',{hour:'2-digit',minute:'2-digit'});
        const skills=s.skills_used&&s.skills_used.length>0?s.skills_used.slice(0,2).join(', '):'';
        const preview=s.first_message||'';
        const previewText=preview.length>40?preview.substring(0,40)+'...':preview;
        html+=`<div style="padding:6px 10px;border:1px solid #e5e3de;border-radius:8px;margin-bottom:4px;display:flex;justify-content:space-between;align-items:center;gap:8px">
          <div style="flex:1;min-width:0;display:flex;align-items:center;gap:8px">
            <span style="font-size:11px;color:#999;flex-shrink:0">${dateStr}</span>
            <span style="font-size:12px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${previewText||skills||s.message_count+'개 메시지'}</span>
          </div>
          <div style="display:flex;gap:4px;flex-shrink:0">
            <button onclick="harnessRestore('${s.session_id}')" style="padding:2px 8px;background:#6366f1;color:#fff;border:none;border-radius:4px;cursor:pointer;font-size:11px">복원</button>
            <button onclick="harnessDelete('${s.session_id}')" style="padding:2px 6px;color:#ef4444;border:1px solid #fca5a5;background:none;border-radius:4px;cursor:pointer;font-size:11px">x</button>
          </div>
        </div>`;
      });
      body.innerHTML=html;
    })
    .catch(()=>{body.innerHTML='<div style="color:#ef4444;text-align:center;padding:20px">하네스 브릿지 미연결</div>';});
}

function harnessRestore(sid){
  fetch('/api/harness/session/load/'+sid).then(r=>r.json()).then(data=>{
    if(!data.messages||!data.messages.length){alert('복원할 메시지 없음');return;}
    const ct=document.querySelector('.content-inner')||document.querySelector('.content');
    if(!ct)return;
    ct.querySelectorAll('.msg').forEach(m=>m.remove());
    data.messages.forEach(msg=>{
      const div=document.createElement('div');
      div.className='msg '+(msg.role==='user'?'user':'assistant');
      div.innerHTML='<div class="msg-text">'+msg.content.replace(/</g,'&lt;').replace(/>/g,'&gt;')+'</div>';
      ct.appendChild(div);
    });
    ct.scrollTop=ct.scrollHeight;
    closeSessionPopup();
  }).catch(()=>alert('복원 실패'));
}

function harnessDelete(sid){
  if(!confirm('삭제할까요?'))return;
  fetch('/api/harness/session/delete/'+sid,{method:'DELETE'}).then(()=>openHarnessSessionTab()).catch(()=>alert('삭제 실패'));
}

// ═══ 📑 PPT 설계 팝업 (MD → PPT 결정론적 변환, LLM 미사용) ═══
function openPptBuilder(){ document.getElementById('pptBuilderOverlay').style.display='flex'; }
function closePptBuilder(){ document.getElementById('pptBuilderOverlay').style.display='none'; }
function pptSwitchTab(tab){
  const tabs={md:'pptTabMd', file:'pptTabFile', llm:'pptTabLlm'};
  const conts={md:'pptTabMdContent', file:'pptTabFileContent', llm:'pptTabLlmContent'};
  for(const k in tabs){
    const tEl=document.getElementById(tabs[k]);
    const cEl=document.getElementById(conts[k]);
    if(!tEl||!cEl) continue;
    if(k===tab){
      tEl.style.background='#eab308'; tEl.style.color='#fff';
      cEl.style.display='flex';
    } else {
      tEl.style.background='#e5e7eb'; tEl.style.color='#6b7280';
      cEl.style.display='none';
    }
  }
}
function pptShowLoading(msg){
  document.getElementById('pptResultPanel').innerHTML =
    `<div style="text-align:center;padding-top:80px;color:#eab308;"><div style="font-size:36px;margin-bottom:10px;">⏳</div>${msg||'변환 중...'}</div>`;
}
function pptShowResult(data){
  const panel=document.getElementById('pptResultPanel');
  if(data.error){ panel.innerHTML=`<div style="color:#ef4444;"><b>❌ 실패</b><br><br>${data.error}</div>`; return; }
  const slides=(data.slides_summary||[]).map((s,i)=>
    `<div style="padding:6px 10px;background:#f1f5f9;border-radius:4px;margin-bottom:4px;display:flex;gap:8px;font-size:11px;">
       <span style="color:#eab308;font-weight:600;">Slide ${i+1}</span>
       <span style="color:#64748b;">[${s.type}]</span>
       <span style="flex:1;color:#334155;">${(s.title||'(제목 없음)').replace(/</g,'&lt;')}</span>
     </div>`).join('');
  // LLM 모드일 때 디버깅 패널 (LLM이 받은 입력 / 뱉은 응답)
  let debugHtml='';
  if(data._debug && (data._debug.preprocessed_input || data._debug.raw_llm_response_preview)){
    const esc=s=>(s||'').replace(/</g,'&lt;');
    debugHtml=`
      <details style="margin-top:14px;border:1px dashed #cbd5e1;border-radius:6px;padding:8px;background:#fffbeb;">
        <summary style="cursor:pointer;font-size:11px;color:#a16207;font-weight:700;">🔍 LLM 디버깅 — 클릭해서 펼치기 (LLM이 본 입력 + 뱉은 응답)</summary>
        <div style="font-size:10px;color:#64748b;margin-top:6px;font-weight:700;">📝 LLM이 받은 입력 (전처리 후)</div>
        <pre style="font-size:10px;background:#f1f5f9;padding:6px;border-radius:4px;max-height:150px;overflow:auto;white-space:pre-wrap;">${esc(data._debug.preprocessed_input)}</pre>
        <div style="font-size:10px;color:#64748b;margin-top:6px;font-weight:700;">🤖 LLM 원본 응답 (앞 800자)</div>
        <pre style="font-size:10px;background:#f1f5f9;padding:6px;border-radius:4px;max-height:150px;overflow:auto;white-space:pre-wrap;">${esc(data._debug.raw_llm_response_preview)}</pre>
      </details>`;
  }
  panel.innerHTML = `
    <div style="margin-bottom:14px;">
      <div style="font-size:14px;font-weight:700;color:#16a34a;margin-bottom:6px;">✅ 변환 완료</div>
      <div style="font-size:11px;color:#64748b;">파일명: ${data.filename||''}${data.model?' · 모델: '+data.model:''}</div>
      <div style="font-size:11px;color:#64748b;">슬라이드: ${data.slide_count||0}개 · 크기 ${((data.size||0)/1024).toFixed(1)} KB</div>
    </div>
    <a href="${data.download_url}" download
       style="display:block;padding:10px;background:linear-gradient(135deg,#22c55e,#16a34a);color:#fff;text-decoration:none;border-radius:6px;font-weight:700;text-align:center;margin-bottom:14px;font-size:13px;">💾 .pptx 다운로드</a>
    <div style="font-size:11px;color:#64748b;margin-bottom:6px;">슬라이드 구성</div>${slides}
    ${debugHtml}`;
}
function pptSelectedTemplate(){
  const sel=document.getElementById('pptTemplateSelect');
  return (sel&&sel.value)?sel.value:'minimal';
}
// 🔄 PPT 설계 팝업 완전 초기화
function pptResetAll(){
  if(!confirm('모든 입력·선택·결과를 초기화할까요?')) return;
  // 1) textarea 두 개 비우기
  ['pptMdInput','pptLlmInput'].forEach(id=>{
    const el=document.getElementById(id); if(el) el.value='';
  });
  // 2) 파일 input 비우기
  const fi=document.getElementById('pptFileInput'); if(fi) fi.value='';
  // 3) 모드 라디오 → 기본 (fast)
  document.querySelectorAll('input[name="pptMdMode"][value="fast"]').forEach(r=>r.checked=true);
  document.querySelectorAll('input[name="pptFileMode"][value="fast"]').forEach(r=>r.checked=true);
  pptToggleMdMode(); pptToggleFileMode();
  // 4) 테마 → minimal
  const tplSel=document.getElementById('pptTemplateSelect');
  if(tplSel) tplSel.value='minimal';
  // 5) 모델 드롭다운 → 첫 번째
  ['pptLlmModelSelect','pptMdLlmModelSelect','pptFileLlmModelSelect'].forEach(id=>{
    const el=document.getElementById(id);
    if(el && el.options.length>0) el.selectedIndex=0;
  });
  // 6) 탭 → MD 텍스트로
  pptSwitchTab('md');
  // 7) 결과 패널 비우기
  const panel=document.getElementById('pptResultPanel');
  if(panel) panel.innerHTML=`
    <div style="text-align:center;color:#94a3b8;padding-top:80px;">
      <div style="font-size:36px;margin-bottom:10px;">⬅️</div>
      왼쪽에서 MD 입력 또는 파일 업로드 후<br>결과가 여기 나옵니다
    </div>`;
}
// MD ↔ LLM textarea 양방향 동기화 (한쪽 적으면 다른 쪽에도)
function pptSyncInputs(source){
  const mdEl=document.getElementById('pptMdInput');
  const llmEl=document.getElementById('pptLlmInput');
  if(!mdEl||!llmEl) return;
  if(source==='md') llmEl.value=mdEl.value;
  else if(source==='llm') mdEl.value=llmEl.value;
}
// 동기화 이벤트 자동 등록 (팝업 처음 열 때 1회)
let _pptSyncBound=false;
function pptBindSync(){
  if(_pptSyncBound) return;
  const mdEl=document.getElementById('pptMdInput');
  const llmEl=document.getElementById('pptLlmInput');
  if(mdEl) mdEl.addEventListener('input', ()=>pptSyncInputs('md'));
  if(llmEl) llmEl.addEventListener('input', ()=>pptSyncInputs('llm'));
  _pptSyncBound=true;
}
function pptToggleMdMode(){
  const mode=(document.querySelector('input[name="pptMdMode"]:checked')||{}).value;
  const row=document.getElementById('pptMdLlmModelRow');
  if(!row) return;
  row.style.display = (mode==='llm') ? 'flex' : 'none';
  if(mode==='llm') pptLoadMdLlmModels();
}
async function pptLoadMdLlmModels(){
  const sel=document.getElementById('pptMdLlmModelSelect');
  if(!sel) return;
  if(sel.dataset.loaded==='1') return;
  sel.innerHTML='<option value="">(로딩 중...)</option>';
  try{
    const r=await fetch('/api/ppt/models');
    const data=await r.json();
    if(!data.ok || !data.models || !data.models.length){
      sel.innerHTML='<option value="">(사용 가능 모델 없음)</option>'; return;
    }
    const ggufs=data.models.filter(m=>m.kind==='GGUF');
    const apis=data.models.filter(m=>m.kind==='API');
    let html='';
    if(apis.length){
      html+='<optgroup label="🌐 사내 API">';
      apis.forEach(m=>{ html+=`<option value="${m.id}">${m.name}</option>`; });
      html+='</optgroup>';
    }
    if(ggufs.length){
      html+='<optgroup label="💻 로컬 GGUF">';
      ggufs.forEach(m=>{
        const sz=m.size_gb?` (${m.size_gb}GB)`:'';
        html+=`<option value="${m.id}">${m.name}${sz}</option>`;
      });
      html+='</optgroup>';
    }
    sel.innerHTML=html;
    sel.dataset.loaded='1';
  }catch(e){ sel.innerHTML=`<option value="">로딩 실패: ${e.message}</option>`; }
}
async function pptGenerateFromMd(){
  const md=document.getElementById('pptMdInput').value.trim();
  if(!md){ alert('MD 내용을 입력해주세요'); return; }
  const tpl=pptSelectedTemplate();
  const mode=(document.querySelector('input[name="pptMdMode"]:checked')||{}).value || 'fast';

  if(mode==='llm'){
    const model=document.getElementById('pptMdLlmModelSelect').value;
    if(!model){ alert('LLM 모드를 선택하셨는데 모델이 비어있습니다.'); return; }
    pptShowLoading(`🤖 ${model} 가 디자인 중... (수십 초~수 분)`);
    try{
      const r=await fetch('/api/ppt/from-llm',{
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({input: md, model, template: tpl})
      });
      pptShowResult(await r.json());
    }catch(e){ pptShowResult({error:'네트워크 오류: '+e.message}); }
    return;
  }
  // 빠른 변환 (결정론)
  pptShowLoading(`MD → PPT 변환 중... (테마: ${tpl})`);
  try{
    const r=await fetch('/api/ppt/from-md',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({md, template: tpl})});
    pptShowResult(await r.json());
  }catch(e){ pptShowResult({error:'네트워크 오류: '+e.message}); }
}
function pptToggleFileMode(){
  const mode=(document.querySelector('input[name="pptFileMode"]:checked')||{}).value;
  const row=document.getElementById('pptFileLlmModelRow');
  if(!row) return;
  row.style.display = (mode==='llm') ? 'flex' : 'none';
  // LLM 모드 켜면 모델 목록 로드
  if(mode==='llm') pptLoadFileLlmModels();
}
async function pptLoadFileLlmModels(){
  const sel=document.getElementById('pptFileLlmModelSelect');
  if(!sel) return;
  if(sel.dataset.loaded==='1') return;  // 한 번만 로드
  sel.innerHTML='<option value="">(로딩 중...)</option>';
  try{
    const r=await fetch('/api/ppt/models');
    const data=await r.json();
    if(!data.ok || !data.models || !data.models.length){
      sel.innerHTML='<option value="">(사용 가능 모델 없음)</option>'; return;
    }
    const ggufs=data.models.filter(m=>m.kind==='GGUF');
    const apis=data.models.filter(m=>m.kind==='API');
    let html='';
    if(apis.length){
      html+='<optgroup label="🌐 사내 API">';
      apis.forEach(m=>{ html+=`<option value="${m.id}">${m.name}</option>`; });
      html+='</optgroup>';
    }
    if(ggufs.length){
      html+='<optgroup label="💻 로컬 GGUF">';
      ggufs.forEach(m=>{
        const sz=m.size_gb?` (${m.size_gb}GB)`:'';
        html+=`<option value="${m.id}">${m.name}${sz}</option>`;
      });
      html+='</optgroup>';
    }
    sel.innerHTML=html;
    sel.dataset.loaded='1';
  }catch(e){ sel.innerHTML=`<option value="">로딩 실패: ${e.message}</option>`; }
}
async function pptGenerateFromFile(file){
  if(!file) return;
  const tpl=pptSelectedTemplate();
  // 파일 내용 미리 읽어 textarea 두 곳 채움
  let text='';
  try{
    text=await file.text();
    const mdEl=document.getElementById('pptMdInput');
    const llmEl=document.getElementById('pptLlmInput');
    if(mdEl) mdEl.value=text;
    if(llmEl) llmEl.value=text;
  }catch(_e){}

  const mode=(document.querySelector('input[name="pptFileMode"]:checked')||{}).value || 'fast';

  if(mode==='llm'){
    const model=document.getElementById('pptFileLlmModelSelect').value;
    if(!model){ alert('LLM 모드를 선택하셨는데 모델이 비어있습니다.'); return; }
    pptShowLoading(`🤖 ${model} 가 디자인 중... (수십 초~수 분, 큰 모델일수록 좋음)`);
    try{
      const r=await fetch('/api/ppt/from-llm',{
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({input: text, model, template: tpl})
      });
      pptShowResult(await r.json());
    }catch(e){ pptShowResult({error:'네트워크 오류: '+e.message}); }
    return;
  }
  // 빠른 변환 (결정론)
  pptShowLoading(`파일 업로드 중... (${file.name}, 테마: ${tpl})`);
  const fd=new FormData(); fd.append('file',file); fd.append('template',tpl);
  try{
    const r=await fetch('/api/ppt/from-md-file',{method:'POST',body:fd});
    pptShowResult(await r.json());
  }catch(e){ pptShowResult({error:'네트워크 오류: '+e.message}); }
}
// 🤖 LLM 디자인 모드
async function pptLoadLlmModels(){
  const sel=document.getElementById('pptLlmModelSelect');
  if(!sel) return;
  sel.innerHTML='<option value="">(로딩 중...)</option>';
  try{
    const r=await fetch('/api/ppt/models');
    const data=await r.json();
    if(!data.ok || !data.models || !data.models.length){
      sel.innerHTML='<option value="">(사용 가능한 모델 없음)</option>';
      return;
    }
    // 그룹화: GGUF, API
    const ggufs=data.models.filter(m=>m.kind==='GGUF');
    const apis=data.models.filter(m=>m.kind==='API');
    let html='';
    if(apis.length){
      html+='<optgroup label="🌐 사내 API (회사망)">';
      apis.forEach(m=>{ html+=`<option value="${m.id}">${m.name}</option>`; });
      html+='</optgroup>';
    }
    if(ggufs.length){
      html+='<optgroup label="💻 로컬 GGUF (집·회사 모두)">';
      ggufs.forEach(m=>{
        const sz=m.size_gb?` (${m.size_gb}GB)`:'';
        html+=`<option value="${m.id}">${m.name}${sz}</option>`;
      });
      html+='</optgroup>';
    }
    sel.innerHTML=html;
  }catch(e){
    sel.innerHTML=`<option value="">로딩 실패: ${e.message}</option>`;
  }
}
async function pptGenerateFromLlm(){
  const input=document.getElementById('pptLlmInput').value.trim();
  if(!input){ alert('주제 또는 MD를 입력하세요'); return; }
  const model=document.getElementById('pptLlmModelSelect').value;
  if(!model){ alert('모델을 선택하세요'); return; }
  const tpl=pptSelectedTemplate();
  pptShowLoading(`🤖 ${model} 가 디자인 사양 생성 중... (수십 초~수 분)`);
  try{
    const r=await fetch('/api/ppt/from-llm',{
      method:'POST', headers:{'Content-Type':'application/json'},
      body:JSON.stringify({input, model, template: tpl})
    });
    pptShowResult(await r.json());
  }catch(e){ pptShowResult({error:'네트워크 오류: '+e.message}); }
}
// 팝업 열 때마다 모델 목록 갱신 + 동기화 이벤트 연결
(function(){
  const _origOpen=window.openPptBuilder;
  window.openPptBuilder=function(){
    if(typeof _origOpen==='function') _origOpen();
    else document.getElementById('pptBuilderOverlay').style.display='flex';
    pptLoadLlmModels();
    pptLoadMdLlmModels();   // MD 텍스트 탭 모델 드롭다운
    pptLoadFileLlmModels(); // 파일 업로드 탭 모델 드롭다운
    pptBindSync();
  };
})();
// 드롭존 이벤트
(function(){
  const zone=document.getElementById('pptDropZone'); if(!zone) return;
  zone.addEventListener('dragover',e=>{e.preventDefault();zone.style.borderColor='#eab308';zone.style.background='#fefce8';});
  zone.addEventListener('dragleave',e=>{zone.style.borderColor='#cbd5e1';zone.style.background='#f8fafc';});
  zone.addEventListener('drop',e=>{
    e.preventDefault();
    zone.style.borderColor='#cbd5e1';zone.style.background='#f8fafc';
    const f=e.dataTransfer.files && e.dataTransfer.files[0];
    if(f) pptGenerateFromFile(f);
  });
})();
</script>

<!-- 📑 PPT 설계 플로팅 버튼 (로그인 후에만 노출) -->
<button id="pptBuilderBtn" onclick="openPptBuilder()"
        title=".md 파일/텍스트 → .pptx 자동 변환 (LLM 미사용, 결정론적)"
        style="position:fixed;left:20px;bottom:20px;z-index:9998;padding:12px 18px;
               background:linear-gradient(135deg,#eab308,#d97706);color:#fff;border:none;
               border-radius:10px;font-size:13px;font-weight:700;cursor:pointer;
               box-shadow:0 4px 14px rgba(234,179,8,0.4);display:none;align-items:center;gap:6px;">
  📑 PPT 설계
</button>

<!-- 📑 PPT 설계 팝업 -->
<div id="pptBuilderOverlay" style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;
     background:rgba(0,0,0,0.5);z-index:10000;justify-content:center;align-items:center;"
     onclick="if(event.target===this)closePptBuilder()">
  <div style="width:min(1100px,94vw);height:min(780px,90vh);background:#fff;border:1px solid #cbd5e1;
       border-radius:12px;display:flex;flex-direction:column;box-shadow:0 20px 60px rgba(0,0,0,0.3);">
    <div style="padding:14px 20px;border-bottom:1px solid #e2e8f0;display:flex;align-items:center;
         justify-content:space-between;background:linear-gradient(135deg,#fefce8,#fef3c7);border-radius:12px 12px 0 0;">
      <div>
        <div style="font-size:16px;font-weight:700;color:#a16207;">📑 PPT 설계</div>
        <div style="font-size:11px;color:#78716c;margin-top:2px;">
          MD 입력 → 빠른 변환 또는 LLM 자동 디자인 → .pptx
        </div>
      </div>
      <div style="display:flex;align-items:center;gap:8px;">
        <button onclick="pptResetAll()" title="모든 입력·선택·결과 초기화"
                style="padding:6px 12px;background:#fff;color:#a16207;border:1px solid #fde68a;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer;">
          🔄 초기화
        </button>
        <button onclick="closePptBuilder()" style="background:transparent;border:none;color:#78716c;font-size:22px;cursor:pointer;padding:4px 10px;">✕</button>
      </div>
    </div>
    <div style="flex:1;display:flex;overflow:hidden;">
      <div style="flex:1;border-right:1px solid #e2e8f0;display:flex;flex-direction:column;padding:14px;">
        <!-- 🎨 테마 선택 -->
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px;">
          <label style="font-size:11px;color:#64748b;white-space:nowrap;font-weight:700;">🎨 테마</label>
          <select id="pptTemplateSelect"
                  style="flex:1;padding:6px 10px;background:#f8fafc;color:#1e293b;
                         border:1px solid #cbd5e1;border-radius:6px;font-size:12px;cursor:pointer;">
            <option value="minimal">Minimal — 노란 액센트, 깔끔</option>
            <option value="corporate">Corporate — 파란색, 정장</option>
            <option value="academic">Academic — 와인색, 논문</option>
            <option value="creative">Creative — 핑크, 화려</option>
            <option value="dark">Dark — 다크모드, 네온</option>
          </select>
        </div>
        <div style="display:flex;gap:6px;margin-bottom:10px;">
          <button id="pptTabMd" onclick="pptSwitchTab('md')"
                  style="flex:1;padding:8px;background:#eab308;color:#fff;border:none;border-radius:6px;cursor:pointer;font-weight:700;font-size:12px;">📝 MD 텍스트</button>
          <button id="pptTabFile" onclick="pptSwitchTab('file')"
                  style="flex:1;padding:8px;background:#e5e7eb;color:#6b7280;border:none;border-radius:6px;cursor:pointer;font-weight:700;font-size:12px;">📎 파일 업로드</button>
          <button id="pptTabLlm" onclick="pptSwitchTab('llm')"
                  style="flex:1;padding:8px;background:#e5e7eb;color:#6b7280;border:none;border-radius:6px;cursor:pointer;font-weight:700;font-size:12px;">🤖 LLM 디자인</button>
        </div>
        <div id="pptTabMdContent" style="flex:1;display:flex;flex-direction:column;">
          <!-- 처리 모드 선택 (모델 드롭다운 항상 표시) -->
          <div style="margin-bottom:8px;padding:10px;background:#fef3c7;border:1px solid #fde68a;border-radius:6px;">
            <div style="font-size:11px;color:#78716c;font-weight:700;margin-bottom:6px;">📋 변환 방식</div>
            <label style="display:flex;align-items:center;gap:6px;font-size:12px;color:#1e293b;cursor:pointer;margin-bottom:4px;">
              <input type="radio" name="pptMdMode" value="fast" checked onchange="pptToggleMdMode()"/>
              <b>🚀 빠른 변환</b> <span style="color:#64748b;font-size:11px;">— 결정론, 1~2초, 단순 디자인</span>
            </label>
            <label style="display:flex;align-items:center;gap:6px;font-size:12px;color:#1e293b;cursor:pointer;">
              <input type="radio" name="pptMdMode" value="llm" onchange="pptToggleMdMode()"/>
              <b>🤖 LLM 자동 디자인</b> <span style="color:#64748b;font-size:11px;">— 알아서 요약+도형 디자인, 30초~수분</span>
            </label>
            <div id="pptMdLlmModelRow" style="display:flex;margin-top:8px;align-items:center;gap:8px;">
              <label style="font-size:11px;color:#64748b;font-weight:700;white-space:nowrap;">🧠 모델 (LLM 모드 시)</label>
              <select id="pptMdLlmModelSelect"
                      style="flex:1;padding:5px 8px;background:#fff;color:#1e293b;border:1px solid #cbd5e1;border-radius:4px;font-size:11px;cursor:pointer;">
                <option value="">(로딩 중...)</option>
              </select>
            </div>
          </div>
          <label style="font-size:11px;color:#64748b;margin-bottom:4px;">
            마크다운 입력 (# 제목 / ## 슬라이드 / - 불릿 / | 표 | / ```코드``` 지원)
          </label>
          <textarea id="pptMdInput"
            style="flex:1;background:#f8fafc;color:#1e293b;border:1px solid #cbd5e1;border-radius:6px;
                   padding:10px;font-family:Consolas,monospace;font-size:12px;resize:none;min-height:240px;"
            placeholder="# 발표 제목&#10;> 부제 또는 날짜&#10;&#10;## 첫 슬라이드&#10;- 요점 1&#10;- 요점 2&#10;&#10;## 표 슬라이드&#10;| 항목 | 값 |&#10;|---|---|&#10;| A | 1 |&#10;&#10;## 코드 슬라이드&#10;```python&#10;def hello():&#10;    print('hi')&#10;```"></textarea>
          <button onclick="pptGenerateFromMd()"
                  style="margin-top:10px;padding:10px;background:linear-gradient(135deg,#eab308,#d97706);
                         color:#fff;border:none;border-radius:6px;font-weight:700;cursor:pointer;font-size:13px;">🚀 PPT 만들기</button>
        </div>
        <div id="pptTabFileContent" style="flex:1;display:none;flex-direction:column;">
          <!-- 처리 모드 선택 -->
          <div style="margin-bottom:8px;padding:10px;background:#fef3c7;border:1px solid #fde68a;border-radius:6px;">
            <div style="font-size:11px;color:#78716c;font-weight:700;margin-bottom:6px;">📋 파일 드롭 시 자동 처리 방식</div>
            <label style="display:flex;align-items:center;gap:6px;font-size:12px;color:#1e293b;cursor:pointer;margin-bottom:4px;">
              <input type="radio" name="pptFileMode" value="fast" checked onchange="pptToggleFileMode()"/>
              <b>🚀 빠른 변환</b> <span style="color:#64748b;font-size:11px;">— 결정론, 1~2초, 단순 디자인</span>
            </label>
            <label style="display:flex;align-items:center;gap:6px;font-size:12px;color:#1e293b;cursor:pointer;">
              <input type="radio" name="pptFileMode" value="llm" onchange="pptToggleFileMode()"/>
              <b>🤖 LLM 자동 디자인</b> <span style="color:#64748b;font-size:11px;">— 알아서 요약+도형 디자인, 30초~수분</span>
            </label>
            <div id="pptFileLlmModelRow" style="display:flex;margin-top:8px;align-items:center;gap:8px;">
              <label style="font-size:11px;color:#64748b;font-weight:700;white-space:nowrap;">🧠 모델 (LLM 모드 시)</label>
              <select id="pptFileLlmModelSelect"
                      style="flex:1;padding:5px 8px;background:#fff;color:#1e293b;border:1px solid #cbd5e1;border-radius:4px;font-size:11px;cursor:pointer;">
                <option value="">(로딩 중...)</option>
              </select>
            </div>
          </div>
          <label style="font-size:11px;color:#64748b;margin-bottom:4px;">.md / .markdown / .txt 파일 드래그-드롭 또는 클릭 → 위 방식으로 자동 실행</label>
          <div id="pptDropZone"
               style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;
                      border:2px dashed #cbd5e1;border-radius:8px;cursor:pointer;padding:40px;
                      transition:all .2s;background:#f8fafc;min-height:240px;"
               onclick="document.getElementById('pptFileInput').click()">
            <div style="font-size:48px;margin-bottom:12px;">📎</div>
            <div style="color:#a16207;font-size:14px;font-weight:700;">파일 드롭 또는 클릭</div>
            <div style="color:#78716c;font-size:11px;margin-top:6px;">.md · .markdown · .txt (UTF-8 / CP949 자동 감지)</div>
          </div>
          <input type="file" id="pptFileInput" accept=".md,.markdown,.txt" style="display:none;"
                 onchange="pptGenerateFromFile(this.files[0])"/>
        </div>
        <!-- 🤖 LLM 디자인 탭 -->
        <div id="pptTabLlmContent" style="flex:1;display:none;flex-direction:column;">
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;">
            <label style="font-size:11px;color:#64748b;font-weight:700;white-space:nowrap;">🧠 모델</label>
            <select id="pptLlmModelSelect"
                    style="flex:1;padding:6px 10px;background:#f8fafc;color:#1e293b;
                           border:1px solid #cbd5e1;border-radius:6px;font-size:12px;cursor:pointer;">
              <option value="">(모델 로딩 중...)</option>
            </select>
            <button onclick="pptLoadLlmModels()" title="새로고침"
                    style="padding:6px 10px;background:#f1f5f9;color:#64748b;border:1px solid #cbd5e1;border-radius:6px;cursor:pointer;font-size:11px;">🔄</button>
          </div>
          <label style="font-size:11px;color:#64748b;margin-bottom:4px;">
            주제 또는 MD 입력 (LLM이 디자인 사양 JSON으로 변환 → 도형 슬라이드 생성)
          </label>
          <textarea id="pptLlmInput"
            style="flex:1;background:#f8fafc;color:#1e293b;border:1px solid #cbd5e1;border-radius:6px;
                   padding:10px;font-family:Consolas,monospace;font-size:12px;resize:none;min-height:280px;"
            placeholder="예시 1) 주제만:&#10;반도체 EUV 노광 공정 5분 발표용 슬라이드 5장&#10;&#10;예시 2) MD 던지기:&#10;# AI 도입 효과&#10;## 생산성&#10;- 코드 작성 30% 빨라짐&#10;- 회의록 자동화&#10;## 비용&#10;- 월 $20/인&#10;&#10;LLM이 도형(원/화살표/카드 등) 사양으로 직접 디자인합니다."></textarea>
          <button onclick="pptGenerateFromLlm()"
                  style="margin-top:10px;padding:10px;background:linear-gradient(135deg,#7c3aed,#5b21b6);
                         color:#fff;border:none;border-radius:6px;font-weight:700;cursor:pointer;font-size:13px;">🤖 LLM 디자인으로 만들기</button>
        </div>
      </div>
      <div style="flex:1;display:flex;flex-direction:column;padding:14px;overflow-y:auto;">
        <label style="font-size:11px;color:#64748b;margin-bottom:4px;">결과</label>
        <div id="pptResultPanel"
             style="flex:1;background:#f8fafc;border:1px solid #cbd5e1;border-radius:6px;
                    padding:16px;color:#1e293b;font-size:12px;overflow-y:auto;min-height:300px;">
          <div style="text-align:center;color:#94a3b8;padding-top:80px;">
            <div style="font-size:36px;margin-bottom:10px;">⬅️</div>
            왼쪽에서 MD 입력 또는 파일 업로드 후<br>결과가 여기 나옵니다
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

</body>
</html>
"""

# ============================================
# 실행
# ============================================
