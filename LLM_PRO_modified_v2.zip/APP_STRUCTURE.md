# Nomos LLM Desktop App - 구조 문서

## 개요

PySide6 기반 데스크탑 LLM 코딩 어시스턴트.
API 우선(SK Hynix 폐쇄망), GGUF 폴백. Aider를 핵심 코드 수정 엔진으로 사용.

## 실행 방법
