#!/usr/bin/env python3
"""
OHT 실시간 시뮬레이터 - FastAPI 웹서버
- 실시간으로 OHT 데이터 생성
- WebSocket으로 프론트엔드에 전송
- CSV 자동 저장
"""

import os
import re
import json
import random
import math
import asyncio
from datetime import datetime
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Tuple, Optional
from collections import defaultdict
import heapq
import csv

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.staticfiles import StaticFiles
import uvicorn

# ============================================================
# 설정
# ============================================================
LAYOUT_PATH = "F:/M14_Q/OHT/OHT_LAYOUT_INFO/layout/layout/layout.html"
OUTPUT_DIR = "F:/M14_Q/OHT/simulator/output"
CSV_SAVE_INTERVAL = 10  # 10초마다 CSV 저장
VEHICLE_COUNT = 50  # OHT 대수
SIMULATION_INTERVAL = 0.5  # 0.5초마다 업데이트

# ============================================================
# 데이터 모델
# ============================================================
@dataclass
class Node:
    no: int
    x: float
    y: float
    stations: List[int] = field(default_factory=list)

@dataclass
class Vehicle:
    vehicleId: str
    currentNode: int
    nextNode: int = 0
    positionRatio: float = 0.0
    x: float = 0.0
    y: float = 0.0
    velocity: float = 0.0
    smoothedVelocity: float = 0.0
    state: int = 1  # 1=RUNNING, 2=STOPPED
    isLoaded: int = 0
    carrierId: str = ""
    destination: int = 0
    runCycle: int = 0
    path: List[int] = field(default_factory=list)
    pathIndex: int = 0

# ============================================================
# 레이아웃 파서
# ============================================================
def parse_layout(filepath: str) -> Tuple[Dict[int, Node], List[Tuple[int, int, float]]]:
    print(f"레이아웃 파싱: {filepath}")

    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    # 노드 데이터
    a_match = re.search(r'const A=(\[.*?\]);', content, re.DOTALL)
    nodes_data = json.loads(a_match.group(1))
    nodes = {}
    for n in nodes_data:
        nodes[n['no']] = Node(no=n['no'], x=n['x'], y=n['y'], stations=n.get('stations', []))

    # 연결 데이터
    c_match = re.search(r'const C=(\[.*?\]);', content, re.DOTALL)
    connections = json.loads(c_match.group(1))

    edges = []
    for conn in connections:
        from_n, to_n = conn[0], conn[1]
        if from_n in nodes and to_n in nodes:
            n1, n2 = nodes[from_n], nodes[to_n]
            dist = math.sqrt((n2.x - n1.x)**2 + (n2.y - n1.y)**2)
            edges.append((from_n, to_n, dist))

    print(f"  노드: {len(nodes)}, 엣지: {len(edges)}")
    return nodes, edges

# ============================================================
# 시뮬레이션 엔진
# ============================================================
class SimulationEngine:
    def __init__(self, nodes: Dict[int, Node], edges: List[Tuple[int, int, float]]):
        self.nodes = nodes
        self.edges = edges
        self.vehicles: Dict[str, Vehicle] = {}

        # 그래프
        self.graph: Dict[int, List[Tuple[int, float]]] = defaultdict(list)
        for from_n, to_n, dist in edges:
            self.graph[from_n].append((to_n, dist))

        # 엣지 맵
        self.edge_map = {(e[0], e[1]): e[2] for e in edges}

        # 속도 설정
        self.base_velocity = 180.0
        self.alpha = 0.3

        # CSV 데이터 버퍼
        self.vehicle_buffer: List[dict] = []
        self.rail_buffer: Dict[Tuple[int,int], dict] = defaultdict(lambda: {'pass_cnt': 0, 'velocities': []})

        # 시작 시간
        self.start_time = datetime.now()

    def init_vehicles(self, count: int):
        node_list = list(self.nodes.keys())
        for i in range(count):
            vid = f"OHT{i+1:04d}"
            start = random.choice(node_list)
            node = self.nodes[start]

            v = Vehicle(
                vehicleId=vid,
                currentNode=start,
                x=node.x,
                y=node.y
            )
            self.vehicles[vid] = v
            self._assign_task(v)

    def _find_path(self, start: int, end: int) -> List[int]:
        if start == end or start not in self.nodes or end not in self.nodes:
            return []

        dist = {start: 0}
        prev = {}
        pq = [(0, start)]

        while pq:
            d, u = heapq.heappop(pq)
            if u == end:
                break
            if d > dist.get(u, float('inf')):
                continue
            for v, w in self.graph[u]:
                nd = d + w
                if nd < dist.get(v, float('inf')):
                    dist[v] = nd
                    prev[v] = u
                    heapq.heappush(pq, (nd, v))

        if end not in prev:
            return []

        path = []
        curr = end
        while curr in prev:
            path.append(curr)
            curr = prev[curr]
        path.append(start)
        path.reverse()
        return path

    def _assign_task(self, v: Vehicle):
        dest = random.choice(list(self.nodes.keys()))
        attempts = 0
        while dest == v.currentNode and attempts < 10:
            dest = random.choice(list(self.nodes.keys()))
            attempts += 1

        path = self._find_path(v.currentNode, dest)
        if len(path) > 1:
            v.path = path
            v.pathIndex = 0
            v.destination = dest
            v.nextNode = path[1]
            v.state = 1
            v.runCycle = random.choice([3, 4])
            v.isLoaded = random.randint(0, 1)
            if v.isLoaded:
                v.carrierId = f"FOUP{random.randint(1000, 9999)}"
            else:
                v.carrierId = ""

    def update(self, dt: float):
        """모든 Vehicle 업데이트"""
        for v in self.vehicles.values():
            self._update_vehicle(v, dt)

    def _update_vehicle(self, v: Vehicle, dt: float):
        if v.state != 1 or not v.path:
            if random.random() < 0.05:
                self._assign_task(v)
            return

        # 속도 계산
        target_vel = self.base_velocity * (0.7 + random.random() * 0.6)
        v.smoothedVelocity = self.alpha * target_vel + (1 - self.alpha) * v.smoothedVelocity
        v.velocity = round(v.smoothedVelocity, 2)

        # 현재 엣지
        edge_dist = self.edge_map.get((v.currentNode, v.nextNode), 100)

        # 이동
        move = v.velocity * (dt / 60.0)
        v.positionRatio += move / max(edge_dist, 1)

        # Rail traffic 기록
        key = (v.currentNode, v.nextNode)
        self.rail_buffer[key]['pass_cnt'] += 1
        self.rail_buffer[key]['velocities'].append(v.velocity)

        # 위치 계산 (보간)
        n1 = self.nodes.get(v.currentNode)
        n2 = self.nodes.get(v.nextNode)
        if n1 and n2:
            ratio = min(1.0, v.positionRatio)
            v.x = n1.x + (n2.x - n1.x) * ratio
            v.y = n1.y + (n2.y - n1.y) * ratio

        # 다음 노드 도달
        if v.positionRatio >= 1.0:
            v.positionRatio = 0.0
            v.pathIndex += 1

            if v.pathIndex < len(v.path) - 1:
                v.currentNode = v.path[v.pathIndex]
                v.nextNode = v.path[v.pathIndex + 1]
            else:
                v.currentNode = v.destination
                v.state = 2
                v.path = []
                v.runCycle = 0

    def get_state(self) -> dict:
        """현재 상태 반환 (WebSocket용)"""
        vehicles = []
        for v in self.vehicles.values():
            # 남은 경로 (현재 위치부터 목적지까지)
            remaining_path = []
            if v.path and v.pathIndex < len(v.path):
                remaining_path = v.path[v.pathIndex:]

            vehicles.append({
                'vehicleId': v.vehicleId,
                'x': round(v.x, 2),
                'y': round(v.y, 2),
                'state': v.state,
                'isLoaded': v.isLoaded,
                'velocity': v.velocity,
                'currentNode': v.currentNode,
                'nextNode': v.nextNode,
                'destination': v.destination,
                'carrierId': v.carrierId,
                'path': remaining_path
            })

        return {
            'timestamp': datetime.now().isoformat(),
            'vehicles': vehicles,
            'stats': {
                'total': len(vehicles),
                'running': sum(1 for v in vehicles if v['state'] == 1),
                'loaded': sum(1 for v in vehicles if v['isLoaded'] == 1)
            }
        }

    def record_to_buffer(self):
        """CSV 버퍼에 기록"""
        now = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
        for v in self.vehicles.values():
            self.vehicle_buffer.append({
                'createTime': now,
                'fabId': 'M14Q',
                'vehicleId': v.vehicleId,
                'state': v.state,
                'runCycle': v.runCycle,
                'currentAddress': v.currentNode,
                'nextAddress': v.nextNode,
                'destination': v.destination,
                'carrierId': v.carrierId,
                'isLoaded': v.isLoaded,
                'velocity': v.velocity,
                'x': round(v.x, 2),
                'y': round(v.y, 2)
            })

    def save_csv(self):
        """CSV 파일 저장"""
        if not self.vehicle_buffer:
            return

        os.makedirs(OUTPUT_DIR, exist_ok=True)
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')

        # Vehicle CSV
        veh_file = os.path.join(OUTPUT_DIR, f'ATLAS_VEHICLE_{timestamp}.csv')
        with open(veh_file, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=self.vehicle_buffer[0].keys())
            writer.writeheader()
            writer.writerows(self.vehicle_buffer)
        print(f"저장: {veh_file} ({len(self.vehicle_buffer)} rows)")

        # Rail Traffic CSV
        rail_file = os.path.join(OUTPUT_DIR, f'ATLAS_RAIL_TRAFFIC_{timestamp}.csv')
        rail_rows = []
        for (from_n, to_n), data in self.rail_buffer.items():
            if data['velocities']:
                rail_rows.append({
                    'createTime': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'fabId': 'M14Q',
                    'fromNode': from_n,
                    'toNode': to_n,
                    'avgVelocity': round(sum(data['velocities']) / len(data['velocities']), 2),
                    'passCnt': data['pass_cnt']
                })

        if rail_rows:
            with open(rail_file, 'w', newline='', encoding='utf-8') as f:
                writer = csv.DictWriter(f, fieldnames=rail_rows[0].keys())
                writer.writeheader()
                writer.writerows(rail_rows)
            print(f"저장: {rail_file} ({len(rail_rows)} rows)")

        # 버퍼 초기화
        self.vehicle_buffer = []
        self.rail_buffer = defaultdict(lambda: {'pass_cnt': 0, 'velocities': []})

# ============================================================
# FastAPI 앱
# ============================================================
app = FastAPI(title="OHT Simulator")

# 전역 변수
engine: Optional[SimulationEngine] = None
layout_data: dict = None
is_running = False

@app.on_event("startup")
async def startup():
    global engine, layout_data, is_running

    # 레이아웃 로드
    nodes, edges = parse_layout(LAYOUT_PATH)

    # 프론트엔드용 레이아웃 데이터
    layout_data = {
        'nodes': [{'no': n.no, 'x': n.x, 'y': n.y} for n in nodes.values()],
        'edges': [{'from': e[0], 'to': e[1]} for e in edges]
    }

    # 엔진 초기화
    engine = SimulationEngine(nodes, edges)
    engine.init_vehicles(VEHICLE_COUNT)

    is_running = True

    # 백그라운드 태스크 시작
    asyncio.create_task(simulation_loop())
    asyncio.create_task(csv_save_loop())

    print(f"\n서버 시작: http://localhost:8000")
    print(f"OHT {VEHICLE_COUNT}대 시뮬레이션 시작\n")

async def simulation_loop():
    """시뮬레이션 메인 루프"""
    global engine, is_running
    while is_running:
        engine.update(SIMULATION_INTERVAL)
        engine.record_to_buffer()
        await asyncio.sleep(SIMULATION_INTERVAL)

async def csv_save_loop():
    """CSV 저장 루프"""
    global engine, is_running
    while is_running:
        await asyncio.sleep(CSV_SAVE_INTERVAL)
        engine.save_csv()

# WebSocket 연결 관리
connections: List[WebSocket] = []

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    connections.append(websocket)
    print(f"WebSocket 연결: {len(connections)}개")

    try:
        # 레이아웃 전송
        await websocket.send_json({'type': 'layout', 'data': layout_data})

        # 실시간 데이터 전송
        while True:
            state = engine.get_state()
            await websocket.send_json({'type': 'update', 'data': state})
            await asyncio.sleep(SIMULATION_INTERVAL)
    except WebSocketDisconnect:
        connections.remove(websocket)
        print(f"WebSocket 해제: {len(connections)}개")

@app.get("/", response_class=HTMLResponse)
async def index():
    return HTML_CONTENT

@app.get("/api/layout")
async def get_layout():
    return layout_data

@app.get("/api/state")
async def get_state():
    return engine.get_state()

# ============================================================
# HTML 프론트엔드
# ============================================================
HTML_CONTENT = """
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<title>OHT 실시간 시뮬레이터</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: 'Segoe UI', sans-serif; background: #0a0a1a; color: #eee; overflow: hidden; }

#header {
    position: fixed; top: 0; left: 0; right: 0; height: 50px;
    background: linear-gradient(90deg, #1a1a3e, #2a2a5e);
    display: flex; align-items: center; justify-content: space-between;
    padding: 0 20px; z-index: 1000;
    box-shadow: 0 2px 10px rgba(0,0,0,0.5);
}
#header h1 { font-size: 18px; color: #00d4ff; }
#header .status { display: flex; gap: 20px; font-size: 13px; }
#header .status span { color: #00d4ff; font-weight: bold; }
.live-dot { width: 10px; height: 10px; background: #00ff88; border-radius: 50%; animation: pulse 1s infinite; }
@keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.5; } }

#sidebar {
    position: fixed; top: 50px; left: 0; bottom: 0; width: 240px;
    background: rgba(20, 20, 40, 0.95); padding: 15px;
    border-right: 1px solid #333; z-index: 900;
}
#sidebar h3 { color: #00d4ff; font-size: 13px; margin: 15px 0 10px; }
#sidebar .section { background: #1a1a2e; padding: 12px; border-radius: 8px; margin-bottom: 12px; }
.stat-row { display: flex; justify-content: space-between; padding: 5px 0; font-size: 12px; }
.stat-row .val { color: #00d4ff; font-weight: bold; font-size: 14px; }

.legend { margin-top: 10px; }
.legend-item { display: flex; align-items: center; gap: 8px; padding: 4px 0; font-size: 11px; }
.legend-dot { width: 14px; height: 14px; border-radius: 50%; border: 2px solid #fff; }

#canvas-container { position: fixed; top: 50px; left: 240px; right: 0; bottom: 0; }
canvas { display: block; }

#tooltip {
    position: fixed; background: rgba(0,20,40,0.95); border: 2px solid #00d4ff;
    padding: 12px; border-radius: 8px; font-size: 11px; display: none; z-index: 2000;
    min-width: 160px; pointer-events: none;
}
#tooltip .title { color: #00d4ff; font-weight: bold; font-size: 14px; margin-bottom: 8px; }
#tooltip .row { display: flex; justify-content: space-between; padding: 3px 0; }
#tooltip .label { color: #888; }
#tooltip .value { color: #fff; font-weight: bold; }

#info-panel {
    position: fixed; bottom: 20px; right: 20px;
    background: rgba(0,0,0,0.8); padding: 15px 20px;
    border-radius: 8px; border: 1px solid #00d4ff; z-index: 1000;
}
#info-panel .time { font-size: 24px; color: #00d4ff; font-weight: bold; }
#info-panel .label { font-size: 11px; color: #888; }
</style>
</head>
<body>

<div id="header">
    <h1>SK Hynix M14 OHT Simulator</h1>
    <div class="status">
        <div style="display:flex;align-items:center;gap:8px;"><div class="live-dot"></div> LIVE</div>
        <div>노드: <span id="nodeCount">-</span></div>
        <div>OHT: <span id="vehCount">-</span></div>
        <div>운행: <span id="runCount">-</span></div>
        <div>적재: <span id="loadCount">-</span></div>
    </div>
</div>

<div id="sidebar">
    <div class="section">
        <h3>실시간 통계</h3>
        <div class="stat-row"><span>총 OHT</span><span class="val" id="statTotal">-</span></div>
        <div class="stat-row"><span>운행중</span><span class="val" id="statRunning">-</span></div>
        <div class="stat-row"><span>적재중</span><span class="val" id="statLoaded">-</span></div>
        <div class="stat-row"><span>정지</span><span class="val" id="statStopped">-</span></div>
    </div>

    <div class="section">
        <h3>범례</h3>
        <div class="legend">
            <div class="legend-item"><div class="legend-dot" style="background:#00ff88"></div>운행중 (공차)</div>
            <div class="legend-item"><div class="legend-dot" style="background:#ff9900"></div>운행중 (적재)</div>
            <div class="legend-item"><div class="legend-dot" style="background:#ff3366"></div>정지</div>
        </div>
    </div>

    <div class="section">
        <h3>컨트롤</h3>
        <div class="stat-row"><span>줌</span><span class="val" id="zoomLevel">100%</span></div>
        <div style="font-size:11px;color:#888;margin-top:8px;">
            마우스 휠: 줌<br>
            드래그: 이동<br>
            OHT 호버: 정보
        </div>
    </div>
</div>

<div id="canvas-container">
    <canvas id="canvas"></canvas>
</div>

<div id="tooltip"></div>

<div id="info-panel">
    <div class="label">시뮬레이션 시간</div>
    <div class="time" id="simTime">00:00:00</div>
</div>

<script>
const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');

let layout = null;
let vehicles = {};
let nodeMap = {};

let offsetX = 0, offsetY = 0, scale = 1;
let isDragging = false, lastMouse = {x: 0, y: 0};
let startTime = Date.now();
let selectedVehicles = new Set();  // 더블클릭으로 선택된 OHT들 (여러개 가능)

// 캔버스 크기
function resize() {
    const container = document.getElementById('canvas-container');
    canvas.width = container.clientWidth;
    canvas.height = container.clientHeight;
    render();
}
window.addEventListener('resize', resize);
resize();

// WebSocket 연결
const ws = new WebSocket(`ws://${location.host}/ws`);

ws.onmessage = (e) => {
    const msg = JSON.parse(e.data);

    if (msg.type === 'layout') {
        layout = msg.data;
        nodeMap = {};
        layout.nodes.forEach(n => nodeMap[n.no] = n);
        document.getElementById('nodeCount').textContent = layout.nodes.length.toLocaleString();
        fitView();
    }
    else if (msg.type === 'update') {
        // 부드러운 보간을 위해 타겟 위치 설정
        msg.data.vehicles.forEach(v => {
            if (!vehicles[v.vehicleId]) {
                vehicles[v.vehicleId] = {...v, dispX: v.x, dispY: v.y};
            } else {
                Object.assign(vehicles[v.vehicleId], v);
            }
        });

        // 통계 업데이트
        const stats = msg.data.stats;
        document.getElementById('vehCount').textContent = stats.total;
        document.getElementById('runCount').textContent = stats.running;
        document.getElementById('loadCount').textContent = stats.loaded;
        document.getElementById('statTotal').textContent = stats.total;
        document.getElementById('statRunning').textContent = stats.running;
        document.getElementById('statLoaded').textContent = stats.loaded;
        document.getElementById('statStopped').textContent = stats.total - stats.running;
    }
};

ws.onclose = () => console.log('WebSocket 연결 해제');
ws.onerror = (e) => console.error('WebSocket 오류:', e);

// 애니메이션 루프
function animate() {
    // 부드러운 보간
    Object.values(vehicles).forEach(v => {
        v.dispX = v.dispX + (v.x - v.dispX) * 0.15;
        v.dispY = v.dispY + (v.y - v.dispY) * 0.15;
    });

    // 시간 업데이트
    const elapsed = Math.floor((Date.now() - startTime) / 1000);
    const h = String(Math.floor(elapsed / 3600)).padStart(2, '0');
    const m = String(Math.floor((elapsed % 3600) / 60)).padStart(2, '0');
    const s = String(elapsed % 60).padStart(2, '0');
    document.getElementById('simTime').textContent = `${h}:${m}:${s}`;

    render();
    requestAnimationFrame(animate);
}
animate();

// 렌더링
function render() {
    ctx.fillStyle = '#0a0a1a';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    if (!layout) return;

    ctx.save();
    ctx.translate(offsetX, offsetY);
    ctx.scale(scale, scale);

    // 엣지 (레일)
    ctx.strokeStyle = '#2a2a4a';
    ctx.lineWidth = 1.5 / scale;
    layout.edges.forEach(e => {
        const from = nodeMap[e.from], to = nodeMap[e.to];
        if (from && to) {
            ctx.beginPath();
            ctx.moveTo(from.x, from.y);
            ctx.lineTo(to.x, to.y);
            ctx.stroke();
        }
    });

    // 노드 점
    ctx.fillStyle = '#4a4a6a';
    const nodeSize = Math.max(1.5, 3 / scale);
    layout.nodes.forEach(n => {
        ctx.beginPath();
        ctx.arc(n.x, n.y, nodeSize, 0, Math.PI * 2);
        ctx.fill();
    });

    // OHT 크기
    const vehSize = Math.max(4, 7 / scale);

    // 선택된 OHT들 경로 표시 (여러개)
    const colors = ['#00ffff', '#ff00ff', '#ffff00', '#00ff00', '#ff8800', '#8800ff'];
    let colorIdx = 0;
    selectedVehicles.forEach(vid => {
        const sv = vehicles[vid];
        if (!sv) return;

        const path = sv.path || [];
        const color = colors[colorIdx % colors.length];
        colorIdx++;

        if (path.length > 0) {
            // 현재 위치에서 시작하는 경로선
            ctx.strokeStyle = color;
            ctx.lineWidth = 4 / scale;
            ctx.setLineDash([8/scale, 4/scale]);
            ctx.beginPath();
            ctx.moveTo(sv.dispX, sv.dispY);

            // 경로의 각 노드를 따라 선 그리기
            path.forEach(nodeNo => {
                const node = nodeMap[nodeNo];
                if (node) {
                    ctx.lineTo(node.x, node.y);
                }
            });
            ctx.stroke();
            ctx.setLineDash([]);

            // 경로 상의 노드들 강조
            ctx.fillStyle = color;
            path.forEach((nodeNo, idx) => {
                const node = nodeMap[nodeNo];
                if (node) {
                    ctx.beginPath();
                    ctx.arc(node.x, node.y, 4 / scale, 0, Math.PI * 2);
                    ctx.fill();
                }
            });

            // 목적지 마커 (마지막 노드)
            const destNode = nodeMap[sv.destination];
            if (destNode) {
                ctx.fillStyle = '#ff0066';
                ctx.beginPath();
                ctx.arc(destNode.x, destNode.y, 12 / scale, 0, Math.PI * 2);
                ctx.fill();
                ctx.strokeStyle = '#fff';
                ctx.lineWidth = 2 / scale;
                ctx.stroke();

                // 목적지 텍스트
                ctx.fillStyle = '#fff';
                ctx.font = `bold ${14/scale}px sans-serif`;
                ctx.textAlign = 'center';
                ctx.fillText(vid, destNode.x, destNode.y - 18/scale);
            }
        }

        // 선택된 OHT 강조 테두리
        ctx.strokeStyle = color;
        ctx.lineWidth = 3 / scale;
        ctx.beginPath();
        ctx.arc(sv.dispX, sv.dispY, vehSize + 5/scale, 0, Math.PI * 2);
        ctx.stroke();
    });

    // OHT
    Object.values(vehicles).forEach(v => {
        let color = '#00ff88';
        if (v.state === 2) color = '#ff3366';
        else if (v.isLoaded === 1) color = '#ff9900';

        // 그림자
        ctx.fillStyle = 'rgba(0,0,0,0.4)';
        ctx.beginPath();
        ctx.arc(v.dispX + 2/scale, v.dispY + 2/scale, vehSize, 0, Math.PI * 2);
        ctx.fill();

        // 본체
        ctx.fillStyle = color;
        ctx.beginPath();
        ctx.arc(v.dispX, v.dispY, vehSize, 0, Math.PI * 2);
        ctx.fill();

        ctx.strokeStyle = '#fff';
        ctx.lineWidth = 1.5 / scale;
        ctx.stroke();

        // 적재 표시
        if (v.isLoaded === 1) {
            ctx.fillStyle = '#fff';
            ctx.beginPath();
            ctx.arc(v.dispX, v.dispY, vehSize * 0.4, 0, Math.PI * 2);
            ctx.fill();
        }

    });

    ctx.restore();

    document.getElementById('zoomLevel').textContent = Math.round(scale * 100) + '%';
}

// 마우스 이벤트
canvas.addEventListener('mousedown', e => {
    isDragging = true;
    lastMouse = {x: e.clientX, y: e.clientY};
});
canvas.addEventListener('mousemove', e => {
    if (isDragging) {
        offsetX += e.clientX - lastMouse.x;
        offsetY += e.clientY - lastMouse.y;
        lastMouse = {x: e.clientX, y: e.clientY};
    }
    updateTooltip(e);
});
canvas.addEventListener('mouseup', () => isDragging = false);
canvas.addEventListener('mouseleave', () => { isDragging = false; document.getElementById('tooltip').style.display = 'none'; });

// 더블클릭 - OHT 선택 토글 (여러개 선택 가능)
canvas.addEventListener('dblclick', e => {
    const rect = canvas.getBoundingClientRect();
    const mx = (e.clientX - rect.left - offsetX) / scale;
    const my = (e.clientY - rect.top - offsetY) / scale;

    let clicked = null;
    let minDist = 20 / scale;
    Object.values(vehicles).forEach(v => {
        const d = Math.hypot(v.dispX - mx, v.dispY - my);
        if (d < minDist) { minDist = d; clicked = v.vehicleId; }
    });

    if (clicked) {
        // 이미 선택된 OHT면 해제, 아니면 추가
        if (selectedVehicles.has(clicked)) {
            selectedVehicles.delete(clicked);
            console.log('선택 해제:', clicked);
        } else {
            selectedVehicles.add(clicked);
            console.log('선택 추가:', clicked);
        }
    }
    // 빈 곳 더블클릭은 아무것도 안함 (기존 선택 유지)
});

canvas.addEventListener('wheel', e => {
    e.preventDefault();
    const rect = canvas.getBoundingClientRect();
    const mx = e.clientX - rect.left, my = e.clientY - rect.top;
    const zoom = e.deltaY < 0 ? 1.15 : 0.87;
    const newScale = Math.max(0.02, Math.min(15, scale * zoom));

    offsetX = mx - (mx - offsetX) * (newScale / scale);
    offsetY = my - (my - offsetY) * (newScale / scale);
    scale = newScale;
});

function updateTooltip(e) {
    const rect = canvas.getBoundingClientRect();
    const mx = (e.clientX - rect.left - offsetX) / scale;
    const my = (e.clientY - rect.top - offsetY) / scale;

    let closest = null, minDist = 20 / scale;
    Object.values(vehicles).forEach(v => {
        const d = Math.hypot(v.dispX - mx, v.dispY - my);
        if (d < minDist) { minDist = d; closest = v; }
    });

    const tooltip = document.getElementById('tooltip');
    if (closest) {
        tooltip.innerHTML = `
            <div class="title">${closest.vehicleId}</div>
            <div class="row"><span class="label">상태</span><span class="value">${closest.state === 1 ? '운행중' : '정지'}</span></div>
            <div class="row"><span class="label">속도</span><span class="value">${closest.velocity} m/min</span></div>
            <div class="row"><span class="label">적재</span><span class="value">${closest.isLoaded === 1 ? 'O (' + closest.carrierId + ')' : 'X'}</span></div>
            <div class="row"><span class="label">현재</span><span class="value">${closest.currentNode}</span></div>
            <div class="row"><span class="label">목적지</span><span class="value">${closest.destination || '-'}</span></div>
        `;
        tooltip.style.display = 'block';
        tooltip.style.left = (e.clientX + 15) + 'px';
        tooltip.style.top = (e.clientY + 15) + 'px';
    } else {
        tooltip.style.display = 'none';
    }
}

function fitView() {
    if (!layout || !layout.nodes.length) return;

    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
    layout.nodes.forEach(n => {
        minX = Math.min(minX, n.x); maxX = Math.max(maxX, n.x);
        minY = Math.min(minY, n.y); maxY = Math.max(maxY, n.y);
    });

    const pad = 50;
    const w = maxX - minX, h = maxY - minY;
    const sx = (canvas.width - pad * 2) / w;
    const sy = (canvas.height - pad * 2) / h;
    scale = Math.min(sx, sy);

    offsetX = pad - minX * scale + (canvas.width - pad * 2 - w * scale) / 2;
    offsetY = pad - minY * scale + (canvas.height - pad * 2 - h * scale) / 2;
}
</script>
</body>
</html>
"""

# ============================================================
# 메인
# ============================================================
if __name__ == "__main__":
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    uvicorn.run(app, host="0.0.0.0", port=10003)
