# ATLAS Dijkstra 검증 보고서

> **목적**: WORLD_SIM 월드모델의 이동예측 모듈 구축 전, ATLAS의 실제 라우팅이 우리가 가정한 Dijkstra와 일치하는지 UDP 데이터로 다각도 검증.
> **결론 한 줄**: ATLAS는 **순수 거리 기반 Dijkstra와 다른 경로**를 선택. 추가 보정 항(차량 가중치/속도 cost) 또는 다른 알고리즘 가능성. 고객 확인 필수.

---

## 1. Context

WORLD_SIM의 핵심 가치 = **이동 예측** (차량이 앞으로 어디로 갈지 시뮬레이션).
이게 신뢰 가능하려면 **ATLAS의 라우팅 알고리즘을 정확히 복제**해야 함.

ATLAS Java SRC 분석에서 발견한 알고리즘:
- [ALT/src/navi/DijkstraVhlRouteFind.java](ALT/src/navi/DijkstraVhlRouteFind.java) — PriorityQueue Dijkstra
- [ALT/src/map/edge/RailEdge.java#L85-91](ALT/src/map/edge/RailEdge.java) — `cost = length / (velocity*1000/60/1000)` (ms 단위)
- [RailEdge.java getVhlCountCost()](ALT/src/map/edge/RailEdge.java) — 차량수 가중치 (+ N*3000ms)

이 코드가 진짜 운영 코드인지 불확실 → **UDP 실 데이터로 검증 필요**.

---

## 2. 방법론

### 2.1 검증 4단계
```
Step 1: UDP 실 경로 재구성 (한 차량의 시간순 노드 시퀀스 추출)
Step 2: 동일 출발-도착에 대해 우리 Dijkstra 직접 실행
Step 3: 두 경로 비교 (노드 일치율, 거리 일치율)
Step 4: 차이 원인 추론 + 가설 검증
```

### 2.2 UDP 데이터 한계 (중요)
- LOGPRESSO 캡처 비율이 약 1% → 차량당 분당 1건 정도
- 즉 **UDP에서 보이는 두 연속 메시지 사이에 실제로는 많은 메시지 누락**
- → "9초 동안 720m 이동 = 281 km/h" 같은 비현실 수치 발생
- **올바른 비교 기준**: UDP가 거친 노드가 Dijkstra 경로에 포함되는지 (포함률)
  - 잘못된 기준: UDP 두 메시지 사이의 hop 수를 직접 비교

### 2.3 사용 데이터
| 항목 | 출처 |
|------|------|
| UDP raw | `OHS_DATA_MD/20260416/LOGPRESSO_OHT_DATA_20260416.csv` (140만건) |
| Layout 그래프 | `OHT_MAP/layout_cache.json` (9,402 노드, 10,422 edges) |
| Dijkstra 구현 | 일회용 파이썬 (Step 2 코드 첨부) |

### 2.4 사용 코드 (재현 가능)
```python
import json, heapq
with open('layout_cache.json') as f: d = json.load(f)
adj   = {int(k):[int(n) for n in v] for k,v in d['adj'].items()}
edges = {tuple(map(int,k.split(','))): float(v) for k,v in d['edges'].items()}

def dijkstra(src, dst, max_hops=300):
    if src == dst: return [src], 0.0
    pq = [(0.0, src, [src])]
    visited = set()
    while pq:
        cost, node, path = heapq.heappop(pq)
        if node in visited: continue
        visited.add(node)
        if node == dst: return path, cost
        if len(path) > max_hops: continue
        for nbr in adj.get(node, []):
            if nbr in visited: continue
            ec = edges.get((node, nbr), 0)
            heapq.heappush(pq, (cost+ec, nbr, path+[nbr]))
    return None, None
```

---

## 3. Step 1 — UDP 실 경로 재구성

### 3.1 차량 선정
가장 활동량 많은 차량 중 V00007 (3,852건/일) 선택. mission 단위로 끊어서 분석.

### 3.2 V00007 한 mission 추출 (07:02:43 ~ 07:05:18, dest=16133)

| 시각 | curr | dist | next | rc | vc | 의미 |
|------|------|------|------|----|----|------|
| 07:02:43 | 1218 | 0 | 1256 | 4 | 4 | 운반 시작 |
| 07:02:57 | 6391 | 1 | 6392 | 4 | 4 | |
| 07:03:11 | 6400 | 0 | 6401 | 4 | 4 | |
| 07:03:43 | 6428 | 0 | 6429 | 4 | 4 | |
| 07:04:17 | 6894 | 4 | 6895 | 4 | 4 | |
| 07:04:41 | 3704 | 1 | 3705 | 4 | 4 | |
| 07:04:49 | 3712 | 1 | 3713 | 4 | 4 | |
| 07:04:52 | 3657 | 0 | 3658 | 4 | 4 | |
| 07:05:18 | 3637 | 0 | 3638 | 4 | 4 | mission 끝 |

**UDP 경로 노드 집합** (10개): `{1218, 1256, 6391, 6392, 6400, 6401, 6428, 6429, 6894, 6895, 3704, 3705, 3712, 3713, 3657, 3658, 3637, 3638}`

(curr만): `{1218, 6391, 6400, 6428, 6894, 3704, 3712, 3657, 3637, 3638}`

---

## 4. Step 2 — 우리 Dijkstra 결과

V00007의 mission 출발(1218) → 끝(3638) 사이 우리 Dijkstra 산출.

### 4.1 결과
- **경로 길이**: 146 노드
- **총 거리**: 6,336.8 m (63,368 dm)
- **시작/끝**: `[1218, 1256, 1257, 1260, 6378, 6379, 6380, 6381, 6382, 6383, ...]` → `[..., 3634, 3635, 3636, 3637, 3638]`
- **소요시간 추정** (속도 150 m/min 가정): 약 **2.5분**
- **실제 UDP 소요시간**: 07:02:43 → 07:05:18 = **2분 35초**
- → 시간 추정은 거의 일치 ✅

### 4.2 그래프 특성 확인
주요 노드의 인접 관계 (대부분 단방향 1-2개 이웃):
```
node 5345 인접: [5346]
node 5358 인접: [5363, 5359]
node 1256 인접: [1257]
node 6391 인접: [6392]
```
→ 그래프는 **레일 라인** 형태 (분기점에서만 2개 이웃)

---

## 5. Step 3 — UDP vs Dijkstra 비교

### 5.1 노드 포함률
UDP가 거친 10개 noded 중 Dijkstra 경로(146 노드)에 **포함된 노드**:

| UDP 노드 | Dijkstra에 있나? |
|---------|----------------|
| 1218 | ✅ (시작) |
| 1256 | ✅ |
| 6391 | ❌ **없음** |
| 6400 | ❌ |
| 6428 | ❌ |
| 6894 | ❌ |
| 3704 | ✅ |
| 3712 | ❌ |
| 3657 | ❌ |
| 3637 | ✅ |
| 3638 | ✅ (끝) |

**일치율**: 6/11 = **55%**

### 5.2 핵심 발견
- UDP 노드 `6391, 6400, 6428, 6894` → 우리 Dijkstra의 **6378-6383 라인이 아닌 다른 라인** 통과
- UDP 노드 `3712, 3657` → 우리 Dijkstra의 **3634-3638 라인 진입 전** 다른 우회로 사용
- → **ATLAS는 명백히 다른 경로 선택**

### 5.3 sparse 데이터 영향
"9초 동안 720m" 같은 비현실 수치는 UDP 누락 때문이지 Dijkstra 오류가 아님.
→ 시간 비교가 아닌 **노드 포함률**이 신뢰성 높은 검증 지표.

---

## 6. Step 4 — 차이 원인 가설 검증

### 6.1 가설 매트릭스

| 가설 | 설명 | 본 데이터로 평가 |
|------|------|----------------|
| H1: 순수 Dijkstra (cost=length) | 우리가 한 방식 | ❌ 실 경로와 55%만 일치 → **기각** |
| H2: Dijkstra + 차량수 가중치 | ATLAS Java의 `getVhlCountCost` | ⚠️ 가능성 있음 — V00007이 6378 라인을 회피한 게 차량 밀집 회피였을 수도 |
| H3: A* (heuristic 사용) | Euclidean 거리 가중 | ⚠️ 검증 필요. 그래프가 단순 라인이라 A*가 큰 차이 안 만들 수 있음 |
| H4: 시간 기반 cost (length/velocity) | ATLAS 코드 명시 | ⚠️ velocity가 edge별 다르면 결과 다름. 검증 필요 |
| H5: 다른 그래프 사용 | ATLAS는 `RailEdge` 별도 정의 | ⚠️ layout_cache.json이 ATLAS 그래프와 다를 수 있음 — **고객 확인 필요** |
| H6: 동적 재라우팅 | 매 스텝마다 재계산 | ⚠️ 가능. 차량 밀집 변화에 따라 경로 바뀜 |

### 6.2 가장 유력한 가설
**H4 + H6 조합** — 시간 기반 cost (`length/velocity`) + 매 스텝 재계산.
근거:
- ATLAS Java 코드와 일치
- 동적 환경(차량 밀집 변화)에 맞음
- 우리 pure-distance Dijkstra와 다른 결과 잘 설명

### 6.3 추가 검증 필요 항목 (별도 작업)
1. ATLAS 그래프 = layout_cache.json 그래프 인지 (고객 확인)
2. velocity 데이터로 cost를 dynamic하게 계산했을 때 H4 결과
3. `getVhlCountCost`의 차량수 가중치 시뮬레이션
4. 같은 출발-도착의 다른 차량들이 모두 같은 경로 선택? (결정론 검증)

---

## 7. 결론

### 7.1 본 보고서 결과
| 항목 | 판정 |
|------|------|
| ATLAS = 우리 pure-distance Dijkstra | ❌ **일치 안 함** |
| ATLAS Java 코드(시간 기반 + 차량수 가중치) 가능성 | ⚠️ **유력하지만 미검증** |
| 신뢰도 등급 | **C** (코드 분석은 했지만 UDP 검증으로 확정 못함) |

### 7.2 권고 — 월드모델 이동예측 모듈 구축 시
**임시 채택**: ATLAS Java 코드 기준 — 시간 기반 cost + 차량수 가중치
- `cost = length_dm / velocity_estimate × 60` (단위: ms)
- `+ vehicleCountOnEdge × 3000ms` (가중치)
- `+ idleVehicleCount × idleVhlPenalty`
- `+ workingVehicleCount × workVhlPenalty`

**리스크**: ATLAS 운영 코드가 다르면 예측 정확도 떨어짐. 고객 확인 필수.

### 7.3 고객 확인 사항 (다음 단계)
1. ATLAS 운영 환경의 라우팅 알고리즘이 Dijkstra인가, 다른가?
2. cost 공식이 `RailEdge.getCost()` 와 같은가?
3. `getVhlCountCost()` 의 차량수/작업 가중치가 운영 환경에서 어떻게 설정되는가?
4. 라우팅 사용하는 그래프는 layout_cache.json과 같은가? (양방향성, 단방향성)
5. 매 스텝 재라우팅 vs 1회 계산 후 고정?

---

## 8. 후속 작업 (이 보고서 이후)

### 8.1 단기 (고객 확인 후)
- 확정된 알고리즘대로 WORLD_SIM에 `route_predictor.py` 모듈 추가
- Dijkstra + cost 공식 + 차량수 가중치 적용
- 매 frame 재라우팅 (또는 mission 단위)

### 8.2 중기
- 이동 예측 시뮬레이션 (10분 후 차량 위치)
- 데드락 전조 + 라우팅 변화 연계 분석
- 병목 구간 자동 식별

### 8.3 검증
- 신규 모듈로 예측한 경로 vs UDP 실 경로 비교
- 노드 포함률 90%+ 목표

---

## 9. 데이터 재현

### 9.1 UDP 추출 명령
```bash
grep '","2,OHT,V00007,' OHS_DATA_MD/20260416/LOGPRESSO_OHT_DATA_20260416.csv \
    | sort -t',' -k4 \
    | head -30 \
    | awk -F'","' '{ split($5,f,","); printf "%s | curr=%s dist=%s next=%s | rc=%s vc=%s | dest=%s\n", substr($4,1,23), f[8],f[9],f[10], f[11],f[12], f[14] }'
```

### 9.2 Dijkstra 검증
§2.4 코드 그대로 실행.

---

## 10. 참고 파일

- [OHT_DIJKSTRA_검증_계획.md](OHT_DIJKSTRA_검증_계획.md) — 본 보고서의 작성 계획
- [OHT_SPEED_JAVA_분석.md](OHT_SPEED_JAVA_분석.md) — ATLAS 속도 계산 분석
- [OHT_UDP_수집_요청.md](OHT_UDP_수집_요청.md) — UDP 캡처 비율 상향 요청
- [ALT/src/navi/DijkstraVhlRouteFind.java](ALT/src/navi/DijkstraVhlRouteFind.java)
- [ALT/src/map/edge/RailEdge.java](ALT/src/map/edge/RailEdge.java)

---

**작성일:** 2026-04-19
**검증 차량:** V00007 (3,852건 표본 중 1 mission)
**그래프:** layout_cache.json (9,402 노드)
**다음 액션:** 고객 미팅 → 라우팅 알고리즘 확정 → 이동예측 모듈 구축
