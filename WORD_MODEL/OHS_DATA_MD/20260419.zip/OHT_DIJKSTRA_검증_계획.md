# ATLAS Dijkstra 검증 — UDP 데이터 vs 코드 다각도 분석 계획

> 본 문서는 WORLD_SIM 월드모델의 이동예측 기능 구축을 위한 **사전 검증 계획**.
> 산출물은 보고서 1개. 후속으로 고객 확인 → 실제 모듈 구축 진행.

---

## Context

**왜 필요한가**:
WORLD_SIM의 진짜 가치는 "이동 예측" — 차량이 앞으로 어디로 갈지 미리 시뮬레이션.
이게 신뢰 가능하려면 **ATLAS의 라우팅 알고리즘을 정확히 복제**해야 함.

**현재 상황**:
- ATLAS Java SRC(`DijkstraVhlRouteFind.java`, `RailEdge.getCost()`)는 분석함
- 그러나 우려: **"이게 진짜 운영 코드가 아닐 수도 있다"**
- 코드 분석만으로는 부족 → **UDP 실 데이터로 다각도 검증** 필요

---

## 전체 3단계 로드맵

```
[1단계 — 지금]              [2단계 — 보고서 후]          [3단계 — 확정 후]
─────────────────         ──────────────────         ──────────────────
검증 보고서 작성     →     고객 미팅                →   진짜 최적경로 +
(이 문서의 범위)            "ATLAS 실 라우팅이           이동예측 모듈 구축
                            이 Dijkstra 맞나요?"       (월드모델 핵심 가치)
                            확정 받기
```

| 단계 | 활동 | 산출물 | 기간 |
|------|------|--------|------|
| 1단계 | 검증 보고서 작성 | `OHT_DIJKSTRA_검증.md` | ~1시간 |
| 2단계 | 고객 미팅 + 확인 | 확정된 라우팅 알고리즘 명세 | 별도 일정 |
| 3단계 | 이동예측 모듈 구현 | WORLD_SIM에 통합 | 별도 플랜 |

**1단계 산출물**: 코드 변경 없음. **보고서 MD 1개**만 생성. 한 번 만들고 끝.
**1단계 목적**: 2단계(고객 확인) 의 인풋 자료. 3단계(이동예측 구축)의 사양서 초안.

---

## 검증 4단계 + 결론 도출 방법

### Step 1 — UDP 실 경로 재구성 (5~10분)
**입력**: `OHS_DATA_MD/20260416/LOGPRESSO_OHT_DATA_20260416.csv`
**작업**:
- 차량 3~5대 선정 (예: V00100, V00115, V00953 + 활동 많은 2대 추가)
- 각 차량의 시간순 UDP 시퀀스에서 `(currentNode → nextNode)` 추출
- 노드 시퀀스로 변환: `[A1 → A2 → ... → An]`

**한계 의식**: UDP가 sparse(분당 1건)라 일부 edge 누락. **연속된 시퀀스만** 선별해서 분석.

**도구**: bash `grep + awk`만 사용 (코드 짜지 않음)

### Step 2 — 우리 그래프에서 Dijkstra 직접 계산 (10~15분)
**입력**: `OHT_MAP/layout_cache.json` (`adj`, `edges`)
**작업**:
- Step 1에서 추출한 차량들의 (출발 → 도착) 쌍에 대해
- 우리가 직접 Dijkstra 돌려서 최단 경로 산출
- cost = `length_dm / velocity_estimate × 60` (또는 단순 length)

**기존 자산 활용**:
- `WORLD_SIM/velocity_tracker.py:_shortest_path_length()` BFS 코드 → Dijkstra로 한 번만 변환 (한 회용 파이썬 한 줄, 보고서용)
- `WORLD_SIM/data_loader.py` LayoutData 로더 (이미 그래프 로드)

### Step 3 — UDP 실경로 vs 우리 Dijkstra 비교 (5분)
**비교 항목**:
| 지표 | 의미 |
|------|------|
| 노드 일치율 | UDP 실 경로의 노드들이 Dijkstra 결과에 모두 포함되는가 |
| 길이 일치율 | UDP 실 경로 총 거리 ≈ Dijkstra 최단 거리? |
| 분기점 일치 | 갈림길에서 UDP가 선택한 방향 = Dijkstra 선택? |

**케이스별 판정**:
- ✅ 100% 일치 → ATLAS = 우리 Dijkstra → 그대로 채용
- ⚠️ 70~99% 일치 → Dijkstra 기반이지만 보정 항 존재 (차량 밀집, zone 가득 등)
- ❌ 50% 미만 → 다른 알고리즘 (A*, 휴리스틱 등) 의심

### Step 4 — 차이 원인 추론 + 가설 검증 (10분)
**Step 3에서 차이 발견 시**:
1. **같은 src→dst 다른 차량**: 동일 경로? (결정론) vs 다른 경로? (동적/랜덤)
2. **차량 밀집 시 우회 여부**: 인기 edge 회피? → ATLAS의 `vhlCountCost` 가중치 일치
3. **carrierId 패턴**: 적재 차량(TPDD/6PDM)과 빈 차량 경로 다름?
4. **Zone 회피**: 가득 찬 HID Zone 우회?

**가능한 가설 (코드 검증 결과 반영)**:
- H1: 순수 Dijkstra (cost = length/velocity)
- H2: Dijkstra + 차량수 가중치 (`getVhlCountCost`: +차량수×3000ms)
- H3: A* (heuristic = Euclidean)
- H4: 동적 재라우팅 (매 frame마다 재계산)

### 결론 형식
보고서 마지막에 **"WORLD_SIM 월드모델에 이동예측 넣을 때 어떤 공식 채택할지"** 권고 + 신뢰도 등급(A/B/C).

---

## 보고서 구조 (`OHT_DIJKSTRA_검증.md`)

1. **Context** — 왜 검증 필요 (월드모델 신뢰성)
2. **방법론** — 4단계 + UDP 한계 명시
3. **Step 1 결과** — 차량 3~5대 실 경로 표
4. **Step 2 결과** — 우리 Dijkstra 결과 표
5. **Step 3 비교** — 일치/불일치 시각적 표
6. **Step 4 차이 원인 분석** — 가설 매트릭스
7. **결론** — 채택할 공식 + 신뢰도 등급 (A/B/C)
8. **후속 작업** — 월드모델 이동예측 적용 방향

---

## 핵심 파일 (read-only로 참조)

| 파일 | 역할 |
|------|------|
| `OHS_DATA_MD/20260416/LOGPRESSO_OHT_DATA_20260416.csv` | 실 UDP raw |
| `OHT_MAP/layout_cache.json` | 그래프 (`adj`, `edges`) |
| `ALT/src/navi/DijkstraVhlRouteFind.java` | ATLAS Dijkstra 코드 (참고) |
| `ALT/src/map/edge/RailEdge.java` | `getCost()`, `getVhlCountCost()` |
| `ALT/src/process/OhtMsgWorkerRunnable.java:822,839` | Dijkstra 호출 지점 |
| `WORLD_SIM/velocity_tracker.py` | BFS 코드 재사용 가능 |

---

## 시간 추정

| 단계 | 소요 |
|------|------|
| Step 1 (UDP 추출) | 5~10분 |
| Step 2 (Dijkstra 계산) | 10~15분 |
| Step 3 (비교) | 5분 |
| Step 4 (가설 검증) | 10분 |
| 보고서 작성 | 10~15분 |
| **합계** | **~45분 ~ 1시간** |

코드는 **임시 일회용** 으로 한두 줄 사용 가능 (보고서 산출용). 영구 모듈 추가 X.

---

## 검증 방법 (보고서 결과물 신뢰도 확인)

- Step 1 결과: bash 명령 결과를 보고서에 그대로 인용 (재현 가능)
- Step 2 결과: 사용한 Dijkstra 한두 줄 코드 보고서에 첨부
- Step 3 비교: 각 차량 케이스별로 표 형태 비교
- 보고서 결론: 가능한 alternative 가설들도 같이 명시 (열린 결론)

후속 적용 시점에 **이 보고서 → 월드모델 이동예측 모듈 설계 인풋**으로 사용.

---

**작성일:** 2026-04-19
**다음 액션:** 1단계 검증 작업 시작 → 보고서 산출 → 고객 미팅 일정 잡기
