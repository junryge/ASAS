# OHT 속도 계산 — Java SRC 기반 분석

> **결론: OHT 속도는 구할 수 있다. Java SRC(ALT/src) 안에 이미 구현되어 있다.**

---

## 1. 한 줄 요약

UDP 메시지의 `(CurrentAddress, Distance, NextAddress)` + 수신시각으로 속도 계산이 가능하며, ATLAS Java 코드는 **edge 전환 시점에 평균 속도(m/min)를 계산하여 RailEdge에 EMA 갱신**한다.

---

## 2. UDP 메시지 구조

### 2.1 raw 예시
```
2,OHT,V00953,1,0,0000,1,4397,0,4399,2,1,,17634,00000000,0000,,,0,101,0
```

### 2.2 속도 계산에 쓰는 필드

| idx | 필드 | 예시값 | 비고 |
|-----|------|--------|------|
| 0 | messageId | `2` | VHL_STATE_REPORT |
| 2 | vid | `V00953` | 차량 ID |
| **7** | **CurrentAddress** | **4397** | 현재 노드 |
| **8** | **Distance** | **0~21** | **dm(100mm) 단위, 14=1.4m** |
| **9** | **NextAddress** | **4399** | 다음 노드 |
| — | 수신시각 | `2026-04-17 06:59:59.992+0900` | CSV `_time`, ms 정밀도 |

> ⚠️ 기존 `OHT_SPEED_CALCULATION.md`는 fields[18]을 "Priority"로 표기했지만, 실 UDP 표본의 fields[18] 분포는 `{0, 50, 80, 101}`로 priority 같지 않음. 명세 재확인 필요.

### 2.3 단위 정정 (가장 중요)

| 위치 | 원본 단위 | 환산 |
|------|----------|------|
| UDP wire fields[8] | **dm (100mm)** | 14 → 1.4m |
| Java 내부 distance | mm | wire값 × 100 ([OhtMsgWorkerRunnable.java:168-171](ALT/src/process/OhtMsgWorkerRunnable.java#L168)) |
| `RailEdge.length` | mm | `layout_cache.json`도 100mm 단위로 저장 (예: 949 = 94.9m) |
| 최종 속도 | **m/min** | `mm / ms × 60` |

근거: [OHT_위치계산_가이드.md:223](OHT_MAP/OHT_위치계산_가이드.md) — `Distance: 14 = 1.4m, 100mm 단위` 명시.

---

## 3. Java SRC 속도 계산 흐름

### 3.1 진입 → 파싱 → 속도 산출 → EMA

```
[OhtMsgWorkerRunnable.run()]               ← UDP 수신
        │
        ▼
[_processOhtReport(tokens)]                ← messageId=2 분기
        │
        ▼
[_processVhlStateReport()]                 ← 필드 파싱 (line 144-228)
   distance = tokens[8] * 100  (mm)
   vehicle.copyCurrentVhlUdpStateToLast()  ← 직전 상태 보존
        │
        ▼
[_buildRailVelocity(vehicle, railEdge)]    ← 속도 계산 트리거 (line 223)
        │
        ▼
[_setRailEdgeVelocity()]                   ← line 789-857
   ┌─────────────────────────────┐
   │ if (edge 전환됨)             │ ← Case B
   │   speed = ran_dist/elapsed*60│
   │   railEdge.addVelocity(speed)│
   │ else                         │ ← Case A (의도적 스킵)
   │   시각/거리를 직전 값으로 복원│
   └─────────────────────────────┘
        │
        ▼
[RailEdge.addVelocity(speed)]              ← EMA 갱신 (line 286-306)
   v = v*W + sample*(1-W)
```

### 3.2 핵심 코드 — Case B (edge 전환 시 속도 계산)

[ALT/src/process/OhtMsgWorkerRunnable.java:796-806](ALT/src/process/OhtMsgWorkerRunnable.java#L796)
```java
if (lastRailEdge.getToNodeId().equals(railEdge.getFromNodeId())) {
    if (this._checkVehicleMovement(vehicle)) {
        double ran_distance = lastRailEdge.getLength()
                            - vehicle.getLastUdpState().distance
                            + vehicle.getDistance();              // mm
        long elapsed = vehicle.getReceivedTime()
                     - vehicle.getLastUdpState().receivedTime;     // ms
        double speed = ran_distance / (double)elapsed * 60.0;      // m/min
        lastRailEdge.addVelocity(speed);
    }
}
```

**산식**: `mm / ms × 60 = m/min`. 결과 단위는 **m/min**이며 `× 60000`이 아님.

### 3.3 Case A — 같은 edge 안 (의도적 미계산)

[ALT/src/process/OhtMsgWorkerRunnable.java:848-856](ALT/src/process/OhtMsgWorkerRunnable.java#L848)
```java
} else {
    if (this._checkVehicleMovement(vehicle)) {
        // 속도 계산시 이동 하지 않은 vehicle 에 대해 추후 이동시 실제 속도를 반영 하기 위함.
        vehicle.setReceivedTime(vehicle.getLastUdpState().receivedTime);
        vehicle.setDistance(vehicle.getLastUdpState().distance);
    }
    railEdge.addVhlId(vehicleId);
}
```

같은 edge 안에서는 속도를 갱신하지 않고, 시각/거리를 직전 값으로 되돌려두어 **edge 전환 순간에 "전체 구간"의 평균 속도**가 한꺼번에 반영되도록 한다.

### 3.4 EMA 갱신

[ALT/src/map/edge/RailEdge.java:286-306](ALT/src/map/edge/RailEdge.java#L286)
```java
public void addVelocity(double velocity) {
    if (Double.isNaN(velocity) || Double.isInfinite(velocity)) return;

    if (velocity < 1.5) velocity = 1.5;                            // 하한 클램핑
    else if (getMaxVelocity() < velocity) velocity = getMaxVelocity(); // 상한 클램핑

    setLastVelocity(this.velocity);

    if (hisCnt > 0) {
        double w = PredictionPara.getInstance().getLastHisWeight();
        this.velocity = this.velocity * w + velocity * (1.0 - w);  // EMA
    } else {
        this.velocity = velocity;                                  // 첫 샘플
    }
    this.changedVelocity = true;
}
```

- **W (lastHisWeight)**: [PredictionPara.java:13](ALT/src/data/PredictionPara.java#L13) 기본 `0.6`, [PredictionPara.java:96](ALT/src/data/PredictionPara.java#L96) 리프레시 시 `0.9`로 갱신 가능.
- **하한 1.5 / 상한 maxVelocity** 클램핑.
- 결과는 `RailEdge.velocity` 필드에 저장 ([RailEdge.java:8](ALT/src/map/edge/RailEdge.java#L8)).

### 3.5 차량 상태 보존

[ALT/src/map/Vhl.java:417-442](ALT/src/map/Vhl.java#L417) — `VhlUdpState` 내부 클래스
- 필드: `distance(mm), receivedTime, railEdgeId, currentAddress, nextAddress, runCycle, vhlCycle, ...`
- [Vhl.java:13](ALT/src/map/Vhl.java#L13) `private VhlUdpState lastUdpState` — 직전 상태.
- 차량 맵: [DataSet.java:683](ALT/src/data/DataSet.java#L683) `getVhlMap() : ConcurrentHashMap<String, Vhl>`.

### 3.6 다운스트림 소비처

| 호출처 | file:line | 용도 |
|--------|-----------|------|
| `TrafficBatch` | [batch/TrafficBatch.java:131](ALT/src/batch/TrafficBatch.java#L131) | 시설 평균 속도 집계 |
| `RailEdge.getCost()` | [map/edge/RailEdge.java:85-91](ALT/src/map/edge/RailEdge.java#L85) | Dijkstra 라우트 비용 (m/min → ms) |
| `DataService` | refresh 시 | edge 속도 동기화 |

---

## 4. 실 UDP 데이터로 검증

### 4.1 데이터 위치
- `OHS_DATA_MD/20260416/LOGPRESSO_OHT_DATA_20260416.csv` — 1,684,140 행
- `OHS_DATA_MD/20260415/LOGPRESSO_OHT_DATA_2026041607.csv`
- `OHS_DATA_MD/20260414/OHT_20260414.csv`

CSV 컬럼: `_host, _id, _table, _time, line` (line이 raw UDP)

### 4.2 V00953 표본 검증 결과

| 검증 | 결과 | 근거 |
|------|------|------|
| fields[8] 단위 | ✅ **dm 확정** | 표본 분포 `{0,1,3,9,11,12,13,15,20,21}` — mm은 비현실적 작음, m은 비현실적 큼, dm만 합리 |
| 가이드 수치 일관성 | ✅ | 가이드 `14 = 1.4m`, `949 = 94.9m`와 일치 |
| fields[18] 정체 | ⚠️ 재확인 필요 | 분포 `{0, 50, 80, 101}` — priority 아님 |

### 4.3 단위 환산 검산

```
distance: dm 단위 (1 dm = 0.1 m)
elapsed:  s 단위

speed_mpm = (delta_dm × 0.1 [m/dm]) / elapsed_s × 60 [s/min]
          = delta_dm × 6 / elapsed_s
```

가이드 예시 0.5초당 5dm: `5 × 6 / 0.5 = 60 m/min` (= 3.6 km/h, 저속). OHT 정상 영역(100~200 m/min, 6~12 km/h)과 일관.

---

## 5. 기존 `OHT_SPEED_CALCULATION.md` 와의 차이점

| 항목 | 기존 MD | Java SRC 실제 | 정정 |
|------|---------|---------------|------|
| 결과 단위 | mm/min (§3, §4, §6) | **m/min** (§8은 맞게 적힘) | mm/min → m/min, `× 60000` → `× 60` |
| Case A 구현 | 파이썬 스케치에 포함 | **미구현** (의도적 스킵) | "Java 원본은 Case B만"이라고 명시 |
| edge 길이 키 | `(from, to)` 튜플 | `"from,to"` 문자열 | layout_cache.json은 문자열 키 |
| W 값 | 0.6 (추정) | 기본 0.6, config로 0.9 가능 | 운영값 명시 |
| fields[18] | Priority | 분포로 봤을 때 priority 아님 | 명세 재확인 |
| Distance 단위 | mm 가정 | **dm (wire), mm (Java 내부)** | wire 단위 dm 명시 |

---

## 6. 두 종류의 속도

| 종류 | 존재 여부 | 출처 |
|------|----------|------|
| **Edge 평균 속도** | ✅ Java SRC에 구현 | `RailEdge.velocity`, EMA 갱신 |
| **차량별 순간 속도** | ⚠️ 저장 안 됨 (계산 후 RailEdge로만 흘러감) | 같은 공식 재적용으로 도출 가능 |

`Vhl` 클래스에는 `currentSpeed` / `instantSpeed` 필드가 없다. 차량별 순간속도가 필요하면:

1. `VhlUdpState`에 `instantSpeed` 필드 추가 → [Vhl.java:417](ALT/src/map/Vhl.java#L417)
2. [OhtMsgWorkerRunnable.java:803](ALT/src/process/OhtMsgWorkerRunnable.java#L803) `addVelocity(speed)` 직전에:
   ```java
   vehicle.getUdpState().instantSpeed = speed;
   ```
3. `Vhl.getInstantSpeed()` 게터 추가.

> 단 ATLAS 원본은 Case A를 의도적으로 스킵했으므로 차량별 순간속도도 **edge 전환 시점에만** 갱신된다. 0.5초 단위 연속 측정이 필요하면 Case A 로직(`distance - prev_distance`)을 별도 추가 구현해야 한다.

---

## 7. 참고 파일

- [OHT_SPEED_CALCULATION.md](OHT_SPEED_CALCULATION.md) — 원본 (단위 정정 필요)
- [OHT_MAP/OHT_위치계산_가이드.md](OHT_MAP/OHT_위치계산_가이드.md) — fields[8] dm 단위 출처
- [ALT/src/process/OhtMsgWorkerRunnable.java](ALT/src/process/OhtMsgWorkerRunnable.java) — UDP 처리 + 속도 계산
- [ALT/src/map/edge/RailEdge.java](ALT/src/map/edge/RailEdge.java) — EMA 저장
- [ALT/src/map/Vhl.java](ALT/src/map/Vhl.java) — 차량 상태
- [ALT/src/data/PredictionPara.java](ALT/src/data/PredictionPara.java) — EMA 가중치 W
- [ALT/src/batch/TrafficBatch.java](ALT/src/batch/TrafficBatch.java) — edge 속도 소비
- `OHS_DATA_MD/{날짜}/LOGPRESSO_OHT_DATA_*.csv` — 실 UDP raw

---

**작성일:** 2026-04-19
**기반 검증:**
- ALT/src Java 소스 직접 읽기
- OHT_위치계산_가이드.md 단위 명세
- LOGPRESSO_OHT_DATA_20260416.csv 실 UDP 표본 (V00953 20행)
