# OHT 속도 작업 계획 — 단기/중기/장기

> **속도는 핵심 지표.** 데드락 전조 감지, 병목 식별, 가동률 분석의 기반.
> 본 문서는 데이터 sparse 문제로 인한 속도 측정 한계와 해결 로드맵을 정리.

---

## 0. 현재 상태 (2026-04-19)

- ✅ 속도 계산 로직 구현 완료 ([velocity_tracker.py](WORLD_SIM/velocity_tracker.py))
- ✅ Case A (같은 edge), Case B (edge 전환), Case C (불연속 BFS 추정) 모두 처리
- ✅ 대시보드 OHT 사이드바에 차량별 속도 표시
- ✅ 색상 구분: 🔴 0(정지) / 🟡 저속 / 🟢 정상 / ⚪ 측정 불가
- ⚠️ **한계**: UDP 로그가 sparse(분당 1건/차량)해서 측정 불가 비율 높음

---

## 1. 진단

### 1.1 데이터 sparsity 측정
| 항목 | 측정값 |
|------|--------|
| 정상 OHT UDP cadence | 0.5초 간격 (예상) |
| 16일 raw 로그 평균 | **분당 1건/차량** |
| 손실 비율 | **약 99% (정상의 1/100)** |
| 차량당 일평균 메시지 | ~1,400건 (정상은 ~172,800건) |

### 1.2 결과
- 같은 차량 두 메시지 사이 갭이 10~90초 → 그동안 차량은 여러 edge 통과
- → **불연속 비율 88% (V00100 25개 메시지 표본 기준)**
- → 트래커가 "산정 불가" 판정 → 0 또는 `-` 표시 다수

### 1.3 핵심 통찰
> **UDP 시스템은 정상. 문제는 로그 캡처가 샘플링됨.**
> ATLAS 운영 환경에서는 0.5초 cadence로 잘 들어오므로 같은 트래커가 잘 작동할 것.

---

## 2. 단기 — 코드만으로 가능 (✅ 구현 완료)

### 2.1 옵션 A: BFS 경로 추정
**위치**: [velocity_tracker.py:_shortest_path_length()](WORLD_SIM/velocity_tracker.py)

불연속 발생 시 `prev.next` 노드 → `curr.curr` 노드까지 layout 그래프에서 BFS 최단경로 길이를 계산해 `ran_distance`에 더함.

```python
# Case C 처리
path_len = self._shortest_path_length(prev.edge[1], edge[0])
if path_len is None:
    return cached  # 경로 없음 → 측정 불가
delta_dm = (prev_len - prev.distance) + path_len + distance
```

**제약**:
- BFS 탐색 한도: 20 hops
- 갭 30초 이내만 적용 (그 이상은 평균 속도가 무의미)
- 결과 캐시 (같은 노드쌍 반복 조회 가속)

**효과**: 0 비율 30~50% 감소 예상 (완전 해결은 아님)

### 2.2 옵션 B: UI 정직화
**위치**: [world_model.py:215](WORLD_SIM/world_model.py:215), [dashboard.html:984](WORLD_SIM/dashboard.html:984)

- 첫 측정 전 = `velocity = None` (가짜 값 안 만듦)
- API 응답에서 `null` 전송
- 대시보드: `- (측정 불가)` 회색 표시
- 측정된 차량은 캐시값 유지 (재측정될 때까지)

**효과**: 빈칸 많아 보여도 거짓말 안 함. 진짜 정지(0)와 측정 불가(`-`) 구분 가능.

---

## 3. 중기 — 운영팀과 협의 필요 (🟡 미진행)

### 3.1 Logpresso 캡처 비율 상향
- **현재**: 약 1% 만 저장 (추정)
- **목표**: 10% 또는 100%
- **트레이드오프**: 저장 비용 ↑, 분석 정확도 ↑↑↑
- **확인 필요**:
  - 현재 샘플링 정책 (rate-limited, event-based, time-windowed?)
  - 단기 1일치라도 전체 캡처 가능한지
  - 비용 추산

### 3.2 어떻게 요청할 것인가
> "OHT 데드락 전조 분석을 위해 차량별 속도 시계열이 필요합니다.
> 현재 LOGPRESSO_OHT_DATA 가 약 1% 샘플링 같은데, 일부 시간대(예: 피크 1시간) 만이라도 100% 캡처 가능할까요?"

---

## 4. 장기 — 구조 변경 (🔴 미진행)

### 4.1 실시간 UDP 직접 수신
- **방식**: WORLD_SIM이 ATLAS UDP 포트에 listen
- **효과**:
  - 로그 의존 X
  - 0.5초 cadence 그대로 받음
  - 진짜 실시간 운영 시뮬레이션 가능
- **필요 작업**:
  - UDP listener 모듈 추가 (Python `socket`)
  - 실시간 수신 큐 + 트래커 통합
  - 운영 네트워크에 read-only 접근 권한 협의
- **위험**:
  - 운영 네트워크 접근 보안 검토
  - 복제 트래픽이 운영에 영향 안 주도록 설계

---

## 5. 우선순위 권장

| 단계 | 누가 | 언제 | 효과 |
|------|------|------|------|
| 1 | **단기 A+B (✅ 완료)** | 지금 | 0 비율 감소 + 정직한 UI |
| 2 | **중기 — 운영팀 요청** | 이번 주 | 데이터 품질 근본 개선 |
| 3 | **장기 — 실시간 수신** | 1~2개월 | 진짜 운영 시뮬레이터 |

---

## 6. 속도가 왜 핵심인가

| 활용 영역 | 속도 데이터로 가능한 것 |
|----------|----------------------|
| 데드락 전조 | 연쇄 속도 하락 패턴 감지 |
| 병목 식별 | edge별 평균 속도 → 만성 저속 구간 |
| 가동률 정확화 | velocity=0 지속시간 = 진짜 멈춤 시간 |
| TAT 예측 정확도 | 평균 속도 × 경로 길이 = 예상 TAT |
| OHT 거동 추적 | 개별 차량 시계열 → 이상 차량 조기 발견 |

→ 속도 측정 정확도 = WORLD_SIM 분석 신뢰도의 상한

---

## 7. 관련 파일

| 파일 | 역할 |
|------|------|
| [WORLD_SIM/velocity_tracker.py](WORLD_SIM/velocity_tracker.py) | 차량별 속도 트래커 (Case A/B/C, BFS, 캐시) |
| [WORLD_SIM/world_model.py](WORLD_SIM/world_model.py) | tracker 인스턴스 + 차량별 velocity 필드 |
| [WORLD_SIM/replay_engine.py](WORLD_SIM/replay_engine.py) | 프레임 로드 시 frame_time 전달 |
| [WORLD_SIM/data_loader.py](WORLD_SIM/data_loader.py) | UDP 메시지 dict에 `_time` 보존 |
| [WORLD_SIM/dashboard.html](WORLD_SIM/dashboard.html) | OHT 사이드바 속도 표시 (색상 + null 처리) |
| [OHT_SPEED_JAVA_분석.md](OHT_SPEED_JAVA_분석.md) | ATLAS Java 속도 계산 원리 분석 |

---

**작성일:** 2026-04-19
**다음 점검:** 운영팀 응답 후 / 실시간 수신 검토 시
