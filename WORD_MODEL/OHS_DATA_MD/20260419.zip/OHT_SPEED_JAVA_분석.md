# OHT 속도 계산 분석 — UDP 데이터 + Java SRC 기반

> 목적: 실제 UDP 데이터(`OHS_DATA_MD/`) 와 Java 소스(`ALT/src/`) 를 직접 분석하여 OHT 차량의 속도를 어떻게 계산하는지 처음부터 끝까지 정리.

---

## 0. 결론

**OHT 속도는 UDP 메시지로 계산할 수 있다.**

- UDP는 **속도 필드를 직접 전송하지 않는다**. 대신 위치(`CurrentAddress`, `Distance`, `NextAddress`)와 수신시각이 주기적으로 들어온다.
- ATLAS Java 코드는 이 값으로 **edge 전환 시점에 평균 속도(m/min)를 계산**하고, RailEdge 객체에 EMA로 누적한다.
- 같은 edge 안에서의 순간 속도(Case A)는 ATLAS가 **의도적으로 계산을 보류**하지만, UDP 데이터 자체로는 계산 가능하다 (실 데이터로 확인됨).

---

## 1. UDP 메시지 구조

### 1.1 raw 한 줄 (V00100, 2026-04-16 07:00:21.717)

```
2,OHT,V00100,6,0,0000,1,5344,1,5345,3,2,,6850,00000000,0000,4KDS3002_1,4ANS6702A_IN04,50,0,0
```

### 1.2 21개 필드 정리 (관찰 기반)

| idx | 의미 (확정) | 예시값 | 비고 |
|-----|------------|--------|------|
| 0 | messageId | `2` | `2`=VHL_STATE_REPORT |
| 1 | msgType | `OHT` | 고정 |
| 2 | **vid** | `V00100` | 차량 ID |
| 3 | state | `1`, `6` | 1=RUN, 6=OBS_BZ_STOP, 7=JAM 등 |
| 4 | (carrier 적재?) | `0`, `1` | 1일 때 carrierId가 비어 있지 않음 |
| 5 | reserved | `0000` | 모든 표본 동일 |
| 6 | reserved | `1` | 모든 표본 동일 |
| 7 | **CurrentAddress** | `5344` | 현재 노드 ID |
| 8 | **Distance** | `0~30` | **dm(100mm) 단위** — 14 = 1.4m |
| 9 | **NextAddress** | `5345` | 다음 노드 ID |
| 10 | runCycle | `0`,`2`,`3`,`4` | 운행 사이클 |
| 11 | vhlCycle | `1`,`2`,`3`,`4`,`5` | 차량 사이클 |
| 12 | carrierId | empty 또는 `TPDD0256` 등 | 적재 화물 ID |
| 13 | destination | `6850`, `13908` 등 | 목적 노드 |
| 14 | reserved | `00000000` | 모든 표본 동일 |
| 15 | reserved | `0000` | 모든 표본 동일 |
| 16 | sourcePort | `4KDS3002_1` 등 | 출발 포트 이름 |
| 17 | destPort | `4ANS6702A_IN04` 등 | 도착 포트 이름 |
| 18 | speedProfile? | `0`, `50`, `80`, `101` | 작은 정수가 아니라 **속도 프로파일** 추정 |
| 19 | ? | `0`, `1`, `101` | 미확정 |
| 20 | ? | `0`, `615`, `6689` | 미확정 |

### 1.3 fields[18]에 대한 관찰
- 표본 분포: `{0, 50, 80, 101}`. priority라면 `1~10` 범위였을 텐데 그렇지 않음.
- `state=1, vhlCycle=4` (운반 중) 일 때 주로 `50` 또는 `80`.
- 화물 운반 중(carrierId 있음)일 때 `80`이 자주 보이고, 빈차일 때 `50`.
- **추정**: 노선/임무별 "속도 프로파일" 또는 "상한 속도 설정". 명세 확인 권장.

> 주의: 속도 계산에는 fields[18]이 필요 없다. 위치 변화로만 계산된다.

### 1.4 timestamp
- CSV `_time` 컬럼. 형식 `2026-04-17 06:59:59.992+0900` (ms 정밀도).
- Java는 `vehicle.getReceivedTime()` 으로 epoch ms 보관 ([OhtMsgWorkerRunnable.java:144-228](ALT/src/process/OhtMsgWorkerRunnable.java#L144)).

---

## 2. 단위 체계

가장 혼동되는 부분이라 명확히 정리.

| 위치 | 단위 | 환산 |
|------|------|------|
| UDP wire fields[8] | **dm (= 100mm = 0.1m)** | `14` → `1.4 m` |
| Java 내부 `vehicle.distance` | **mm** | wire값 × 100 |
| `RailEdge.length` | **mm** | layout 데이터에 mm로 저장 |
| `addVelocity()` 입력 | **m/min** | 산식: `mm / ms × 60` |
| `RailEdge.velocity` 저장값 | **m/min** | EMA 결과 |
| `getCost()` 변환 | m/min → ms | `length / (velocity × 1000 / 60 / 1000)` |

### 2.1 단위 환산 근거

[ALT/src/process/OhtMsgWorkerRunnable.java:168-171](ALT/src/process/OhtMsgWorkerRunnable.java#L168)
```java
double distance = Util.getDoubleOrZero(tokens[DISTANCE_IDX]) * 100L;
//                                                          ^^^^^ dm → mm
```

[OHT_위치계산_가이드.md:223](OHT_MAP/OHT_위치계산_가이드.md#L223)
> `[8] Distance: 14 → ★ 이동 거리 (100mm 단위, 14=1.4m)`

[OHT_위치계산_가이드.md:170](OHT_MAP/OHT_위치계산_가이드.md#L170)
> `→ 연결: [12341] (거리 949 = 94.9m)` — edge 길이도 100mm 단위로 저장

### 2.2 정상 OHT 속도 영역

- `100 ~ 200 m/min` = `6 ~ 12 km/h` (반송 중)
- `1.5 ~ 50 m/min` (저속/감속/정체 구간)
- ATLAS 클램핑 하한: **1.5 m/min** ([RailEdge.java:289](ALT/src/map/edge/RailEdge.java#L289))

---

## 3. 속도 계산 공식

### 3.0 대전제 — UDP 한 줄로는 못 구한다

UDP 한 줄은 **위치 스냅샷**일 뿐이다. 속도는 "변화량"이라 **같은 차량의 연속된 두 줄**이 필요하다.

```
한 줄  →  여기 있다 (위치만 알 수 있음)
두 줄  →  속도 계산 가능
```

### 3.1 기본 공식 (모든 경우 공통)

```
speed [m/min] = ran_distance [mm] / elapsed [ms] × 60

  ran_distance : 마지막 UDP 이후 실제 이동 거리
  elapsed      : 마지막 UDP와의 시간 차
```

### 3.2 두 가지 케이스

같은 vid의 연속 두 메시지를 비교했을 때, **edge가 같은가 / 바뀌었는가** 로 분기된다.

#### Case A — 같은 edge 안에서 이동
**판정**: 두 메시지의 `(CurrentAddress, NextAddress)` 가 같을 때.

```
ran_distance = curr_distance - prev_distance     (mm 단위)
```

**예시** (V00100 rows 7→8):
```
[줄 1] T1=07:02:56.504, curr=13112, dist=7,  next=13113
[줄 2] T2=07:02:59.878, curr=13112, dist=17, next=13113
        ↑ 같은 edge (13112→13113)

delta   = (17 - 7) dm = 10 dm = 1000 mm = 1 m
elapsed = 3.374 초
speed   = 1000 mm / 3374 ms × 60 = 17.78 m/min  ✅
```

#### Case B — Edge를 넘어갔을 때
**판정**: 이전 메시지의 `NextAddress` 와 현재 메시지의 `CurrentAddress` 가 같을 때 (= 자연스러운 edge 전환).

```
ran_distance = (이전_edge_길이 - 이전_distance) + 현재_distance
                ↑ 이전 edge에서 남은 거리        ↑ 새 edge 진입 거리
```

**예시** (가상):
```
[줄 1] T1, curr=1296, dist=20, next=1297    ← edge (1296→1297), 20dm 지점
[줄 2] T2, curr=1297, dist=5,  next=1298    ← edge (1297→1298), 5dm 지점
       ↑ 1296→1297 길이가 30dm 라고 가정

ran_distance = (30 - 20) + 5 = 15 dm = 1500 mm
elapsed      = (T2 - T1) ms
speed        = 1500 / elapsed × 60  [m/min]
```

#### 케이스 판정 표

| 직전 메시지 | 현재 메시지 | 판정 | 식 |
|------------|------------|------|-----|
| `(A, B), dist=d1` | `(A, B), dist=d2` | **Case A** | `d2 - d1` |
| `(A, B), dist=d1` | `(B, C), dist=d2` | **Case B** | `(len(A,B) - d1) + d2` |
| `(A, B)` | `(X, Y)` (불연속) | 산정 불가 | drop |

### 3.3 ATLAS Java의 선택

ATLAS는 **Case B만** 호출 ([OhtMsgWorkerRunnable.java:796-806](ALT/src/process/OhtMsgWorkerRunnable.java#L796)).

이유: edge 전환 순간에 **"전체 구간을 평균"** 으로 한 번에 잡아야 edge별 평균 속도가 안정적으로 나오기 때문. 같은 edge 안에서 잦은 갱신을 하면 EMA가 노이즈에 흔들림.

→ 차량별 순간속도가 필요하면 **Case A도 같이 계산**해야 함 (Java 원본은 안 함).

### 3.4 UDP wire 단위로 바로 쓰는 단축 공식

내부 mm 변환 없이 wire의 dm 그대로 쓸 때:

```
Case A:
  delta_dm    = curr_dist_dm - prev_dist_dm
  elapsed_sec = (curr_time - prev_time).total_seconds()
  speed_mpm   = delta_dm × 6 / elapsed_sec        ← m/min

Case B:
  delta_dm    = (prev_edge_length_dm - prev_dist_dm) + curr_dist_dm
  speed_mpm   = delta_dm × 6 / elapsed_sec        ← m/min
```

**왜 ×6?**
- dm × 0.1 [m/dm] = m
- m / s × 60 [s/min] = m/min
- → 합쳐서 ×6

**검산**: 0.5초당 5dm 이동 → `5 × 6 / 0.5 = 60 m/min` (= 3.6 km/h, 저속).
정상 운행: 0.5초당 15~17dm 이동 → `15 × 6 / 0.5 = 180 m/min` (= 10.8 km/h). ✅

### 3.5 의사코드 (그대로 구현 가능)

```python
def calc_speed(prev, curr, edge_length_dm):
    """
    prev, curr: dict with keys (time:datetime, curr_addr:int,
                                next_addr:int, dist_dm:int)
    edge_length_dm: dict {(from, to): length_dm}

    return: speed in m/min, or None if cannot compute
    """
    elapsed_sec = (curr['time'] - prev['time']).total_seconds()
    if elapsed_sec <= 0:
        return None

    prev_edge = (prev['curr_addr'], prev['next_addr'])
    curr_edge = (curr['curr_addr'], curr['next_addr'])

    if prev_edge == curr_edge:
        # Case A
        delta_dm = curr['dist_dm'] - prev['dist_dm']
    elif prev['next_addr'] == curr['curr_addr']:
        # Case B
        prev_len = edge_length_dm.get(prev_edge, 0)
        delta_dm = (prev_len - prev['dist_dm']) + curr['dist_dm']
    else:
        # 불연속 — drop
        return None

    if delta_dm < 0:
        return 0.0  # 이상치 방어 (후진/리셋)

    return delta_dm * 6.0 / elapsed_sec  # m/min
```

### 3.6 차량별 적용 절차

```
1. UDP 행을 시간순 정렬
2. vid 별로 그룹핑
3. 각 차량 그룹 내에서 (i)번 행과 (i+1)번 행을 짝지어
   calc_speed(prev=i, curr=i+1) 호출
4. 결과 시계열을 차량별로 보관
   → 0.5초~수초 간격의 속도 시계열 생성
```

---

### 3.7 실 UDP 데이터로 본 계산 예제 모음

#### 예제 ① — Case A, 가속 시작 시점 (저속)

**입력 (V00100, 실 데이터):**
```
[줄 1] 2026-04-16 07:02:56.504+0900
       2,OHT,V00100,1,1,0000,1,13112,7,13113,3,2,,35177,...

[줄 2] 2026-04-16 07:02:59.878+0900
       2,OHT,V00100,1,1,0000,1,13112,17,13113,3,2,,35177,...
```

**판정:**
- prev_edge = `(13112, 13113)`
- curr_edge = `(13112, 13113)` → 같음 → **Case A**

**계산:**
```
delta_dm    = 17 - 7 = 10 dm
elapsed_sec = 07:02:59.878 - 07:02:56.504 = 3.374 s
speed       = 10 × 6 / 3.374
            = 17.78 m/min
            = 1.07 km/h
```

**해석**: 직전 메시지에서 state=6(정지)였다가 RUN(state=1) 전환 직후. 가속 중이라 매우 느린 속도. ✅ 물리적 타당.

---

#### 예제 ② — Case A, 정상 주행 (가상)

**입력:**
```
[줄 1] 07:30:00.000, V00200, curr=2500, dist=10, next=2501
[줄 2] 07:30:00.500, V00200, curr=2500, dist=25, next=2501
```

**판정:** 같은 edge → Case A

**계산:**
```
delta_dm    = 25 - 10 = 15 dm
elapsed_sec = 0.5 s
speed       = 15 × 6 / 0.5
            = 180 m/min
            = 10.8 km/h
```

**해석**: 정상 OHT 운행 속도 (100~200 m/min 범위). ✅

---

#### 예제 ③ — Case B, edge 전환 (가상, edge 길이 30dm 가정)

**입력:**
```
[줄 1] 07:30:10.000, V00300, curr=1296, dist=20, next=1297
[줄 2] 07:30:10.800, V00300, curr=1297, dist=5,  next=1298
```

**판정:**
- prev.next_addr = 1297, curr.curr_addr = 1297 → 같음
- prev_edge ≠ curr_edge → **Case B**

**계산** (edge `(1296,1297)` 길이 = 30dm 가정):
```
ran_distance = (30 - 20) + 5 = 15 dm
elapsed_sec  = 0.8 s
speed        = 15 × 6 / 0.8
             = 112.5 m/min
             = 6.75 km/h
```

**해석**: edge 전환 직후의 평균 속도. 정상 영역. ✅

---

#### 예제 ④ — 정지 차량 (delta=0)

**입력:**
```
[줄 1] 07:35:00.000, V00400, curr=4000, dist=12, next=4001
[줄 2] 07:35:05.000, V00400, curr=4000, dist=12, next=4001
```

**판정:** 같은 edge → Case A

**계산:**
```
delta_dm = 12 - 12 = 0
speed    = 0 × 6 / 5.0 = 0 m/min
```

**해석**: 5초간 움직임 없음. 데드락 / OBS_BZ_STOP 의심 시그널.

---

#### 예제 ⑤ — 불연속 (drop)

**입력:**
```
[줄 1] 07:40:00.000, V00500, curr=5000, dist=15, next=5001
[줄 2] 07:40:30.000, V00500, curr=8000, dist=3,  next=8001
```

**판정:**
- prev_edge = (5000, 5001)
- curr_edge = (8000, 8001)
- prev.next_addr (5001) ≠ curr.curr_addr (8000) → **불연속**

**처리**: drop. 30초간 메시지 누락 또는 중간 이벤트 손실로 추정. 속도 산정 불가.

---

#### 예제 ⑥ — 사용자 질문 라인 (단일 메시지)

**입력:**
```
2,OHT,R00006,1,1,0000,1,1296,0,1297,4,4,4RPS5413,9199,...
```

**판정**: 한 줄뿐 → **계산 불가**.

이 메시지는 다음을 알려준다:
- vid: R00006
- state: 1 (RUN)
- 현재 위치: edge (1296→1297) 의 시작점 (dist=0)
- carrier: 4RPS5413 적재 중

R00006의 **다음 메시지가 들어오면** 비로소 속도 계산 가능.
가령 다음 메시지가 `... curr=1296, dist=18, next=1297, T=+1.0초` 라면:
```
delta = 18 - 0 = 18 dm
speed = 18 × 6 / 1.0 = 108 m/min  (정상 운행)
```

---

### 3.8 케이스별 결과 요약 (예제 종합)

| 예제 | 케이스 | delta_dm | elapsed | speed (m/min) | 해석 |
|------|--------|----------|---------|---------------|------|
| ① V00100 실데이터 | A | 10 | 3.374s | 17.78 | 가속 시작 |
| ② 가상 정상 주행 | A | 15 | 0.5s | 180 | 정상 운행 |
| ③ 가상 edge 전환 | B | 15 | 0.8s | 112.5 | 평균 |
| ④ 정지 | A | 0 | 5.0s | 0 | 데드락 의심 |
| ⑤ 불연속 | — | — | — | drop | 메시지 누락 |
| ⑥ R00006 단일 | — | — | — | 계산 불가 | 1줄만 있음 |

---

## 4. Java SRC 처리 흐름 (전 구간)

```
UDP 패킷 수신
   │
   ▼
OhtMsgWorkerRunnable.run()                              [line 29-39]
   │  tokens = StringUtils.splitPreserveAllTokens(message, ',')
   │  if (tokens[0] == "2") → _processOhtReport(tokens)
   ▼
_processOhtReport / _processVhlStateReport               [line 144-228]
   │  vehicle = vhlMap.get(vid)
   │  vehicle.copyCurrentVhlUdpStateToLast()  ← 직전 상태 보존
   │  distance = tokens[8] * 100L              ← dm → mm
   │  vehicle.setDistance(distance)
   │  vehicle.setReceivedTime(timestamp)
   │  ... (currentAddress, nextAddress, etc 갱신)
   │  _buildRailVelocity(vehicle, railEdge)
   ▼
_setRailEdgeVelocity()                                   [line 789-857]
   │  ┌──────────────────────────────────────┐
   │  │ if (lastRailEdge.toNode == railEdge.fromNode)  ← Case B (edge 전환)
   │  │   ran_distance = lastRailEdge.length
   │  │                - lastUdpState.distance
   │  │                + vehicle.distance
   │  │   elapsed     = receivedTime - lastUdpState.receivedTime
   │  │   speed       = ran_distance / elapsed × 60  → m/min
   │  │   lastRailEdge.addVelocity(speed)
   │  │   lastRailEdge.addHistory()
   │  │ else                                          ← Case A (같은 edge)
   │  │   // 의도적 스킵
   │  │   vehicle.setReceivedTime(lastUdpState.receivedTime)
   │  │   vehicle.setDistance(lastUdpState.distance)
   │  └──────────────────────────────────────┘
   ▼
RailEdge.addVelocity(double velocity)                    [line 286-306]
   │  if (NaN || Inf) return
   │  velocity = clamp(velocity, 1.5, getMaxVelocity())
   │  setLastVelocity(this.velocity)
   │  if (hisCnt > 0)
   │    this.velocity = this.velocity × W + velocity × (1 - W)   ← EMA
   │  else
   │    this.velocity = velocity                                  ← 첫 샘플
   │  changedVelocity = true
   ▼
다운스트림 사용:
   - TrafficBatch.collect()                              ← 시설 평균
   - RailEdge.getCost(carrierId)                         ← Dijkstra
   - DataService.refresh()                               ← 동기화
```

### 4.1 Case A를 의도적으로 스킵하는 이유

[OhtMsgWorkerRunnable.java:848-856](ALT/src/process/OhtMsgWorkerRunnable.java#L848) 주석:
> `// 속도 계산시 이동 하지 않은 vehicle 에 대해 추후 이동시 실제 속도를 반영 하기 위함.`

```java
} else {
    if (this._checkVehicleMovement(vehicle)) {
        vehicle.setReceivedTime(vehicle.getLastUdpState().receivedTime);
        vehicle.setDistance(vehicle.getLastUdpState().distance);
    }
    railEdge.addVhlId(vehicleId);
}
```

**의미**: 같은 edge 안에서는 시각/거리를 직전 값으로 되돌려놓음. 그 후 다음 UDP에서 edge가 바뀌면 "이전→이번 사이의 누적 거리/누적 시간"이 한꺼번에 잡혀 결과적으로 **edge 평균 속도**가 산출된다. ATLAS의 설계 철학은 **차량별 순간속도가 아닌 edge별 평균속도**.

### 4.2 EMA 가중치 W

[ALT/src/data/PredictionPara.java:13](ALT/src/data/PredictionPara.java#L13)
```java
private double lastHisWeight = 0.6;       // 기본값
```

[PredictionPara.java:96](ALT/src/data/PredictionPara.java#L96) — config refresh 시 0.9로 갱신될 수 있음.

```
new_velocity = old_velocity × W + sample × (1 - W)
```

- `W = 0.6` → 새 샘플 40% 반영 (반응 빠름)
- `W = 0.9` → 새 샘플 10% 반영 (안정적이지만 변화 느림)
- 첫 관측(`hisCnt == 0`) 일 때는 W 무시, 샘플 그대로 사용

### 4.3 클램핑

[RailEdge.java:289-290](ALT/src/map/edge/RailEdge.java#L289)
```java
if (velocity < 1.5) velocity = 1.5;
else if (getMaxVelocity() < velocity) velocity = getMaxVelocity();
```

- **하한 1.5 m/min**: 사실상 정지 시에도 비-0 값 유지 (Dijkstra `getCost()`에서 0으로 나누는 것 방지).
- **상한 maxVelocity**: edge별 Free Flow Speed. 맵 초기화 시 설정.

---

## 5. 차량 상태 객체 (Vhl)

### 5.1 VhlUdpState 내부 클래스
[ALT/src/map/Vhl.java:417-442](ALT/src/map/Vhl.java#L417)

```java
public static class VhlUdpState implements Cloneable {
    public double distance;          // mm 단위
    public long receivedTime;        // epoch ms
    public String railEdgeId;        // 현재 edge ID
    public int currentAddress;
    public int nextAddress;
    public RUN_CYCLE runCycle;
    public VHL_CYCLE vhlCycle;
    // ... 17+ 필드
}
```

### 5.2 직전 상태 보존
[Vhl.java:13](ALT/src/map/Vhl.java#L13)
```java
private VhlUdpState lastUdpState;
```

매 UDP 처리 직전에 `copyCurrentVhlUdpStateToLast()` 호출 → 현재 상태가 last로, 새 값이 current로 들어감.

### 5.3 차량 맵
[ALT/src/data/DataSet.java:683](ALT/src/data/DataSet.java#L683)
```java
ConcurrentHashMap<String, Vhl> vhlMap;
```

키 형식: `{fabId}:{VHL_PREFIX}:{mcpName}:{vhlName}` (예: `M14A:VHL:MCP01:V00100`).

### 5.4 ⚠️ 차량별 순간속도 필드는 없음

`Vhl` 클래스에는 `currentSpeed`, `instantSpeed`, `getVelocity()` 같은 필드/메서드가 **존재하지 않는다**. 속도는 계산 직후 `RailEdge.addVelocity()`로 흘러가서 edge 객체에만 저장된다.

차량별 순간속도가 필요하면 다음 3가지를 추가해야 한다:
1. `VhlUdpState`에 `instantSpeed` 필드 추가
2. [OhtMsgWorkerRunnable.java:803](ALT/src/process/OhtMsgWorkerRunnable.java#L803) `addVelocity(speed)` 직전에 `vehicle.getUdpState().instantSpeed = speed;`
3. `Vhl.getInstantSpeed()` 게터 추가

---

## 6. 실 UDP 데이터로 검증 — V00100 사례

### 6.1 데이터 위치
- `OHS_DATA_MD/20260416/LOGPRESSO_OHT_DATA_20260416.csv`
- 전체 행: **1,684,140**
- VHL_STATE_REPORT (msgId=2) 행: **1,397,815**
- V00100 차량의 표본 (07:00 ~ 07:35)을 시간순으로 추출하여 분석

### 6.2 시퀀스 발췌

| # | 시각 | state | curr | dist | next | f18 | 비고 |
|---|------|-------|------|------|------|-----|------|
| 1 | 07:00:21.717 | 6 | 5344 | 1 | 5345 | 50 | OBS_BZ_STOP |
| 2 | 07:00:30.912 | 1 | 5358 | 1 | 5363 | 50 | edge 전환 |
| 3 | 07:00:41.040 | 1 | 5366 | 14 | 5367 | 50 | edge 전환 |
| 4 | 07:01:00.593 | 1 | 5331 | 1 | 5332 | 50 | edge 전환 + carrier 적재 |
| 5 | 07:02:31.075 | 6 | 13108 | 4 | 13109 | 50 | STOP |
| 6 | 07:02:48.063 | 6 | 13112 | 7 | 13113 | 50 | STOP |
| **7** | **07:02:56.504** | **1** | **13112** | **7** | **13113** | **50** | **RUN 시작 (같은 edge)** |
| **8** | **07:02:59.878** | **1** | **13112** | **17** | **13113** | **50** | **★ Case A 직접 관측** |
| 9 | 07:04:50.221 | 1 | 12640 | 26 | 12545 | 80 | edge 전환 (고속 모드 80) |

### 6.3 ★ Case A 직접 계산 (rows 7→8)

같은 edge `(13112, 13113)` 안에서 두 번 연속 관측됨:

```
delta_dist = (17 - 7) dm = 10 dm = 1 m
elapsed    = 07:02:59.878 - 07:02:56.504 = 3.374 초
speed      = 10 × 6 / 3.374 = 17.78 m/min  (= 1.07 km/h)
```

**해석**: 직전(row 6)에 state=6 (정지)였다가 row 7에서 state=1 (RUN)으로 전환된 직후. 가속 중이라 정상 주행 속도(100~200 m/min)보다 매우 낮음 → 물리적으로 타당. 이 사례 하나만으로 Case A 공식이 유효하게 동작함이 입증됨.

### 6.4 표본 통계
- V00100, 07:00~07:35 (35분) 동안 28개 메시지 수신.
- 그중 **같은 edge 연속 (Case A 가능)**: 1쌍 (rows 7→8)
- 나머지는 모두 edge 전환 또는 시간 간격이 큼 → ATLAS는 edge 전환 시 위주로 보고 받는다는 가설 일치.
- distance 값 분포: `{0, 1, 4, 7, 13, 14, 17, 20, 26, 27}` 등 모두 0~30 dm 범위 → **dm 단위 확정**.

### 6.5 Case B 계산 예 (rows 7→9 가상 적용)
이전 edge `(13112, 13113)` 의 길이를 가정 (예: 30 dm = 3 m라 치면):

```
ran_dist = (30 - 7) + 26 = 49 dm = 4.9 m
elapsed  = 07:04:50.221 - 07:02:56.504 = 113.717 초
speed    = 49 × 6 / 113.717 = 2.59 m/min
```

(실제 길이는 `layout_cache.json` 의 `(13112,13113)` 또는 `RailEdge.length` 조회 필요. 위 수치는 공식 시연용.)

---

## 7. 두 종류의 "OHT 속도"

| 구분 | 어디서 | 단위 | 출처 |
|------|--------|------|------|
| **차량별 순간 속도** | (Java에 저장 안 됨) | m/min | UDP 위치 변화로 직접 계산 |
| **Edge별 평균 속도** | `RailEdge.velocity` 필드 | m/min | `addVelocity()` EMA |

**용도 차이**:
- **차량별 순간 속도** → 개별 OHT 거동 추적, 비정상 감속 감지, 데드락 전조 시그널, 0속도 지속시간 측정
- **Edge별 평균 속도** → 라우트 비용 계산(Dijkstra), 병목 구간 식별, 시설 단위 평균 속도 보고

ATLAS는 후자만 갖고 있다. 전자가 필요하면 §5.4의 3줄 추가로 노출 가능.

---

## 8. 다운스트림 — 누가 속도를 사용하는가

| 호출처 | 위치 | 용도 |
|--------|------|------|
| `RailEdge.getCost(carrierId)` | [RailEdge.java:85-91](ALT/src/map/edge/RailEdge.java#L85) | Dijkstra 라우트 비용 (m/min → 통과 ms) |
| `TrafficBatch` | [batch/TrafficBatch.java:131](ALT/src/batch/TrafficBatch.java#L131) | 시설 단위 평균 속도 집계 |
| `DataService.refresh()` | DataService | edge 속도 동기화 (백업/복원) |

`getCost()`의 변환:
```java
public long getCost(String carrierId) {
    if (velocity <= 0) velocity = 1;
    return (long)(length / (velocity * 1000 / 60 / 1000));
    //              mm   /  (m/min × m→mm × min→s × s→ms)
    //                                                      → ms
}
```

---

## 9. 한계와 보완점

### 9.1 한계
1. **차량별 순간속도 미저장** — `Vhl`에 필드가 없어 다운스트림에서 직접 못 씀.
2. **Case A 미산출** — 같은 edge 안 0.5초 단위 속도가 필요한 분석(저속 감지 등)에는 직접 구현해야 함.
3. **첫 메시지는 항상 None** — 비교 대상 직전 상태가 없음.
4. **Edge 전환 미탐지 케이스** — `lastRailEdge.toNode != railEdge.fromNode` 인 비연속 전환(원격 jump 등)은 Case B로 처리 안 됨.

### 9.2 보완 방향
1. **VhlUdpState에 `instantSpeed` 추가** (§5.4) — Java SRC 측에서 차량별 속도 노출.
2. **Case A 활성화** — 같은 edge 분기에서도 `addVelocity(speed)` 호출하면 더 조밀한 EMA 가능. 단 ATLAS의 설계 철학을 깨므로 별도 `addInstantVelocity()` 신설 권장.
3. **이상치 방어** — 음수 delta, elapsed=0, 비정상적 큰 delta(노이즈) 처리.

---

## 10. 한 줄 요약

> **UDP에 속도 필드는 없지만, `(CurrentAddress, Distance, NextAddress)` 와 수신시각의 차분으로 계산 가능. ATLAS Java는 edge 전환 시점에 `mm/ms × 60 = m/min` 공식으로 산출 후 `RailEdge.velocity` 에 EMA 누적. distance는 wire에서 dm, 내부에서 mm. 차량별 순간속도는 SRC에 미저장.**

---

## 11. 참고 파일

### Java SRC
- [ALT/src/process/OhtMsgWorkerRunnable.java](ALT/src/process/OhtMsgWorkerRunnable.java) — UDP 처리, 속도 계산
- [ALT/src/map/edge/RailEdge.java](ALT/src/map/edge/RailEdge.java) — EMA 저장
- [ALT/src/map/Vhl.java](ALT/src/map/Vhl.java) — 차량 상태
- [ALT/src/data/PredictionPara.java](ALT/src/data/PredictionPara.java) — EMA 가중치
- [ALT/src/data/DataSet.java](ALT/src/data/DataSet.java) — 차량 맵
- [ALT/src/batch/TrafficBatch.java](ALT/src/batch/TrafficBatch.java) — 다운스트림

### UDP raw 데이터
- [OHS_DATA_MD/20260416/LOGPRESSO_OHT_DATA_20260416.csv](OHS_DATA_MD/20260416/LOGPRESSO_OHT_DATA_20260416.csv)
- [OHS_DATA_MD/20260415/LOGPRESSO_OHT_DATA_2026041607.csv](OHS_DATA_MD/20260415/LOGPRESSO_OHT_DATA_2026041607.csv)
- [OHS_DATA_MD/20260414/OHT_20260414.csv](OHS_DATA_MD/20260414/OHT_20260414.csv)

### 단위 명세
- [OHT_MAP/OHT_위치계산_가이드.md](OHT_MAP/OHT_위치계산_가이드.md) — fields[8] dm 단위 명시

---

**작성일:** 2026-04-19
**검증 방법:**
- ALT/src/ 자바 소스 직접 읽기 (5개 파일)
- LOGPRESSO_OHT_DATA_20260416.csv (139만건 VHL_STATE_REPORT) 중 V00100 차량 35분 표본 직접 분석
- Case A 공식을 V00100 rows 7→8 에 직접 적용하여 17.78 m/min 산출 — 물리적 타당성 확인
