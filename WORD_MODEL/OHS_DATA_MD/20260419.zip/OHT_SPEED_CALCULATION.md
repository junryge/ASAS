# OHT 속도 계산 — 정리

> UDP 메시지로 OHT 차량별 순간 속도 계산이 가능한가?
> **결론: 가능하다.**

---

## 1. 결론

UDP 메시지에 **직접 속도 필드는 없지만**, 연속된 두 UDP 메시지의 위치 변화와 시간 차이로 **계산 가능**하다.

---

## 2. 왜 가능한가

### UDP 메시지 21필드 중 속도 계산에 필요한 필드

| 인덱스 | 필드명 | 설명 |
|--------|--------|------|
| fields[7] | CurrentAddress | 현재 위치 노드 |
| fields[8] | Distance | 현재 번지 내 이동 거리 (mm) |
| fields[9] | NextAddress | 다음 노드 |
| — | 수신 시각 | UDP 타임스탬프 |

> 참고: `fields[18]`은 `Priority`(우선순위 코드)이며 속도가 아니다.

---

## 3. 계산 공식

```
ran_distance [mm] = 이동한 실제 거리
elapsed [ms]      = 두 UDP 수신 간격
speed [mm/min]    = ran_distance / elapsed × 60000
```

### Case A — 같은 edge 안에서 이동
```
ran_distance = 현재_distance − 이전_distance
```

### Case B — Edge를 넘어갔을 때
```
ran_distance = (이전_edge_길이 − 이전_distance) + 현재_distance
```

---

## 4. 단위 참고

| 단위 | 값 |
|------|-----|
| UDP 계산 결과 | **mm/min** |
| 정상 OHT 주행 속도 | 100,000 ~ 200,000 mm/min |
| 변환 | = 100 ~ 200 m/min (분속) |
| 변환 | = 6 ~ 12 km/h |

---

## 5. 필요한 것

### 5.1 Edge 길이 맵
각 (from_node, to_node) 쌍의 거리(mm).
- `layout_cache.json`의 `edges` 필드에 이미 있음 ✅

### 5.2 차량별 이전 상태 저장소
```python
prev[vid] = (timestamp, edge, distance)
```

### 5.3 5만건 UDP 샘플로 해석 검증
- **해석 1**: 같은 edge 안에서 `distance`가 누적 증가 → `distance - prev_distance`로 계산
- **해석 2**: edge 바뀔 때만 업데이트 → Case B 공식만 사용
- → 실제 데이터로 확인 필요

---

## 6. 구현 스케치

```python
class VelocityTracker:
    """차량별 UDP 기반 순간 속도 계산"""
    
    def __init__(self, edge_length_map):
        self.prev = {}  # vid -> {time, edge, distance}
        self.edge_length = edge_length_map  # (from, to) -> length(mm)
    
    def update(self, vid, timestamp, current_addr, next_addr, distance):
        """
        Returns: speed in mm/min, or None if first observation
        """
        curr_edge = (current_addr, next_addr)
        
        if vid in self.prev:
            p = self.prev[vid]
            elapsed_ms = (timestamp - p['time']).total_seconds() * 1000
            
            if elapsed_ms <= 0:
                self.prev[vid] = {
                    'time': timestamp, 'edge': curr_edge, 'distance': distance
                }
                return None
            
            # Edge 바뀜 여부 판정
            if p['edge'] != curr_edge:
                # Case B: Edge 넘어감
                prev_edge_len = self.edge_length.get(p['edge'], 0)
                ran_distance = prev_edge_len - p['distance'] + distance
            else:
                # Case A: 같은 edge 내
                ran_distance = distance - p['distance']
                if ran_distance < 0:
                    ran_distance = 0  # 이상치 방어
            
            speed_mmpm = ran_distance / elapsed_ms * 60000  # mm/min
            
            self.prev[vid] = {
                'time': timestamp, 'edge': curr_edge, 'distance': distance
            }
            return speed_mmpm
        
        # 첫 관측
        self.prev[vid] = {
            'time': timestamp, 'edge': curr_edge, 'distance': distance
        }
        return None
```

---

## 7. 이걸로 할 수 있는 것

### 7.1 WORLD_SIM 개선
**현재 (버그):**
```python
velocity = DEFAULT_VELOCITY if state == 1 else 0.0  # 가짜 값
```

**수정 후:**
```python
velocity = velocity_tracker.update(vid, t, curr, next, distance)
```

### 7.2 활용 분야
1. **OHT별 속도 시계열** (0.5초 해상도)
2. **velocity=0 지속 시간** 정확 측정
3. **저속 주행 감지** (state=RUN인데 실제로 느림)
4. **Edge별 평균 속도** = 병목 지표
5. **데드락 전조 시그널** (연쇄 속도 하락)
6. **ATLAS 방식 EMA로 edge 속도 추적**

---

## 8. ATLAS 원본 로직 (참고)

`RailEdge.addVelocity()` 에서 확인된 ATLAS 속도 갱신 방식:

```java
public void addVelocity(double velocity) {
    // 1. NaN/Infinite 방어
    if (Double.isNaN(velocity) || Double.isInfinite(velocity)) return;
    
    // 2. 클램핑
    if (velocity < 1.5) velocity = 1.5;
    else if (getMaxVelocity() < velocity) velocity = getMaxVelocity();
    
    // 3. 이전 값 저장
    setLastVelocity(this.velocity);
    
    // 4. EMA 갱신
    if (hisCnt > 0) {
        // 과거 W + 현재 (1-W)
        // W = PredictionPara.getLastHisWeight() (추정: 0.6)
        this.velocity = this.velocity * W + velocity * (1 - W);
    } else {
        this.velocity = velocity;  // 첫 관측
    }
    
    this.changedVelocity = true;
}
```

**핵심 특징:**
- 단위: **분속(m/min)**
- 클램핑: 하한 1.5, 상한 `maxVelocity` (Free Flow Speed)
- 이력 있으면 EMA, 없으면 샘플 그대로
- **차량별 속도가 아닌 Edge별 평균 속도**를 추적

---

## 9. 두 가지 속도의 구분

| 구분 | 존재? | 출처 | 용도 |
|------|-------|------|------|
| **차량별 순간 속도** | ✅ 계산 가능 | UDP 위치 변화 | 개별 OHT 거동 분석, 데드락 전조 |
| **Edge별 평균 속도** | ✅ 계산 가능 | ATLAS EMA 복제 | 병목 지표, 구간 혼잡도 |

두 방식 모두 구현 가능. 용도에 따라 선택 또는 병행.

---

## 10. 다음 단계 (지금 바로 진행)

- [ ] UDP 5만건 샘플 공유
- [ ] 같은 edge 안에서 distance 변화 패턴 확인
  - 누적 증가 → 해석 1
  - 고정/0 → 해석 2
- [ ] 해석 확정 후 `VelocityTracker` 최종 구현
- [ ] `data_loader.py`에 통합
- [ ] `world_model.py`의 기존 velocity 버그 수정
- [ ] Edge별 EMA 속도 추적 추가 (ATLAS 방식 복제)
- [ ] 대시보드에 속도 기반 시각화 추가

---

## 11. 한 줄 요약

**UDP에 속도 필드는 없지만, 위치(CurrentAddress + Distance) 변화와 수신 시각 차이로 계산 가능. 단위는 mm/min.**

---

**작성일:** 2026-04-17  
**기반:**
- UDP 메시지 필드 명세 (21필드)
- ATLAS `RailEdge.java` `addVelocity()` EMA 로직
- ATLAS `TrafficBatch.java` 집계 방식

---

## 12. 참고한 Java 소스

- `RailEdge.java`
- `TrafficBatch.java`
- `OhtMsgWorkerRunnable.java`
- `PredictionPara.java`
