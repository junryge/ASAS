# FAB 위험 룰 v1.1

먼저 FAB_위험룰_v1_1_개정결과.md와 CHANGELOG.md를 확인하세요. 상세 산식은 RULES.md에 있습니다.

실행: `python run_safe.py --input "원천데이터.zip" --out result_v1_1 --timeout 300`

입력은 CRT_TM 및 원본 지표 컬럼이 있는 CSV/ZIP/CSV 폴더입니다. pandas/numpy 필요. 기본 제한300초, 자동 재시도없음. 실패 시 run.log와 run_status.json을 확인하세요. --fit은 이 고정 배포본에서 차단됩니다.

결과: FAB_scores.csv.gz, score_summary.csv, alert_episodes.csv. gzip을 풀면 일반 CSV입니다. 원본 지표명을 바꾸지 않으며 결과는 원천./파생./룰./기여./점수. 접두어로 구분합니다. 각 점수 행에 룰버전·설정ID가 기록됩니다.

검증: `python verify_rules.py --input "설계용원천.zip"`. 제공된 8/11~9/11 원천과 재생 결과가 있는 패키지를 기준으로 실행합니다.

평가 시 과거40분 이상 원천을 함께 넣고 해당 평가기간 결과만 집계하세요. 9/12~15 독립평가 미완료. 자동 장비 제어나 메시지 발송 기능은 없습니다.

v1.0으로 돌아가려면 history/v1.0의 ZIP을 별도 폴더에 풀고 그 안의 코드와 설정을 함께 실행합니다. 원천데이터 전체 및 대화 전문은 이번 패키지에 중복 포함하지 않았습니다.
