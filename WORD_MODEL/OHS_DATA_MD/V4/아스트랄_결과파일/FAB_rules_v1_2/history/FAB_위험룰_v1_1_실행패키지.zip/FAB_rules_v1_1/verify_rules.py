"""Bounded verification of changed behavior; no fitting or retry loops."""
from pathlib import Path
import argparse,json,zipfile,hashlib
import pandas as pd,numpy as np
from fab_risk_rules import load_data,score,storage_context,STORAGE_USED,STORAGE_FREE,STORAGE_CMD
ROOT=Path(__file__).resolve().parent

def run(path):
 d,_=load_data(path);cfg=json.loads((ROOT/'rule_config.json').read_text());checks=[]
 def check(name,ok):
  if not bool(ok):raise AssertionError(name)
  checks.append({'check':name,'passed':True})
 small=d.loc['2026-08-26':'2026-08-27'].copy();cut=pd.Timestamp('2026-08-27 06:20')
 full,_=score(small,cfg);pre,_=score(small.loc[:cut],cfg)
 a=full[full.time<=cut].set_index(['FAB','time']).sort_index();b=pre.set_index(['FAB','time']).sort_index()
 check('미래행 없이도 과거 점수 동일',a['점수.FAB반송위험'].equals(b['점수.FAB반송위험']))
 pert=small.copy();pert[STORAGE_CMD]=99999;pert[STORAGE_FREE]=0;pert['M16HUB.STRATE.STK.STORAGERATIO']=100
 other,_=score(pert,cfg)
 check('STB행 CMD·빈공간·존재하지 않는 STK 지표는 직접 가점하지 않음',full['점수.FAB반송위험'].equals(other['점수.FAB반송위험']))
 pert=small.copy();pert[[c for c in pert if '.SORTER.' in c]]=99999;other,_=score(pert,cfg)
 check('Sorter는 FAB 반송점수와 분리',full['점수.FAB반송위험'].equals(other['점수.FAB반송위험']))
 pert=small.copy();pert[STORAGE_USED]=np.nan;other,_=score(pert,cfg);hub=other[other.FAB.eq('M16HUB')]
 check('저장률 결측은 명시하고 대체 비율을 사용하지 않음',(~hub['품질.HUB 저장률 유효'].astype(bool)).all() and hub['원천.HUB 예약포함 저장률(%)'].isna().all() and hub['기여.HUB 예약포함 저장대기'].eq(0).all())
 # Controlled physical scenarios: normal transport, prolonged storage, then delay.
 syn=pd.DataFrame(0.,index=pd.date_range('2026-08-26',periods=100,freq='min'),columns=d.columns)
 syn['M16HUB.QUE.ALL.CURRENT_M16A_3F_JOB_2']=max(1,cfg['parameters']['M16HUB.q']['low']/2)
 syn['M16HUB.QUE.OHT.CURRENTOHTQCNT']=100
 tk='M16HUB.QUE.TIME.AVGTOTALTIME1MIN';syn[tk]=max(.001,cfg['parameters']['M16HUB.time']['low']/2)
 syn[STORAGE_USED]=0;syn.loc[syn.index[30]:,STORAGE_USED]=30
 ctx=storage_context(syn,cfg)
 check('5회 분 관측 미만 일시 저장은 Storage 가점 없음',ctx['severity'].iloc[30:34].eq(0).all())
 normal,_=score(syn,cfg);h=normal[normal.FAB.eq('M16HUB')]
 check('반송 영향 없는 지속 저장의 대기 기여는 10점 이하',h['룰.미완료 물량 누적'].max()<=10)
 delayed=syn.copy();delayed[tk]=cfg['parameters']['M16HUB.time']['high']+1
 r,_=score(delayed,cfg);h2=r[r.FAB.eq('M16HUB')]
 check('지속 저장과 실제 반송지연이 함께 있으면 대기 기여 증가',h2['기여.HUB 예약포함 저장대기'].iloc[50]>=39.9)
 check('내부JOB와 Storage 대기는 합산 대신 MAX 결합',np.allclose(h2['룰.미완료 물량 누적'],h2[['기여.HUB 내부JOB 대기','기여.HUB 예약포함 저장대기']].max(axis=1),atol=.011))
 release=syn.copy();release.loc[release.index[60]:,STORAGE_USED]=20
 ctx=storage_context(release,cfg)
 check('5분간 2%p 이상 해소 중에는 Storage 가점 중단',ctx['severity'].iloc[60:65].eq(0).all())
 missing=syn.copy();missing.loc[missing.index[50],STORAGE_USED]=np.nan;ctx=storage_context(missing,cfg)
 check('저장률 결측은 지속시간을 끊고 재확인',pd.isna(ctx['minutes'].iloc[50]) and ctx['minutes'].iloc[51]==1 and ctx['severity'].iloc[51:55].fillna(0).eq(0).all())
 result=pd.read_csv(ROOT/'design_replay/FAB_scores.csv.gz',low_memory=False)
 with zipfile.ZipFile(ROOT/'history/v1.0/FAB_위험룰_v1_실행패키지.zip') as z:
  with z.open('FAB_rules_v1/design_replay/FAB_scores.csv.gz') as f:old=pd.read_csv(f,compression='gzip')
 for fab in ['M14A','M14B','M16A','M16B']:
  left=old[old.FAB.eq(fab)].set_index('time');right=result[result.FAB.eq(fab)].set_index('time')
  check(fab+' 점수·Sorter는 v1.0과 모든 분 동일',left[['점수.FAB반송위험','점수.Sorter대기']].equals(right[['점수.FAB반송위험','점수.Sorter대기']]))
 check('최종 점수 범위 0~100',result['점수.FAB반송위험'].dropna().between(0,100).all())
 check('HUB Sorter 없음',result.loc[result.FAB.eq('M16HUB'),'점수.Sorter대기'].isna().all())
 (ROOT/'verification.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps({'passed':len(checks),'failed':0}))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--input',required=True);run(p.parse_args().input)
