# ML 재학습 가이드 (v3.1 + 위험도)

> 새로운 70개 피처로 XGBoost 모델 재학습

---

## 0. 폴더 구성

```
TRAIN_ML/
├── README_학습가이드.md          (이 문서)
│
├── [룰 엔진 — 사건단위.csv 생성용]
│   ├── hubroom_predictor.py       (★ 룰베이스 + 위험도)
│   ├── aws_idc_realtime_collector.py
│   └── 룰베이스검증.py
│
├── [ML 학습 도구]
│   ├── feature_builder.py         (70개 피처 추출)
│   ├── make_incidents.py          (사건단위.csv → incidents.json)
│   ├── train_xgboost.py           (★ 학습 메인)
│   ├── evaluate.py                (성능 평가)
│   └── predict_all.py             (일괄 예측)
│
├── [ML 실시간 도구]
│   ├── ml_predictor.py            (모델 로더)
│   └── ml_predict_runner.py       (실시간 예측 runner)
│
└── [라벨 샘플]
    └── incidents_sample.json
```

---

## 1. 학습 데이터 준비

학습 데이터는 별도로 받으셔야 합니다 (예: `dss_data.csv`).
- 65개 컬럼 (CRT_TM + 64 IDC, v3.1 포함)
- 1분 단위
- 최소 1개월 이상 권장 (4.5개월 추천)

이 폴더 안에 `dss_data.csv` 두고 시작하세요.

---

## 2. 학습 4단계

### ★ 단계 1: 룰베이스로 사건 라벨 추출

```bash
python hubroom_predictor.py dss_data.csv -o ./labels
```

출력:
- `./labels/YYYYMMDD_발동이벤트.csv` (매분 1행, 위험도 포함)
- `./labels/YYYYMMDD_사건단위.csv` ← **★ ML 학습 라벨 소스**

### ★ 단계 2: 사건단위.csv → incidents.json 변환

```bash
python make_incidents.py --csv ./labels/*_사건단위.csv --out incidents.json
```

출력: `incidents.json` (각 사건의 predict_time, start_time, end_time)

**중요**: 사건단위.csv 가 여러 날짜에 분산되어 있으면 모두 합쳐서 변환.

### ★ 단계 3: 피처 추출 (70개)

```bash
python feature_builder.py --csv dss_data.csv --out features.csv
```

출력: `features.csv` (timestamp + 70개 피처 + s1/s2/s3 플래그)

피처 그룹:
- 현재값 (16개) — `1min_now`, `m14_now`, `fabstorage_now`, `hub_storage_util`, `m14_inflow`, …
- 슬라이딩 통계 (15개) — `1min_max_30m`, `fabstorage_mean_30m`, `hub_storage_max_30m`, …
- 변화율/모멘텀 (12개) — `1min_delta_30m`, `inflow_total_delta_10m`, …
- 가속도 (2개) — `1min_accel_5m`, `fabstorage_accel_5m`
- 룰 컨텍스트 (18개) — `rule_ra_count`, `rule_rd_trig`, `rule_re_trig`, …
- **위험도 점수 (1개) — `risk_score`** ★★★
- 조합 (8개) — `1min_x_fabstorage`, `risk_x_inflow`, …

### ★ 단계 4: XGBoost 학습

```bash
python train_xgboost.py --features features.csv --labels incidents.json
```

출력: `model.json` (학습된 모델)

선택 옵션:
- `--horizon 30` : 30분 뒤 예측 라벨링 (기본)
- `--n-estimators 200` : 트리 개수
- `--max-depth 6` : 트리 깊이

---

## 3. 학습 후 검증

### 성능 평가

```bash
python evaluate.py --model model.json --features features.csv --labels incidents.json
```

출력 지표:
- AUC, Precision, Recall, F1
- 30/45/60분 사전 인지율
- 위양성 비율

### 일괄 예측 (학습 데이터에 다시 적용)

```bash
python predict_all.py --model model.json --features features.csv --out preds.csv
```

---

## 4. 실시간 운영 (학습 완료 후)

학습된 `model.json` 을 운영 폴더로 복사:

```bash
cp model.json /path/to/운영_OHS_HYBRID_OPS/
```

운영 폴더에서:
```bash
python run_ml.py
# → 수집기 + 룰베이스 + ML + 하이브리드 동시 실행
```

---

## 5. 트러블슈팅

### Q1: `feature_builder.py` 가 룰 엔진 못 찾음
```
FileNotFoundError: 룰 엔진 파일을 찾을 수 없습니다
```
→ `hubroom_predictor.py` 가 같은 폴더 안에 있는지 확인

### Q2: `make_incidents.py` 에서 사건단위.csv 가 비어있음
→ 단계 1 다시 실행, `predict_tobe/` 폴더 안에 파일 생성됐는지 확인

### Q3: 피처 개수가 70이 아닌 53이 나옴
→ `feature_builder.py` v3.1 버전 확인. `risk_score`, `hub_storage_util` 키 있어야 함

### Q4: 학습 데이터에 v3.1 컬럼이 비어있음
→ 수집 시기가 v3.1 도입 이전 (예: 2026-03-23 이전) 인지 확인. 비어있는 행은 자동으로 0 처리됨.

### Q5: model.json 호환성
→ 기존 53개 피처 모델은 70개 피처와 호환 안 됨. **반드시 재학습 필요**.

---

## 6. 학습 시간 / 리소스 예상

| 데이터 기간 | 행 수 | 피처 추출 | 학습 시간 |
|---|---|---|---|
| 1주일 | ~10,000 | <1분 | <30초 |
| 1개월 | ~43,000 | 2~3분 | 1~2분 |
| 4.5개월 | ~192,000 | 10~15분 | 5~10분 |

---

## 7. v3.1 신규 피처 — 학습 시 주목할 점

### ★★★ 최고 가치 피처
- `risk_score` — 룰베이스 종합 점수 (0~170)
- `hub_storage_delta_30m` — HUB 저장 변화 (감소 = 가득 차가는 중)
- `inflow_total_delta_10m` — 인플로 폭증 신호

### ★★ 중요 피처
- `rule_re_trig`, `rule_rf_trig` — v3.1 보조 룰 발동
- `hub_storage_util` — 현재 HUB 저장 상태
- `inflow_total_now` — 현재 HUB 들어올 부하

### ★ 보조 피처
- `m14_inflow`, `m16a_2f_inflow` 등 개별 인플로 — 정체 원인 영역 식별

---

*본 가이드는 v3.1 (65컬럼 + 70피처 + 위험도) 기준입니다.*
