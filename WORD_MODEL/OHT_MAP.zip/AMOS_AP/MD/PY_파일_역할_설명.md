# PY 파일 역할 설명

`F:\M14_Q\OHT_MAP\` 폴더에 있는 파이썬 파일들의 역할을 정리한 문서입니다.
각 파일이 **무엇을 하는지**, **언제 실행되는지**, **누가 누구를 호출하는지**를 설명합니다.

---

## 전체 구조 한눈에 보기

```
고객이 직접 실행하는 파일:
  ├── sim_server_3d_D5_D7.py    ★ 메인 웹서버 (항상 먼저 실행)
  └── test_send_ui.py           ★ OHT 메시지 전송 테스트 GUI

내부 동작 파일 (직접 실행 X, 서버가 자동 호출):
  ├── oht_position.py           번지 → 좌표 계산기
  ├── layout_map_cre.py         layout.xml → layout.html 생성기
  └── hid_zone_csv_cre.py       HID_Zone_Master.csv 생성기
```

**의존 관계**
```
sim_server_3d_D5_D7.py
    ├─ import oht_position        (메시지 받을 때 좌표 계산)
    ├─ import layout_map_cre      (서버 시작 시 layout.html 자동 생성)
    └─ import hid_zone_csv_cre    (서버 시작 시 Zone CSV 자동 생성)

test_send_ui.py
    └─ 네트워크(HTTP)로 sim_server_3d_D5_D7.py 의
       /api/oht-raw 엔드포인트에 메시지 POST
```

---

## 1. `sim_server_3d_D5_D7.py` (메인 서버, ~5720줄)

### 역할
**FastAPI 기반 실시간 OHT 시뮬레이터 웹서버**. 브라우저에 맵 UI 를 제공하고, MCS 또는 `test_send_ui.py` 에서 들어오는 OHT 메시지를 받아 WebSocket으로 실시간 방송합니다.

### 이 파일 안에 들어있는 것

**Python 백엔드 (~2500줄)**
- **FastAPI 앱 정의** — 모든 HTTP/WebSocket 엔드포인트
- **시뮬레이션 엔진 (`SimulationEngine` 클래스)** — Vehicle, HIDZone, Station, RailEdge 등 도메인 모델
- **OHT 메시지 파서 (`_parse_oht_message_full`)** — 21필드 콤마 구분 메시지 → 차량 상태 dict
- **FAB 관리** — `MAP/` 폴더 자동 스캔, FAB 전환 로직, `fab_config.json` 영속화
- **백그라운드 루프**
  - `csv_save_loop` — 10초마다 ATLAS CSV 저장
  - `output_cleanup_loop` — 10분마다 output 폴더 정리
  - `vehicle_cleanup_loop` — 1초마다 stale 차량 제거 (5초 이상 미수신)

**HTML/CSS/JavaScript 프론트엔드 (~3200줄, `HTML_CONTENT` 상수 안)**
- 헤더 (FAB 드롭다운, 3D/곡선 토글, 히트맵 셀렉트, 곡률 슬라이더)
- 좌측 사이드바 (실시간 통계, 속도 정보, HID Zone, 시스템 정보, 범례, 줌)
- 우측 사이드바 (OHT 리스트 + 필터/검색, HID Zone 리스트 + 필터/검색)
- 메인 캔버스 (pan/zoom, pseudo-3D 아이소메트릭 렌더링, 곡선 레일, 히트맵, 차량 보간)
- 툴팁, 하단 시각 패널
- WebSocket 클라이언트 (자동 재연결, layout/update 메시지 처리)

### API 엔드포인트 (12개)
| Method | Path | 설명 |
|--------|------|------|
| GET | `/` | 브라우저용 HTML UI 반환 |
| GET | `/api/layout` | 현재 FAB 의 노드/엣지/Zone/Station 데이터 |
| GET | `/api/state` | 현재 차량 + 통계 상태 |
| GET | `/api/fab/list` | 사용 가능한 FAB 목록 |
| GET | `/api/fab/current` | 현재 FAB 정보 |
| POST | `/api/fab/switch` | FAB 런타임 전환 |
| POST | `/api/oht-raw` | ★ OHT raw 메시지 수신 (MCS / test_send_ui 용) |
| POST | `/api/reroute-all` | 모든 차량 경로 재탐색 |
| GET | `/api/path-info` | 두 노드 간 경로 조회 |
| WS | `/ws` | 레이아웃 전송 + 0.5초 주기 상태 브로드캐스트 |

### 실행 방법
```bash
python sim_server_3d_D5_D7.py
```
→ `http://localhost:10003` 에서 UI 열림

### 이 파일을 수정해야 할 때
- 새 API 엔드포인트 추가
- UI 레이아웃/색상/섹션 변경
- 새 통계/필터 추가
- WebSocket 메시지 포맷 변경

### 이 파일을 수정하지 말아야 할 때 (주의)
- **OHT 위치 계산 로직** — `oht_position.py` 에서 수정
- **layout.html 생성 로직** — `layout_map_cre.py` 에서 수정
- **HID Zone CSV 포맷** — `hid_zone_csv_cre.py` 에서 수정

---

## 2. `oht_position.py` (위치 계산기, ~362줄)

### 역할
**번지 번호를 실제 좌표(x, y)로 변환하는 라이브러리**. MCS에서 오는 OHT 메시지에는 `현재번지 / 거리 / 다음번지` 만 들어있고 좌표가 없으므로, 이 파일이 **레일 지도(layout.xml)** 를 기반으로 실제 화면 좌표를 계산해 줍니다.

### 핵심 클래스: `OHTPosition`

```python
from oht_position import OHTPosition

pos = OHTPosition("layout_cache.json")

# 위치 계산
x, y = pos.calc(현재번지=12340, 거리=14, 다음번지=12341)
# → (11227.86, 1204.46)

# OHT 메시지 한 줄에서 바로 계산
result = pos.calc_from_message("2,OHT,V00795,1,1,0000,1,12340,14,12341,...")
# → {"vehicleId":"V00795", "x":..., "y":..., "currentNode":12340, ...}
```

### 동작 원리
1. `layout_cache.json` (번지 → 좌표 매핑) 을 메모리에 로드
2. `calc(현재, 거리, 다음)` 호출 시:
   - 현재번지와 다음번지 사이를 `거리 / 엣지길이` 비율로 선형 보간
   - 예: (500, 200) 과 (600, 200) 사이 1.4m → (501.4, 200)
3. `calc_from_message(msg)` 는 21필드 메시지를 파싱해서 바로 좌표 계산

### 주요 함수
| 함수 | 역할 |
|------|------|
| `OHTPosition(cache_path)` | layout_cache.json 로드 |
| `pos.calc(current, distance, next)` | 번지→좌표 선형 보간 |
| `pos.calc_from_message(msg)` | OHT raw 메시지 → 좌표 + 차량 정보 |
| `pos.get_node(node_no)` | 특정 번지의 좌표 + 연결 노드 조회 |
| `convert_xml_to_json(xml_content, output_path)` | layout.xml → layout_cache.json 변환 |
| `convert_file(filepath)` | .xml 또는 .zip 파일을 받아 변환 실행 |

### CLI 사용법 (직접 실행할 때)
```bash
# layout.xml → layout_cache.json 변환 (최초 1회)
python oht_position.py convert MAP/M14A/A.layout.zip

# 번지 정보 조회
python oht_position.py node 12340

# 위치 직접 계산
python oht_position.py calc 12340 14 12341

# OHT 메시지 파싱
python oht_position.py parse "2,OHT,V00795,1,1,0000,1,12340,14,12341,..."

# 전체 노드 목록
python oht_position.py list
```

### 누가 이 파일을 사용하는가?
- **`sim_server_3d_D5_D7.py`** — 서버 시작 시 `OHTPosition` 인스턴스를 만들고, `/api/oht-raw` 로 들어오는 모든 메시지를 이 인스턴스로 좌표 계산
- **사람(개발자/운영자)** — CLI 로 번지 존재 여부, 좌표, 거리 조회 디버깅

### 입력/출력 파일
- **입력**: `layout.xml` 또는 `A.layout.zip` (MCS 원본 레일 지도)
- **출력**: `layout_cache.json` (파싱된 번지/거리 캐시, 수 MB)

### 수정하지 말 것
- 계산 로직 (`calc()`) — 물리적으로 틀린 좌표가 나오면 맵 전체가 망가집니다
- 메시지 파싱 (`calc_from_message()`) — 21필드 순서 변경 시 깨짐

---

## 3. `layout_map_cre.py` (레이아웃 HTML 생성기, ~349줄)

### 역할
**MCS에서 받은 `layout.xml` (또는 `.zip`) 을 파싱해서 서버가 쓰기 좋은 `layout.html` 로 변환**. 240만 줄짜리 XML 을 매번 읽으면 느리므로, 노드/엣지 정보만 뽑아 JSON 형태로 임베드한 작은 HTML 파일을 만듭니다.

### 핵심 함수: `ensure_layout_html()`

```python
from layout_map_cre import ensure_layout_html

ensure_layout_html(
    layout_html_path="MAP/M14A/A.layout/layout.html",   # 출력
    layout_xml_path="MAP/M14A/A.layout/layout.xml",     # 입력 (1순위)
    layout_zip_path="MAP/M14A/A.layout.zip",            # 입력 (2순위)
)
```

**동작**
- `layout.html` 이 이미 있으면 → 스킵 (빠른 재시작)
- 없으면 → `layout.zip` 또는 `layout.xml` 에서 Addr/NextAddr 정보 추출
- 노드 배열과 연결 정보를 임베드한 `layout.html` 생성:
  ```html
  <script>
  const A = [{no:12340,x:500,y:200}, ...];   // 노드
  const C = [[12340,12341], [12341,12342], ...];  // 엣지
  </script>
  ```
- `sim_server_3d_D5_D7.py` 의 `parse_layout()` 이 이 `const A` / `const C` 를 정규식으로 추출해서 사용

### 누가 이 파일을 사용하는가?
- **`sim_server_3d_D5_D7.py`** — 서버 시작 시(`@app.on_event("startup")`) 와 FAB 전환 시 자동 호출
- **사람** — 거의 직접 실행할 일 없음 (자동화됨)

### 입력/출력 파일
- **입력**: `MAP/{FAB}/{prefix}.layout.zip` 또는 `.../layout.xml`
- **출력**: `MAP/{FAB}/{prefix}.layout/layout.html`

### `oht_position.py` 와의 차이점
| 구분 | `layout_map_cre.py` | `oht_position.py` |
|------|--------------------|-------------------|
| 출력 형식 | **HTML** (브라우저에 뿌릴 작은 HTML 파일) | **JSON** (파이썬 런타임 로드 캐시) |
| 용도 | **프론트엔드 맵 렌더링**용 노드/엣지 목록 | **백엔드 좌표 계산**용 번지↔좌표 맵 |
| 엣지 거리 정보 | 없음 (노드 연결만) | 있음 (100mm 단위 거리값) |
| 로드 속도 | HTML 파일 하나로 한 번 로드 | JSON 파일 하나로 한 번 로드 |

두 파일 모두 **같은 `layout.xml` 소스**에서 나오지만, **용도가 다르기 때문에 별도로 관리**합니다.

---

## 4. `hid_zone_csv_cre.py` (HID Zone CSV 생성기, ~756줄)

### 역할
**MCS의 `layout.xml` 에서 HID Zone 정보(McpZone 구조)를 파싱해서 `HID_Zone_Master.csv` 를 생성**. HID Zone 이란 "특정 구간에 동시에 몇 대까지 들어올 수 있는지" 제한하는 **혼잡 제어 영역**입니다.

### 핵심 함수: `create_hid_zone_csv()`

```python
from hid_zone_csv_cre import create_hid_zone_csv

create_hid_zone_csv(
    layout_xml_path="MAP/M14A/A.layout/layout.xml",
    output_csv_path="MAP/M14A/HID_Zone_Master_M14A_A.csv",
    fab_name="M14A"
)
```

### CSV 출력 포맷 (ATLAS 호환)
```
ZONE_ID, HID_NO, BAY_ZONE, SUB_REGION, FULL_NAME, HID_TYPE,
IN_LANES, OUT_LANES, VEHICLE_MAX, VEHICLE_PRECAUTION, FAB
```

**주요 필드**
- `ZONE_ID` — Zone 고유 번호
- `IN_LANES` / `OUT_LANES` — `"12340-12341|12342-12343"` 형식 (진입/진출 레인 목록)
- `VEHICLE_MAX` — 최대 수용 차량 수 (넘으면 FULL)
- `VEHICLE_PRECAUTION` — 주의 기준 (넘으면 PRECAUTION 상태)

### 누가 이 파일을 사용하는가?
- **`sim_server_3d_D5_D7.py`** — 서버 시작 시 / FAB 전환 시 `create_hid_zone_csv()` 를 호출하여 CSV 가 없으면 자동 생성
- 엔진은 이렇게 만들어진 CSV 를 파싱해서 `HIDZone` 객체 리스트를 만들고, 렌더링/통계에 사용

### 입력/출력 파일
- **입력**: `MAP/{FAB}/{prefix}.layout.zip` 또는 `.../layout.xml`
- **출력**: `MAP/{FAB}/HID_Zone_Master_{FAB}_{prefix}.csv`

### 복잡한 이유
layout.xml 의 McpZone 구조가 복잡합니다:
- McpZone 내부에 여러 Address 가 그룹으로 묶여있고
- 각 Address 에 `in-lane` / `out-lane` 속성이 있으며
- Zone 간 계층(BayZone > SubRegion > Full HID) 이 존재

그래서 **한 파일에 756줄**이나 되고, 원본 파이썬 `xml.etree.iterparse` 로 메모리 효율적으로 순회합니다.

---

## 5. `test_send_ui.py` (테스트용 GUI, ~257줄)

### 역할
**`sim_server_3d_D5_D7.py` 의 `/api/oht-raw` 엔드포인트로 OHT 메시지를 쉽게 보낼 수 있는 Tkinter GUI**. MCS가 실제로 붙기 전에, 서버가 메시지를 제대로 받는지, 브라우저 화면에 차량이 제대로 나타나는지 **수동으로 테스트**하기 위한 용도입니다.

### 기능
1. **서버 URL 설정** — 기본 `http://localhost:10003`
2. **샘플 로드** — 21필드 샘플 메시지 3개 자동 삽입
3. **파일 열기** — `.txt` 파일에서 OHT 메시지 로드 (예: `oht_5v_move.txt`)
4. **한 번 전송** — 메시지 1회 POST
5. **자동 전송** — 주기적(기본 0.5초) 반복 POST + 매번 `distance` 값을 증가시켜 **차량 이동 효과** 재현
6. **응답 로그** — 서버 응답 (`{status, received, updated, total_vehicles}`) 을 타임스탬프와 함께 표시

### 사용 방법
```bash
# 1) 서버 먼저 실행
python sim_server_3d_D5_D7.py

# 2) 브라우저 열기
#    http://localhost:10003

# 3) 새 터미널에서 테스트 GUI 실행
python test_send_ui.py

# 4) GUI 에서
#    [파일 열기] → oht_5v_move.txt
#    [자동 전송 시작]
#    → 브라우저 화면에 5대 OHT 가 이동하는 것 확인
```

### 메시지 전송 방식
```
[test_send_ui.py]
     │
     │  HTTP POST http://localhost:10003/api/oht-raw
     │  body: {"messages": ["2,OHT,V00795,...", ...]}
     ▼
[sim_server_3d_D5_D7.py]
     │  _parse_oht_message_full(msg, oht_positioner)
     │       └─ oht_positioner.calc(12340, 14, 12341) → (x, y)
     │  vehicle_state_store[vid] = {...}
     ▼
[WebSocket /ws]
     │  type: 'update'
     ▼
[브라우저 화면]
     → OHT 5대 표시 + 이동
```

### 이 파일을 수정해야 할 때
- 새 테스트 패턴 추가 (예: 랜덤 거리, 여러 FAB 시뮬레이션)
- 다른 서버 주소로 기본값 변경
- UI 개선

### 마이그레이션 제외 대상
`test_send_ui.py` 는 **마이그레이션된 시스템을 검증하기 위한 독립 도구**입니다.
다른 파이썬 파일들이 Node/React 로 이식되더라도 이 파일은 **원본 파이썬 그대로 유지**됩니다.

---

## 6. 파일 간 호출 체인 전체 그림

### 서버 시작 시
```
python sim_server_3d_D5_D7.py
    │
    ├─ @app.on_event("startup")
    │     │
    │     ├─ layout_map_cre.ensure_layout_html()
    │     │     └─ MAP/M14A/A.layout.zip → layout.html 생성 (없으면)
    │     │
    │     ├─ parse_layout(layout.html)
    │     │     └─ const A, const C 추출 → nodes, edges
    │     │
    │     ├─ hid_zone_csv_cre.create_hid_zone_csv()
    │     │     └─ layout.xml → HID_Zone_Master_M14A_A.csv 생성 (없으면)
    │     │
    │     ├─ parse_hid_zones(HID_Zone_Master_M14A_A.csv)
    │     │     └─ HIDZone 객체 리스트
    │     │
    │     ├─ parse_stations(station.dat)
    │     │     └─ Station 객체 리스트
    │     │
    │     ├─ oht_position.convert_file(layout.zip)
    │     │     └─ layout_cache.json 생성 (없거나 오래됐으면)
    │     │
    │     ├─ oht_positioner = oht_position.OHTPosition(layout_cache.json)
    │     │
    │     └─ 백그라운드 태스크 시작 (csv_save, output_cleanup, vehicle_cleanup)
    │
    └─ uvicorn → http://localhost:10003 대기
```

### OHT 메시지 수신 시
```
[MCS 또는 test_send_ui.py]
    │ POST /api/oht-raw {"messages": [...]}
    ▼
sim_server_3d_D5_D7.py
    │
    ├─ _parse_oht_message_full(msg, oht_positioner)
    │     │
    │     └─ oht_positioner.calc(현재, 거리, 다음)   ← oht_position.py 호출
    │           └─ return (x, y)
    │
    ├─ vehicle_state_store[vid] = {..., _last_seen: now}
    │
    ├─ engine.vehicle_buffer.append({...})   ← CSV 버퍼 기록
    │
    └─ return {"status":"ok", ...}
```

### WebSocket 주기 송신 (0.5초마다)
```
sim_server_3d_D5_D7.py WebSocket 루프
    │
    ├─ engine.get_state()
    │     └─ vehicles = list(vehicle_state_store.values())
    │     └─ Zone 통계, 히트맵, 데드락 엣지 계산
    │
    └─ ws.send_json({"type":"update", "data": state})
        ▼
[브라우저 HTML_CONTENT JS]
    └─ render() → Canvas 에 차량/레일/Zone/Station 그림
```

---

## 7. 파일별 "건드려도 되나" 표

| 파일 | 수정 가능 여부 | 주의 사항 |
|------|---------------|-----------|
| **`sim_server_3d_D5_D7.py`** | ⚠ 조건부 | 엔드포인트 추가/UI 수정은 OK. 엔진 내부 클래스 수정은 다른 기능 깨질 수 있음 |
| **`oht_position.py`** | ❌ 금지 | 위치 계산 로직 건드리면 좌표 전부 깨짐 |
| **`layout_map_cre.py`** | ❌ 금지 | layout.html 포맷 변경 시 parse_layout 과 맞지 않음 |
| **`hid_zone_csv_cre.py`** | ❌ 금지 | CSV 포맷 변경 시 parser 가 깨짐 |
| **`test_send_ui.py`** | ✅ OK | 독립 도구. 사용자 편의에 맞게 자유 수정 가능 |

---

## 8. 자주 쓰는 명령 요약

```bash
# 메인 서버 실행 (가장 먼저)
python sim_server_3d_D5_D7.py

# OHT 메시지 테스트 GUI
python test_send_ui.py

# 위치 계산 디버깅 (번지 조회)
python oht_position.py node 12340

# 위치 계산 디버깅 (거리 → 좌표)
python oht_position.py calc 12340 14 12341

# layout.xml 캐시 수동 재생성
python oht_position.py convert MAP/M14A/A.layout.zip
```

---

## 9. 한 줄 요약표

| 파일 | 한 줄 요약 |
|------|-----------|
| `sim_server_3d_D5_D7.py` | **메인 웹서버** — FastAPI + WebSocket + 브라우저 UI |
| `oht_position.py` | **번지→좌표 계산기** (내부 라이브러리) |
| `layout_map_cre.py` | **layout.xml → layout.html 생성기** (서버 시작 시 자동) |
| `hid_zone_csv_cre.py` | **HID_Zone_Master.csv 생성기** (서버 시작 시 자동) |
| `test_send_ui.py` | **OHT 메시지 전송 테스트 GUI** (독립 도구) |

**한 줄**: `sim_server_3d_D5_D7.py` 만 기억하시면 됩니다. 나머지는 서버가 알아서 불러 쓰고, `test_send_ui.py` 는 개발 중 테스트용으로만 쓰세요.
