"""
Demos(민중) 프로젝트 Alpha 0.8 - Flask 웹앱 (고도화 버전)
=====================================================
cla-main + zircote/.claude 통합: 355개 스킬 (과학 174 + 개발도구 52 + 에이전트 117 + 가이드 12)

사용법:
  1. scientific-skills 폴더를 이 파일과 같은 위치에 복사
  2. TOKEN.TXT 파일에 API 키를 넣어두기 (같은 폴더)
  3. pip install flask requests
  4. python app.py
  5. 브라우저에서 http://localhost:10009 접속

폴더 구조:
  app.py
  TOKEN.TXT              ← API 키 (한 줄)
  scientific-skills/     ← 355개 스킬 (과학+개발+에이전트+가이드)
    ├── biopython/SKILL.md          (과학 스킬)
    ├── agent-python-pro/SKILL.md   (에이전트 스킬)
    ├── guide-python/SKILL.md       (개발 가이드)
    └── ... (나머지 스킬 폴더들)
"""

import os
import sys
import io
import csv
import json
import glob
import requests as req
from flask import Flask, request, jsonify, render_template_string

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024  # 50MB 제한

# GGUF 모델 (llama-cpp-python)
gguf_model = None  # Llama 인스턴스

# 업로드된 CSV 데이터 (세션별 - 단순 메모리 저장)
uploaded_csv_data = {
    "filename": "",
    "headers": [],
    "rows": [],
    "summary": "",
    "raw_preview": "",
}

# 업로드된 파일 (CSV 외 범용)
uploaded_files = []  # [{filename, type, size, summary, content_preview}]
UPLOAD_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

# ============================================
# 설정
# ============================================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SKILLS_DIR = os.path.join(BASE_DIR, "scientific-skills")
TOKEN_FILE = os.path.join(BASE_DIR, "TOKEN.TXT")
PROMPTS_DIR = os.path.join(BASE_DIR, "saved-prompts")
os.makedirs(PROMPTS_DIR, exist_ok=True)

# 회사 LLM API 환경 설정
ENV_CONFIG = {
    "dev": {
        "url": "http://dev.hcp.llm.skhynix.com/v1/chat/completions",
        "model": "GLM-4.7",
        "name": "4.7"
    },
    "prod": {
        "url": "http://dev.hcp.llm.skhynix.com/v1/chat/completions",
        "model": "Qwen3.5-397B-A17B",
        "name": "PROD (397B)"
    },
    "common": {
        "url": "http://dev.hcp.llm.skhynix.com/v1/chat/completions",
        "model": "gpt-oss-120b",
        "name": "COMMON (120B)"
    },
    # gguf-local은 앱 시작 시 자동 감지되면 추가됨
}


def load_token():
    """TOKEN.TXT 파일에서 API 키 읽기"""
    if os.path.isfile(TOKEN_FILE):
        with open(TOKEN_FILE, "r", encoding="utf-8-sig") as f:
            token = f.read().strip()
            if not token:
                print(f"  ⚠️  TOKEN.TXT 파일이 비어있습니다 - API 키를 입력하세요: {TOKEN_FILE}")
                return ""
            # ASCII만 허용 (한글 플레이스홀더 무시)
            try:
                token.encode("ascii")
                return token
            except UnicodeEncodeError:
                print(f"  ⚠️  TOKEN.TXT에 비영문 문자 포함 - 실제 API 키로 교체하세요")
                return ""
    else:
        print(f"  ⚠️  TOKEN.TXT 파일을 찾을 수 없습니다: {TOKEN_FILE}")
    return ""


API_TOKEN = load_token()

# 372개 스킬 한글 설명 (과학 174 + 개발도구 55 + 에이전트 117 + 가이드 15 + 커맨드 11)
SKILL_DESC_KO = {
    "biopython":"생물 서열/구조 분석","scanpy":"단일세포 RNA-seq 분석","pydeseq2":"차등 유전자 발현 분석",
    "bioservices":"40+ 생물정보학 DB 통합","anndata":"단일세포 주석 행렬","arboreto":"유전자 조절 네트워크 추론",
    "cellxgene-census":"6100만+ 단일세포 데이터","deeptools":"NGS BAM/bigWig 분석","gget":"20+ 생물DB 빠른 조회",
    "geniml":"유전체 구간 ML","gtars":"유전체 구간 고성능 분석","pysam":"SAM/BAM/VCF 파일 처리",
    "scikit-bio":"서열/다양성/마이크로바이옴","scvelo":"RNA velocity 분석","scvi-tools":"단일세포 딥러닝",
    "tiledbvcf":"유전체 변이 저장/조회","flowio":"유세포분석 FCS 파싱","phylogenetics":"계통수 구축",
    "etetoolkit":"계통수 조작/시각화","cobrapy":"대사 모델링 FBA/FVA","glycoengineering":"글리코실화 분석",
    "esm":"단백질 언어모델 구조예측","gene-database":"NCBI Gene 조회","ensembl-database":"Ensembl 250+ 종 유전체",
    "uniprot-database":"UniProt 단백질 검색","geo-database":"GEO 유전자 발현","clinvar-database":"ClinVar 변이 의미",
    "gnomad-database":"gnomAD 대립유전자 빈도","gtex-database":"GTEx 조직별 발현","gwas-database":"GWAS SNP-형질 연관",
    "ena-database":"유럽 뉴클레오타이드 아카이브","biorxiv-database":"bioRxiv 프리프린트","string-database":"단백질 상호작용",
    "reactome-database":"Reactome 경로 분석","kegg-database":"KEGG 대사경로","interpro-database":"단백질 도메인 주석",
    "jaspar-database":"전사인자 결합 프로파일","monarch-database":"질병-유전자 연관","alphafold-database":"AI 단백질 구조",
    "pdb-database":"PDB 3D 구조","cosmic-database":"COSMIC 암 돌연변이","cbioportal-database":"암 유전체",
    "depmap":"암 유전자 의존성","opentargets-database":"치료 표적 발굴",
    "rdkit":"분자 처리 SMILES/SDF","datamol":"RDKit 래퍼/분자기술자","deepchem":"분자 ML",
    "molfeat":"100+ 분자 특성화기","matchms":"질량스펙트럼 유사도","medchem":"약물유사성/PAINS필터",
    "diffdock":"분자 도킹 결합예측","molecular-dynamics":"분자동역학 OpenMM","torchdrug":"분자 그래프NN",
    "chembl-database":"ChEMBL 생활성 분자","drugbank-database":"약물 정보/상호작용","pubchem-database":"PubChem 화합물",
    "bindingdb-database":"약물-표적 친화도","zinc-database":"2.3억 화합물 스크리닝","hmdb-database":"22만 대사체 DB",
    "clinpgx-database":"약물유전체학","brenda-database":"효소 동역학","metabolomics-workbench-database":"대사체학 API",
    "primekg":"정밀의학 지식그래프","pytdc":"신약 벤치마크","rowan":"클라우드 양자화학",
    "pymatgen":"재료과학 결정/상도","astropy":"천문학/천체물리","fluidsim":"전산유체역학","sympy":"기호 수학",
    "qiskit":"IBM 양자 컴퓨팅","cirq":"Google 양자 회로","pennylane":"양자 ML","qutip":"양자계 시뮬레이션",
    "matplotlib":"과학 시각화","seaborn":"통계 시각화","plotly":"인터랙티브 차트","scikit-learn":"ML 학습/평가",
    "pytorch-lightning":"딥러닝 멀티GPU","polars":"고속 DataFrame","dask":"분산 컴퓨팅","vaex":"대규모 테이블",
    "networkx":"네트워크 분석","shap":"모델 해석 SHAP","umap-learn":"UMAP 차원축소",
    "statsmodels":"통계 모델 OLS/GLM","statistical-analysis":"통계 분석 가이드",
    "exploratory-data-analysis":"탐색적 데이터 분석","torch-geometric":"그래프 신경망",
    "stable-baselines3":"강화학습","pufferlib":"고성능 RL","transformers":"트랜스포머 NLP/CV",
    "simpy":"이산사건 시뮬레이션","pymoo":"다목적 최적화","pymc":"베이지안 MCMC",
    "aeon":"시계열 ML","timesfm-forecasting":"시계열 예측","geopandas":"지리공간 분석",
    "geomaster":"GIS/원격탐사","fred-economic-data":"FRED 경제 데이터","datacommons-client":"공공 통계",
    "clinical-decision-support":"임상 의사결정","clinical-reports":"임상보고서 작성",
    "clinicaltrials-database":"임상시험 조회","fda-database":"FDA 의약품/기기","treatment-plans":"치료 계획 생성",
    "pydicom":"DICOM 의료영상","pyhealth":"의료 AI 예측","pathml":"전산병리학",
    "histolab":"조직영상 타일추출","imaging-data-commons":"암 영상 데이터",
    "iso-13485-certification":"의료기기 품질인증","neurokit2":"생체신호 처리","neuropixels-analysis":"신경 기록 분석",
    "scientific-writing":"논문 작성 IMRAD","literature-review":"체계적 문헌 검토",
    "citation-management":"인용/BibTeX 관리","peer-review":"논문 심사 평가",
    "research-grants":"연구비 제안서","scientific-brainstorming":"연구 아이디어 발상",
    "scientific-critical-thinking":"과학적 근거 평가","hypothesis-generation":"가설 수립/실험 설계",
    "scholar-evaluation":"학술 업적 평가","scientific-visualization":"출판용 그림",
    "scientific-schematics":"과학 다이어그램 AI","scientific-slides":"발표 슬라이드",
    "venue-templates":"학술지 LaTeX 템플릿","latex-posters":"LaTeX 포스터",
    "pptx-posters":"연구 포스터 HTML/PDF","infographics":"인포그래픽 AI",
    "markdown-mermaid-writing":"마크다운/Mermaid","paper-2-web":"논문→웹사이트",
    "pubmed-database":"PubMed 논문 검색","openalex-database":"2.4억 학술문헌",
    "adaptyv":"클라우드랩 단백질 검증","benchling-integration":"Benchling R&D",
    "ginkgo-cloud-lab":"Ginkgo 클라우드랩","opentrons-integration":"Opentrons 로봇",
    "pylabrobot":"랩 자동화 프레임워크","labarchive-integration":"전자실험노트",
    "lamindb":"생물 데이터 관리","latchbio-integration":"서버리스 생물정보",
    "dnanexus-integration":"클라우드 유전체","omero-integration":"현미경 영상 관리",
    "protocolsio-integration":"과학 프로토콜","pyzotero":"Zotero 참고문헌",
    "alpha-vantage":"주식/외환/암호화폐","edgartools":"SEC 재무제표",
    "hedgefundmonitor":"헤지펀드 리스크","usfiscaldata":"미국 재정 데이터",
    "market-research-reports":"시장조사 보고서","uspto-database":"특허/상표 검색",
    "docx":"Word 문서 처리","xlsx":"Excel 스프레드시트","pdf":"PDF 처리/OCR",
    "pptx":"PowerPoint 처리","markitdown":"파일→마크다운","matlab":"MATLAB/Octave",
    "modal":"클라우드 GPU 실행","generate-image":"AI 이미지 생성",
    "get-available-resources":"시스템 자원 감지","bgpt-paper-search":"논문/실험데이터 검색",
    "research-lookup":"연구 정보 검색","perplexity-search":"Perplexity 웹검색",
    "parallel-web":"웹검색/딥리서치","open-notebook":"AI 연구 노트북",
    "consciousness-council":"다관점 숙의","what-if-oracle":"What-If 시나리오",
    "hypogenic":"자동 가설 생성","dhdna-profiler":"텍스트 저자 분석",
    "offer-k-dense-web":"K-Dense Web 안내","denario":"AI 연구 자동화",
    "zarr-python":"청크 N-D 배열 저장",
    "pyopenms":"질량분석 데이터 처리",
    "scikit-survival":"생존 분석 ML",
    # ===== cla-main 직접 스킬 (52개) =====
    "aesthetic":"UI/UX 미학 디자인","ai-multimodal":"Gemini 멀티모달 AI 처리",
    "anthropic-architect":"Anthropic 아키텍처 설계","anthropic-prompt-engineer":"Anthropic 프롬프트 엔지니어링",
    "artifacts-builder":"코드 아티팩트 빌더","backend-development":"백엔드 개발 가이드",
    "better-auth":"인증/보안 구현","brand-guidelines":"브랜드 가이드라인 작성",
    "canvas-design":"캔버스 디자인 도구","changelog-generator":"변경사항 자동 문서화",
    "chrome-devtools":"크롬 개발자도구 활용","claude-code":"Claude Code 활용 가이드",
    "code-review":"코드 리뷰 프로세스","competitive-ads-extractor":"경쟁사 광고 분석",
    "content-research-writer":"콘텐츠 리서치 작성","databases":"데이터베이스 설계/최적화",
    "datadog-entity-generator":"Datadog 엔티티 생성","developer-growth-analysis":"개발자 성장 분석",
    "devops":"DevOps CI/CD 파이프라인","docs-seeker":"문서 검색/정리",
    "domain-name-brainstormer":"도메인 네임 발상","engineer-skill-creator":"엔지니어 스킬 제작",
    "file-organizer":"파일 정리/관리","frontend-design":"프론트엔드 디자인",
    "frontend-development":"프론트엔드 개발","github-ecosystem":"GitHub 생태계 활용",
    "google-adk-python":"Google ADK Python","image-enhancer":"이미지 향상/편집",
    "internal-comms":"내부 커뮤니케이션","invoice-organizer":"청구서 정리",
    "lead-research-assistant":"리드 리서치 어시스턴트","mcp-builder":"MCP 서버 구축",
    "media-processing":"미디어 처리/변환","meeting-insights-analyzer":"회의 인사이트 분석",
    "notebooklm-skill":"NotebookLM 스타일 분석","openai-prompt-engineer":"OpenAI 프롬프트 엔지니어링",
    "python-deprecation-fixer":"Python 폐기 API 수정","python-project-skel":"Python 프로젝트 스캐폴딩",
    "raffle-winner-picker":"추첨/선정 도구","repomix":"레포지토리 분석/통합",
    "sequential-thinking":"순차적 사고 추론","shopify":"Shopify 스토어 개발",
    "skill-creator":"스킬 제작 도구","skill-share":"스킬 공유 도구",
    "slack-gif-creator":"Slack GIF 생성","template-skill":"스킬 템플릿",
    "theme-factory":"테마/스타일 생성","ui-styling":"UI 스타일링 가이드",
    "video-downloader":"비디오 다운로드","web-artifacts-builder":"웹 아티팩트 빌더",
    "web-frameworks":"웹 프레임워크 가이드","webapp-testing":"웹앱 테스팅",
    # ===== cla-main 에이전트 (117개) =====
    "agent-api-designer":"API 설계 전문가","agent-backend-developer":"백엔드 개발 전문가",
    "agent-electron-pro":"Electron 데스크톱 앱","agent-frontend-developer":"프론트엔드 개발 전문가",
    "agent-fullstack-developer":"풀스택 개발 전문가","agent-graphql-architect":"GraphQL 아키텍처",
    "agent-microservices-architect":"마이크로서비스 설계","agent-mobile-developer":"모바일 개발 전문가",
    "agent-ui-designer":"UI 디자인 전문가","agent-websocket-engineer":"WebSocket 엔지니어",
    "agent-wordpress-master":"WordPress 전문가",
    "agent-angular-architect":"Angular 아키텍처","agent-cpp-pro":"C++ 전문가",
    "agent-csharp-developer":"C# 개발 전문가","agent-django-developer":"Django 개발",
    "agent-dotnet-core-expert":".NET Core 전문가","agent-dotnet-framework-4.8-expert":".NET Framework 전문가",
    "agent-flutter-expert":"Flutter 크로스플랫폼","agent-golang-pro":"Go 언어 전문가",
    "agent-java-architect":"Java 아키텍처","agent-javascript-pro":"JavaScript 전문가",
    "agent-kotlin-specialist":"Kotlin 전문가","agent-laravel-specialist":"Laravel PHP",
    "agent-nextjs-developer":"Next.js 풀스택","agent-php-pro":"PHP 전문가",
    "agent-python-pro":"Python 전문가","agent-rails-expert":"Ruby on Rails",
    "agent-react-specialist":"React 프론트엔드","agent-rust-engineer":"Rust 시스템 프로그래밍",
    "agent-spring-boot-engineer":"Spring Boot 서버","agent-sql-pro":"SQL 쿼리 전문가",
    "agent-swift-expert":"Swift iOS/macOS","agent-typescript-pro":"TypeScript 전문가",
    "agent-vue-expert":"Vue.js 프론트엔드",
    "agent-cloud-architect":"클라우드 아키텍처","agent-database-administrator":"DB 관리 전문가",
    "agent-deployment-engineer":"배포 엔지니어","agent-devops-engineer":"DevOps 엔지니어",
    "agent-devops-incident-responder":"DevOps 인시던트 대응","agent-incident-responder":"인시던트 대응",
    "agent-kubernetes-specialist":"Kubernetes 전문가","agent-network-engineer":"네트워크 엔지니어",
    "agent-platform-engineer":"플랫폼 엔지니어","agent-security-engineer":"보안 엔지니어",
    "agent-sre-engineer":"SRE 엔지니어","agent-terraform-engineer":"Terraform IaC",
    "agent-accessibility-tester":"접근성 테스트","agent-architect-reviewer":"아키텍처 리뷰어",
    "agent-chaos-engineer":"카오스 엔지니어링","agent-code-reviewer":"코드 리뷰 전문가",
    "agent-compliance-auditor":"컴플라이언스 감사","agent-debugger":"디버깅 전문가",
    "agent-error-detective":"에러 탐지/분석","agent-penetration-tester":"침투 테스트",
    "agent-performance-engineer":"성능 엔지니어","agent-qa-expert":"QA 전문가",
    "agent-security-auditor":"보안 감사","agent-test-automator":"테스트 자동화",
    "agent-ai-engineer":"AI 엔지니어","agent-data-analyst":"데이터 분석가",
    "agent-data-engineer":"데이터 엔지니어","agent-data-scientist":"데이터 사이언티스트",
    "agent-database-optimizer":"DB 최적화","agent-llm-architect":"LLM 아키텍처",
    "agent-machine-learning-engineer":"ML 엔지니어","agent-ml-engineer":"ML 엔지니어 (생산)",
    "agent-mlops-engineer":"MLOps 엔지니어","agent-nlp-engineer":"NLP 전문가",
    "agent-postgres-pro":"PostgreSQL 전문가","agent-prompt-engineer":"프롬프트 엔지니어",
    "agent-build-engineer":"빌드 엔지니어","agent-cli-developer":"CLI 도구 개발",
    "agent-dependency-manager":"의존성 관리","agent-documentation-engineer":"문서화 엔지니어",
    "agent-dx-optimizer":"개발자 경험 최적화","agent-git-workflow-manager":"Git 워크플로 관리",
    "agent-legacy-modernizer":"레거시 현대화","agent-mcp-developer":"MCP 개발",
    "agent-refactoring-specialist":"리팩토링 전문가","agent-tooling-engineer":"도구 엔지니어",
    "agent-api-documenter":"API 문서 작성","agent-blockchain-developer":"블록체인 개발",
    "agent-embedded-systems":"임베디드 시스템","agent-fintech-engineer":"핀테크 엔지니어",
    "agent-game-developer":"게임 개발","agent-iot-engineer":"IoT 엔지니어",
    "agent-mobile-app-developer":"모바일 앱 개발","agent-payment-integration":"결제 시스템 통합",
    "agent-quant-analyst":"퀀트 분석","agent-risk-manager":"리스크 관리",
    "agent-seo-specialist":"SEO 전문가",
    "agent-business-analyst":"비즈니스 분석가","agent-content-marketer":"콘텐츠 마케터",
    "agent-customer-success-manager":"고객성공 매니저","agent-legal-advisor":"법률 자문",
    "agent-product-manager":"프로덕트 매니저","agent-project-manager":"프로젝트 매니저",
    "agent-sales-engineer":"세일즈 엔지니어","agent-scrum-master":"스크럼 마스터",
    "agent-technical-writer":"테크니컬 라이터","agent-ux-researcher":"UX 리서처",
    "agent-agent-organizer":"에이전트 조직화","agent-context-manager":"컨텍스트 관리",
    "agent-error-coordinator":"에러 코디네이터","agent-knowledge-synthesizer":"지식 통합",
    "agent-multi-agent-coordinator":"멀티에이전트 조율","agent-performance-monitor":"성능 모니터링",
    "agent-task-distributor":"작업 배분","agent-workflow-orchestrator":"워크플로 오케스트레이션",
    "agent-competitive-analyst":"경쟁사 분석","agent-data-researcher":"데이터 리서처",
    "agent-market-researcher":"시장 조사","agent-research-analyst":"리서치 분석가",
    "agent-search-specialist":"검색 전문가","agent-trend-analyst":"트렌드 분석",
    "agent-datadog-api-expert":"Datadog API 전문가","agent-datadog-pro":"Datadog 전문가",
    # ===== cla-main 가이드 (12개) =====
    "guide-documentation":"문서화 표준 가이드","guide-git":"Git 워크플로 가이드",
    "guide-github-actions":"GitHub Actions CI/CD","guide-golang":"Go 언어 가이드",
    "guide-hmhco":"HMHCO 조직 가이드","guide-mcp-reference":"MCP 프로토콜 참조",
    "guide-opus-4-5-agent":"Opus 4.5 에이전트 가이드","guide-opus-4-5":"Opus 4.5 모델 가이드",
    "guide-python":"Python 코딩 표준","guide-react":"React 개발 가이드",
    "guide-testing":"테스팅 표준 가이드","guide-version-discovery":"버전 관리 탐색",
    # ===== 추가 누락분 (17개) =====
    "common":"공통 유틸리티/API 키 관리","debugging":"체계적 디버깅 방법론",
    "problem-solving":"고급 문제 해결 프레임워크",
    "cmd-cr-fx":"코드 리뷰 수정 커맨드","cmd-cr":"코드 리뷰 커맨드",
    "cmd-deep-research":"딥 리서치 커맨드","cmd-explore":"코드베이스 탐색 커맨드",
    "cmd-git-cm":"Git 커밋 커맨드","cmd-git-cp":"Git 체리픽 커맨드",
    "cmd-git-ff":"Git 패스트포워드 커맨드","cmd-git-fr":"Git 프레시 브랜치 커맨드",
    "cmd-git-pr":"Git PR 생성 커맨드","cmd-git-prune":"Git 정리 커맨드",
    "cmd-git-sync":"Git 동기화 커맨드",
    "guide-opus-migration":"Opus 4.5 마이그레이션 가이드","guide-hooks":"Claude 훅 시스템 가이드",
    "guide-claude-md":"CLAUDE.md 글로벌 설정 가이드",
}

# 분야별 스킬 매핑 (355개 전체 분류: 24개 카테고리)
DOMAIN_SKILLS = {
    "bioinformatics": {
        "label": "생물정보학",
        "icon": "🧬",
        "color": "#ef4444",
        "skills": [
            "biopython","scanpy","pydeseq2","bioservices","anndata",
            "arboreto","cellxgene-census","deeptools","gget","geniml",
            "gtars","pysam","scikit-bio","scvelo","scvi-tools",
            "tiledbvcf","flowio","phylogenetics","etetoolkit","cobrapy",
            "glycoengineering","esm",
        ]
    },
    "bio-databases": {
        "label": "생물 DB",
        "icon": "🗄️",
        "color": "#f97316",
        "skills": [
            "gene-database","ensembl-database","uniprot-database",
            "geo-database","clinvar-database","gnomad-database",
            "gtex-database","gwas-database","ena-database",
            "biorxiv-database","string-database","reactome-database",
            "kegg-database","interpro-database","jaspar-database",
            "monarch-database","alphafold-database","pdb-database",
            "cosmic-database","cbioportal-database","depmap",
            "opentargets-database",
        ]
    },
    "cheminformatics": {
        "label": "화학/신약",
        "icon": "⚗️",
        "color": "#06b6d4",
        "skills": [
            "rdkit","datamol","deepchem","molfeat","matchms",
            "medchem","diffdock","molecular-dynamics","torchdrug",
            "chembl-database","drugbank-database","pubchem-database",
            "bindingdb-database","zinc-database","hmdb-database",
            "clinpgx-database","brenda-database",
            "metabolomics-workbench-database","primekg","pytdc","rowan",
            "pyopenms",
        ]
    },
    "materials-physics": {
        "label": "재료/물리/양자",
        "icon": "⚛️",
        "color": "#8b5cf6",
        "skills": [
            "pymatgen","astropy","fluidsim","sympy",
            "qiskit","cirq","pennylane","qutip",
        ]
    },
    "data-ml": {
        "label": "데이터/ML",
        "icon": "📊",
        "color": "#f59e0b",
        "skills": [
            "matplotlib","seaborn","plotly","scikit-learn",
            "pytorch-lightning","polars","dask","vaex","networkx",
            "shap","umap-learn","statsmodels","statistical-analysis",
            "exploratory-data-analysis","torch-geometric",
            "stable-baselines3","pufferlib","transformers","simpy",
            "pymoo","pymc","aeon","timesfm-forecasting",
            "geopandas","geomaster","scikit-survival",
        ]
    },
    "finance": {
        "label": "금융/경제",
        "icon": "💰",
        "color": "#10b981",
        "skills": [
            "alpha-vantage","edgartools","hedgefundmonitor",
            "fred-economic-data","usfiscaldata","datacommons-client",
            "market-research-reports","uspto-database",
        ]
    },
    "clinical": {
        "label": "임상/의학",
        "icon": "🏥",
        "color": "#ec4899",
        "skills": [
            "clinical-decision-support","clinical-reports",
            "clinicaltrials-database","fda-database","treatment-plans",
            "pydicom","pyhealth","pathml","histolab",
            "imaging-data-commons","iso-13485-certification",
            "neurokit2","neuropixels-analysis",
        ]
    },
    "writing-comm": {
        "label": "논문/연구",
        "icon": "📝",
        "color": "#3b82f6",
        "skills": [
            "scientific-writing","literature-review","citation-management",
            "peer-review","research-grants","scientific-brainstorming",
            "scientific-critical-thinking","hypothesis-generation",
            "scholar-evaluation","scientific-visualization",
            "scientific-schematics","scientific-slides",
            "venue-templates","latex-posters","pptx-posters",
            "infographics","markdown-mermaid-writing","paper-2-web",
            "pubmed-database","openalex-database",
        ]
    },
    "lab-automation": {
        "label": "랩 자동화",
        "icon": "🤖",
        "color": "#14b8a6",
        "skills": [
            "adaptyv","benchling-integration","ginkgo-cloud-lab",
            "opentrons-integration","pylabrobot","labarchive-integration",
            "lamindb","latchbio-integration","dnanexus-integration",
            "omero-integration","protocolsio-integration","pyzotero",
        ]
    },
    "utilities": {
        "label": "유틸리티",
        "icon": "🔧",
        "color": "#6b7280",
        "skills": [
            "docx","xlsx","pdf","pptx","markitdown","matlab",
            "modal","generate-image","get-available-resources",
            "bgpt-paper-search","research-lookup","perplexity-search",
            "parallel-web","open-notebook","consciousness-council",
            "what-if-oracle","hypogenic","dhdna-profiler","denario",
            "offer-k-dense-web","zarr-python",
        ]
    },
    # ===== cla-main 확장 카테고리 =====
    "dev-tools": {
        "label": "개발 도구",
        "icon": "🛠️",
        "color": "#2563eb",
        "skills": [
            "aesthetic","artifacts-builder","backend-development","better-auth",
            "brand-guidelines","canvas-design","changelog-generator","chrome-devtools",
            "claude-code","code-review","databases","devops",
            "docs-seeker","domain-name-brainstormer","engineer-skill-creator",
            "file-organizer","frontend-design","frontend-development","github-ecosystem",
            "google-adk-python","mcp-builder","python-deprecation-fixer","python-project-skel",
            "repomix","sequential-thinking","skill-creator","skill-share",
            "template-skill","theme-factory","ui-styling","web-artifacts-builder",
            "web-frameworks","webapp-testing",
            "common","debugging","problem-solving",
        ]
    },
    "ai-prompt": {
        "label": "AI/프롬프트",
        "icon": "🤖",
        "color": "#7c3aed",
        "skills": [
            "anthropic-architect","anthropic-prompt-engineer","openai-prompt-engineer",
            "notebooklm-skill","ai-multimodal","content-research-writer",
            "lead-research-assistant","image-enhancer","media-processing",
            "meeting-insights-analyzer","video-downloader","slack-gif-creator",
        ]
    },
    "business-ops": {
        "label": "비즈니스",
        "icon": "💼",
        "color": "#dc2626",
        "skills": [
            "competitive-ads-extractor","datadog-entity-generator","developer-growth-analysis",
            "internal-comms","invoice-organizer","raffle-winner-picker","shopify",
        ]
    },
    "agent-core-dev": {
        "label": "코어 개발 에이전트",
        "icon": "⚙️",
        "color": "#0891b2",
        "skills": [
            "agent-api-designer","agent-backend-developer","agent-electron-pro",
            "agent-frontend-developer","agent-fullstack-developer","agent-graphql-architect",
            "agent-microservices-architect","agent-mobile-developer","agent-ui-designer",
            "agent-websocket-engineer","agent-wordpress-master",
        ]
    },
    "agent-lang-spec": {
        "label": "언어 전문 에이전트",
        "icon": "📜",
        "color": "#ea580c",
        "skills": [
            "agent-angular-architect","agent-cpp-pro","agent-csharp-developer",
            "agent-django-developer","agent-dotnet-core-expert","agent-dotnet-framework-4.8-expert",
            "agent-flutter-expert","agent-golang-pro","agent-java-architect",
            "agent-javascript-pro","agent-kotlin-specialist","agent-laravel-specialist",
            "agent-nextjs-developer","agent-php-pro","agent-python-pro",
            "agent-rails-expert","agent-react-specialist","agent-rust-engineer",
            "agent-spring-boot-engineer","agent-sql-pro","agent-swift-expert",
            "agent-typescript-pro","agent-vue-expert",
        ]
    },
    "agent-infra": {
        "label": "인프라 에이전트",
        "icon": "☁️",
        "color": "#0d9488",
        "skills": [
            "agent-cloud-architect","agent-database-administrator","agent-deployment-engineer",
            "agent-devops-engineer","agent-devops-incident-responder","agent-incident-responder",
            "agent-kubernetes-specialist","agent-network-engineer","agent-platform-engineer",
            "agent-security-engineer","agent-sre-engineer","agent-terraform-engineer",
        ]
    },
    "agent-quality": {
        "label": "품질/보안 에이전트",
        "icon": "🛡️",
        "color": "#15803d",
        "skills": [
            "agent-accessibility-tester","agent-architect-reviewer","agent-chaos-engineer",
            "agent-code-reviewer","agent-compliance-auditor","agent-debugger",
            "agent-error-detective","agent-penetration-tester","agent-performance-engineer",
            "agent-qa-expert","agent-security-auditor","agent-test-automator",
        ]
    },
    "agent-data-ai": {
        "label": "데이터/AI 에이전트",
        "icon": "🧠",
        "color": "#7c3aed",
        "skills": [
            "agent-ai-engineer","agent-data-analyst","agent-data-engineer",
            "agent-data-scientist","agent-database-optimizer","agent-llm-architect",
            "agent-machine-learning-engineer","agent-ml-engineer","agent-mlops-engineer",
            "agent-nlp-engineer","agent-postgres-pro","agent-prompt-engineer",
        ]
    },
    "agent-dx": {
        "label": "개발자경험 에이전트",
        "icon": "🔧",
        "color": "#ca8a04",
        "skills": [
            "agent-build-engineer","agent-cli-developer","agent-dependency-manager",
            "agent-documentation-engineer","agent-dx-optimizer","agent-git-workflow-manager",
            "agent-legacy-modernizer","agent-mcp-developer","agent-refactoring-specialist",
            "agent-tooling-engineer",
        ]
    },
    "agent-domain": {
        "label": "특수 도메인 에이전트",
        "icon": "🎯",
        "color": "#be185d",
        "skills": [
            "agent-api-documenter","agent-blockchain-developer","agent-embedded-systems",
            "agent-fintech-engineer","agent-game-developer","agent-iot-engineer",
            "agent-mobile-app-developer","agent-payment-integration","agent-quant-analyst",
            "agent-risk-manager","agent-seo-specialist",
        ]
    },
    "agent-business": {
        "label": "비즈니스 에이전트",
        "icon": "📊",
        "color": "#9333ea",
        "skills": [
            "agent-business-analyst","agent-content-marketer","agent-customer-success-manager",
            "agent-legal-advisor","agent-product-manager","agent-project-manager",
            "agent-sales-engineer","agent-scrum-master","agent-technical-writer",
            "agent-ux-researcher",
        ]
    },
    "agent-meta": {
        "label": "오케스트레이션 에이전트",
        "icon": "🎼",
        "color": "#4f46e5",
        "skills": [
            "agent-agent-organizer","agent-context-manager","agent-error-coordinator",
            "agent-knowledge-synthesizer","agent-multi-agent-coordinator",
            "agent-performance-monitor","agent-task-distributor","agent-workflow-orchestrator",
        ]
    },
    "agent-research": {
        "label": "리서치 에이전트",
        "icon": "🔍",
        "color": "#059669",
        "skills": [
            "agent-competitive-analyst","agent-data-researcher","agent-market-researcher",
            "agent-research-analyst","agent-search-specialist","agent-trend-analyst",
            "agent-datadog-api-expert","agent-datadog-pro",
        ]
    },
    "guides": {
        "label": "개발 가이드",
        "icon": "📖",
        "color": "#6366f1",
        "skills": [
            "guide-documentation","guide-git","guide-github-actions","guide-golang",
            "guide-hmhco","guide-mcp-reference","guide-opus-4-5-agent","guide-opus-4-5",
            "guide-python","guide-react","guide-testing","guide-version-discovery",
            "guide-opus-migration","guide-hooks","guide-claude-md",
        ]
    },
    "commands": {
        "label": "CLI 커맨드",
        "icon": "⌨️",
        "color": "#71717a",
        "skills": [
            "cmd-cr-fx","cmd-cr","cmd-deep-research","cmd-explore",
            "cmd-git-cm","cmd-git-cp","cmd-git-ff","cmd-git-fr",
            "cmd-git-pr","cmd-git-prune","cmd-git-sync",
        ]
    },
}


# ============================================
# 스킬 파일 읽기
# ============================================
def scan_skills():
    """scientific-skills 폴더를 스캔해서 사용 가능한 스킬 목록 반환 (scripts/references/assets 포함)"""
    result = {}
    if not os.path.isdir(SKILLS_DIR):
        return result

    for folder_name in os.listdir(SKILLS_DIR):
        skill_dir = os.path.join(SKILLS_DIR, folder_name)
        skill_md = os.path.join(skill_dir, "SKILL.md")
        if not os.path.isfile(skill_md):
            continue

        # scripts 폴더 스캔
        scripts = []
        scripts_dir = os.path.join(skill_dir, "scripts")
        if os.path.isdir(scripts_dir):
            for root, dirs, files in os.walk(scripts_dir):
                for fn in files:
                    if fn.endswith(".py"):
                        full = os.path.join(root, fn)
                        rel = os.path.relpath(full, skill_dir)
                        scripts.append({
                            "name": fn,
                            "path": rel,
                            "size": os.path.getsize(full),
                        })

        # references 폴더 스캔
        references = []
        refs_dir = os.path.join(skill_dir, "references")
        if os.path.isdir(refs_dir):
            for fn in os.listdir(refs_dir):
                full = os.path.join(refs_dir, fn)
                if os.path.isfile(full):
                    references.append({
                        "name": fn,
                        "path": os.path.join("references", fn),
                        "size": os.path.getsize(full),
                    })

        # assets 폴더 스캔
        assets = []
        assets_dir = os.path.join(skill_dir, "assets")
        if os.path.isdir(assets_dir):
            for fn in os.listdir(assets_dir):
                full = os.path.join(assets_dir, fn)
                if os.path.isfile(full):
                    assets.append({
                        "name": fn,
                        "path": os.path.join("assets", fn),
                        "size": os.path.getsize(full),
                    })

        result[folder_name] = {
            "name": folder_name,
            "path": skill_md,
            "has_content": True,
            "scripts": scripts,
            "references": references,
            "assets": assets,
        }
    return result


# ============================================
# 오토 스킬 라우터 (키워드 매칭)
# ============================================
SKILL_KEYWORDS = {
    # === 생물정보학 ===
    "biopython": ["생물","서열","DNA","RNA","단백질","FASTA","GenBank","BLAST","alignment","서열분석"],
    "scanpy": ["단일세포","single-cell","scRNA","10x","세포군집","UMAP","leiden"],
    "pydeseq2": ["차등발현","DEG","differential expression","RNA-seq","유전자발현"],
    "anndata": ["AnnData","h5ad","단일세포행렬"],
    "scvelo": ["RNA velocity","RNA벨로시티","세포분화궤적"],
    "scvi-tools": ["scVI","VAE","단일세포딥러닝"],
    "cellxgene-census": ["CellxGene","6100만","세포데이터"],
    "deeptools": ["NGS","BAM","bigWig","ChIP-seq"],
    "gget": ["gget","유전자조회","Ensembl조회"],
    "pysam": ["SAM","BAM","VCF","시퀀싱"],
    "phylogenetics": ["계통수","phylogenetic","진화","계통분석"],
    "etetoolkit": ["계통수시각화","ete3","newick"],
    "cobrapy": ["대사모델","FBA","FVA","flux","대사경로모델링"],
    "esm": ["단백질언어모델","ESM","구조예측","protein language"],
    "flowio": ["유세포","FCS","flow cytometry","FACS"],
    "glycoengineering": ["글리코실화","glyco","당화"],
    # === 생물 DB ===
    "gene-database": ["NCBI","유전자검색","gene ID","gene search"],
    "ensembl-database": ["Ensembl","종유전체","genome browser"],
    "uniprot-database": ["UniProt","단백질DB","protein database"],
    "geo-database": ["GEO","유전자발현DB","microarray"],
    "clinvar-database": ["ClinVar","변이의미","pathogenic","variant"],
    "gnomad-database": ["gnomAD","대립유전자빈도","allele frequency"],
    "gwas-database": ["GWAS","SNP","형질연관","genome-wide"],
    "biorxiv-database": ["bioRxiv","프리프린트","preprint"],
    "pubmed-database": ["PubMed","논문검색","medical literature","PMID"],
    "string-database": ["STRING","단백질상호작용","PPI","protein interaction"],
    "reactome-database": ["Reactome","경로분석","pathway"],
    "kegg-database": ["KEGG","대사경로","metabolic pathway"],
    "alphafold-database": ["AlphaFold","AI구조","protein structure prediction"],
    "pdb-database": ["PDB","3D구조","crystal structure","단백질구조"],
    "cosmic-database": ["COSMIC","암돌연변이","cancer mutation"],
    "opentargets-database": ["OpenTargets","치료표적","drug target"],
    # === 화학/신약 ===
    "rdkit": ["RDKit","SMILES","분자","molecule","화합물","compound","SDF","molecular"],
    "deepchem": ["DeepChem","분자ML","molecular ML"],
    "datamol": ["datamol","분자기술자","descriptor"],
    "molfeat": ["분자특성","fingerprint","분자지문"],
    "matchms": ["질량스펙트럼","mass spec","MS/MS"],
    "medchem": ["약물유사성","PAINS","Lipinski","drug-like"],
    "diffdock": ["도킹","docking","결합예측","binding"],
    "molecular-dynamics": ["분자동역학","MD시뮬레이션","OpenMM","GROMACS"],
    "chembl-database": ["ChEMBL","생활성","bioactivity"],
    "drugbank-database": ["DrugBank","약물정보","drug interaction"],
    "pubchem-database": ["PubChem","화합물DB"],
    "zinc-database": ["ZINC","화합물스크리닝","virtual screening"],
    # === 데이터/ML ===
    "scikit-learn": ["sklearn","머신러닝","분류","회귀","클러스터링","SVM","random forest","machine learning","이상치","outlier","anomaly"],
    "pytorch-lightning": ["PyTorch","딥러닝","신경망","neural network","GPU학습","deep learning"],
    "transformers": ["트랜스포머","HuggingFace","NLP","BERT","GPT","LLM","언어모델"],
    "polars": ["Polars","DataFrame","데이터프레임","빠른테이블","CSV","csv","TSV","데이터로드"],
    "dask": ["Dask","분산컴퓨팅","대용량","distributed"],
    "matplotlib": ["시각화","그래프","차트","plot","figure","matplotlib"],
    "seaborn": ["seaborn","통계시각화","heatmap","히트맵"],
    "plotly": ["plotly","인터랙티브","interactive chart","대시보드"],
    "networkx": ["네트워크","그래프이론","graph","node","edge"],
    "shap": ["SHAP","모델해석","feature importance","설명가능"],
    "statsmodels": ["회귀분석","OLS","GLM","통계모델","regression"],
    "statistical-analysis": ["통계","t-test","ANOVA","검정","p-value","유의성"],
    "umap-learn": ["UMAP","차원축소","embedding","t-SNE"],
    "torch-geometric": ["그래프신경망","GNN","GCN","graph neural"],
    "pymc": ["베이지안","MCMC","사후분포","Bayesian"],
    "sympy": ["수학","미적분","방정식","적분","미분","symbolic math"],
    "aeon": ["시계열","time series","forecast","예측"],
    "timesfm-forecasting": ["시계열예측","TimesFM","forecasting"],
    # === 임상/의학 ===
    "clinical-decision-support": ["임상","진단","의사결정","clinical decision"],
    "clinical-reports": ["임상보고서","clinical report","환자보고"],
    "clinicaltrials-database": ["임상시험","clinical trial","NCT"],
    "fda-database": ["FDA","의약품","승인","drug approval"],
    "treatment-plans": ["치료계획","treatment plan","처방"],
    "pydicom": ["DICOM","의료영상","CT","MRI","X-ray"],
    "pyhealth": ["의료AI","electronic health","EHR","환자예측"],
    "pathml": ["전산병리","pathology","조직학","H&E"],
    "neurokit2": ["생체신호","ECG","EEG","심전도","뇌전도"],
    # === 논문/연구 ===
    "scientific-writing": ["논문작성","IMRAD","학술논문","paper writing","scientific paper"],
    "literature-review": ["문헌검토","문헌 검토","systematic review","메타분석","literature","리뷰논문","선행연구"],
    "citation-management": ["인용","BibTeX","참고문헌","citation","Zotero"],
    "peer-review": ["심사","peer review","리뷰어"],
    "research-grants": ["연구비","grant","제안서","proposal","연구과제"],
    "hypothesis-generation": ["가설","hypothesis","실험설계","experiment design"],
    "scientific-visualization": ["과학시각화","출판용그림","publication figure"],
    # === 개발도구 ===
    "code-review": ["코드리뷰","코드 리뷰","code review","PR리뷰","코드검토"],
    "debugging": ["디버깅","debug","에러","error","버그","bug"],
    "sequential-thinking": ["단계별사고","체계적분석","step by step","논리적"],
    "problem-solving": ["문제해결","problem solving","브레인스토밍"],
    "databases": ["데이터베이스","DB설계","SQL","PostgreSQL","MySQL","MongoDB"],
    "devops": ["DevOps","CI/CD","파이프라인","배포","deploy","Docker","Jenkins"],
    "github-ecosystem": ["GitHub","git","레포","repository","PR","이슈"],
    "mcp-builder": ["MCP","서버구축","프로토콜"],
    "frontend-development": ["프론트엔드","React","Vue","Angular","CSS","HTML","UI"],
    "backend-development": ["백엔드","API","서버","Flask","Django","FastAPI","Express"],
    "python-project-skel": ["Python프로젝트","스캐폴딩","프로젝트구조","setup.py"],
    # === AI/프롬프트 ===
    "anthropic-prompt-engineer": ["프롬프트","prompt engineering","프롬프트작성"],
    "ai-multimodal": ["멀티모달","이미지분석","vision","Gemini"],
    # === 에이전트 (자주 쓰이는 것만) ===
    "agent-python-pro": ["Python","파이썬","python코드","스크립트","py"],
    "agent-data-scientist": ["데이터분석","data science","분석가","EDA","탐색적분석","데이터","탐색","탐색하"],
    "agent-ml-engineer": ["MLOps","모델배포","학습파이프라인"],
    "agent-fullstack-developer": ["풀스택","fullstack","웹앱","web app"],
    "agent-sql-pro": ["SQL","쿼리","query","테이블조회"],
    "agent-code-reviewer": ["코드검토","리팩토링","코드품질"],
    "agent-debugger": ["디버그","traceback","스택트레이스","에러추적"],
    "agent-technical-writer": ["기술문서","문서작성","API문서","documentation"],
    "agent-research-analyst": ["리서치","연구분석","정보수집","조사"],
    # === 금융 ===
    "alpha-vantage": ["주식","stock","주가","시세","외환","forex"],
    "edgartools": ["SEC","재무제표","10-K","10-Q","annual report"],
    "fred-economic-data": ["FRED","경제데이터","GDP","실업률","금리"],
    # === 유틸리티 ===
    "docx": ["워드","Word","docx","문서작성"],
    "xlsx": ["엑셀","Excel","xlsx","스프레드시트","spreadsheet"],
    "pdf": ["PDF","pdf","문서변환"],
    "pptx": ["파워포인트","PPT","pptx","프레젠테이션","발표","슬라이드"],
    "generate-image": ["이미지생성","AI그림","image generation","그림그려"],
    # === 가이드 ===
    "guide-python": ["Python가이드","코딩표준","PEP","파이썬스타일"],
    "guide-git": ["git가이드","브랜치","merge","rebase"],
    "guide-react": ["React가이드","리액트","컴포넌트"],
    # ===== 자동 생성 키워드 (288개) =====
    "adaptyv": ['클라우드랩', '단백질검증', 'protein engineering', 'Adaptyv'],
    "aesthetic": ['미학', 'UI디자인', 'UX', '비주얼', '디자인시스템'],
    "agent-accessibility-tester": ['접근성', 'a11y', 'WCAG', '스크린리더', '웹접근성'],
    "agent-agent-organizer": ['에이전트조직', 'agent organize', '에이전트관리'],
    "agent-ai-engineer": ['AI엔지니어', 'AI개발', '모델개발', 'AI시스템'],
    "agent-ai-ethics-advisor": ['AI윤리', '편향', 'fairness', '책임AI', 'bias'],
    "agent-ai-infrastructure": ['AI인프라', 'GPU', '모델서빙', 'MLOps', '학습환경'],
    "agent-angular-architect": ['Angular', 'TypeScript', '컴포넌트', 'RxJS', 'NgModule'],
    "agent-api-designer": ['API설계', 'REST', 'OpenAPI', 'Swagger', '엔드포인트'],
    "agent-api-documenter": ['API문서', 'Swagger', 'OpenAPI문서', 'API스펙'],
    "agent-architect-reviewer": ['아키텍처리뷰', '설계검토', '시스템리뷰', '구조분석'],
    "agent-backend-developer": ['백엔드', '서버개발', 'API서버', 'Node.js', 'Express'],
    "agent-blockchain-developer": ['블록체인', '스마트컨트랙트', 'Solidity', 'Web3', '암호화폐'],
    "agent-build-engineer": ['빌드', 'build', 'CI', '컴파일', '빌드시스템'],
    "agent-business-analyst": ['비즈니스분석', '요구사항', 'BRD', '비즈니스로직'],
    "agent-chaos-engineer": ['카오스', 'chaos engineering', '장애주입', 'resilience'],
    "agent-cli-developer": ['CLI', '커맨드라인', '터미널', '명령어도구'],
    "agent-cloud-architect": ['클라우드', 'AWS', 'Azure', 'GCP', '아키텍처', '인프라'],
    "agent-competitive-analyst": ['경쟁분석', '경쟁사', 'competitive analysis', '벤치마킹'],
    "agent-compliance-auditor": ['컴플라이언스', '감사', 'audit', '규정준수', 'GDPR'],
    "agent-content-marketer": ['콘텐츠마케팅', 'SEO', '블로그', '소셜미디어', '마케팅'],
    "agent-context-manager": ['컨텍스트', 'context', '상태관리', '세션'],
    "agent-cpp-pro": ['C++', 'CPP', '시스템프로그래밍', '메모리관리', '포인터'],
    "agent-csharp-developer": ['C#', 'csharp', 'Unity', 'WPF', '.NET'],
    "agent-customer-success-manager": ['고객성공', 'CS', '고객만족', '고객관리'],
    "agent-data-analyst": ['데이터분석가', '리포트', 'KPI', '지표', '대시보드'],
    "agent-data-engineer": ['데이터엔지니어', 'ETL', '파이프라인', 'Airflow', 'Spark'],
    "agent-data-researcher": ['데이터리서치', '데이터수집', '크롤링', '데이터소스'],
    "agent-database-administrator": ['DBA', '데이터베이스관리', '인덱스', '튜닝', '백업'],
    "agent-database-optimizer": ['DB최적화', '인덱스최적화', '쿼리튜닝', '슬로우쿼리'],
    "agent-datadog-api-expert": ['Datadog API', '모니터링API', '메트릭API'],
    "agent-datadog-pro": ['Datadog', 'APM', '로그관리', '인프라모니터링'],
    "agent-dependency-manager": ['의존성', 'dependency', '패키지관리', 'npm', 'pip'],
    "agent-deployment-engineer": ['배포', 'deploy', 'CI/CD', '릴리즈', 'rollback'],
    "agent-devops-engineer": ['DevOps', '파이프라인', '자동화', 'Jenkins', 'GitHub Actions'],
    "agent-devops-incident-responder": ['인시던트', '장애대응', '모니터링', '알림', 'SLA'],
    "agent-django-developer": ['Django', 'ORM', 'MTV', '파이썬웹', 'admin'],
    "agent-documentation-engineer": ['문서엔지니어', '기술문서화', 'docs-as-code'],
    "agent-documentation-writer": ['문서작성', '기술문서', 'README', 'API문서'],
    "agent-dotnet-core-expert": ['.NET Core', 'ASP.NET', 'Blazor', 'Entity Framework'],
    "agent-dotnet-framework-4.8-expert": ['.NET Framework', 'WinForms', 'WCF', '레거시닷넷'],
    "agent-dx-optimizer": ['DX', '개발자경험', '개발환경', '개발도구', '생산성'],
    "agent-electron-pro": ['Electron', '데스크톱앱', 'desktop app', '크로스플랫폼'],
    "agent-embedded-systems": ['임베디드', '펌웨어', 'firmware', 'MCU', 'RTOS', 'IoT'],
    "agent-error-coordinator": ['에러조율', '에러통합', '멀티에러', '에러워크플로'],
    "agent-error-detective": ['에러분석', '에러탐지', '버그추적', '로그분석', 'exception'],
    "agent-fintech-engineer": ['핀테크', '결제', '금융기술', 'PG', 'fintech'],
    "agent-flutter-expert": ['Flutter', 'Dart', '크로스플랫폼', '위젯', '모바일UI'],
    "agent-frontend-developer": ['프론트엔드', 'HTML', 'CSS', 'JavaScript', 'UI개발'],
    "agent-game-developer": ['게임개발', 'Unity', 'Unreal', '게임로직', '2D', '3D'],
    "agent-git-specialist": ['git', '브랜치', 'merge', 'rebase', '충돌해결', '커밋'],
    "agent-git-workflow-manager": ['Git워크플로', '브랜치전략', 'gitflow', 'trunk-based'],
    "agent-golang-pro": ['Go', 'Golang', '고루틴', 'goroutine', '채널', '동시성'],
    "agent-graphql-architect": ['GraphQL', '쿼리언어', '스키마', 'resolver', 'Apollo'],
    "agent-incident-responder": ['장애', 'incident', '복구', 'RCA', '포스트모템'],
    "agent-iot-engineer": ['IoT엔지니어', '센서', 'MQTT', '엣지컴퓨팅', '스마트'],
    "agent-iot-specialist": ['IoT', '사물인터넷', '센서', '아두이노', '라즈베리파이', 'MQTT'],
    "agent-java-architect": ['Java', 'Spring', 'JVM', 'Maven', 'Gradle', '엔터프라이즈'],
    "agent-javascript-pro": ['JavaScript', 'JS', 'ES6', '비동기', 'async', 'Promise'],
    "agent-knowledge-synthesizer": ['지식통합', '정보종합', 'knowledge synthesis', '요약통합'],
    "agent-kotlin-specialist": ['Kotlin', '코틀린', 'Android', 'JetBrains', '코루틴'],
    "agent-kubernetes-specialist": ['Kubernetes', 'K8s', '쿠버네티스', 'Pod', 'Helm', '컨테이너'],
    "agent-laravel-specialist": ['Laravel', 'PHP프레임워크', 'Eloquent', 'Blade'],
    "agent-legacy-modernizer": ['레거시', '현대화', '마이그레이션', '리라이트', 'monolith'],
    "agent-legal-advisor": ['법률', '계약서', '이용약관', '개인정보', 'GDPR'],
    "agent-llm-architect": ['LLM', '대규모언어모델', 'RAG', '파인튜닝', '프롬프트설계'],
    "agent-low-code-builder": ['로우코드', 'no-code', 'Bubble', 'Retool', '자동화'],
    "agent-machine-learning-engineer": ['ML엔지니어', '모델학습', '하이퍼파라미터', '피처'],
    "agent-market-researcher": ['시장조사', '마켓리서치', 'TAM', '시장규모', '경쟁'],
    "agent-mcp-developer": ['MCP', 'Model Context Protocol', 'MCP서버', 'MCP개발'],
    "agent-microservices-architect": ['마이크로서비스', 'MSA', '서비스분리', 'API게이트웨이'],
    "agent-ml-ops-specialist": ['MLOps', '모델관리', '실험추적', 'MLflow', 'Kubeflow'],
    "agent-mlops-engineer": ['MLOps엔지니어', '모델배포', '실험추적', '모델레지스트리'],
    "agent-mobile-app-developer": ['모바일앱', '앱스토어', 'iOS앱', '안드로이드앱'],
    "agent-mobile-developer": ['모바일', '앱개발', 'iOS', 'Android', 'React Native'],
    "agent-multi-agent-coordinator": ['멀티에이전트', '에이전트조율', '오케스트레이션', '협업'],
    "agent-network-engineer": ['네트워크', 'TCP', 'DNS', '방화벽', '로드밸런서', 'VPN'],
    "agent-nextjs-developer": ['Next.js', 'SSR', 'SSG', 'App Router', 'Vercel'],
    "agent-nlp-engineer": ['NLP', '자연어처리', '텍스트분석', '토큰화', '임베딩'],
    "agent-payment-integration": ['결제연동', 'PG연동', 'Stripe', '토스페이먼츠'],
    "agent-penetration-tester": ['침투테스트', 'pentest', '모의해킹', '취약점스캔'],
    "agent-performance-engineer": ['성능최적화', 'performance', '벤치마크', '프로파일링', 'latency'],
    "agent-performance-monitor": ['성능모니터링', 'APM', '메트릭수집', '대시보드'],
    "agent-php-pro": ['PHP', 'Laravel', 'Composer', 'WordPress개발'],
    "agent-platform-engineer": ['플랫폼', 'IDP', '개발자플랫폼', '셀프서비스'],
    "agent-postgres-pro": ['PostgreSQL', 'Postgres', 'PSQL', 'PG튜닝', '확장'],
    "agent-product-manager": ['프로덕트매니저', 'PM', '로드맵', 'PRD', '사용자스토리'],
    "agent-project-manager": ['프로젝트관리', '일정', 'WBS', '간트', '마일스톤'],
    "agent-prompt-engineer": ['프롬프트엔지니어', '프롬프트최적화', 'few-shot', 'chain-of-thought'],
    "agent-qa-engineer": ['QA', '품질보증', '테스트케이스', '테스트자동화'],
    "agent-qa-expert": ['QA전문가', '테스트전략', '버그리포트', '회귀테스트'],
    "agent-quant-analyst": ['퀀트', '알고리즘트레이딩', '금융모델', '리스크모델'],
    "agent-rails-expert": ['Rails', 'Ruby', 'ActiveRecord', 'MVC', 'Gem'],
    "agent-react-specialist": ['React', '리액트', 'JSX', 'Hooks', '상태관리', 'Redux'],
    "agent-refactoring-guru": ['리팩토링', '클린코드', '디자인패턴', 'SOLID', '코드개선'],
    "agent-refactoring-specialist": ['리팩토링전문', '코드개선', '기술부채', '클린코드'],
    "agent-regex-master": ['정규식', 'regex', '정규표현식', '패턴매칭', 'regexp'],
    "agent-risk-manager": ['리스크', '위험관리', 'risk management', '위험평가'],
    "agent-robotics-engineer": ['로보틱스', 'ROS', '로봇', '자율주행', '모션플래닝'],
    "agent-rust-engineer": ['Rust', '러스트', '소유권', 'ownership', 'borrow', '시스템'],
    "agent-sales-engineer": ['세일즈엔지니어', '기술영업', 'POC', '데모'],
    "agent-scrum-master": ['스크럼', 'Scrum', '스프린트', '애자일', 'Agile', '칸반'],
    "agent-search-specialist": ['검색', 'search', '정보검색', '쿼리최적화'],
    "agent-security-auditor": ['보안감사', '취약점감사', '코드보안', 'OWASP'],
    "agent-security-engineer": ['보안', 'security', '취약점', '암호화', '방화벽', 'CVE'],
    "agent-seo-specialist": ['SEO', '검색최적화', '메타태그', '사이트맵', '구글'],
    "agent-spring-boot-engineer": ['Spring Boot', '스프링', 'JPA', 'Gradle', 'Maven'],
    "agent-sre-engineer": ['SRE', '신뢰성', '가용성', 'SLO', 'SLI', '모니터링'],
    "agent-startup-advisor": ['스타트업', 'MVP', '비즈니스모델', '투자', '피칭'],
    "agent-swift-expert": ['Swift', '스위프트', 'iOS', 'SwiftUI', 'Xcode', 'macOS'],
    "agent-systems-programmer": ['시스템프로그래밍', 'OS', '커널', '드라이버', 'C', '어셈블리'],
    "agent-task-distributor": ['작업분배', '태스크배분', '로드밸런싱', '스케줄링'],
    "agent-tech-lead": ['테크리드', '기술리더', '아키텍처결정', '팀리딩'],
    "agent-terraform-engineer": ['Terraform', 'IaC', '인프라코드', 'HCL', '프로비저닝'],
    "agent-test-automator": ['테스트자동화', 'CI테스트', '자동화테스트', '파이프라인'],
    "agent-test-engineer": ['단위테스트', 'unit test', 'pytest', 'jest', '테스트코드'],
    "agent-tooling-engineer": ['도구개발', '내부도구', 'tooling', 'CLI도구'],
    "agent-trend-analyst": ['트렌드', '동향분석', '기술트렌드', '시장동향'],
    "agent-typescript-pro": ['TypeScript', 'TS', '타입', '인터페이스', '제네릭', 'type'],
    "agent-ui-designer": ['UI디자인', 'Figma', '목업', '와이어프레임', '프로토타입'],
    "agent-ux-researcher": ['UX리서치', '사용자조사', '사용성', '유저테스트'],
    "agent-vue-expert": ['Vue', '뷰', 'Vuex', 'Pinia', 'Composition API', 'Nuxt'],
    "agent-websocket-engineer": ['WebSocket', '실시간', '소켓', '채팅', 'push'],
    "agent-wordpress-master": ['WordPress', '워드프레스', '플러그인', '테마', 'CMS'],
    "agent-workflow-orchestrator": ['워크플로', '자동화', '파이프라인', '태스크관리'],
    "anthropic-architect": ['Anthropic', '아키텍처', 'Claude API', '시스템설계'],
    "arboreto": ['유전자네트워크', 'GRN', 'gene regulatory', 'GENIE3', 'GRNBoost'],
    "artifacts-builder": ['아티팩트', '코드생성', 'code artifact', '빌더'],
    "astropy": ['astropy', '천문학', '천체', 'astronomy', 'FITS', 'celestial'],
    "benchling-integration": ['Benchling', '실험노트', 'LIMS', '분자생물학'],
    "better-auth": ['인증', 'authentication', 'OAuth', 'JWT', '로그인', '보안'],
    "bgpt-paper-search": ['논문검색', '실험데이터', 'paper search', '학술검색'],
    "bindingdb-database": ['BindingDB', '약물표적', 'binding affinity', 'Ki', 'Kd'],
    "bioservices": ['BioServices', 'DB통합', 'UniProt', 'KEGG', 'NCBI', '생물DB'],
    "brand-guidelines": ['브랜드', '가이드라인', 'CI', '로고', '스타일가이드'],
    "brenda-database": ['BRENDA', '효소', 'enzyme kinetics', 'Km', 'Vmax'],
    "canvas-design": ['캔버스', 'Canvas', '그래픽', '드로잉'],
    "cbioportal-database": ['cBioPortal', '암유전체', 'cancer genomics', 'mutation'],
    "changelog-generator": ['변경로그', 'changelog', '릴리즈노트', '버전관리'],
    "chrome-devtools": ['크롬개발자도구', 'DevTools', '디버깅', '네트워크탭', '콘솔'],
    "cirq": ['Cirq', '양자회로', 'quantum circuit', 'Google quantum'],
    "claude-code": ['Claude Code', 'CLI', '에이전트코딩', '클로드'],
    "clinpgx-database": ['약물유전체', 'pharmacogenomics', 'PGx', '약물반응'],
    "cmd-cr": ['코드리뷰', '커밋리뷰', 'PR분석'],
    "cmd-cr-fx": ['코드수정', '자동수정', 'fix', '패치'],
    "cmd-deep-research": ['딥리서치', '심층조사', '종합분석', 'deep research'],
    "cmd-dr": ['디렉토리분석', '폴더구조', '프로젝트분석'],
    "cmd-explore": ['탐색', 'explore', '코드베이스', '디렉토리탐색'],
    "cmd-gen-mcp": ['MCP생성', 'MCP서버', '프로토콜'],
    "cmd-git-cm": ['커밋', 'commit', 'git commit', '커밋메시지'],
    "cmd-git-cp": ['체리픽', 'cherry-pick', '커밋선택', 'git cp'],
    "cmd-git-ff": ['패스트포워드', 'fast-forward', 'git merge ff'],
    "cmd-git-fr": ['프레시브랜치', 'fresh branch', '새브랜치'],
    "cmd-git-pr": ['PR생성', '풀리퀘스트', 'git PR', '코드제출'],
    "cmd-git-prune": ['정리', 'prune', 'git clean', '불필요제거'],
    "cmd-git-sync": ['동기화', 'sync', 'git pull', 'git fetch', '원격동기화'],
    "cmd-implement": ['구현', 'implement', '기능개발', '코딩'],
    "cmd-init": ['초기화', 'init', '프로젝트생성', 'setup'],
    "cmd-memory": ['메모리', '기억', '컨텍스트', 'context'],
    "cmd-think": ['사고', 'think', '분석', '추론', 'reasoning'],
    "cmd-user-prompt": ['사용자프롬프트', '커스텀', 'user prompt'],
    "common": ['공통', '유틸리티', '설정', 'configuration', '환경변수'],
    "competitive-ads-extractor": ['경쟁사', '광고분석', 'competitive', 'ads'],
    "consciousness-council": ['다관점', '숙의', '다각도분석', 'council', '관점비교'],
    "content-research-writer": ['콘텐츠', '리서치', '글쓰기', 'content writing'],
    "datacommons-client": ['공공통계', 'DataCommons', '인구', 'GDP', '통계데이터'],
    "datadog-entity-generator": ['Datadog', '모니터링', '엔티티', '메트릭'],
    "denario": ['AI연구', '자동화연구', 'research automation'],
    "depmap": ['DepMap', '암유전자의존성', 'CRISPR screen', 'cancer dependency'],
    "developer-growth-analysis": ['개발자성장', '성장분석', '커리어', '역량'],
    "dhdna-profiler": ['저자분석', '텍스트분석', 'authorship', '문체분석'],
    "dnanexus-integration": ['DNAnexus', '클라우드유전체', 'WGS', 'WES', '유전체분석'],
    "docs-seeker": ['문서검색', '문서정리', 'documentation', '문서'],
    "document-skills": ['문서스킬', '문서변환', '문서처리', 'document'],
    "domain-name-brainstormer": ['도메인', 'domain name', '네이밍', '사이트이름'],
    "ena-database": ['ENA', '유럽뉴클레오타이드', '시퀀싱데이터', 'FASTQ'],
    "engineer-skill-creator": ['스킬제작', 'skill builder', '엔지니어스킬'],
    "exploratory-data-analysis": ['EDA', '탐색적분석', '데이터탐색', '분포', '상관관계', 'describe'],
    "file-organizer": ['파일정리', '파일관리', '폴더정리', 'file organize'],
    "fluidsim": ['유체역학', 'CFD', 'fluid dynamics', 'Navier-Stokes', '유동'],
    "frontend-design": ['프론트엔드디자인', 'UI구현', 'CSS디자인', '레이아웃'],
    "geniml": ['유전체구간', 'genomic interval', 'BED', '유전체ML'],
    "geomaster": ['GIS', '원격탐사', 'remote sensing', '위성영상', '지리정보'],
    "geopandas": ['GeoPandas', '지리공간', 'GIS', 'shapefile', '좌표', '지도'],
    "get-available-resources": ['시스템자원', 'CPU', '메모리', '디스크', 'GPU감지'],
    "ginkgo-cloud-lab": ['Ginkgo', '합성생물학', 'synthetic biology', '클라우드랩'],
    "google-adk-python": ['Google ADK', 'Agent Development Kit', '구글에이전트'],
    "gtars": ['유전체구간', 'genomic region', '고성능분석', 'interval'],
    "gtex-database": ['GTEx', '조직발현', 'tissue expression', 'RNA발현'],
    "guide-claude-md": ['CLAUDE.md', '프로젝트설정', 'Claude설정'],
    "guide-documentation": ['문서화', 'documentation', '표준문서', 'README'],
    "guide-github-actions": ['GitHub Actions', 'CI/CD', '워크플로', '자동배포'],
    "guide-golang": ['Go가이드', 'Golang패턴', 'Go관례', '고루틴패턴'],
    "guide-hmhco": ['HMHCO', '조직가이드', '회사가이드'],
    "guide-hooks": ['훅', 'hook', '커스텀훅', 'pre-commit', '이벤트'],
    "guide-mcp-reference": ['MCP참조', 'MCP프로토콜', 'MCP문서'],
    "guide-opus-4-5": ['Opus 4.5', '모델가이드', 'Claude모델'],
    "guide-opus-4-5-agent": ['Opus에이전트', 'Agent가이드', '에이전트모델'],
    "guide-opus-migration": ['Opus', '마이그레이션', '모델전환', '업그레이드'],
    "guide-pydantic": ['Pydantic', '데이터검증', '모델정의', 'validation'],
    "guide-ruby": ['Ruby', '루비', 'Gem', 'Rails가이드'],
    "guide-rust": ['Rust가이드', '러스트패턴', '소유권', 'lifetime'],
    "guide-testing": ['테스트가이드', 'TDD', '테스트전략', '커버리지'],
    "guide-typescript": ['TypeScript가이드', '타입설계', 'TS패턴'],
    "guide-version-discovery": ['버전관리', 'version discovery', '버전탐색'],
    "hedgefundmonitor": ['헤지펀드', '리스크', 'fund monitoring', '포트폴리오'],
    "histolab": ['조직영상', 'histology', '타일추출', 'H&E', 'WSI', '병리', 'pathology', '조직학'],
    "hmdb-database": ['HMDB', '대사체', 'metabolite', 'metabolomics'],
    "hypogenic": ['가설생성', 'hypothesis generation', '자동가설'],
    "image-enhancer": ['이미지향상', '이미지편집', 'image enhance', '보정'],
    "imaging-data-commons": ['암영상', 'IDC', '의료영상데이터', 'TCIA'],
    "infographics": ['인포그래픽', 'infographic', '데이터시각화', '정보디자인'],
    "internal-comms": ['내부소통', '커뮤니케이션', '공지', '사내'],
    "interpro-database": ['InterPro', '단백질도메인', 'domain annotation', 'Pfam'],
    "invoice-organizer": ['청구서', '인보이스', 'invoice', '결제'],
    "iso-13485-certification": ['ISO 13485', '의료기기', '품질인증', 'QMS'],
    "jaspar-database": ['JASPAR', '전사인자', 'transcription factor', 'motif'],
    "labarchive-integration": ['전자실험노트', 'ELN', 'LabArchives', '실험기록'],
    "lamindb": ['LaminDB', '데이터관리', '생물데이터', 'data lineage'],
    "latchbio-integration": ['LatchBio', '서버리스', '워크플로우', 'bioinformatics pipeline'],
    "latex-posters": ['LaTeX포스터', '학회포스터', 'poster', '연구포스터'],
    "lead-research-assistant": ['리드리서치', '연구보조', 'research assistant'],
    "markdown-mermaid-writing": ['마크다운', 'Mermaid', '다이어그램', 'flowchart', '시퀀스'],
    "market-research-reports": ['시장조사', 'market research', '산업분석', '보고서'],
    "markitdown": ['마크다운변환', '파일변환', '문서변환', 'markdown conversion'],
    "matlab": ['MATLAB', 'Octave', '매트랩', '행렬', '수치해석'],
    "media-processing": ['미디어', '동영상', '오디오', '변환', 'ffmpeg'],
    "meeting-insights-analyzer": ['회의', '미팅', '인사이트', 'meeting', '회의록'],
    "metabolomics-workbench-database": ['대사체학', 'metabolomics', 'Metabolomics Workbench'],
    "modal": ['Modal', '클라우드GPU', '서버리스GPU', 'GPU실행'],
    "monarch-database": ['Monarch', '질병유전자', 'disease gene', 'phenotype'],
    "neuropixels-analysis": ['Neuropixels', '신경기록', 'electrophysiology', '뉴런', 'spike'],
    "notebooklm-skill": ['NotebookLM', '노트북', '문서분석', '요약'],
    "offer-k-dense-web": ['K-Dense', '웹가이드', '안내'],
    "omero-integration": ['OMERO', '현미경', 'microscopy', '영상관리', 'imaging'],
    "open-notebook": ['연구노트북', 'AI노트북', '실험기록', 'notebook'],
    "openai-prompt-engineer": ['OpenAI', 'GPT', '프롬프트', 'prompt', 'ChatGPT'],
    "openalex-database": ['OpenAlex', '학술문헌', '논문검색', 'academic search'],
    "opentrons-integration": ['Opentrons', '로봇', '피펫팅', '자동화', 'liquid handling'],
    "paper-2-web": ['논문웹사이트', 'paper to web', '연구홍보', '랜딩페이지'],
    "parallel-web": ['병렬검색', '딥리서치', 'deep research', '웹크롤링'],
    "pennylane": ['PennyLane', '양자ML', 'quantum machine learning', 'variational'],
    "perplexity-search": ['Perplexity', '웹검색', 'AI검색', 'web search'],
    "pptx-posters": ['연구포스터', 'poster', 'HTML포스터', '학회'],
    "primekg": ['PrimeKG', '정밀의학', 'precision medicine', 'knowledge graph'],
    "protocolsio-integration": ['protocols.io', '실험프로토콜', 'method', '실험방법'],
    "pufferlib": ['PufferLib', '고성능RL', '게임AI', '환경병렬화'],
    "pylabrobot": ['랩자동화', '로봇실험', 'laboratory automation', 'Hamilton'],
    "pymatgen": ['pymatgen', '재료과학', '결정구조', 'crystal', '상도', 'phase diagram', 'Materials Project'],
    "pymoo": ['pymoo', '다목적최적화', 'multi-objective', 'NSGA', 'Pareto'],
    "pyopenms": ['OpenMS', '질량분석', 'mass spectrometry', 'LC-MS', 'proteomics'],
    "pytdc": ['PyTDC', '신약벤치마크', 'drug benchmark', 'ADMET', 'TDC'],
    "python-deprecation-fixer": ['deprecated', '폐기API', '버전업', '마이그레이션'],
    "pyzotero": ['Zotero', '참고문헌', 'bibliography', '문헌관리', '인용'],
    "qiskit": ['Qiskit', '양자컴퓨팅', 'quantum computing', 'IBM quantum', '큐비트', 'qubit'],
    "qutip": ['QuTiP', '양자시뮬레이션', 'quantum simulation', '양자역학'],
    "raffle-winner-picker": ['추첨', '랜덤선정', 'raffle', '당첨'],
    "repomix": ['레포분석', 'repository analysis', '코드분석', '코드베이스'],
    "research-lookup": ['연구정보', '리서치', '정보검색', 'research lookup'],
    "rowan": ['Rowan', '양자화학', 'quantum chemistry', 'DFT', 'ab initio'],
    "scholar-evaluation": ['학술업적', 'h-index', '논문평가', '인용', 'impact factor'],
    "scientific-brainstorming": ['연구아이디어', '브레인스토밍', '실험설계', '연구주제'],
    "scientific-critical-thinking": ['비판적사고', '과학적근거', '논증', 'evidence-based'],
    "scientific-schematics": ['다이어그램', 'schematic', '과학그림', '모식도'],
    "scientific-slides": ['발표', '슬라이드', '학회발표', 'presentation', '학술발표'],
    "scikit-bio": ['scikit-bio', '마이크로바이옴', 'microbiome', '다양성지수', '서열정렬'],
    "scikit-survival": ['생존분석', 'survival analysis', 'Kaplan-Meier', 'Cox', '생존곡선'],
    "shopify": ['Shopify', '쇼핑몰', '이커머스', 'e-commerce', '스토어'],
    "simpy": ['SimPy', '시뮬레이션', '이산사건', 'discrete event', '큐잉'],
    "skill-creator": ['스킬생성', 'skill create', '스킬템플릿'],
    "skill-share": ['스킬공유', 'skill share', '스킬배포'],
    "slack-gif-creator": ['Slack', 'GIF', '애니메이션', '슬랙'],
    "stable-baselines3": ['강화학습', 'RL', 'reinforcement learning', 'PPO', 'DQN', 'A2C'],
    "template-skill": ['템플릿', '스킬템플릿', 'boilerplate'],
    "theme-factory": ['테마', 'theme', '스타일', '다크모드', '색상'],
    "tiledbvcf": ['TileDB', 'VCF', '유전체변이', 'variant storage', 'genotype'],
    "torchdrug": ['TorchDrug', '분자그래프', 'molecular graph', 'GNN', 'drug discovery'],
    "ui-styling": ['UI스타일', 'CSS', '스타일링', '디자인시스템', '색상'],
    "usfiscaldata": ['미국재정', 'fiscal data', '국채', 'government debt'],
    "uspto-database": ['USPTO', '특허', 'patent', '상표', 'trademark', '지식재산'],
    "vaex": ['vaex', '대규모데이터', 'out-of-core', 'lazy evaluation', '빅데이터'],
    "venue-templates": ['LaTeX', '학술지', '템플릿', 'journal template', '논문포맷'],
    "video-downloader": ['비디오', '영상다운로드', 'video download', 'YouTube'],
    "web-artifacts-builder": ['웹아티팩트', '웹앱생성', 'HTML생성', '인터랙티브'],
    "web-frameworks": ['웹프레임워크', 'Express', 'Next.js', 'Nuxt', 'SvelteKit'],
    "webapp-testing": ['웹테스트', 'E2E', 'Playwright', 'Cypress', '테스팅'],
    "what-if-oracle": ['What-If', '시나리오', '가정분석', 'hypothetical'],
    "zarr-python": ['Zarr', '청크배열', 'N-D array', '대용량배열', 'cloud storage'],
}

def _score_query(query_lower):
    """쿼리에 대한 스킬별 점수 계산 (내부 공통 함수)"""
    import re
    scores = {}
    for skill_id, keywords in SKILL_KEYWORDS.items():
        score = 0
        for kw in keywords:
            kw_lower = kw.lower()
            if len(kw_lower) <= 4 and kw_lower.isascii() and kw_lower.isalpha():
                pattern = r'(?<![a-zA-Z])' + re.escape(kw_lower) + r'(?![a-zA-Z])'
                if re.search(pattern, query_lower):
                    score += len(kw_lower) * 2
            elif kw_lower in query_lower:
                score += len(kw_lower)
        if score > 0:
            scores[skill_id] = score
    return scores


def auto_select_skills(query, max_skills=5):
    """사용자 질문을 분석하여 관련 스킬을 자동 선택"""
    scores = _score_query(query.lower())
    sorted_skills = sorted(scores.items(), key=lambda x: -x[1])
    return [(sid, sc) for sid, sc in sorted_skills[:max_skills]]


def context_aware_skill_select(query, history, max_skills=7):
    """대화 컨텍스트 + 현재 질문 기반 스킬 자동 선택 (멀티에이전트 Router)

    [Router 역할]
    1. 현재 질문에서 직접 매칭되는 스킬 → 높은 가중치
    2. 최근 대화 3턴에서 매칭되는 스킬 → 중간 가중치 (컨텍스트 유지)
    3. 질문 유형 분석 → 보조 스킬 자동 추가
    """
    # 1단계: 현재 질문 스코어링 (가중치 1.0)
    current_scores = _score_query(query.lower())

    # 2단계: 최근 대화 컨텍스트 스코어링 (가중치 0.3, 최근 3턴)
    context_scores = {}
    recent_msgs = [m for m in history if m.get("role") == "user"][-3:]
    for msg in recent_msgs:
        msg_scores = _score_query(msg.get("content", "").lower())
        for sid, sc in msg_scores.items():
            context_scores[sid] = context_scores.get(sid, 0) + sc * 0.3

    # 3단계: 합산
    combined = {}
    all_sids = set(list(current_scores.keys()) + list(context_scores.keys()))
    for sid in all_sids:
        combined[sid] = current_scores.get(sid, 0) + context_scores.get(sid, 0)

    # 4단계: 질문 유형별 보조 스킬 자동 추가
    q = query.lower()
    boosted = set()
    # 코드 수정/디버깅 감지
    if any(kw in q for kw in ["에러", "error", "버그", "bug", "수정", "고쳐", "안돼", "안되", "traceback", "exception"]):
        for sid in ["debugging", "agent-debugger", "agent-error-detective"]:
            combined[sid] = combined.get(sid, 0) + 5
            boosted.add(sid)
    # 데이터 분석 감지
    if any(kw in q for kw in ["분석", "데이터", "csv", "그래프", "시각화", "차트", "통계"]):
        for sid in ["exploratory-data-analysis", "matplotlib", "statistical-analysis"]:
            combined[sid] = combined.get(sid, 0) + 3
            boosted.add(sid)
    # 코드 작성 감지
    if any(kw in q for kw in ["코드", "함수", "클래스", "구현", "작성", "만들어", "코딩"]):
        for sid in ["agent-python-pro", "debugging"]:
            combined[sid] = combined.get(sid, 0) + 3
            boosted.add(sid)

    # 5단계: 정렬 후 반환 (현재 질문 직접 매칭 우선)
    sorted_skills = sorted(combined.items(), key=lambda x: -x[1])
    result = [(sid, sc) for sid, sc in sorted_skills[:max_skills] if sc > 0]

    return result, list(boosted)


def build_orchestration_prompt(query, skill_ids, loaded_skills_content):
    """멀티에이전트 오케스트레이션 프롬프트 생성

    [Expert 역할] 각 스킬을 전문가로 취급
    [Synthesizer 역할] 여러 전문가 지식을 조합하는 지시문
    """
    if len(loaded_skills_content) <= 1:
        return ""  # 단일 스킬이면 오케스트레이션 불필요

    expert_names = [f"[{SKILL_DESC_KO.get(sid, sid)}]" for sid in skill_ids if sid in loaded_skills_content]

    orchestration = f"""
[멀티에이전트 오케스트레이션 모드]
현재 {len(expert_names)}명의 전문가 지식이 로드되었습니다: {', '.join(expert_names)}

당신은 이 전문가들의 지식을 조합하여 최적의 답변을 생성하는 통합 전문가입니다.

[오케스트레이션 원칙]
1. 각 SKILL의 전문 지식을 해당 영역에 맞게 활용
2. 서로 다른 SKILL 간의 시너지를 찾아 조합 (예: biopython + matplotlib → 서열분석+시각화)
3. 답변을 하나의 통합된 흐름으로 제시 (분절되지 않게)
4. 각 SKILL에서 가져온 핵심 기법/코드를 명시하되, 자연스럽게 녹여내기
"""
    return orchestration


def load_skill_content(skill_name):
    """스킬 SKILL.md 내용 읽기"""
    skill_md = os.path.join(SKILLS_DIR, skill_name, "SKILL.md")
    if os.path.isfile(skill_md):
        with open(skill_md, "r", encoding="utf-8") as f:
            return f.read()
    return ""


def get_skill_catalog():
    """프론트엔드에 보낼 스킬 카탈로그 생성"""
    available = scan_skills()
    catalog = {}

    for domain_id, domain_info in DOMAIN_SKILLS.items():
        skills_list = []
        for skill_id in domain_info["skills"]:
            info = available.get(skill_id, {})
            skills_list.append({
                "id": skill_id,
                "name": skill_id.replace("-", " ").title(),
                "desc": SKILL_DESC_KO.get(skill_id, ""),
                "available": skill_id in available,
                "scripts": len(info.get("scripts", [])),
                "references": len(info.get("references", [])),
                "assets": len(info.get("assets", [])),
            })
        catalog[domain_id] = {
            "label": domain_info["label"],
            "icon": domain_info["icon"],
            "color": domain_info["color"],
            "skills": skills_list,
        }

    # 매핑에 없지만 폴더에 존재하는 스킬도 추가
    mapped_ids = set()
    for d in DOMAIN_SKILLS.values():
        mapped_ids.update(d["skills"])

    extra = []
    for sid in available:
        if sid not in mapped_ids:
            info = available[sid]
            extra.append({
                "id": sid,
                "name": sid.replace("-", " ").title(),
                "desc": SKILL_DESC_KO.get(sid, ""),
                "available": True,
                "scripts": len(info.get("scripts", [])),
                "references": len(info.get("references", [])),
                "assets": len(info.get("assets", [])),
            })

    if extra:
        catalog["etc"] = {
            "label": "기타 스킬",
            "icon": "📦",
            "color": "#6b7280",
            "skills": extra,
        }

    return catalog


# ============================================
# API 라우트
# ============================================
@app.route("/")
def index():
    return render_template_string(HTML_TEMPLATE)


@app.route("/api/config")
def api_config():
    """환경 설정 및 토큰 상태 반환"""
    return jsonify({
        "envs": {k: {"url": v["url"], "model": v["model"], "name": v["name"]} for k, v in ENV_CONFIG.items()},
        "has_token": bool(API_TOKEN),
        "token_file": TOKEN_FILE,
        "token_optional": True,
    })


# ============================================
# GGUF 모델 관리 (llama-cpp-python)
# ============================================
def find_gguf_files():
    """app.py 주변에서 GGUF 파일 검색"""
    patterns = [
        os.path.join(BASE_DIR, "*.gguf"),
        os.path.join(BASE_DIR, "models", "*.gguf"),
        os.path.join(BASE_DIR, "model", "*.gguf"),
    ]
    files = []
    for p in patterns:
        files.extend(glob.glob(p))
    return [{"path": f, "name": os.path.basename(f), "size_gb": round(os.path.getsize(f) / 1e9, 1)} for f in files]


def load_gguf_model(model_path, n_ctx=32768, n_gpu_layers=99):
    """llama-cpp-python으로 GGUF 모델 로드"""
    global gguf_model
    try:
        from llama_cpp import Llama
        print(f"     모델 로딩 중: {os.path.basename(model_path)}...")

        # Windows: llama.cpp C 라이브러리가 stdout/stderr 핸들을 건드려서
        # Flask(click/colorama) 콘솔 출력이 깨지는 문제 방지
        saved_stdout = sys.stdout
        saved_stderr = sys.stderr
        try:
            gguf_model = Llama(
                model_path=model_path,
                n_ctx=n_ctx,
                n_gpu_layers=n_gpu_layers,
                verbose=False,
            )
        finally:
            # 핸들 복원
            sys.stdout = saved_stdout
            sys.stderr = saved_stderr

        return True
    except ImportError:
        print(f"     ❌ llama-cpp-python 패키지 없음")
        print(f"        → pip install llama-cpp-python")
        return False
    except Exception as e:
        print(f"     ❌ 모델 로드 실패: {e}")
        return False


def gguf_chat(messages, temperature=0.5, max_tokens=4096, stop_flag=None):
    """로드된 GGUF 모델로 채팅 (스트리밍으로 중단 가능)"""
    global gguf_model
    if gguf_model is None:
        return None, "GGUF 모델이 로드되지 않았습니다."
    try:
        # 중단 플래그가 있으면 스트리밍 모드로 토큰별 체크
        if stop_flag is not None:
            chunks = []
            for chunk in gguf_model.create_chat_completion(
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
                stream=True,
            ):
                if stop_flag.get("stop", False):
                    # 중단 요청 → 지금까지 생성된 부분 반환
                    partial = "".join(chunks)
                    return (partial + "\n\n⏹️ (응답이 중단되었습니다)") if partial else None, None
                delta = chunk.get("choices", [{}])[0].get("delta", {})
                content = delta.get("content", "")
                if content:
                    chunks.append(content)
            return "".join(chunks), None
        else:
            resp = gguf_model.create_chat_completion(
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
            )
            if resp and "choices" in resp and len(resp["choices"]) > 0:
                return resp["choices"][0]["message"]["content"], None
            return None, f"예상치 못한 응답: {resp}"
    except Exception as e:
        return None, f"GGUF 추론 오류: {str(e)}"


@app.route("/api/auto-skills", methods=["POST"])
def api_auto_skills():
    """사용자 질문에 맞는 스킬을 자동 추천 (컨텍스트 인식)"""
    data = request.json
    query = data.get("query", "")
    max_skills = data.get("max_skills", 7)
    history = data.get("history", [])  # 대화 히스토리

    if not query:
        return jsonify({"skills": [], "message": "질문을 입력해주세요."})

    # 대화 히스토리가 있으면 컨텍스트 인식 모드
    if history and len(history) > 0:
        results, boosted = context_aware_skill_select(query, history, max_skills=max_skills)
    else:
        results = auto_select_skills(query, max_skills=max_skills)
        boosted = []

    skills = []
    for sid, score in results:
        desc = SKILL_DESC_KO.get(sid, "")
        skills.append({
            "id": sid,
            "desc": desc,
            "score": score,
            "boosted": sid in boosted,  # 질문유형으로 자동 추가된 것
        })

    mode = "🧠 컨텍스트" if history else "🔍 키워드"
    return jsonify({
        "skills": skills,
        "query": query,
        "mode": mode,
        "boosted_count": len(boosted),
        "message": f"{mode} 매칭: {len(skills)}개 스킬" if skills else "매칭되는 스킬이 없습니다.",
    })


# ===================== 시스템 프롬프트 저장/불러오기 (TXT) =====================

# 기본 프리셋 프롬프트 (파일로 저장 안 됨, 코드 내장)
PRESET_PROMPTS = {
    "coding": {
        "name": "코딩 전문가",
        "icon": "💻",
        "content": """당신은 숙련된 소프트웨어 개발자입니다. 다음 원칙을 따르세요:

[코드 작성 규칙]
- 코드는 반드시 즉시 실행 가능하게 작성 (import 포함, 필요 패키지 명시)
- 에러 처리(try/except)를 반드시 포함
- 함수/클래스 단위로 구조화, 재사용 가능하게
- 주석은 한국어로 '왜' 이렇게 했는지 설명
- 타입 힌트 사용 권장
- 변수명은 명확하고 의미 있게

[응답 구조]
1. 요구사항 분석 (1~2줄)
2. 핵심 코드 (주석 포함)
3. 사용법/실행 방법
4. 필요 패키지: pip install xxx"""
    },
    "code-fix": {
        "name": "코드 수정/디버깅",
        "icon": "🔧",
        "content": """당신은 코드 디버깅 및 리팩토링 전문가입니다.

[분석 절차]
1. 원본 코드를 먼저 분석하고 문제점을 정확히 진단
2. 에러 메시지가 있으면 원인과 해결책을 명확히 설명
3. 수정 전/후 코드를 비교해서 보여주기
4. 왜 그렇게 고쳤는지 이유 설명

[코드 수정 원칙]
- 최소 변경 원칙: 문제를 고치는 데 필요한 최소한만 수정
- 기존 코딩 스타일 유지
- 성능 개선이 가능하면 제안 (하지만 강요하지 않음)
- 잠재적 버그나 취약점이 보이면 경고

[응답 형식]
- 문제 원인 → 수정 코드 → 설명 순서"""
    },
    "data-analysis": {
        "name": "데이터 분석",
        "icon": "📊",
        "content": """당신은 데이터 분석 전문가입니다.

[분석 절차]
1. 데이터 형태 파악 (shape, dtypes, 결측치, 이상치)
2. 탐색적 분석 (EDA): 분포, 상관관계, 패턴
3. 시각화: matplotlib/seaborn으로 핵심 차트 생성
4. 인사이트 도출: 데이터가 말해주는 것을 명확히 해석

[코드 원칙]
- pandas/polars 활용, 코드와 해석을 함께 제공
- 차트에는 반드시 한글 제목/라벨 (plt.rcParams 설정 포함)
- 큰 데이터는 샘플링 전략 제시
- 통계적 검증이 필요하면 scipy/statsmodels 활용

[응답 구조]
데이터 개요 → 분석 코드 → 시각화 → 인사이트 요약"""
    },
    "general-dev": {
        "name": "개발 올라운더",
        "icon": "🛠️",
        "content": """당신은 풀스택 개발 어시스턴트입니다. 코딩, 디버깅, 아키텍처, DevOps를 모두 지원합니다.

[핵심 원칙]
- 질문의 맥락을 파악하고 가장 적합한 방식으로 답변
- 코드는 실행 가능하게, 설명은 간결하게
- 한국어 주석, 필요 패키지 명시
- 모르는 건 모른다고 솔직히 말하기
- 여러 해결책이 있으면 장단점 비교 후 추천

[스킬 활용]
- 로드된 스킬의 방법론, 코드 패턴, API를 적극 활용
- 여러 스킬이 관련되면 조합해서 최적의 답변 생성"""
    },
    "semiconductor": {
        "name": "반도체 엔지니어",
        "icon": "🔬",
        "content": """당신은 반도체 공정 및 소자 전문가입니다.

[전문 영역]
- DRAM/NAND Flash 구조, 공정 흐름, 불량 분석
- 웨이퍼 공정 데이터 분석 (수율, SPC, FDC)
- 장비 데이터 분석 및 공정 최적화
- 신뢰성 분석, 불량 메커니즘

[응답 원칙]
- 전문 용어를 정확히 사용하되, 필요시 설명 추가
- 데이터 분석 코드가 필요하면 pandas + matplotlib 활용
- 공정 파라미터 관계는 시각화로 보여주기
- 양산 환경을 고려한 실용적 제안"""
    },
}


@app.route("/api/prompts", methods=["GET"])
def api_list_prompts():
    """저장된 프롬프트 목록 (프리셋 + 사용자 저장분)"""
    result = []

    # 1) 프리셋
    for pid, p in PRESET_PROMPTS.items():
        result.append({
            "id": f"preset:{pid}",
            "name": p["name"],
            "icon": p["icon"],
            "type": "preset",
            "preview": p["content"][:80] + "...",
        })

    # 2) 사용자 저장 TXT 파일
    if os.path.isdir(PROMPTS_DIR):
        for fname in sorted(os.listdir(PROMPTS_DIR)):
            if fname.endswith(".txt"):
                fpath = os.path.join(PROMPTS_DIR, fname)
                name = fname[:-4]  # .txt 제거
                try:
                    with open(fpath, "r", encoding="utf-8") as f:
                        content = f.read()
                    result.append({
                        "id": f"saved:{name}",
                        "name": name,
                        "icon": "💾",
                        "type": "saved",
                        "preview": content[:80] + "..." if len(content) > 80 else content,
                    })
                except:
                    pass

    return jsonify({"prompts": result})


@app.route("/api/prompts/<prompt_id>", methods=["GET"])
def api_get_prompt(prompt_id):
    """프롬프트 내용 불러오기"""
    if prompt_id.startswith("preset:"):
        key = prompt_id[7:]
        if key in PRESET_PROMPTS:
            p = PRESET_PROMPTS[key]
            return jsonify({"id": prompt_id, "name": p["name"], "content": p["content"]})
        return jsonify({"error": "프리셋을 찾을 수 없습니다."}), 404

    elif prompt_id.startswith("saved:"):
        name = prompt_id[6:]
        fpath = os.path.join(PROMPTS_DIR, f"{name}.txt")
        if os.path.isfile(fpath):
            with open(fpath, "r", encoding="utf-8") as f:
                content = f.read()
            return jsonify({"id": prompt_id, "name": name, "content": content})
        return jsonify({"error": "저장된 프롬프트를 찾을 수 없습니다."}), 404

    return jsonify({"error": "잘못된 ID 형식"}), 400


@app.route("/api/prompts", methods=["POST"])
def api_save_prompt():
    """시스템 프롬프트를 TXT로 저장"""
    data = request.json
    name = data.get("name", "").strip()
    content = data.get("content", "").strip()

    if not name or not content:
        return jsonify({"error": "이름과 내용을 모두 입력해주세요."}), 400

    # 파일명 안전하게
    safe_name = "".join(c for c in name if c.isalnum() or c in (' ', '-', '_', '.', 'ㄱ', 'ㄴ', 'ㄷ', 'ㄹ', 'ㅁ', 'ㅂ', 'ㅅ', 'ㅇ', 'ㅈ', 'ㅊ', 'ㅋ', 'ㅌ', 'ㅍ', 'ㅎ') or ('\uac00' <= c <= '\ud7a3')).strip()
    if not safe_name:
        safe_name = "custom-prompt"

    fpath = os.path.join(PROMPTS_DIR, f"{safe_name}.txt")
    with open(fpath, "w", encoding="utf-8") as f:
        f.write(content)

    return jsonify({"success": True, "id": f"saved:{safe_name}", "name": safe_name, "path": fpath})


@app.route("/api/prompts/<prompt_id>", methods=["DELETE"])
def api_delete_prompt(prompt_id):
    """저장된 프롬프트 삭제 (프리셋은 삭제 불가)"""
    if prompt_id.startswith("preset:"):
        return jsonify({"error": "프리셋은 삭제할 수 없습니다."}), 400

    if prompt_id.startswith("saved:"):
        name = prompt_id[6:]
        fpath = os.path.join(PROMPTS_DIR, f"{name}.txt")
        if os.path.isfile(fpath):
            try:
                os.remove(fpath)
            except Exception as e:
                return jsonify({"error": f"삭제 실패: {str(e)}"}), 500
            return jsonify({"success": True})
        return jsonify({"error": "파일을 찾을 수 없습니다."}), 404

    return jsonify({"error": "잘못된 ID 형식"}), 400


@app.route("/api/skills")
def api_skills():
    """스킬 카탈로그 반환"""
    return jsonify(get_skill_catalog())


@app.route("/api/skill/<skill_name>")
def api_skill_content(skill_name):
    """개별 스킬 상세 반환 (SKILL.md + scripts/references/assets 목록)"""
    content = load_skill_content(skill_name)
    available = scan_skills()
    info = available.get(skill_name, {})
    return jsonify({
        "name": skill_name,
        "content": content,
        "scripts": info.get("scripts", []),
        "references": info.get("references", []),
        "assets": info.get("assets", []),
    })


@app.route("/api/skill/<skill_name>/file")
def api_skill_file(skill_name):
    """스킬 내부 파일(scripts/references/assets) 내용 읽기"""
    file_path = request.args.get("path", "")
    if not file_path:
        return jsonify({"error": "path 파라미터가 필요합니다."}), 400

    # 보안: 상위 디렉토리 접근 차단
    if ".." in file_path or file_path.startswith("/"):
        return jsonify({"error": "잘못된 경로"}), 400

    full_path = os.path.join(SKILLS_DIR, skill_name, file_path)
    if not os.path.isfile(full_path):
        return jsonify({"error": f"파일 없음: {file_path}"}), 404

    try:
        with open(full_path, "r", encoding="utf-8") as f:
            content = f.read()
        return jsonify({
            "name": os.path.basename(file_path),
            "path": file_path,
            "content": content,
            "size": os.path.getsize(full_path),
        })
    except UnicodeDecodeError:
        return jsonify({"error": "바이너리 파일은 읽을 수 없습니다."}), 400


@app.route("/api/skill/<skill_name>/run", methods=["POST"])
def api_skill_run(skill_name):
    """스킬 내부 파이썬 스크립트 실행"""
    import subprocess

    data = request.json or {}
    script_path = data.get("script", "")
    args = data.get("args", [])

    if not script_path:
        return jsonify({"error": "script 파라미터가 필요합니다."}), 400
    if ".." in script_path or script_path.startswith("/"):
        return jsonify({"error": "잘못된 경로"}), 400
    if not script_path.endswith(".py"):
        return jsonify({"error": "파이썬 파일만 실행 가능합니다."}), 400

    full_path = os.path.join(SKILLS_DIR, skill_name, script_path)
    if not os.path.isfile(full_path):
        return jsonify({"error": f"스크립트 없음: {script_path}"}), 404

    try:
        result = subprocess.run(
            [sys.executable, full_path] + args,
            capture_output=True, text=True,
            timeout=60,
            cwd=os.path.join(SKILLS_DIR, skill_name),
        )
        return jsonify({
            "stdout": result.stdout[-8000:] if len(result.stdout) > 8000 else result.stdout,
            "stderr": result.stderr[-4000:] if len(result.stderr) > 4000 else result.stderr,
            "returncode": result.returncode,
            "script": script_path,
        })
    except subprocess.TimeoutExpired:
        return jsonify({"error": "스크립트 실행 시간 초과 (60초)"}), 504
    except Exception as e:
        return jsonify({"error": f"실행 오류: {str(e)}"}), 500


@app.route("/api/upload_csv", methods=["POST"])
def api_upload_csv():
    """CSV 파일 업로드 및 파싱"""
    global uploaded_csv_data

    if 'file' not in request.files:
        return jsonify({"error": "파일이 없습니다."}), 400

    file = request.files['file']
    if not file.filename:
        return jsonify({"error": "파일명이 없습니다."}), 400

    fname = file.filename.lower()
    if not (fname.endswith('.csv') or fname.endswith('.tsv') or fname.endswith('.txt')):
        return jsonify({"error": "CSV, TSV, TXT 파일만 지원합니다."}), 400

    try:
        # 파일 읽기 (여러 인코딩 시도)
        raw_bytes = file.read()
        content = None
        for enc in ["utf-8", "utf-8-sig", "cp949", "euc-kr", "latin-1"]:
            try:
                content = raw_bytes.decode(enc)
                break
            except (UnicodeDecodeError, LookupError):
                continue

        if content is None:
            return jsonify({"error": "파일 인코딩을 인식할 수 없습니다."}), 400

        # 구분자 자동 감지
        sample = content[:4096]
        try:
            dialect = csv.Sniffer().sniff(sample, delimiters=',\t;|')
            delimiter = dialect.delimiter
        except csv.Error:
            delimiter = '\t' if fname.endswith('.tsv') else ','

        # CSV 파싱
        reader = csv.reader(io.StringIO(content), delimiter=delimiter)
        all_rows = []
        for row in reader:
            all_rows.append(row)
            if len(all_rows) > 10000:  # 최대 10000행
                break

        if len(all_rows) < 1:
            return jsonify({"error": "빈 파일입니다."}), 400

        headers = all_rows[0]
        data_rows = all_rows[1:]

        # 통계 요약 생성
        total_rows = len(data_rows)
        total_cols = len(headers)

        # 각 컬럼 타입 추정 및 기본 통계
        col_stats = []
        for ci, h in enumerate(headers):
            vals = [r[ci] for r in data_rows if ci < len(r) and r[ci].strip()]
            # 숫자 판별
            nums = []
            for v in vals:
                try:
                    nums.append(float(v.replace(',', '')))
                except ValueError:
                    pass

            if len(nums) > len(vals) * 0.5 and nums:
                col_stats.append(f"  {h}: 숫자형 ({len(vals)}건, 범위 {min(nums):.4g}~{max(nums):.4g}, 평균 {sum(nums)/len(nums):.4g})")
            else:
                unique = len(set(vals))
                col_stats.append(f"  {h}: 문자형 ({len(vals)}건, 고유값 {unique}개)")

        summary = f"파일: {file.filename}\n행: {total_rows}개, 열: {total_cols}개\n컬럼:\n" + "\n".join(col_stats)

        # 미리보기 (상위 5행)
        preview_rows = data_rows[:5]
        preview_text = delimiter.join(headers) + "\n"
        for r in preview_rows:
            preview_text += delimiter.join(r) + "\n"
        if total_rows > 5:
            preview_text += f"... ({total_rows - 5}행 더 있음)"

        # 저장
        uploaded_csv_data = {
            "filename": file.filename,
            "headers": headers,
            "rows": data_rows,
            "summary": summary,
            "raw_preview": preview_text,
        }

        return jsonify({
            "success": True,
            "filename": file.filename,
            "rows": total_rows,
            "cols": total_cols,
            "headers": headers,
            "summary": summary,
            "preview": preview_text,
            "sample_rows": [dict(zip(headers, r)) for r in preview_rows[:3]],
        })

    except Exception as e:
        return jsonify({"error": f"파일 처리 오류: {str(e)}"}), 500


@app.route("/api/clear_csv", methods=["POST"])
def api_clear_csv():
    """업로드된 CSV 데이터 삭제"""
    global uploaded_csv_data
    uploaded_csv_data = {"filename": "", "headers": [], "rows": [], "summary": "", "raw_preview": ""}
    return jsonify({"success": True})


# ===================== 범용 파일 업로드 =====================
ALLOWED_EXTENSIONS = {
    'csv', 'tsv', 'txt',
    'docx', 'xlsx', 'pdf', 'pptx',
    'md', 'markdown',
    'png', 'jpg', 'jpeg', 'gif', 'bmp', 'webp', 'svg',
    'py', 'js', 'html', 'css', 'json', 'xml', 'yaml', 'yml',
    'c', 'cpp', 'h', 'java', 'go', 'rs', 'sh', 'bat',
}


def extract_file_text(filepath, filename):
    """파일에서 텍스트 추출 (가능한 경우)"""
    ext = filename.rsplit('.', 1)[-1].lower() if '.' in filename else ''
    text = ""
    file_type = "unknown"

    try:
        # 텍스트 기반 파일
        if ext in ('md', 'markdown', 'txt', 'py', 'js', 'html', 'css', 'json',
                    'xml', 'yaml', 'yml', 'c', 'cpp', 'h', 'java', 'go', 'rs', 'sh', 'bat'):
            for enc in ["utf-8", "utf-8-sig", "cp949", "euc-kr", "latin-1"]:
                try:
                    with open(filepath, "r", encoding=enc) as f:
                        text = f.read()
                    break
                except (UnicodeDecodeError, LookupError):
                    continue
            file_type = "text"

        # DOCX
        elif ext == 'docx':
            try:
                import zipfile
                with zipfile.ZipFile(filepath) as z:
                    with z.open('word/document.xml') as doc:
                        import xml.etree.ElementTree as ET
                        tree = ET.parse(doc)
                        ns = {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
                        paragraphs = tree.findall('.//w:p', ns)
                        texts = []
                        for p in paragraphs:
                            runs = p.findall('.//w:t', ns)
                            para_text = ''.join(r.text or '' for r in runs)
                            if para_text.strip():
                                texts.append(para_text)
                        text = '\n'.join(texts)
                file_type = "docx"
            except Exception as e:
                text = f"(DOCX 텍스트 추출 실패: {e})"
                file_type = "docx"

        # XLSX
        elif ext == 'xlsx':
            try:
                import zipfile
                import xml.etree.ElementTree as ET
                with zipfile.ZipFile(filepath) as z:
                    # shared strings
                    shared = []
                    if 'xl/sharedStrings.xml' in z.namelist():
                        with z.open('xl/sharedStrings.xml') as ss:
                            tree = ET.parse(ss)
                            ns = {'s': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
                            for si in tree.findall('.//s:si', ns):
                                t_el = si.find('.//s:t', ns)
                                shared.append(t_el.text if t_el is not None and t_el.text else '')
                    # sheet1
                    with z.open('xl/worksheets/sheet1.xml') as ws:
                        tree = ET.parse(ws)
                        ns = {'s': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
                        rows = tree.findall('.//s:row', ns)
                        lines = []
                        for row in rows[:100]:  # 최대 100행
                            cells = []
                            for c in row.findall('s:c', ns):
                                v_el = c.find('s:v', ns)
                                t_attr = c.get('t', '')
                                if v_el is not None and v_el.text:
                                    if t_attr == 's' and v_el.text.isdigit():
                                        idx = int(v_el.text)
                                        cells.append(shared[idx] if idx < len(shared) else v_el.text)
                                    else:
                                        cells.append(v_el.text)
                                else:
                                    cells.append('')
                            lines.append('\t'.join(cells))
                        text = '\n'.join(lines)
                file_type = "xlsx"
            except Exception as e:
                text = f"(XLSX 텍스트 추출 실패: {e})"
                file_type = "xlsx"

        # PDF (기본 텍스트 추출)
        elif ext == 'pdf':
            try:
                with open(filepath, 'rb') as f:
                    content = f.read()
                # 간단한 PDF 텍스트 추출 (stream 기반)
                import re as re_mod
                texts = re_mod.findall(rb'\((.*?)\)', content)
                decoded = []
                for t in texts[:500]:
                    try:
                        decoded.append(t.decode('utf-8', errors='ignore'))
                    except:
                        pass
                text = ' '.join(decoded)
                if len(text.strip()) < 50:
                    text = f"(PDF 텍스트 추출 제한 - 바이너리 PDF. 파일크기: {os.path.getsize(filepath)}바이트)"
                file_type = "pdf"
            except Exception as e:
                text = f"(PDF 텍스트 추출 실패: {e})"
                file_type = "pdf"

        # PPTX
        elif ext == 'pptx':
            try:
                import zipfile
                import xml.etree.ElementTree as ET
                with zipfile.ZipFile(filepath) as z:
                    slide_texts = []
                    for name in sorted(z.namelist()):
                        if name.startswith('ppt/slides/slide') and name.endswith('.xml'):
                            with z.open(name) as sl:
                                tree = ET.parse(sl)
                                ns = {'a': 'http://schemas.openxmlformats.org/drawingml/2006/main'}
                                texts_in_slide = []
                                for t in tree.findall('.//a:t', ns):
                                    if t.text and t.text.strip():
                                        texts_in_slide.append(t.text)
                                if texts_in_slide:
                                    slide_num = name.split('slide')[-1].split('.')[0]
                                    slide_texts.append(f"[슬라이드 {slide_num}] {' | '.join(texts_in_slide)}")
                    text = '\n'.join(slide_texts)
                file_type = "pptx"
            except Exception as e:
                text = f"(PPTX 텍스트 추출 실패: {e})"
                file_type = "pptx"

        # 이미지
        elif ext in ('png', 'jpg', 'jpeg', 'gif', 'bmp', 'webp', 'svg'):
            import base64
            with open(filepath, 'rb') as f:
                img_data = base64.b64encode(f.read()).decode('ascii')
            text = f"[이미지 파일: {filename}, 크기: {os.path.getsize(filepath)}바이트, base64 길이: {len(img_data)}]"
            file_type = "image"

        else:
            text = f"(지원하지 않는 파일 형식: .{ext})"
            file_type = ext

    except Exception as e:
        text = f"(파일 읽기 오류: {e})"

    return text, file_type


@app.route("/api/upload_file", methods=["POST"])
def api_upload_file():
    """범용 파일 업로드 (docx, xlsx, pdf, pptx, md, 이미지, 코드 등)"""
    global uploaded_files

    if 'file' not in request.files:
        return jsonify({"error": "파일이 없습니다."}), 400

    file = request.files['file']
    if not file.filename:
        return jsonify({"error": "파일명이 없습니다."}), 400

    fname = file.filename
    ext = fname.rsplit('.', 1)[-1].lower() if '.' in fname else ''

    if ext not in ALLOWED_EXTENSIONS:
        return jsonify({"error": f"지원하지 않는 파일 형식입니다: .{ext}"}), 400

    # CSV/TSV는 기존 CSV 업로드로 리다이렉트
    if ext in ('csv', 'tsv'):
        return jsonify({"error": "CSV/TSV는 데이터 업로드 영역을 사용하세요.", "redirect": "csv"}), 400

    try:
        # 파일 저장
        import time as _time
        safe_name = f"{int(_time.time())}_{fname}"
        filepath = os.path.join(UPLOAD_DIR, safe_name)
        file.save(filepath)
        file_size = os.path.getsize(filepath)

        # 텍스트 추출
        text, file_type = extract_file_text(filepath, fname)

        # 미리보기 (최대 3000자)
        preview = text[:3000]
        if len(text) > 3000:
            preview += f"\n... (총 {len(text)}자 중 3000자 표시)"

        # 파일 정보 저장
        file_info = {
            "filename": fname,
            "safe_name": safe_name,
            "type": file_type,
            "ext": ext,
            "size": file_size,
            "content_preview": preview,
            "content_full": text[:30000],  # 시스템 프롬프트용 최대 30000자
            "path": filepath,
        }
        uploaded_files.append(file_info)

        # 아이콘 매핑
        icon_map = {
            "docx": "📄", "xlsx": "📊", "pdf": "📕", "pptx": "📽️",
            "text": "📝", "image": "🖼️",
        }
        icon = icon_map.get(file_type, "📎")

        return jsonify({
            "success": True,
            "filename": fname,
            "type": file_type,
            "ext": ext,
            "size": file_size,
            "icon": icon,
            "preview": preview[:500],
            "total_files": len(uploaded_files),
        })

    except Exception as e:
        return jsonify({"error": f"파일 처리 오류: {str(e)}"}), 500


@app.route("/api/uploaded_files", methods=["GET"])
def api_uploaded_files():
    """업로드된 파일 목록"""
    return jsonify({
        "files": [{
            "filename": f["filename"],
            "type": f["type"],
            "ext": f["ext"],
            "size": f["size"],
        } for f in uploaded_files]
    })


@app.route("/api/remove_file", methods=["POST"])
def api_remove_file():
    """업로드된 파일 제거"""
    global uploaded_files
    data = request.json
    fname = data.get("filename", "")

    new_files = []
    removed = False
    for f in uploaded_files:
        if f["filename"] == fname and not removed:
            # 파일 삭제
            try:
                os.remove(f["path"])
            except:
                pass
            removed = True
        else:
            new_files.append(f)
    uploaded_files = new_files
    return jsonify({"success": removed, "total_files": len(uploaded_files)})


@app.route("/api/clear_files", methods=["POST"])
def api_clear_files():
    """모든 업로드 파일 제거"""
    global uploaded_files
    for f in uploaded_files:
        try:
            os.remove(f["path"])
        except:
            pass
    uploaded_files = []
    return jsonify({"success": True})


# ===================== 응답 중지 =====================
chat_stop_flag = {"stop": False}

@app.route("/api/chat/stop", methods=["POST"])
def api_chat_stop():
    """진행 중인 LLM 응답을 중지"""
    chat_stop_flag["stop"] = True
    return jsonify({"stopped": True})


@app.route("/api/chat", methods=["POST"])
def api_chat():
    """LLM API 프록시 - 스킬을 시스템 프롬프트에 넣어서 회사 API로 전달"""
    chat_stop_flag["stop"] = False  # 새 요청 시작 시 플래그 초기화
    data = request.json
    # 환경 선택 시 서버에서 URL/모델 결정, 토큰은 TOKEN.TXT에서 읽음
    env_id = data.get("env", "")
    if env_id and env_id in ENV_CONFIG:
        api_url = ENV_CONFIG[env_id]["url"]
        model = ENV_CONFIG[env_id]["model"]
    else:
        api_url = data.get("api_url", "")
        model = data.get("model", "")
    api_key = API_TOKEN or data.get("api_key", "")
    messages = data.get("messages", [])
    skill_ids = data.get("skills", [])
    effort = data.get("effort", 2)
    output_format = data.get("format", "code")
    writing_style = data.get("writing_style", "")
    custom_system_prompt = data.get("system_prompt", "")
    max_tokens = data.get("max_tokens", 4096)

    if not api_url or not model:
        return jsonify({"error": "API URL과 모델 이름을 설정해주세요."}), 400

    # 시스템 프롬프트 구성
    default_prompt = """당신은 Demos(민중) Alpha 0.8 - 과학 연구와 소프트웨어 개발을 돕는 전문 AI 어시스턴트입니다.
370개+ 전문 스킬(과학/개발/AI/인프라/비즈니스)을 활용할 수 있습니다.

[기본 규칙]
- 반드시 한국어(한글)로 답변하세요. 코드 주석도 한글로 작성하세요.
- <think> 태그를 사용하여 사고할 때도 반드시 한국어로 작성하세요. 영어로 사고하지 마세요.
- 코드는 즉시 실행 가능하게 (import 포함, 필요 패키지 명시)
- 에러 처리(try/except)를 포함하세요

[스킬 활용]
- 아래에 로드된 SKILL 내용은 당신의 전문 지식입니다
- 해당 스킬의 방법론, 코드 패턴, API, 도구를 적극 활용하세요
- 여러 스킬이 로드된 경우 관련된 것끼리 조합하여 최적의 답변을 생성하세요

"""

    if custom_system_prompt:
        system_prompt = custom_system_prompt + "\n\n" + default_prompt
    else:
        system_prompt = default_prompt

    # ===== 토큰 예산 관리 =====
    # API 대형 모델 → 제한 거의 없음 (128K+ 컨텍스트)
    # GGUF 로컬 → 32K 컨텍스트이므로 스마트하게 제한
    is_gguf = (env_id == "gguf-local")
    history_chars = sum(len(m.get("content", "")) for m in messages)

    if is_gguf:
        gguf_ctx = 32768
        # GGUF: 토큰 ≈ 글자수 * 0.7 (한글 기준), 시스템+히스토리+응답 여유
        available_chars = int(gguf_ctx / 0.7) - len(system_prompt) - history_chars - 3000
        available_chars = max(available_chars, 3000)
    else:
        available_chars = 999999  # API는 사실상 무제한

    # 스킬 로드
    loaded = []
    available = scan_skills()
    total_skill_chars = 0
    num_skills = max(len(skill_ids), 1)
    per_skill_limit = available_chars // num_skills if is_gguf else 999999

    for sid in skill_ids:
        content = load_skill_content(sid)
        if content:
            # GGUF만 자르기, API는 전체 로드
            if is_gguf and total_skill_chars + len(content) > available_chars:
                remaining = available_chars - total_skill_chars
                if remaining > 500:
                    content = content[:remaining] + f"\n... ({len(content)}자 중 {remaining}자 로드)\n"
                else:
                    system_prompt += f"[⚠️ GGUF 컨텍스트 한도 → 스킬 생략: {', '.join(skill_ids[len(loaded):])}]\n"
                    break

            if is_gguf and len(content) > per_skill_limit:
                content = content[:per_skill_limit] + f"\n... ({len(content)}자 중 {per_skill_limit}자 로드)\n"

            system_prompt += f"=== SKILL: {sid} ===\n{content}\n\n"
            total_skill_chars += len(content)
            loaded.append(sid)

            # scripts/references 목록 (짧으니 항상 포함)
            info = available.get(sid, {})
            scripts = info.get("scripts", [])
            if scripts:
                system_prompt += f"[{sid} 스크립트: {', '.join(s['name'] for s in scripts)}]\n"
            refs = info.get("references", [])
            if refs:
                system_prompt += f"[{sid} 참고: {', '.join(r['name'] for r in refs)}]\n"
            system_prompt += "\n"

    if loaded:
        system_prompt += f"[로드된 스킬: {', '.join(loaded)}]\n\n"
        # 멀티에이전트 오케스트레이션 (스킬 2개 이상)
        if len(loaded) >= 2:
            loaded_set = {sid: True for sid in loaded}
            orch_prompt = build_orchestration_prompt(
                messages[-1].get("content", "") if messages else "",
                loaded, loaded_set
            )
            system_prompt += orch_prompt

    # CSV 데이터가 업로드되어 있으면 시스템 프롬프트에 포함
    include_csv = data.get("include_csv", True)
    if include_csv and uploaded_csv_data["filename"]:
        csv_info = uploaded_csv_data["summary"]
        # 데이터 미리보기 (최대 50행)
        preview_limit = min(50, len(uploaded_csv_data["rows"]))
        csv_rows_text = ",".join(uploaded_csv_data["headers"]) + "\n"
        for row in uploaded_csv_data["rows"][:preview_limit]:
            csv_rows_text += ",".join(row) + "\n"
        if len(uploaded_csv_data["rows"]) > preview_limit:
            csv_rows_text += f"... (총 {len(uploaded_csv_data['rows'])}행 중 {preview_limit}행만 표시)\n"

        system_prompt += f"=== 업로드된 CSV 데이터 ===\n{csv_info}\n\n데이터 미리보기:\n{csv_rows_text}\n\n"
        system_prompt += "사용자가 이 데이터에 대해 질문하면 위 CSV 데이터를 기반으로 분석해주세요.\n\n"

    # 업로드된 파일 내용 주입
    if uploaded_files:
        system_prompt += f"=== 업로드된 파일 ({len(uploaded_files)}개) ===\n"
        for uf in uploaded_files:
            system_prompt += f"\n--- 파일: {uf['filename']} ({uf['type']}, {uf['size']}바이트) ---\n"
            content = uf.get("content_full", "")
            if is_gguf:
                # GGUF: 파일당 최대 2000자로 제한
                content = content[:2000]
                if len(uf.get("content_full", "")) > 2000:
                    content += f"\n... (총 {len(uf['content_full'])}자 중 2000자 표시)"
            else:
                content = content[:15000]  # API: 파일당 최대 15000자
                if len(uf.get("content_full", "")) > 15000:
                    content += f"\n... (총 {len(uf['content_full'])}자 중 15000자 표시)"
            system_prompt += content + "\n"
        system_prompt += "\n사용자가 업로드된 파일에 대해 질문하면 위 내용을 기반으로 답변하세요.\n\n"

    # 응답 수준
    effort_map = [
        "매우 간결하게 핵심만 답변하세요.",
        "간결하게 답변하세요.",
        "표준적인 깊이로 설명하세요.",
        "매우 상세하고 전문적으로 분석하세요. 코드에 주석을 자세히 달고, 원리를 설명하세요.",
    ]
    format_map = {
        "code": "답변을 Python 코드 중심으로 작성하세요. import 포함, 즉시 실행 가능하게.",
        "code-fix": "문제 진단 → 수정 전/후 비교 → 수정 이유 설명 순서로 답변하세요. 최소 변경 원칙.",
        "analysis": "데이터 개요 → 분석 코드(pandas/matplotlib) → 시각화 → 인사이트 요약 순서로 답변하세요.",
        "report": "답변을 보고서 형식으로 작성하세요. 제목, 요약, 본문, 결론 구조.",
        "step-by-step": "답변을 단계별(1,2,3...)로 작성하세요. 각 단계마다 왜 필요한지 설명.",
    }

    system_prompt += effort_map[min(effort, 3)] + "\n"
    system_prompt += format_map.get(output_format, "") + "\n"
    if writing_style:
        system_prompt += f"작성 스타일: {writing_style}\n"

    # API 요청 구성
    api_messages = [{"role": "system", "content": system_prompt}] + messages
    temperature_map = [0.1, 0.3, 0.5, 0.7]

    # ===== GGUF 로컬 모델: Python에서 직접 추론 =====
    if env_id == "gguf-local":
        if gguf_model is None:
            return jsonify({"error": "GGUF 모델이 로드되지 않았습니다. .gguf 파일과 llama-cpp-python이 필요합니다."}), 400

        # GGUF 컨텍스트 한도 내에서 max_tokens 자동 조정
        gguf_ctx = getattr(gguf_model, 'n_ctx', lambda: 32768)()
        prompt_tokens_est = len(system_prompt) // 2 + sum(len(m.get("content","")) // 2 for m in messages)
        safe_max = max(256, gguf_ctx - prompt_tokens_est - 100)
        actual_max_tokens = min(max_tokens, safe_max)

        if prompt_tokens_est > gguf_ctx - 256:
            return jsonify({"error": f"프롬프트가 너무 깁니다 (~{prompt_tokens_est}토큰). 스킬 수를 줄이거나 히스토리를 초기화해주세요. (GGUF ctx: {gguf_ctx})"}), 400

        answer, err = gguf_chat(
            api_messages,
            temperature=temperature_map[min(effort, 3)],
            max_tokens=actual_max_tokens,
            stop_flag=chat_stop_flag,
        )
        if err:
            return jsonify({"error": err}), 500

        return jsonify({
            "content": answer,
            "loaded_skills": loaded,
            "system_prompt_length": len(system_prompt),
            "tokens_budget": f"prompt~{prompt_tokens_est}, max_tokens={actual_max_tokens}, ctx={gguf_ctx}",
        })

    # ===== 회사 API: HTTP 요청 =====
    headers = {"Content-Type": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    try:
        resp = req.post(
            api_url,
            headers=headers,
            json={
                "model": model,
                "messages": api_messages,
                "temperature": temperature_map[min(effort, 3)],
                "max_tokens": max_tokens,
                "stream": False,
            },
            timeout=120,
            verify=False,  # 폐쇄망 인증서 문제 대응
        )
        resp.raise_for_status()
        result = resp.json()

        # 응답 추출
        if "choices" in result and len(result["choices"]) > 0:
            answer = result["choices"][0]["message"]["content"]
        elif "error" in result:
            answer = f"API 에러: {result['error']}"
        else:
            answer = f"예상치 못한 응답: {json.dumps(result, ensure_ascii=False, indent=2)}"

        return jsonify({
            "content": answer,
            "loaded_skills": loaded,
            "system_prompt_length": len(system_prompt),
        })

    except req.exceptions.Timeout:
        return jsonify({"error": "API 응답 시간 초과 (120초). max_tokens를 줄이거나 API 서버 상태를 확인하세요."}), 504
    except req.exceptions.ConnectionError as e:
        return jsonify({"error": f"API 연결 실패: {str(e)}. URL을 확인하세요."}), 502
    except req.exceptions.HTTPError as e:
        code = e.response.status_code if e.response is not None else 0
        if code == 401 or code == 403:
            return jsonify({"error": f"인증 실패 ({code}): TOKEN.TXT의 API 키를 확인하세요."}), code
        return jsonify({"error": f"API HTTP 에러 ({code}): {str(e)}"}), code or 500
    except Exception as e:
        return jsonify({"error": f"오류 발생: {str(e)}"}), 500


# ============================================
# HTML 템플릿
# ============================================
HTML_TEMPLATE = r"""<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Demos(민중) Alpha 0.8</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:#f8f7f4;color:#1a1a1a;display:flex;height:100vh}
.sidebar{width:250px;background:#fff;border-right:1px solid #e5e3de;padding:20px 16px;display:flex;flex-direction:column;overflow-y:auto;transition:width .2s ease,padding .2s ease;flex-shrink:0}
.sidebar.collapsed{width:48px;padding:12px 6px;overflow:hidden}
.sidebar.collapsed .sidebar-inner{display:none}
.sidebar.collapsed .sidebar-logo{display:none}
.sidebar-toggle{position:absolute;top:12px;left:250px;width:24px;height:24px;border-radius:0 6px 6px 0;border:1px solid #e5e3de;border-left:none;background:#fff;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:12px;color:#999;z-index:200;transition:left .2s ease}
.sidebar-toggle:hover{background:#eef2ff;color:#6366f1}
body.sb-collapsed .sidebar-toggle{left:48px}
body.sb-collapsed .chat-box-fixed{left:48px}
.sidebar-toggle-mini{width:100%;padding:6px 0;border:none;background:none;cursor:pointer;font-size:16px;display:none;color:#6366f1}
.sidebar.collapsed .sidebar-toggle-mini{display:block}
.sidebar-logo{font-size:22px;font-weight:700;margin-bottom:24px}.sidebar-logo span{color:#6366f1}
.sidebar-btn{width:100%;padding:10px 14px;border-radius:8px;border:none;cursor:pointer;font-size:14px;text-align:left;margin-bottom:4px;background:transparent;color:#555;transition:all .15s}
.sidebar-btn:hover{background:#f3f2ef}.sidebar-btn.active{background:#6366f1;color:#fff}
.session-item{display:flex;align-items:center;padding:5px 8px;border-radius:6px;cursor:pointer;font-size:12px;color:#555;transition:all .12s;gap:4px;margin:1px 4px}
.session-item:hover{background:#f3f2ef}
.session-item.current{background:#eef2ff;color:#6366f1;font-weight:600}
.session-item .session-name{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.session-item .session-cb{width:14px;height:14px;cursor:pointer;accent-color:#6366f1;flex-shrink:0}
.session-item .session-time{font-size:9px;color:#bbb;flex-shrink:0}
.sidebar-collapse{display:flex;align-items:center;justify-content:space-between;cursor:pointer;padding:4px 0;user-select:none}
.sidebar-collapse:hover{opacity:.8}
.sidebar-collapse .arrow{font-size:10px;color:#999;transition:transform .15s}
.sidebar-collapse .arrow.open{transform:rotate(90deg)}
.sidebar-collapsible{overflow:hidden;transition:max-height .2s ease}
.sidebar-collapsible.collapsed{max-height:0!important}
.session-actions{display:flex;gap:4px;padding:4px 8px}
.session-actions button{flex:1;padding:3px 0;border:1px solid #e5e3de;border-radius:4px;background:#fafaf8;font-size:10px;cursor:pointer;transition:all .12s}
.session-actions button:hover{background:#eef2ff;border-color:#6366f1}
.session-actions button.danger{color:#ef4444;border-color:#fca5a5}
.session-actions button.danger:hover{background:#fef2f2;border-color:#ef4444}
.sidebar-section{font-size:11px;font-weight:600;color:#999;text-transform:uppercase;letter-spacing:.5px;margin:20px 0 8px 8px}
.skill-count{font-size:11px;color:#6366f1;background:#eef2ff;padding:2px 8px;border-radius:10px;margin-left:6px}
.sidebar-footer{margin-top:auto;padding-top:16px;border-top:1px solid #e5e3de}
.credits{font-size:12px;color:#999}
.main{flex:1;display:flex;flex-direction:column;overflow:hidden}
.header{padding:16px 32px;border-bottom:1px solid #e5e3de;background:#fff;display:flex;align-items:center;justify-content:space-between}
.project-title{font-size:20px;font-weight:600}
.content{flex:1;overflow-y:auto;padding:24px 32px}
.content-inner{max-width:800px;margin:0 auto}
.section-label{font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:#555;margin-bottom:10px}
/* Chat - Fixed Bottom */
.chat-box-fixed{position:fixed;bottom:0;left:250px;right:0;background:#fff;border-top:2px solid #e5e3de;padding:6px 32px;z-index:100;box-shadow:0 -2px 10px rgba(0,0,0,.05);transition:left .2s ease}
.chat-box-fixed:focus-within{border-top-color:#6366f1}
.chat-box-fixed-inner{max-width:800px;margin:0 auto}
.chat-input{width:100%;border:none;outline:none;font-size:13px;resize:none;min-height:20px;max-height:100px;font-family:inherit;line-height:1.4}
.chat-input::placeholder{color:#aaa;font-size:12px}
.chat-footer{display:flex;justify-content:space-between;align-items:center;margin-top:2px}
.send-btn{width:32px;height:32px;border-radius:50%;border:none;background:#6366f1;color:#fff;cursor:pointer;font-size:14px;transition:background .15s}
.send-btn:hover{background:#4f46e5}
.send-btn:disabled{background:#ccc;cursor:not-allowed}
.content{padding-bottom:80px!important}
/* Tags */
.tag-row{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:24px}
.tag{padding:8px 18px;border-radius:20px;border:2px solid #e5e3de;font-size:13px;font-weight:500;cursor:pointer;transition:all .15s;background:#fff;user-select:none}
.tag:hover{border-color:#6366f1}.tag.selected{border-color:var(--c,#6366f1);background:var(--bg,#eef2ff);color:var(--fg,#4f46e5)}
/* Skills */
.skill-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:8px;margin-bottom:24px;max-height:220px;overflow-y:auto;padding:4px}
.skill-card{padding:10px 14px;border-radius:10px;border:2px solid #e5e3de;background:#fff;cursor:pointer;transition:all .15s;font-size:13px;position:relative}
.skill-card:hover{border-color:#6366f1;transform:translateY(-1px)}
.skill-card.selected{border-color:#6366f1;background:#eef2ff}
.skill-card.unavailable{opacity:.45;cursor:default}
.skill-card .sn{font-weight:600;margin-bottom:2px}.skill-card .sd{font-size:11px;color:#888}
.skill-card .badge{position:absolute;top:6px;right:8px;font-size:10px;background:#10b981;color:#fff;padding:1px 6px;border-radius:8px}
/* Effort */
.effort-section{margin-bottom:24px}
.effort-slider{width:100%;-webkit-appearance:none;appearance:none;height:6px;border-radius:3px;background:linear-gradient(to right,#6366f1 0%,#6366f1 var(--val,66%),#e5e3de var(--val,66%),#e5e3de 100%);outline:none}
.effort-slider::-webkit-slider-thumb{-webkit-appearance:none;width:20px;height:20px;border-radius:50%;background:#6366f1;cursor:pointer;border:3px solid #fff;box-shadow:0 1px 4px rgba(0,0,0,.2)}
.effort-labels{display:flex;justify-content:space-between;font-size:12px;color:#999;margin-top:4px}
.effort-labels span.active{color:#6366f1;font-weight:600}
/* Style */
.style-row{display:flex;gap:16px;margin-bottom:24px}.style-group{flex:1}
.style-group label{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:#999;margin-bottom:8px;display:block}
.style-group textarea{width:100%;border:1px solid #e5e3de;border-radius:10px;padding:10px 12px;font-size:13px;resize:none;height:56px;font-family:inherit;outline:none}
.style-group textarea:focus{border-color:#6366f1}
.fmt-btns{display:flex;flex-wrap:wrap;gap:6px}
.fmt-btn{padding:6px 14px;border-radius:8px;border:2px solid #e5e3de;font-size:12px;cursor:pointer;transition:all .15s;background:#fff}
.fmt-btn:hover{border-color:#6366f1}.fmt-btn.selected{background:#6366f1;color:#fff;border-color:#6366f1}
/* Quick */
.quick-row{display:flex;flex-wrap:wrap;gap:8px;justify-content:center;margin-bottom:20px}
.quick-btn{padding:8px 16px;border-radius:20px;border:1px solid #e5e3de;background:#fff;font-size:13px;cursor:pointer;transition:all .15s}
.quick-btn:hover{border-color:#6366f1;background:#eef2ff}
/* Auto Skill */
.auto-skill-toggle{display:flex;align-items:center;gap:8px;margin-bottom:12px;padding:8px 14px;background:#f8f7ff;border:2px solid #e5e3de;border-radius:12px;cursor:pointer;transition:all .15s;user-select:none}
.auto-skill-toggle:hover{border-color:#6366f1}
.auto-skill-toggle.on{border-color:#6366f1;background:#eef2ff}
.auto-skill-toggle .toggle-dot{width:36px;height:20px;border-radius:10px;background:#ccc;position:relative;transition:all .2s}
.auto-skill-toggle.on .toggle-dot{background:#6366f1}
.auto-skill-toggle .toggle-dot::after{content:'';position:absolute;top:2px;left:2px;width:16px;height:16px;border-radius:50%;background:#fff;transition:all .2s}
.auto-skill-toggle.on .toggle-dot::after{left:18px}
.auto-skill-badge{display:inline-block;padding:2px 8px;border-radius:10px;font-size:11px;background:#eef2ff;color:#6366f1;border:1px solid #c7d2fe;margin:2px}
.auto-skill-preview{margin-top:6px;padding:8px 12px;background:#f0fdf4;border:1px solid #a7f3d0;border-radius:8px;font-size:12px;display:none}
.auto-skill-preview.show{display:block}
/* Messages */
.messages{margin-top:8px}
.msg{margin-bottom:8px;padding:8px 12px;border-radius:10px;line-height:1.5;font-size:13px;word-wrap:break-word}
.msg.user{background:#6366f1;color:#fff;margin-left:120px;border-bottom-right-radius:4px;white-space:pre-wrap}
.msg.assistant{background:#fff;border:1px solid #e5e3de;margin-right:120px;border-bottom-left-radius:4px}
.msg pre{background:#f5f5f0;padding:8px;border-radius:6px;overflow-x:auto;margin:4px 0;font-size:12px;white-space:pre-wrap}
.msg code{font-family:'SF Mono','Fira Code',monospace;font-size:12px}
.msg p{margin:0 0 4px 0}.msg p:last-child{margin-bottom:0}
.msg h1,.msg h2,.msg h3,.msg h4{margin:8px 0 4px 0;font-weight:700}
.msg h1{font-size:1.2em;border-bottom:1px solid #e5e3de;padding-bottom:2px}
.msg h2{font-size:1.1em;border-bottom:1px solid #eee;padding-bottom:2px}
.msg h3{font-size:1em}.msg h4{font-size:.95em}
.msg ul,.msg ol{margin:4px 0 4px 16px;padding:0}.msg li{margin:1px 0}
.msg table{border-collapse:collapse;margin:4px 0;width:100%;font-size:12px}
.msg th,.msg td{border:1px solid #ddd;padding:4px 8px;text-align:left}
.msg th{background:#f5f5f0;font-weight:600}
.msg tr:nth-child(even){background:#fafaf8}
.msg hr{border:none;border-top:1px solid #e5e3de;margin:6px 0}
.msg blockquote{border-left:3px solid #6366f1;margin:4px 0;padding:2px 8px;color:#666;background:#fafaf8;border-radius:0 6px 6px 0}
.msg-label{font-size:10px;font-weight:600;color:#999;margin-bottom:3px;text-transform:uppercase;letter-spacing:.5px}
.msg.user .msg-label{color:rgba(255,255,255,.7)}
.msg .skill-info{font-size:10px;color:#6366f1;margin-top:4px}
.typing{display:inline-flex;gap:4px;padding:8px 14px}
.typing span{width:8px;height:8px;border-radius:50%;background:#ccc;animation:blink 1.4s infinite both}
.typing span:nth-child(2){animation-delay:.2s}.typing span:nth-child(3){animation-delay:.4s}
@keyframes blink{0%,80%,100%{opacity:.3}40%{opacity:1}}
/* Modal */
.modal-bg{position:fixed;inset:0;background:rgba(0,0,0,.4);z-index:100;display:flex;align-items:center;justify-content:center}
.modal-bg.hidden{display:none}
.modal{background:#fff;border-radius:16px;padding:28px;width:500px;max-width:90vw;box-shadow:0 20px 60px rgba(0,0,0,.15)}
.modal h2{font-size:18px;margin-bottom:16px}
.modal label{font-size:13px;font-weight:600;color:#555;display:block;margin-bottom:4px;margin-top:12px}
.modal input{width:100%;padding:10px 12px;border:1px solid #e5e3de;border-radius:8px;font-size:14px;outline:none;font-family:inherit}
.modal input:focus{border-color:#6366f1}
.modal-btns{display:flex;justify-content:flex-end;gap:8px;margin-top:20px}
.modal-btns button{padding:10px 20px;border-radius:8px;border:none;font-size:14px;cursor:pointer}
.btn-ok{background:#6366f1;color:#fff}.btn-ok:hover{background:#4f46e5}
.btn-cancel{background:#f3f2ef;color:#555}
.settings-btn{background:none;border:none;cursor:pointer;font-size:20px;color:#999;padding:4px 8px;border-radius:6px}
.settings-btn:hover{background:#f3f2ef;color:#555}
.status{font-size:12px}
.status.on{color:#10b981}.status.off{color:#999}
/* Env selector */
.env-row{display:flex;gap:8px;margin-bottom:24px}
.env-btn{flex:1;padding:12px 10px;border-radius:12px;border:2px solid #e5e3de;background:#fff;cursor:pointer;text-align:center;transition:all .15s;font-size:13px}
.env-btn:hover{border-color:#6366f1;transform:translateY(-1px)}
.env-btn.selected{border-color:#6366f1;background:#eef2ff}
.env-btn .env-name{font-weight:700;font-size:14px;margin-bottom:2px}
.env-btn .env-model{font-size:11px;color:#888}
.env-btn.selected .env-model{color:#6366f1}
.token-status{font-size:12px;padding:8px 12px;border-radius:8px;margin-bottom:16px}
.token-status.ok{background:#ecfdf5;color:#059669}
.token-status.missing{background:#fef2f2;color:#dc2626}
/* System Prompt */
.sysprompt-section{margin-bottom:24px}
.sysprompt-toggle{display:flex;align-items:center;gap:8px;cursor:pointer;margin-bottom:8px}
.sysprompt-toggle .arrow{font-size:12px;transition:transform .2s;color:#999}
.sysprompt-toggle .arrow.open{transform:rotate(90deg)}
.sysprompt-body{display:none}
.sysprompt-body.show{display:block}
.sysprompt-textarea{width:100%;border:1px solid #e5e3de;border-radius:10px;padding:12px;font-size:13px;resize:vertical;min-height:80px;max-height:300px;font-family:'SF Mono','Fira Code',monospace;line-height:1.5;outline:none;background:#fafaf8}
.sysprompt-textarea:focus{border-color:#6366f1;background:#fff}
.sysprompt-info{font-size:11px;color:#999;margin-top:4px}
.prompt-chip{display:inline-flex;align-items:center;gap:3px;padding:3px 10px;border-radius:12px;font-size:11px;cursor:pointer;border:1px solid #e5e3de;background:#fafaf8;transition:all .15s;white-space:nowrap}
.prompt-chip:hover{background:#eef2ff;border-color:#6366f1}
.prompt-chip.active{background:#6366f1;color:#fff;border-color:#6366f1}
.prompt-chip.saved{border-color:#f59e0b;background:#fffbeb}
.prompt-chip.saved:hover{background:#fef3c7}
.prompt-chip.saved.active{background:#f59e0b;color:#fff}
.sysprompt-preview{font-size:11px;color:#6366f1;background:#eef2ff;padding:6px 10px;border-radius:6px;margin-top:6px;max-height:60px;overflow:hidden;cursor:pointer}
.sysprompt-preview:hover{max-height:200px;overflow-y:auto}
/* CSV Upload */
.csv-section{margin-bottom:24px}
.csv-upload-area{border:2px dashed #d1d5db;border-radius:12px;padding:20px;text-align:center;cursor:pointer;transition:all .2s;background:#fafaf8}
.csv-upload-area:hover{border-color:#6366f1;background:#eef2ff}
.csv-upload-area.dragover{border-color:#6366f1;background:#eef2ff;border-style:solid}
.csv-upload-area .icon{font-size:28px;margin-bottom:6px}
.csv-upload-area .label{font-size:13px;color:#888}
.csv-upload-area .sub{font-size:11px;color:#bbb;margin-top:2px}
.csv-info{background:#fff;border:2px solid #10b981;border-radius:12px;padding:14px 18px;position:relative}
.csv-info .fname{font-weight:700;font-size:14px;color:#059669}
.csv-info .fstats{font-size:12px;color:#666;margin-top:4px}
.csv-info .fremove{position:absolute;top:10px;right:12px;background:#fee2e2;color:#dc2626;border:none;border-radius:6px;padding:4px 10px;font-size:11px;cursor:pointer}
.csv-info .fremove:hover{background:#fca5a5}
.csv-preview{margin-top:8px;max-height:160px;overflow:auto;font-size:11px;background:#f9fafb;border-radius:8px;padding:8px}
.csv-preview table{border-collapse:collapse;width:100%}
.csv-preview th,.csv-preview td{border:1px solid #e5e7eb;padding:3px 8px;text-align:left;white-space:nowrap}
.csv-preview th{background:#f3f4f6;font-weight:600;position:sticky;top:0}
/* Skill Detail Panel */
.skill-detail-overlay{position:fixed;inset:0;background:rgba(0,0,0,.4);z-index:200;display:flex;align-items:center;justify-content:center}
.skill-detail-panel{background:#fff;border-radius:16px;width:720px;max-width:92vw;max-height:85vh;display:flex;flex-direction:column;box-shadow:0 20px 60px rgba(0,0,0,.2)}
.sdp-header{padding:18px 24px;border-bottom:1px solid #e5e3de;display:flex;justify-content:space-between;align-items:center}
.sdp-header h2{font-size:18px;margin:0}.sdp-close{background:none;border:none;font-size:22px;cursor:pointer;color:#999;padding:4px 8px}
.sdp-close:hover{color:#333}
.sdp-tabs{display:flex;border-bottom:1px solid #e5e3de;padding:0 24px}
.sdp-tab{padding:10px 18px;font-size:13px;font-weight:600;cursor:pointer;border-bottom:3px solid transparent;color:#888;transition:all .15s}
.sdp-tab:hover{color:#333}.sdp-tab.active{color:#6366f1;border-bottom-color:#6366f1}
.sdp-body{flex:1;overflow-y:auto;padding:18px 24px}
.sdp-file-list{list-style:none;padding:0}
.sdp-file-item{display:flex;align-items:center;gap:10px;padding:10px 14px;border:1px solid #e5e3de;border-radius:10px;margin-bottom:6px;transition:all .15s;cursor:pointer}
.sdp-file-item:hover{border-color:#6366f1;background:#f8f7ff}
.sdp-file-icon{font-size:18px}
.sdp-file-name{font-weight:600;font-size:13px;flex:1}
.sdp-file-size{font-size:11px;color:#999}
.sdp-file-actions{display:flex;gap:4px}
.sdp-btn{padding:4px 12px;border-radius:6px;border:1px solid #e5e3de;font-size:11px;cursor:pointer;background:#fff;transition:all .15s}
.sdp-btn:hover{border-color:#6366f1;background:#eef2ff}
.sdp-btn.run{background:#10b981;color:#fff;border-color:#10b981}.sdp-btn.run:hover{background:#059669}
.sdp-btn.inject{background:#6366f1;color:#fff;border-color:#6366f1}.sdp-btn.inject:hover{background:#4f46e5}
.sdp-code{background:#1e1e1e;color:#d4d4d4;padding:14px;border-radius:10px;font-family:'SF Mono','Fira Code',monospace;font-size:12px;line-height:1.5;overflow:auto;max-height:400px;white-space:pre-wrap;word-break:break-all}
.sdp-result{margin-top:12px;padding:12px;border-radius:10px;font-family:monospace;font-size:12px;line-height:1.4;overflow:auto;max-height:300px;white-space:pre-wrap}
.sdp-result.ok{background:#ecfdf5;border:1px solid #a7f3d0}.sdp-result.err{background:#fef2f2;border:1px solid #fca5a5}
.skill-card .extras{font-size:10px;color:#6366f1;margin-top:3px}
/* Copy button */
.copy-btn{position:absolute;top:4px;right:4px;background:#e5e3de;border:none;border-radius:4px;padding:2px 8px;font-size:11px;cursor:pointer;opacity:.7}
.copy-btn:hover{opacity:1}
.send-btn.stop-mode{background:#e74c3c;animation:pulse-stop 1.2s infinite}
@keyframes pulse-stop{0%,100%{opacity:1}50%{opacity:.7}}
.uploaded-files-header{font-size:12px;font-weight:600;color:#555;padding:6px 0;border-bottom:1px solid #eee;margin-bottom:4px}
.uploaded-file-item{display:flex;align-items:center;gap:6px;padding:5px 4px;border-bottom:1px solid #f0f0f0;font-size:12px}
.ufi-icon{font-size:16px;flex-shrink:0}
.ufi-name{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#333;cursor:help}
.ufi-size{color:#999;font-size:10px;flex-shrink:0}
.ufi-remove{background:none;border:none;color:#ccc;cursor:pointer;font-size:13px;padding:0 2px}
.ufi-remove:hover{color:#e74c3c}
.think-box{margin:8px 0 12px;border:1px solid #d4c8f0;border-radius:8px;background:#f8f5ff;overflow:hidden}
.think-box summary{cursor:pointer;padding:8px 12px;font-size:12px;font-weight:600;color:#7c5cbf;background:#f0ebfa;user-select:none}
.think-box summary:hover{background:#e8e0f6}
.think-box[open] summary{border-bottom:1px solid #d4c8f0}
.think-content{padding:10px 14px;font-size:12px;color:#555;line-height:1.6;max-height:400px;overflow-y:auto}
pre{position:relative}
@media(max-width:768px){.sidebar{display:none}.sidebar-toggle{display:none}.chat-box-fixed{left:0}.style-row{flex-direction:column}.msg.user{margin-left:16px}.msg.assistant{margin-right:16px}.msg{font-size:12px}}
</style>
</head>
<body>
<div class="sidebar" id="sidebar">
  <button class="sidebar-toggle-mini" onclick="toggleSidebar()" title="펼치기">☰</button>
  <div class="sidebar-inner">
    <div class="sidebar-logo"><span>D</span>emos <span style="font-size:12px;color:#999">Alpha 0.8</span></div>
    <button class="sidebar-btn active" onclick="createNewSession()">✨ 새 세션</button>
    <div class="sidebar-section">세션 목록 <span class="skill-count" id="sessionCount">0</span></div>
    <div id="sessionList" style="max-height:200px;overflow-y:auto;margin-bottom:4px;"></div>
    <div class="session-actions" id="sessionActions" style="display:none">
      <button onclick="archiveSelectedSessions()">📦 보관</button>
      <button class="danger" onclick="deleteSelectedSessions()">🗑️ 삭제</button>
      <button onclick="clearSessionSelection()">취소</button>
    </div>
    <div class="sidebar-section">불러온 스킬 <span class="skill-count" id="loadedCount">0</span></div>
    <div id="loadedSkillsList" style="font-size:12px;color:#666;padding:0 8px;"></div>
    <div class="sidebar-section" style="margin-top:16px;">안내</div>
    <div style="font-size:12px;color:#888;padding:0 8px;line-height:1.5;">
      1. ⚙️ API 설정<br>
      2. 분야/스킬 선택<br>
      3. 질문 입력 후 전송<br><br>
      <strong>SKILL.md</strong> 파일이 있는 스킬만 ✅ 표시됩니다.
    </div>
  </div>
  <div class="sidebar-footer">
    <div class="credits">🔬 Demos(민중) Alpha 0.8</div>
  </div>
  </div>
</div>
<button class="sidebar-toggle" id="sidebarToggle" onclick="toggleSidebar()">◀</button>

<div class="main">
  <div class="header">
    <div class="project-title">📁 Demos(민중) 프로젝트</div>
    <div style="display:flex;align-items:center;gap:8px;">
      <span id="tokenBadge" class="status off">⏳ 로딩중...</span>
      <span id="status" class="status off">⚪ 환경 미선택</span>
    </div>
  </div>
  <div class="content">
    <div class="content-inner">
      <!-- 환경 선택 -->
      <div class="section-label">LLM 환경 선택</div>
      <div id="tokenStatus" class="token-status missing">⏳ 토큰 상태 확인중...</div>
      <div class="env-row" id="envRow">
        <!-- JS에서 동적 생성 -->
      </div>

      <!-- CSV 업로드 -->
      <div class="csv-section">
        <div class="section-label">📎 데이터 업로드 (CSV/TSV)</div>
        <div id="csvUploadArea" class="csv-upload-area" onclick="document.getElementById('csvFileInput').click()"
             ondragover="event.preventDefault();this.classList.add('dragover')"
             ondragleave="this.classList.remove('dragover')"
             ondrop="event.preventDefault();this.classList.remove('dragover');handleCsvDrop(event)">
          <div class="icon">📂</div>
          <div class="label">CSV / TSV 파일을 끌어놓거나 클릭</div>
          <div class="sub">최대 50MB · UTF-8/CP949 자동 인식</div>
          <input type="file" id="csvFileInput" accept=".csv,.tsv,.txt" style="display:none" onchange="handleCsvSelect(event)">
        </div>
        <div id="csvInfoPanel" style="display:none"></div>
      </div>

      <!-- 범용 파일 업로드 -->
      <div class="csv-section">
        <div class="section-label">📁 파일 업로드 (문서/이미지/코드)</div>
        <div id="fileUploadArea" class="csv-upload-area" onclick="document.getElementById('fileInput').click()"
             ondragover="event.preventDefault();this.classList.add('dragover')"
             ondragleave="this.classList.remove('dragover')"
             ondrop="event.preventDefault();this.classList.remove('dragover');handleFileDrop(event)">
          <div class="icon">📁</div>
          <div class="label">파일을 끌어놓거나 클릭하여 업로드</div>
          <div class="sub">docx · xlsx · pdf · pptx · md · 이미지 · 코드</div>
          <input type="file" id="fileInput" accept=".docx,.xlsx,.pdf,.pptx,.md,.markdown,.png,.jpg,.jpeg,.gif,.bmp,.webp,.svg,.py,.js,.html,.css,.json,.xml,.yaml,.yml,.c,.cpp,.h,.java,.go,.rs,.sh,.bat" style="display:none" onchange="handleFileSelect(event)" multiple>
        </div>
        <div id="fileListPanel" style="display:none"></div>
      </div>

      <div class="section-label">분야 선택</div>
      <div class="tag-row" id="tagRow"></div>

      <div class="section-label">스킬 선택 <span style="font-weight:400;color:#bbb">( ✅ = SKILL.md 로드됨 )</span></div>
      <div class="skill-grid" id="skillGrid"></div>

      <div class="sysprompt-section">
        <div class="sysprompt-toggle" onclick="toggleSysPrompt()">
          <span class="arrow" id="spArrow">▶</span>
          <div class="section-label" style="margin-bottom:0;cursor:pointer">시스템 프롬프트</div>
          <span id="spPreviewBadge" style="font-size:11px;color:#6366f1;background:#eef2ff;padding:2px 8px;border-radius:10px">기본값</span>
        </div>
        <div class="sysprompt-body" id="spBody">
          <!-- 프리셋/저장 프롬프트 선택 바 -->
          <div id="promptPresets" style="display:flex;flex-wrap:wrap;gap:4px;margin-bottom:8px"></div>
          <textarea class="sysprompt-textarea" id="systemPromptInput" placeholder="시스템 프롬프트를 입력하세요. 비워두면 기본값 사용됩니다.&#10;&#10;아래 프리셋 버튼을 클릭하면 자동으로 채워집니다.&#10;수정 후 '저장' 버튼으로 나만의 프롬프트를 저장하세요."></textarea>
          <div class="sysprompt-info" style="display:flex;align-items:center;flex-wrap:wrap;gap:4px">
            <span>💡 스킬 프롬프트 <strong>앞에</strong> 추가됩니다.</span>
            <button style="background:#6366f1;color:#fff;border:none;border-radius:4px;padding:3px 10px;font-size:11px;cursor:pointer" onclick="saveCurrentPrompt()">💾 저장</button>
            <button style="background:#ef4444;color:#fff;border:none;border-radius:4px;padding:3px 10px;font-size:11px;cursor:pointer" onclick="deleteCurrentPrompt()" id="btnDeletePrompt" title="현재 선택된 저장 프롬프트 삭제">🗑️ 삭제</button>
            <button style="background:#f3f2ef;border:1px solid #e5e3de;border-radius:4px;padding:3px 8px;font-size:11px;cursor:pointer" onclick="resetSysPrompt()">초기화</button>
            <span id="promptSaveStatus" style="font-size:11px;color:#16a34a;display:none">✅ 저장됨!</span>
          </div>
        </div>
      </div>

      <div class="effort-section">
        <div class="section-label">응답 수준</div>
        <input type="range" class="effort-slider" id="effortSlider" min="0" max="3" value="2" oninput="updateEffort()">
        <div class="effort-labels">
          <span id="e0">즉시</span><span id="e1">빠름</span><span id="e2" class="active">표준</span><span id="e3">프로</span>
        </div>
      </div>

      <div class="style-row">
        <div class="style-group">
          <label>작성 스타일</label>
          <div id="styleChips" style="display:flex;flex-wrap:wrap;gap:3px;margin-bottom:4px"></div>
          <textarea id="writingStyle" placeholder="위 프리셋 클릭 또는 직접 입력..." style="min-height:28px;max-height:60px"></textarea>
        </div>
        <div class="style-group">
          <label>출력 형식</label>
          <div class="fmt-btns">
            <div class="fmt-btn selected" data-f="code" onclick="selFmt(this)">💻 코드</div>
            <div class="fmt-btn" data-f="code-fix" onclick="selFmt(this)">🔧 수정</div>
            <div class="fmt-btn" data-f="analysis" onclick="selFmt(this)">📊 분석</div>
            <div class="fmt-btn" data-f="report" onclick="selFmt(this)">📄 보고서</div>
            <div class="fmt-btn" data-f="step-by-step" onclick="selFmt(this)">📝 단계별</div>
          </div>
        </div>
      </div>

      <!-- 자동 스킬 선택 -->
      <div class="auto-skill-toggle" id="autoSkillToggle" onclick="toggleAutoSkill()">
        <div class="toggle-dot"></div>
        <div>
          <div style="font-weight:700;font-size:13px">🧠 자동 스킬 선택</div>
          <div style="font-size:11px;color:#888">질문을 분석하여 관련 스킬을 자동으로 로드합니다</div>
        </div>
      </div>
      <div class="auto-skill-preview" id="autoSkillPreview"></div>

      <div class="quick-row">
        <button class="quick-btn" onclick="qp('이 데이터를 분석해줘')">📊 데이터 분석</button>
        <button class="quick-btn" onclick="qp('업로드된 CSV 데이터의 통계 요약을 보여줘')">📋 CSV 요약</button>
        <button class="quick-btn" onclick="qp('이 데이터로 시각화 코드를 작성해줘')">📈 시각화</button>
        <button class="quick-btn" onclick="qp('Python 코드를 작성해줘')">🐍 코드 작성</button>
        <button class="quick-btn" onclick="qp('이 데이터에서 이상치를 찾아줘')">🔍 이상치 탐색</button>
        <button class="quick-btn" onclick="qp('논문 스타일로 정리해줘')">📝 논문 정리</button>
      </div>

      <div class="messages" id="msgs"></div>
    </div>
  </div>

  <!-- 질문 입력 - 하단 고정 -->
  <div class="chat-box-fixed">
    <div class="chat-box-fixed-inner">
      <textarea class="chat-input" id="input" placeholder="질문을 하거나 수행하려는 분석을 설명하세요..." onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();handleSendStop()}" oninput="this.style.height='auto';this.style.height=this.scrollHeight+'px'"></textarea>
      <div class="chat-footer">
        <span style="font-size:12px;color:#bbb">Enter 전송 / Shift+Enter 줄바꿈</span>
        <button class="send-btn" onclick="handleSendStop()" id="sendBtn">▶</button>
      </div>
    </div>
  </div>
</div>

<!-- 스킬 상세 패널 -->
<div id="skillDetailOverlay" class="skill-detail-overlay" style="display:none" onclick="if(event.target===this)closeSkillDetail()">
  <div class="skill-detail-panel">
    <div class="sdp-header">
      <h2 id="sdpTitle">스킬 상세</h2>
      <button class="sdp-close" onclick="closeSkillDetail()">✕</button>
    </div>
    <div class="sdp-tabs" id="sdpTabs"></div>
    <div class="sdp-body" id="sdpBody">로딩중...</div>
  </div>
</div>

<script>
let envs = {};
let hasToken = false;
let selEnv = '';
let catalog = {};
let selDomains = ['bioinformatics','dev-tools','agent-data-ai'];
let selSkills = [];
let autoSkillMode = true;  // 기본 ON
let selFormat = 'code';
let effort = 2;
let history = [];
let maxTokens = 4096;
let currentSessionId = null;
let sessions = {};

// ===== Init =====
loadSessions();
// Restore last session or create new
const lastSessions = Object.values(sessions).sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0));
if(lastSessions.length > 0){
  currentSessionId = lastSessions[0].id;
  const s = lastSessions[0];
  history = s.history || [];
  setTimeout(()=>{
    document.getElementById('msgs').innerHTML = s.msgsHtml || '';
    if(s.writingStyle) document.getElementById('writingStyle').value = s.writingStyle;
    if(s.systemPrompt) document.getElementById('systemPromptInput').value = s.systemPrompt;
    if(s.systemPromptId){ currentPromptId=s.systemPromptId; renderPromptChips(); }
    if(s.selFormat){ selFormat=s.selFormat; document.querySelectorAll('.fmt-btn').forEach(b=>{b.classList.toggle('selected',b.dataset.f===selFormat);}); }
    if(s.effort!==undefined){ effort=s.effort; document.getElementById('effortSlider').value=effort; }
    if(s.selEnv){ selEnv=s.selEnv; renderEnvs(); updateStatus(); }
    if(s.selDomains && s.selDomains.length>0){ selDomains=s.selDomains; renderTags(); renderSkills(); }
    if(s.selSkills && s.selSkills.length>0){ selSkills=s.selSkills; renderSkills(); updateLoaded(); }
    renderSessionList();
  }, 100);
} else {
  currentSessionId = 'sess_'+Date.now();
  sessions[currentSessionId] = { id:currentSessionId, name:'새 세션', history:[], msgsHtml:'', updatedAt:Date.now() };
  saveSessions();
}

Promise.all([
  fetch('/api/config').then(r=>r.json()),
  fetch('/api/skills').then(r=>r.json()),
]).then(([cfgData, skillData])=>{
  envs = cfgData.envs || {};
  hasToken = cfgData.has_token;
  catalog = skillData || {};
  try{ renderTokenStatus(); }catch(e){ console.error('renderTokenStatus:',e); }
  try{ renderEnvs(); }catch(e){ console.error('renderEnvs:',e); }
  try{ renderTags(); }catch(e){ console.error('renderTags:',e); }
  try{ renderSkills(); }catch(e){ console.error('renderSkills:',e); }
  try{ renderSessionList(); }catch(e){ console.error('renderSessionList:',e); }
}).catch(err=>{
  console.error('설정 로드 실패:', err);
  document.getElementById('tokenStatus').className='token-status missing';
  document.getElementById('tokenStatus').textContent='❌ 서버 연결 실패 - 새로고침 해주세요';
  document.getElementById('tokenBadge').className='status off';
  document.getElementById('tokenBadge').textContent='❌ 연결 실패';
});

// ===== 환경 선택 =====
function renderEnvs(){
  const row = document.getElementById('envRow');
  row.innerHTML = '';
  const icons = {'dev':'🧪','prod':'🚀','common':'🌐','gguf-local':'💻'};
  for(const [id, env] of Object.entries(envs)){
    const btn = document.createElement('div');
    btn.className = 'env-btn' + (selEnv===id?' selected':'');
    btn.innerHTML = `<div class="env-name">${icons[id]||'🔗'} ${env.name}</div><div class="env-model">${env.model}</div>`;
    btn.onclick = ()=>{ selEnv=id; renderEnvs(); updateStatus(); };
    row.appendChild(btn);
  }
}
function renderTokenStatus(){
  const el = document.getElementById('tokenStatus');
  const badge = document.getElementById('tokenBadge');
  if(hasToken){
    el.className='token-status ok';
    el.textContent='🔑 TOKEN.TXT 로드됨 - API 키 자동 적용';
    badge.className='status on';
    badge.textContent='🔑 토큰 OK';
  } else {
    el.className='token-status ok';
    el.textContent='ℹ️ TOKEN.TXT 미설정 - 폐쇄망 API는 토큰 없이 사용 가능합니다';
    badge.className='status on';
    badge.textContent='🔗 토큰 선택';
  }
}
function updateStatus(){
  const st = document.getElementById('status');
  if(selEnv && envs[selEnv]){
    st.className='status on';
    st.textContent='🟢 ' + envs[selEnv].name;
  } else {
    st.className='status off';
    st.textContent='⚪ 환경 미선택';
  }
}

// ===== Tags =====
function renderTags(){
  const row = document.getElementById('tagRow');
  row.innerHTML = '';
  for(const [id, d] of Object.entries(catalog)){
    const t = document.createElement('div');
    t.className = 'tag' + (selDomains.includes(id)?' selected':'');
    t.style.setProperty('--c', d.color);
    t.style.setProperty('--bg', d.color+'18');
    t.style.setProperty('--fg', d.color);
    t.textContent = d.icon + ' ' + d.label;
    t.onclick = ()=>{ toggleDomain(id); t.classList.toggle('selected'); renderSkills(); };
    row.appendChild(t);
  }
}
function toggleDomain(id){
  if(selDomains.includes(id)) selDomains=selDomains.filter(x=>x!==id);
  else selDomains.push(id);
}

// ===== Skills =====
function renderSkills(){
  const grid = document.getElementById('skillGrid');
  grid.innerHTML = '';
  selDomains.forEach(did=>{
    const d = catalog[did];
    if(!d) return;
    d.skills.forEach(s=>{
      const c = document.createElement('div');
      c.className = 'skill-card' + (selSkills.includes(s.id)?' selected':'') + (!s.available?' unavailable':'');
      const desc = s.desc ? s.desc : '';
      const avail = s.available ? '✅' : '❌';
      // extras: 스크립트/레퍼런스 개수
      let extras = [];
      if(s.scripts > 0) extras.push(`🐍${s.scripts}`);
      if(s.references > 0) extras.push(`📄${s.references}`);
      if(s.assets > 0) extras.push(`📦${s.assets}`);
      const extrasHtml = extras.length ? `<div class="extras">${extras.join(' ')}</div>` : '';
      c.innerHTML = `<div class="sn">${avail} ${s.name}</div><div class="sd">${desc}</div>${extrasHtml}`;
      if(s.available){
        c.onclick = (e)=>{
          // Shift+클릭 = 상세 패널
          if(e.shiftKey || (extras.length > 0 && e.detail === 2)){
            openSkillDetail(s.id);
            return;
          }
          if(selSkills.includes(s.id)) selSkills=selSkills.filter(x=>x!==s.id);
          else selSkills.push(s.id);
          renderSkills();
          updateLoaded();
        };
        // 우클릭 = 상세 패널
        c.oncontextmenu = (e)=>{
          e.preventDefault();
          openSkillDetail(s.id);
        };
      }
      grid.appendChild(c);
    });
  });
  updateLoaded();
}
function updateLoaded(){
  document.getElementById('loadedCount').textContent = selSkills.length;
  document.getElementById('loadedSkillsList').innerHTML = selSkills.map(s=>`<div style="padding:2px 0">✅ ${s}</div>`).join('') || '<div style="color:#bbb">선택된 스킬 없음</div>';
}

// ===== Effort =====
function updateEffort(){
  const s = document.getElementById('effortSlider');
  effort = parseInt(s.value);
  s.style.setProperty('--val', (effort/3*100)+'%');
  for(let i=0;i<=3;i++) document.getElementById('e'+i).className = i===effort?'active':'';
}
updateEffort();

// ===== Format =====
function selFmt(el){
  document.querySelectorAll('.fmt-btn').forEach(b=>b.classList.remove('selected'));
  el.classList.add('selected');
  selFormat = el.dataset.f;
}

// ===== Quick prompt =====
function qp(t){ document.getElementById('input').value=t; }

// ===== Auto Skill =====
function toggleAutoSkill(){
  autoSkillMode = !autoSkillMode;
  const el = document.getElementById('autoSkillToggle');
  el.classList.toggle('on', autoSkillMode);
  if(!autoSkillMode){
    document.getElementById('autoSkillPreview').classList.remove('show');
    document.getElementById('autoSkillPreview').innerHTML = '';
  }
}
// 초기 상태 반영
setTimeout(()=>{
  document.getElementById('autoSkillToggle').classList.toggle('on', autoSkillMode);
}, 200);

// 입력 중 자동 스킬 미리보기 (디바운스)
let autoSkillTimer = null;
document.addEventListener('DOMContentLoaded', ()=>{
  const inp = document.getElementById('input');
  if(inp) inp.addEventListener('input', ()=>{
    if(!autoSkillMode) return;
    clearTimeout(autoSkillTimer);
    autoSkillTimer = setTimeout(async ()=>{
      const q = inp.value.trim();
      if(q.length < 4) { document.getElementById('autoSkillPreview').classList.remove('show'); return; }
      try{
        const r = await fetch('/api/auto-skills',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({query:q,max_skills:7,history:history})});
        const d = await r.json();
        const prev = document.getElementById('autoSkillPreview');
        if(d.skills && d.skills.length > 0){
          prev.innerHTML = '🧠 자동 추천: ' + d.skills.map(s=>`<span class="auto-skill-badge" title="${s.desc}">${s.id} (${s.score})</span>`).join('');
          prev.classList.add('show');
        } else {
          prev.classList.remove('show');
        }
      }catch(e){}
    }, 500);
  });
});

// ===== Chat =====
let chatAbort = null;  // AbortController for current request
let isSending = false;

function handleSendStop(){
  if(isSending){
    stopGeneration();
  } else {
    send();
  }
}
function stopGeneration(){
  if(chatAbort){
    chatAbort.abort();
    chatAbort = null;
  }
  // 백엔드 GGUF 중단 요청
  fetch('/api/chat/stop',{method:'POST'}).catch(()=>{});
  isSending = false;
  const btn = document.getElementById('sendBtn');
  btn.textContent = '▶';
  btn.classList.remove('stop-mode');
  btn.disabled = false;
  // typing indicator 제거
  document.querySelectorAll('.typing-wrap').forEach(el=>el.remove());
  addMsg('assistant','⏹️ 응답이 중지되었습니다.');
  saveCurrentSession();
}

async function send(){
  const el=document.getElementById('input');
  const text=el.value.trim();
  if(!text) return;
  if(!selEnv){alert('먼저 위에서 LLM 환경을 선택해주세요.');return;}

  // 자동 스킬 모드: 수동 선택이 없으면 자동 추천 스킬 사용
  let skillsToUse = [...selSkills];
  let autoLoaded = [];
  if(autoSkillMode && skillsToUse.length === 0){
    try{
      const ar = await fetch('/api/auto-skills',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({query:text,max_skills:7,history:history})});
      const ad = await ar.json();
      if(ad.skills && ad.skills.length > 0){
        autoLoaded = ad.skills.map(s=>s.id);
        skillsToUse = autoLoaded;
      }
    }catch(e){}
  }

  addMsg('user',text);
  history.push({role:'user',content:text});
  el.value=''; el.style.height='auto';
  document.getElementById('autoSkillPreview').classList.remove('show');

  // 자동 로드 안내
  if(autoLoaded.length > 0){
    addMsg('assistant', '🧠 자동 스킬 로드: ' + autoLoaded.join(', '));
  }

  const typing=addTyping();
  isSending = true;
  const btn = document.getElementById('sendBtn');
  btn.textContent = '⏹';
  btn.classList.add('stop-mode');
  btn.disabled = false;

  chatAbort = new AbortController();

  try{
    const resp=await fetch('/api/chat',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      signal: chatAbort.signal,
      body:JSON.stringify({
        env: selEnv,
        messages:history, skills:skillsToUse, effort,
        format:selFormat,
        writing_style:document.getElementById('writingStyle').value.trim(),
        system_prompt:document.getElementById('systemPromptInput').value.trim(),
        max_tokens:maxTokens,
      })
    });
    const data=await resp.json();
    typing.remove();

    if(data.error){
      addMsg('assistant','❌ '+data.error);
    } else {
      let info = '';
      if(data.loaded_skills && data.loaded_skills.length > 0){
        let extra = data.tokens_budget ? ` [${data.tokens_budget}]` : '';
        let mode = autoLoaded.length > 0 ? '🧠자동' : '✅수동';
        info = `\n[${mode} 스킬: ${data.loaded_skills.join(', ')}] [${envs[selEnv].name}] (${data.system_prompt_length}자)${extra}`;
      }
      addMsg('assistant', data.content + info);
      history.push({role:'assistant',content:data.content});
    }
  }catch(e){
    typing.remove();
    if(e.name === 'AbortError'){
      // 사용자가 중지한 경우 - stopGeneration()에서 이미 처리됨
    } else {
      addMsg('assistant','❌ 서버 연결 실패: '+e.message);
    }
  }
  isSending = false;
  chatAbort = null;
  btn.textContent = '▶';
  btn.classList.remove('stop-mode');
  btn.disabled = false;
  const inp=document.getElementById('input');
  inp.focus();
  inp.style.height='auto';
  saveCurrentSession();
}

function renderMd(text){
  // 0) <think> 블록을 접이식 사고과정 박스로 변환 (HTML escape 전)
  text=text.replace(/<think>([\s\S]*?)<\/think>\s*/g, function(_,content){
    const escaped=content.trim().replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/\n/g,'<br>');
    return `<details class="think-box"><summary>💭 사고 과정</summary><div class="think-content">${escaped}</div></details>`;
  });
  // 닫히지 않은 <think> 태그도 처리 (응답 잘림 대비)
  text=text.replace(/<think>([\s\S]*)$/g, function(_,content){
    const escaped=content.trim().replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/\n/g,'<br>');
    return `<details class="think-box"><summary>💭 사고 과정 (진행중...)</summary><div class="think-content">${escaped}</div></details>`;
  });
  // 1) escape HTML (think-box는 이미 처리했으므로 보호)
  const thinkBlocks=[];
  text=text.replace(/<details class="think-box">[\s\S]*?<\/details>/g, m=>{thinkBlocks.push(m);return `__THINK_${thinkBlocks.length-1}__`;});
  let s=text.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  // 2) code blocks (```lang\n...``` 또는 ```lang코드...``` 모두 지원)
  s=s.replace(/```(\w*)\s*([\s\S]*?)```/g,(_,lang,code)=>{
    const cls=lang?` class="language-${lang}"`:'';
    return `<pre><code${cls}>${code.trim()}</code></pre>`;
  });
  // 3) tables
  s=s.replace(/((?:^\|.+\|[ ]*\n){2,})/gm, function(tbl){
    const rows=tbl.trim().split('\n').filter(r=>r.trim());
    if(rows.length<2) return tbl;
    const parseRow=r=>r.replace(/^\|/,'').replace(/\|$/,'').split('|').map(c=>c.trim());
    const hdr=parseRow(rows[0]);
    // skip separator row
    let startIdx=1;
    if(/^[\s|:-]+$/.test(rows[1])) startIdx=2;
    let h='<table><thead><tr>'+hdr.map(c=>'<th>'+c+'</th>').join('')+'</tr></thead><tbody>';
    for(let i=startIdx;i<rows.length;i++){
      const cells=parseRow(rows[i]);
      h+='<tr>'+cells.map(c=>'<td>'+c+'</td>').join('')+'</tr>';
    }
    return h+'</tbody></table>';
  });
  // 4) headings
  s=s.replace(/^#### (.+)$/gm,'<h4>$1</h4>');
  s=s.replace(/^### (.+)$/gm,'<h3>$1</h3>');
  s=s.replace(/^## (.+)$/gm,'<h2>$1</h2>');
  s=s.replace(/^# (.+)$/gm,'<h1>$1</h1>');
  // 5) hr
  s=s.replace(/^---+$/gm,'<hr>');
  // 6) blockquote
  s=s.replace(/^&gt; (.+)$/gm,'<blockquote>$1</blockquote>');
  // 7) unordered list
  s=s.replace(/(^[\-\*] .+\n?)+/gm, function(block){
    const items=block.trim().split('\n').map(l=>l.replace(/^[\-\*] /,''));
    return '<ul>'+items.map(i=>'<li>'+i+'</li>').join('')+'</ul>';
  });
  // 8) ordered list
  s=s.replace(/(^\d+\. .+\n?)+/gm, function(block){
    const items=block.trim().split('\n').map(l=>l.replace(/^\d+\. /,''));
    return '<ol>'+items.map(i=>'<li>'+i+'</li>').join('')+'</ol>';
  });
  // 9) inline: bold, italic, code
  s=s.replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>');
  s=s.replace(/\*(.+?)\*/g,'<em>$1</em>');
  s=s.replace(/`([^`]+)`/g,'<code>$1</code>');
  // 10) paragraphs: double newline -> <p>
  s=s.split(/\n{2,}/).map(block=>{
    const t=block.trim();
    if(!t) return '';
    if(/^<(pre|h[1-4]|ul|ol|table|hr|blockquote)/.test(t)) return t;
    return '<p>'+t.replace(/\n/g,'<br>')+'</p>';
  }).join('\n');
  // single newlines inside remaining text
  // think 블록 복원
  thinkBlocks.forEach((block,i)=>{s=s.replace(`__THINK_${i}__`,block);});
  return s;
}
function addMsg(role,text){
  const c=document.getElementById('msgs');
  const d=document.createElement('div');
  d.className='msg '+role;
  let html = role==='user' ? text.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;') : renderMd(text);
  d.innerHTML=`<div class="msg-label">${role==='user'?'나':'Demos'}</div>${html}`;
  c.appendChild(d);
  d.querySelectorAll('pre').forEach(pre=>{
    const btn=document.createElement('button');
    btn.className='copy-btn';btn.textContent='복사';
    btn.onclick=()=>{navigator.clipboard.writeText(pre.textContent.replace('복사',''));btn.textContent='✓';setTimeout(()=>btn.textContent='복사',1500);};
    pre.appendChild(btn);
  });
  c.scrollIntoView({behavior:'smooth',block:'end'});
}
function addTyping(){
  const c=document.getElementById('msgs');
  const d=document.createElement('div');
  d.className='msg assistant';
  d.innerHTML='<div class="typing"><span></span><span></span><span></span></div>';
  c.appendChild(d);
  c.scrollIntoView({behavior:'smooth',block:'end'});
  return d;
}
// ===== Session Management =====
function loadSessions(){
  try{ sessions = JSON.parse(localStorage.getItem('domos_sessions') || '{}'); }catch(e){ sessions={}; }
}
function saveSessions(){
  localStorage.setItem('domos_sessions', JSON.stringify(sessions));
}
function saveCurrentSession(){
  if(!currentSessionId) return;
  sessions[currentSessionId] = {
    id: currentSessionId,
    name: sessions[currentSessionId]?.name || '새 세션',
    history: history,
    selEnv: selEnv,
    selDomains: selDomains,
    selSkills: selSkills,
    selFormat: selFormat,
    effort: effort,
    writingStyle: document.getElementById('writingStyle')?.value || '',
    writingStyleId: activeStyleId || '',
    systemPrompt: document.getElementById('systemPromptInput')?.value || '',
    systemPromptId: currentPromptId || '',
    msgsHtml: document.getElementById('msgs').innerHTML,
    updatedAt: Date.now()
  };
  // Auto-name from first user message
  if(sessions[currentSessionId].name === '새 세션' && history.length > 0){
    const first = history.find(m=>m.role==='user');
    if(first) sessions[currentSessionId].name = first.content.slice(0,30) + (first.content.length>30?'...':'');
  }
  saveSessions();
  renderSessionList();
}
let selectedSessions = new Set();

function renderSessionList(){
  const el=document.getElementById('sessionList');
  if(!el) return;
  const sorted = Object.values(sessions).filter(s=>!s.archived).sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0));
  const archived = Object.values(sessions).filter(s=>s.archived).sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0));

  document.getElementById('sessionCount').textContent = sorted.length;

  if(sorted.length===0 && archived.length===0){
    el.innerHTML='<div style="font-size:11px;color:#bbb;padding:4px 8px;">저장된 세션 없음</div>';
    return;
  }

  let html = sorted.map(s=>{
    const checked = selectedSessions.has(s.id) ? 'checked' : '';
    const isCurrent = s.id===currentSessionId;
    const time = s.updatedAt ? new Date(s.updatedAt).toLocaleDateString('ko',{month:'short',day:'numeric'}) : '';
    return `<div class="session-item${isCurrent?' current':''}" onclick="loadSession('${s.id}')">
      <input type="checkbox" class="session-cb" ${checked} onclick="event.stopPropagation();toggleSessionCheck('${s.id}',this)">
      <span class="session-name">${s.name||'새 세션'}</span>
      <span class="session-time">${time}</span>
    </div>`;
  }).join('');

  // 보관된 세션 (항상 펼쳐서 보여줌)
  if(archived.length > 0){
    html += `<div style="padding:4px 8px;margin-top:6px;border-top:1px solid #e5e3de;padding-top:8px;">
      <div style="font-size:11px;color:#999;margin-bottom:4px">📦 보관함 (${archived.length})</div>
      ${archived.map(s=>{
        const checked = selectedSessions.has(s.id) ? 'checked' : '';
        return `<div class="session-item" style="opacity:.7" onclick="loadSession('${s.id}')">
          <input type="checkbox" class="session-cb" ${checked} onclick="event.stopPropagation();toggleSessionCheck('${s.id}',this)">
          <span class="session-name">${s.name||'세션'}</span>
        </div>`;
      }).join('')}
    </div>`;
  }

  el.innerHTML = html;

  // 체크된 게 있으면 액션 버튼 표시
  updateSessionActions();
}

function toggleSessionCheck(id, cb){
  if(cb.checked) selectedSessions.add(id);
  else selectedSessions.delete(id);
  updateSessionActions();
}

function updateSessionActions(){
  const el = document.getElementById('sessionActions');
  if(selectedSessions.size === 0){ el.style.display='none'; return; }
  // 체크된 것 중 보관/일반 구분
  let hasArchived=false, hasNormal=false;
  selectedSessions.forEach(id=>{
    if(sessions[id]?.archived) hasArchived=true;
    else hasNormal=true;
  });
  let btns = '';
  if(hasNormal) btns += `<button onclick="archiveSelectedSessions()">📦 보관</button>`;
  if(hasArchived) btns += `<button onclick="restoreSelectedSessions()">↩ 복원</button>`;
  btns += `<button class="danger" onclick="deleteSelectedSessions()">🗑️ 삭제</button>`;
  btns += `<button onclick="clearSessionSelection()">취소</button>`;
  el.innerHTML = btns;
  el.style.display = 'flex';
}

function clearSessionSelection(){
  selectedSessions.clear();
  renderSessionList();
}

function deleteSelectedSessions(){
  if(selectedSessions.size===0) return;
  const count = selectedSessions.size;
  if(!confirm(count + '개 세션을 삭제할까요?')) return;
  let deletedCurrent = false;
  selectedSessions.forEach(id=>{
    if(id===currentSessionId) deletedCurrent = true;
    delete sessions[id];
  });
  selectedSessions.clear();
  saveSessions();
  if(deletedCurrent) createNewSession();
  else renderSessionList();
}

function archiveSelectedSessions(){
  if(selectedSessions.size===0) return;
  let archivedCurrent = false;
  selectedSessions.forEach(id=>{
    if(sessions[id]){
      sessions[id].archived = true;
      if(id===currentSessionId) archivedCurrent = true;
    }
  });
  selectedSessions.clear();
  saveSessions();
  if(archivedCurrent) createNewSession();
  else renderSessionList();
}

// ===== 사이드바 전체 접기/펼치기 =====
function toggleSidebar(){
  const sb = document.getElementById('sidebar');
  const btn = document.getElementById('sidebarToggle');
  const chatBox = document.querySelector('.chat-box-fixed');
  sb.classList.toggle('collapsed');
  document.body.classList.toggle('sb-collapsed');
  if(sb.classList.contains('collapsed')){
    btn.textContent = '▶';
    btn.title = '사이드바 펼치기';
    if(chatBox) chatBox.style.left = '48px';
  } else {
    btn.textContent = '◀';
    btn.title = '사이드바 접기';
    if(chatBox) chatBox.style.left = '250px';
  }
  // localStorage에 상태 저장
  localStorage.setItem('domos_sidebar_collapsed', sb.classList.contains('collapsed'));
}
// 저장된 상태 복원
(function(){
  const saved = localStorage.getItem('domos_sidebar_collapsed');
  if(saved === 'true'){
    const sb = document.getElementById('sidebar');
    const btn = document.getElementById('sidebarToggle');
    const chatBox = document.querySelector('.chat-box-fixed');
    if(sb){ sb.classList.add('collapsed'); }
    if(btn){ btn.textContent='▶'; btn.title='사이드바 펼치기'; }
    if(chatBox){ chatBox.style.left='48px'; }
    document.body.classList.add('sb-collapsed');
  }
})();
function createNewSession(){
  // Save current before switching
  saveCurrentSession();
  currentSessionId = 'sess_'+Date.now();
  history=[];
  selSkills=[];
  document.getElementById('msgs').innerHTML='';
  document.getElementById('writingStyle').value='';
  document.getElementById('systemPromptInput').value='';
  activeStyleId=null;
  currentPromptId=null;
  selFormat='code';
  effort=2;
  document.getElementById('effortSlider').value=2;
  document.querySelectorAll('.fmt-btn').forEach(b=>{b.classList.toggle('selected',b.dataset.f==='code');});
  renderSkills();
  updateLoaded();
  renderStyleChips();
  renderPromptChips();
  updateSpBadge();
  updateEffort();
  sessions[currentSessionId] = { id:currentSessionId, name:'새 세션', history:[], msgsHtml:'', updatedAt:Date.now() };
  saveSessions();
  renderSessionList();
}
function loadSession(id){
  if(id===currentSessionId) return;
  saveCurrentSession();
  const s=sessions[id];
  if(!s) return;
  currentSessionId=id;
  history=s.history||[];
  document.getElementById('msgs').innerHTML=s.msgsHtml||'';
  if(s.writingStyle) document.getElementById('writingStyle').value=s.writingStyle;
  if(s.writingStyleId){ activeStyleId=s.writingStyleId; renderStyleChips(); }
  if(s.systemPrompt) document.getElementById('systemPromptInput').value=s.systemPrompt;
  if(s.selFormat){ selFormat=s.selFormat; document.querySelectorAll('.fmt-btn').forEach(b=>{b.classList.toggle('selected',b.dataset.f===selFormat);}); }
  if(s.effort!==undefined){ effort=s.effort; document.getElementById('effortSlider').value=effort; updateEffort(); }
  renderSessionList();
}
function deleteSession(id){
  delete sessions[id];
  saveSessions();
  if(id===currentSessionId) createNewSession();
  else renderSessionList();
}
function restoreArchivedSession(id){
  if(sessions[id]){ sessions[id].archived=false; saveSessions(); renderSessionList(); }
}
function restoreSelectedSessions(){
  if(selectedSessions.size===0) return;
  selectedSessions.forEach(id=>{
    if(sessions[id]) sessions[id].archived=false;
  });
  selectedSessions.clear();
  saveSessions();
  renderSessionList();
}
function newSession(){ createNewSession(); }

// ===== System Prompt =====
function toggleSysPrompt(){
  const body = document.getElementById('spBody');
  const arrow = document.getElementById('spArrow');
  body.classList.toggle('show');
  arrow.classList.toggle('open');
  if(body.classList.contains('show')){
    arrow.textContent='▼';
  } else {
    arrow.textContent='▶';
    updateSpBadge();
  }
}
function updateSpBadge(){
  const badge = document.getElementById('spPreviewBadge');
  const val = document.getElementById('systemPromptInput').value.trim();
  if(val){
    badge.textContent = val.length + '자 커스텀';
    badge.style.background='#fef3c7';
    badge.style.color='#d97706';
  } else {
    badge.textContent = '기본값';
    badge.style.background='#eef2ff';
    badge.style.color='#6366f1';
  }
}
function resetSysPrompt(){
  document.getElementById('systemPromptInput').value='';
  currentPromptId = null;
  updateSpBadge();
  renderPromptChips();
}
document.getElementById('systemPromptInput').addEventListener('input', function(){
  updateSpBadge();
  // 수동 편집하면 active 해제
  if(currentPromptId){
    currentPromptId = null;
    renderPromptChips();
  }
});

// ===== 시스템 프롬프트 프리셋/저장 관리 =====
let currentPromptId = null;
let promptList = [];

async function loadPromptList(){
  try {
    const r = await fetch('/api/prompts');
    const d = await r.json();
    promptList = d.prompts || [];
    renderPromptChips();
  } catch(e){ console.error('프롬프트 목록 로드 실패:', e); }
}

function renderPromptChips(){
  const container = document.getElementById('promptPresets');
  if(!container) return;
  container.innerHTML = '';
  promptList.forEach(p => {
    const chip = document.createElement('span');
    chip.className = 'prompt-chip' + (p.type==='saved'?' saved':'') + (currentPromptId===p.id?' active':'');
    chip.innerHTML = p.icon + ' ' + p.name;
    chip.title = p.preview;
    chip.onclick = () => selectPrompt(p.id);
    container.appendChild(chip);
  });
  // 삭제 버튼 표시/숨김
  const delBtn = document.getElementById('btnDeletePrompt');
  if(delBtn) delBtn.style.display = (currentPromptId && currentPromptId.startsWith('saved:')) ? '' : 'none';
}

async function selectPrompt(pid){
  try {
    const r = await fetch('/api/prompts/' + encodeURIComponent(pid));
    const d = await r.json();
    if(d.content){
      document.getElementById('systemPromptInput').value = d.content;
      currentPromptId = pid;
      updateSpBadge();
      renderPromptChips();
    }
  } catch(e){ console.error('프롬프트 로드 실패:', e); }
}

async function saveCurrentPrompt(){
  const content = document.getElementById('systemPromptInput').value.trim();
  if(!content){ alert('저장할 내용이 없습니다.'); return; }
  const name = prompt('프롬프트 이름을 입력하세요:', currentPromptId?.startsWith('saved:') ? currentPromptId.slice(6) : '');
  if(!name) return;
  try {
    const r = await fetch('/api/prompts', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({name, content})
    });
    const d = await r.json();
    if(d.success){
      currentPromptId = d.id;
      const status = document.getElementById('promptSaveStatus');
      status.style.display='inline'; setTimeout(()=>status.style.display='none', 2000);
      await loadPromptList();
    } else { alert(d.error || '저장 실패'); }
  } catch(e){ alert('저장 오류: ' + e); }
}

async function deleteCurrentPrompt(){
  if(!currentPromptId || !currentPromptId.startsWith('saved:')) return;
  const name = currentPromptId.slice(6);
  if(!confirm('"' + name + '" 프롬프트를 삭제하시겠습니까?')) return;
  try {
    const r = await fetch('/api/prompts/' + encodeURIComponent(currentPromptId), {method:'DELETE'});
    const d = await r.json();
    if(d.success){
      document.getElementById('systemPromptInput').value = '';
      currentPromptId = null;
      updateSpBadge();
      await loadPromptList();
    }
  } catch(e){ alert('삭제 오류: ' + e); }
}

// 페이지 로드시 프롬프트 목록 불러오기
loadPromptList();

// ===== 작성 스타일 프리셋 =====
const STYLE_PRESETS = [
  {id:'concise',    icon:'⚡', name:'간결', value:'간결하고 핵심만. 불필요한 설명 생략.'},
  {id:'detailed',   icon:'📖', name:'상세', value:'상세하고 친절하게. 원리, 배경, 예시 포함.'},
  {id:'practical',  icon:'🔨', name:'실용적', value:'바로 복붙해서 쓸 수 있게. 실전 위주, 이론 최소화.'},
  {id:'academic',   icon:'🎓', name:'학술', value:'학술적 톤. 정확한 용어, 인용, 근거 제시.'},
  {id:'comment-kr', icon:'💬', name:'한글주석', value:'코드 주석을 상세한 한국어로. 변수명은 영어 유지.'},
  {id:'senior-dev', icon:'👨‍💻', name:'시니어', value:'시니어 개발자 관점. 왜 이렇게 하는지, 대안은 뭔지, 주의점 포함.'},
  {id:'debug',      icon:'🐛', name:'디버그', value:'에러 원인 분석 중심. traceback 해석, 재현 조건, 해결책 순서.'},
  {id:'data-story', icon:'📊', name:'데이터', value:'데이터 스토리텔링. 숫자→의미→액션 순서로 해석.'},
];
let activeStyleId = null;

function renderStyleChips(){
  const container = document.getElementById('styleChips');
  if(!container) return;
  container.innerHTML = '';
  STYLE_PRESETS.forEach(s => {
    const chip = document.createElement('span');
    chip.className = 'prompt-chip' + (activeStyleId===s.id ? ' active' : '');
    chip.innerHTML = s.icon + ' ' + s.name;
    chip.title = s.value;
    chip.onclick = () => {
      if(activeStyleId === s.id){
        activeStyleId = null;
        document.getElementById('writingStyle').value = '';
      } else {
        activeStyleId = s.id;
        document.getElementById('writingStyle').value = s.value;
      }
      renderStyleChips();
    };
    container.appendChild(chip);
  });
}
renderStyleChips();
document.getElementById('writingStyle').addEventListener('input', function(){
  // 수동 편집하면 active 해제
  const val = this.value.trim();
  const match = STYLE_PRESETS.find(s => s.value === val);
  activeStyleId = match ? match.id : null;
  renderStyleChips();
});

// ===== Skill Detail Panel =====
let currentSkillDetail = null;

async function openSkillDetail(skillId){
  const overlay = document.getElementById('skillDetailOverlay');
  overlay.style.display = 'flex';
  document.getElementById('sdpTitle').textContent = skillId;
  document.getElementById('sdpBody').innerHTML = '⏳ 로딩중...';

  try{
    const resp = await fetch(`/api/skill/${skillId}`);
    currentSkillDetail = await resp.json();
    renderSdpTabs('scripts');
  }catch(e){
    document.getElementById('sdpBody').innerHTML = `❌ 로딩 실패: ${e.message}`;
  }
}

function closeSkillDetail(){
  document.getElementById('skillDetailOverlay').style.display = 'none';
  currentSkillDetail = null;
}

function renderSdpTabs(active){
  if(!currentSkillDetail) return;
  const d = currentSkillDetail;
  const tabsEl = document.getElementById('sdpTabs');
  const tabs = [
    {id:'scripts', label:`🐍 스크립트 (${d.scripts.length})`, show: true},
    {id:'references', label:`📄 레퍼런스 (${d.references.length})`, show: true},
    {id:'assets', label:`📦 에셋 (${d.assets.length})`, show: d.assets.length > 0},
    {id:'skillmd', label:'📋 SKILL.md', show: true},
  ];
  tabsEl.innerHTML = '';
  tabs.forEach(t=>{
    if(!t.show) return;
    const el = document.createElement('div');
    el.className = 'sdp-tab' + (active===t.id?' active':'');
    el.textContent = t.label;
    el.onclick = ()=> renderSdpTabs(t.id);
    tabsEl.appendChild(el);
  });
  renderSdpContent(active);
}

function renderSdpContent(tab){
  const body = document.getElementById('sdpBody');
  const d = currentSkillDetail;

  if(tab === 'skillmd'){
    body.innerHTML = `<div class="sdp-code">${esc(d.content || '(내용 없음)')}</div>
      <button class="sdp-btn inject" style="margin-top:10px" onclick="injectToChat('skillmd','')">💬 채팅에 SKILL.md 주입</button>`;
    return;
  }

  const files = d[tab] || [];
  if(files.length === 0){
    body.innerHTML = '<div style="text-align:center;color:#999;padding:40px">파일 없음</div>';
    return;
  }

  const isPy = tab === 'scripts';
  let html = '<ul class="sdp-file-list">';
  files.forEach(f=>{
    const icon = f.name.endsWith('.py') ? '🐍' : f.name.endsWith('.md') ? '📄' : '📎';
    const sizeKb = (f.size / 1024).toFixed(1);
    html += `<li class="sdp-file-item" onclick="viewSkillFile('${d.name}','${f.path}')">
      <span class="sdp-file-icon">${icon}</span>
      <span class="sdp-file-name">${esc(f.name)}</span>
      <span class="sdp-file-size">${sizeKb} KB</span>
      <div class="sdp-file-actions">
        <button class="sdp-btn" onclick="event.stopPropagation();viewSkillFile('${d.name}','${f.path}')">👁️ 보기</button>
        <button class="sdp-btn inject" onclick="event.stopPropagation();injectToChat('${tab}','${f.path}')">💬 주입</button>
        ${isPy && f.name.endsWith('.py') ? `<button class="sdp-btn run" onclick="event.stopPropagation();runSkillScript('${d.name}','${f.path}')">▶ 실행</button>` : ''}
      </div>
    </li>`;
  });
  html += '</ul><div id="sdpFileContent"></div>';
  body.innerHTML = html;
}

async function viewSkillFile(skillId, filePath){
  const container = document.getElementById('sdpFileContent');
  if(!container) return;
  container.innerHTML = '⏳ 로딩중...';
  try{
    const resp = await fetch(`/api/skill/${skillId}/file?path=${encodeURIComponent(filePath)}`);
    const data = await resp.json();
    if(data.error){
      container.innerHTML = `<div class="sdp-result err">${esc(data.error)}</div>`;
    } else {
      container.innerHTML = `<div style="font-size:12px;font-weight:700;margin:10px 0 6px">${esc(data.name)} (${(data.size/1024).toFixed(1)} KB)</div>
        <div class="sdp-code">${esc(data.content)}</div>`;
    }
  }catch(e){
    container.innerHTML = `<div class="sdp-result err">오류: ${e.message}</div>`;
  }
}

async function runSkillScript(skillId, scriptPath){
  const container = document.getElementById('sdpFileContent');
  if(!container) return;
  container.innerHTML = '⏳ 스크립트 실행 중... (최대 60초)';
  try{
    const resp = await fetch(`/api/skill/${skillId}/run`, {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({script: scriptPath})
    });
    const data = await resp.json();
    if(data.error){
      container.innerHTML = `<div class="sdp-result err">❌ ${esc(data.error)}</div>`;
    } else {
      const cls = data.returncode === 0 ? 'ok' : 'err';
      let output = '';
      if(data.stdout) output += `=== stdout ===\n${data.stdout}\n`;
      if(data.stderr) output += `=== stderr ===\n${data.stderr}\n`;
      output += `\n[종료 코드: ${data.returncode}]`;
      container.innerHTML = `<div style="font-size:12px;font-weight:700;margin:10px 0 6px">▶ ${esc(scriptPath)} 실행 결과</div>
        <div class="sdp-result ${cls}">${esc(output)}</div>`;
    }
  }catch(e){
    container.innerHTML = `<div class="sdp-result err">실행 오류: ${e.message}</div>`;
  }
}

async function injectToChat(type, filePath){
  // 파일 내용을 채팅 입력에 주입
  const input = document.getElementById('input');
  const skillId = currentSkillDetail ? currentSkillDetail.name : '';

  if(type === 'skillmd'){
    input.value += `[${skillId} SKILL.md 참조 중]\n`;
    closeSkillDetail();
    return;
  }

  try{
    const resp = await fetch(`/api/skill/${skillId}/file?path=${encodeURIComponent(filePath)}`);
    const data = await resp.json();
    if(data.content){
      const preview = data.content.length > 500 ? data.content.substring(0,500) + '...' : data.content;
      input.value += `\n--- ${data.name} ---\n${preview}\n---\n`;
    }
  }catch(e){}
  closeSkillDetail();
  input.focus();
}

// ===== CSV Upload =====
let csvLoaded = false;
let csvFilename = '';

function handleCsvDrop(e){
  const files = e.dataTransfer.files;
  if(files.length > 0) uploadCsvFile(files[0]);
}
function handleCsvSelect(e){
  const files = e.target.files;
  if(files.length > 0) uploadCsvFile(files[0]);
  e.target.value = ''; // 같은 파일 재업로드 가능
}
async function uploadCsvFile(file){
  const area = document.getElementById('csvUploadArea');
  area.innerHTML = '<div class="icon">⏳</div><div class="label">업로드 중...</div>';

  const formData = new FormData();
  formData.append('file', file);

  try{
    const resp = await fetch('/api/upload_csv', {method:'POST', body:formData});
    const data = await resp.json();

    if(data.error){
      area.innerHTML = `<div class="icon">❌</div><div class="label">${data.error}</div><div class="sub">다시 시도하세요</div>`;
      setTimeout(()=>resetCsvArea(), 3000);
      return;
    }

    csvLoaded = true;
    csvFilename = data.filename;
    area.style.display = 'none';

    // 미리보기 테이블 생성
    let tableHtml = '<table><tr>' + data.headers.map(h=>`<th>${esc(h)}</th>`).join('') + '</tr>';
    if(data.sample_rows){
      data.sample_rows.forEach(row=>{
        tableHtml += '<tr>' + data.headers.map(h=>`<td>${esc(row[h]||'')}</td>`).join('') + '</tr>';
      });
    }
    tableHtml += '</table>';
    if(data.rows > 3) tableHtml += `<div style="text-align:center;color:#999;font-size:10px;margin-top:4px">... 총 ${data.rows}행</div>`;

    const panel = document.getElementById('csvInfoPanel');
    panel.style.display = 'block';
    panel.innerHTML = `
      <div class="csv-info">
        <div class="fname">📊 ${esc(data.filename)}</div>
        <div class="fstats">${data.rows}행 × ${data.cols}열</div>
        <button class="fremove" onclick="removeCsv()">✕ 제거</button>
        <div class="csv-preview">${tableHtml}</div>
      </div>`;

  }catch(e){
    area.innerHTML = `<div class="icon">❌</div><div class="label">업로드 실패: ${e.message}</div>`;
    setTimeout(()=>resetCsvArea(), 3000);
  }
}
function esc(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

async function removeCsv(){
  await fetch('/api/clear_csv', {method:'POST'});
  csvLoaded = false;
  csvFilename = '';
  resetCsvArea();
  document.getElementById('csvInfoPanel').style.display = 'none';
}
function resetCsvArea(){
  const area = document.getElementById('csvUploadArea');
  area.style.display = '';
  area.innerHTML = `<div class="icon">📂</div><div class="label">CSV / TSV 파일을 끌어놓거나 클릭</div><div class="sub">최대 50MB · UTF-8/CP949 자동 인식</div><input type="file" id="csvFileInput" accept=".csv,.tsv,.txt" style="display:none" onchange="handleCsvSelect(event)">`;
}

// ===== 범용 파일 업로드 =====
let uploadedFilesList = [];

function handleFileDrop(e){
  const files = e.dataTransfer.files;
  for(let i=0; i<files.length; i++) uploadGenericFile(files[i]);
}
function handleFileSelect(e){
  const files = e.target.files;
  for(let i=0; i<files.length; i++) uploadGenericFile(files[i]);
  e.target.value = '';
}

async function uploadGenericFile(file){
  const area = document.getElementById('fileUploadArea');
  const origHtml = area.innerHTML;
  area.innerHTML = `<div class="icon">⏳</div><div class="label">${esc(file.name)} 업로드 중...</div>`;

  const formData = new FormData();
  formData.append('file', file);

  try{
    const resp = await fetch('/api/upload_file', {method:'POST', body:formData});
    const data = await resp.json();

    if(data.error){
      area.innerHTML = `<div class="icon">❌</div><div class="label">${esc(data.error)}</div>`;
      setTimeout(()=>{ area.innerHTML = origHtml; }, 2500);
      return;
    }

    uploadedFilesList.push({
      filename: data.filename,
      type: data.type,
      ext: data.ext,
      size: data.size,
      icon: data.icon,
      preview: data.preview,
    });
    renderFileList();
    area.innerHTML = origHtml;

  }catch(e){
    area.innerHTML = `<div class="icon">❌</div><div class="label">업로드 실패: ${e.message}</div>`;
    setTimeout(()=>{ area.innerHTML = origHtml; }, 2500);
  }
}

function renderFileList(){
  const panel = document.getElementById('fileListPanel');
  if(uploadedFilesList.length === 0){
    panel.style.display = 'none';
    return;
  }
  panel.style.display = 'block';
  let html = '<div class="uploaded-files-header"><span>📎 업로드된 파일 ('+uploadedFilesList.length+')</span><button onclick="clearAllFiles()" class="fremove" style="float:right">전체 제거</button></div>';
  uploadedFilesList.forEach((f,i)=>{
    const sizeStr = f.size > 1048576 ? (f.size/1048576).toFixed(1)+'MB' : (f.size/1024).toFixed(1)+'KB';
    html += `<div class="uploaded-file-item">
      <span class="ufi-icon">${f.icon}</span>
      <span class="ufi-name" title="${esc(f.preview||'')}">${esc(f.filename)}</span>
      <span class="ufi-size">${sizeStr}</span>
      <button class="ufi-remove" onclick="removeFile('${esc(f.filename)}',${i})">✕</button>
    </div>`;
  });
  panel.innerHTML = html;
}

async function removeFile(filename, idx){
  await fetch('/api/remove_file', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({filename})});
  uploadedFilesList.splice(idx, 1);
  renderFileList();
}

async function clearAllFiles(){
  await fetch('/api/clear_files', {method:'POST'});
  uploadedFilesList = [];
  renderFileList();
}
</script>
</body>
</html>
"""

# ============================================
# 실행
# ============================================
if __name__ == "__main__":
    # Windows 콘솔 인코딩 사전 보호 (colorama/click 충돌 방지)
    if sys.platform == "win32":
        # UTF-8 콘솔 모드 강제
        os.environ.setdefault("PYTHONIOENCODING", "utf-8")
        os.environ.setdefault("PYTHONUTF8", "1")
        try:
            os.system("chcp 65001 >nul 2>&1")
        except Exception:
            pass
        # colorama 초기화 문제 방지
        os.environ.setdefault("NO_COLOR", "1")
        os.environ.setdefault("TERM", "dumb")

    print("=" * 50)
    print("  Demos(민중) Alpha 0.8")
    print("=" * 50)

    # 스킬 폴더 확인
    if os.path.isdir(SKILLS_DIR):
        skills = scan_skills()
        print(f"  📂 스킬 폴더: {SKILLS_DIR}")
        print(f"  ✅ 발견된 스킬: {len(skills)}개")
        for s in sorted(skills.keys())[:10]:
            print(f"     - {s}")
        if len(skills) > 10:
            print(f"     ... 외 {len(skills)-10}개")
    else:
        print(f"  ⚠️  스킬 폴더 없음: {SKILLS_DIR}")
        print(f"     scientific-skills 폴더를 app.py와 같은 위치에 복사하세요.")

    # 토큰 확인
    if API_TOKEN:
        print(f"  🔑 TOKEN.TXT: 로드됨 ({len(API_TOKEN)}자)")
    else:
        print(f"  ⚠️  TOKEN.TXT: 없음 또는 비어있음")
        print(f"     → {TOKEN_FILE} 에 API 키를 넣어주세요")

    # ============================================
    # GGUF 자동 감지 & Python으로 직접 로드
    # ============================================
    gguf_files = find_gguf_files()

    if gguf_files:
        # GGUF 파일 중 가장 큰 것 선택
        best_gguf = max(gguf_files, key=lambda x: x["size_gb"])
        print(f"\n  💻 GGUF 자동 감지!")
        print(f"     모델: {best_gguf['name']} ({best_gguf['size_gb']} GB)")

        if load_gguf_model(best_gguf["path"]):
            ENV_CONFIG["gguf-local"] = {
                "url": "python://llama-cpp-python",
                "model": best_gguf["name"].replace(".gguf", ""),
                "name": f"LOCAL GGUF ({best_gguf['name']})"
            }
            print(f"     ✅ GGUF 모델 로드 완료!")
    else:
        print(f"\n  ℹ️  GGUF 파일 없음 → LOCAL GGUF 비활성")

    # 환경 목록
    print()
    print("  🖥️  사용 가능한 LLM 환경:")
    for eid, ecfg in ENV_CONFIG.items():
        print(f"     [{eid}] {ecfg['name']} → {ecfg['url']}")

    print()
    print(f"  🌐 http://localhost:10009 에서 접속하세요")
    print("=" * 50)

    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    # Windows: GGUF 모델 로드 후 콘솔 핸들이 깨질 수 있으므로 복원
    if sys.platform == "win32":
        import io as _io

        # 1) colorama/click 배너 출력 시 OSError: Windows error 6 방지
        #    → 환경변수로 Flask CLI 배너를 비활성화
        os.environ.setdefault("WERKZEUG_RUN_MAIN", "false")

        # 2) stdout/stderr 핸들 복원 시도
        for _stream_name in ("stdout", "stderr"):
            try:
                getattr(sys, _stream_name).write("")
            except (OSError, AttributeError, ValueError):
                try:
                    _orig = getattr(sys, f"__{_stream_name}__")
                    _fd = _orig.fileno()
                    setattr(sys, _stream_name, _io.TextIOWrapper(
                        open(_fd, "wb", closefd=False),
                        encoding="utf-8", errors="replace"
                    ))
                except (OSError, AttributeError, ValueError):
                    # fileno()도 죽은 경우 → devnull로 대체 (서버는 정상 동작)
                    setattr(sys, _stream_name, open(os.devnull, "w", encoding="utf-8"))

        # 3) click의 echo가 colorama를 통해 쓸 때 터지는 것 방지
        try:
            import click
            click.echo = lambda message=None, file=None, nl=True, err=False, color=None: None
        except ImportError:
            pass

    app.run(host="0.0.0.0", port=10009, debug=False)