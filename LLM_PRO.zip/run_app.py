#!/usr/bin/env python3
"""Nomos LLM Desktop - 실행 스크립트"""
from app.main import main

if __name__ == "__main__":
    main()
