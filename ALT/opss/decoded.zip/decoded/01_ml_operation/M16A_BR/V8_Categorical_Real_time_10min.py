# -*- coding: utf-8 -*-
"""
V8 실시간 예측 - 범주형 10분 버전
3-Class Classification (Class 0/1/2)
+ 결과를 로그프레소 test_table에 저장
"""

import numpy as np
import pandas as pd
import pickle
from datetime import datetime, timedelta
import os
import json
import requests
import urllib.parse
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

script_dir = os.path.dirname(os.path.abspath(__file__))
model_dir = os.path.join(script_dir, 'model_10min', 'xgboost_Categorical_V8_10min.pkl')
data_dir = os.path.join(script_dir, 'data', 'HUBROOM_PIVOT_DATA.csv')

FEATURE_COLS = {
    'storage': ['M16A_3F_STORAGE_UTIL'],
    'fs_storage': ['CD_M163FSTORAGEUSE', 'CD_M163FSTORAGETOTAL', 'CD_M163FSTORAGEUTIL'],
    'hub': ['HUBROOMTOTAL'],
    'cmd': ['M16A_3F_CMD', 'M16A_6F_TO_HUB_CMD'],
    'inflow': ['M16A_6F_TO_HUB_JOB', 'M16A_2F_TO_HUB_JOB2', 'M14A_3F_TO_HUB_JOB2'],
    'outflow': ['M16A_3F_TO_M16A_6F_JOB', 'M16A_3F_TO_M16A_2F_JOB', 'M16A_3F_TO_M14A_3F_JOB'],
    'maxcapa': ['M16A_6F_LFT_MAXCAPA', 'M16A_2F_LFT_MAXCAPA'],
    'que': ['M16HUB.QUE.ALL.CURRENTQCNT', 'M16HUB.QUE.TIME.AVGTOTALTIME1MIN'],
    'target_alt': ['CURRENT_M16A_3F_JOB'],
    'm16hub_que': [
        'M16HUB.QUE.ALL.CURRENTQCOMPLETED',
        'M16HUB.QUE.ALL.FABTRANSJOBCNT',
        'M16HUB.QUE.TIME.AVGTOTALTIME',
        'M16HUB.QUE.OHT.CURRENTOHTQCNT',
        'M16HUB.QUE.OHT.OHTUTIL'
    ],
    'm16a_que': [
        'M16A.QUE.ALL.CURRENTQCOMPLETED',
        'M16A.QUE.ALL.CURRENTQCREATED',
        'M16A.QUE.OHT.CURRENTOHTQCNT',
        'M16A.QUE.OHT.OHTUTIL',
        'M16A.QUE.LOAD.AVGLOADTIME1MIN',
        'M16A.QUE.ALL.TRANSPORT4MINOVERCNT',
        'M16A.QUE.ABN.QUETIMEDELAY'
    ]
}

def get_class_name(cls):
    """클래스 번호를 이름으로"""
    names = {
        0: 'DECLINE',      # ~0 (하락/정체)
        1: 'SMALL_RISE',   # 0~50 (소폭 증가)
        2: 'SURGE'         # 50~ (급증)
    }
    return names.get(cls, f'CLASS_{cls}')

def realtime_prediction():
    try:
        with open(model_dir, 'rb') as f:
            model = pickle.load(f)
    except:
        return None, "model is not found"
   
    try:
        df = pd.read_csv(data_dir, on_bad_lines='skip')
    except FileNotFoundError:
        return None, "file is not found"
    except Exception as e:
        return None, "exception occurred while reading file"
   
    recent_30 = df.tail(30).copy()
    TARGET_COL = 'CURRENT_M16A_3F_JOB_2'
   
    if TARGET_COL not in recent_30.columns:
        return None, "target column is not included"
   
    seq_target = recent_30[TARGET_COL].values
    current_value = seq_target[-1]
   
    if 'STAT_DT' in recent_30.columns:
        try:
            recent_30['STAT_DT'] = pd.to_datetime(recent_30['STAT_DT'].astype(str), format='%Y%m%d%H%M')
        except:
            base_time = datetime(2024, 1, 1, 0, 0)
            recent_30['STAT_DT'] = [base_time + timedelta(minutes=i) for i in range(len(recent_30))]
   
    seq_end = recent_30['STAT_DT'].iloc[-1]
    current_time = seq_end
    prediction_time = seq_end + timedelta(minutes=10)
   
    # Feature 생성
    features = {
        'target_mean': np.mean(seq_target),
        'target_std': np.std(seq_target),
        'target_max': np.max(seq_target),
        'target_min': np.min(seq_target),
        'target_last_value': seq_target[-1],
        'target_last_5_mean': np.mean(seq_target[-5:]),
        'target_slope': np.polyfit(np.arange(30), seq_target, 1)[0],
    }
   
    features['target_acceleration'] = (seq_target[-5:].mean() - seq_target[-10:-5].mean()) / 5
    features['target_is_rising'] = 1 if seq_target[-1] > seq_target[-5] else 0
    features['target_rapid_rise'] = 1 if (seq_target[-1] - seq_target[-5] > 10) else 0
    features['target_last_10_mean'] = np.mean(seq_target[-10:])
   
    for group_name, cols in FEATURE_COLS.items():
        for col in cols:
            if col not in recent_30.columns:
                continue
           
            col_seq = recent_30[col].values
           
            if group_name == 'maxcapa':
                features[f'{col}_last_value'] = col_seq[-1]
           
            elif group_name in ['cmd', 'storage', 'fs_storage', 'hub', 'que',
                               'target_alt', 'm16hub_que', 'm16a_que']:
                features[f'{col}_mean'] = np.mean(col_seq)
                features[f'{col}_std'] = np.std(col_seq)
                features[f'{col}_max'] = np.max(col_seq)
                features[f'{col}_min'] = np.min(col_seq)
                features[f'{col}_last_value'] = col_seq[-1]
                features[f'{col}_last_5_mean'] = np.mean(col_seq[-5:])
                features[f'{col}_slope'] = np.polyfit(np.arange(30), col_seq, 1)[0]
           
            else:  # inflow, outflow
                features[f'{col}_mean'] = np.mean(col_seq)
                features[f'{col}_last_value'] = col_seq[-1]
                features[f'{col}_slope'] = np.polyfit(np.arange(30), col_seq, 1)[0]
   
    if 'CD_M163FSTORAGEUSE' in recent_30.columns and 'CD_M163FSTORAGETOTAL' in recent_30.columns and 'CD_M163FSTORAGEUTIL' in recent_30.columns:
        use_seq = recent_30['CD_M163FSTORAGEUSE'].values
        total_seq = recent_30['CD_M163FSTORAGETOTAL'].values
        util_seq = recent_30['CD_M163FSTORAGEUTIL'].values
       
        features['storage_use_rate'] = (use_seq[-1] - use_seq[0]) / 30
        features['storage_remaining'] = total_seq[-1] - use_seq[-1]
        features['storage_util_last'] = util_seq[-1]
        features['storage_util_high'] = 1 if util_seq[-1] >= 7 else 0
        features['storage_util_critical'] = 1 if util_seq[-1] >= 10 else 0
   
    if 'HUBROOMTOTAL' in recent_30.columns:
        hub_seq = recent_30['HUBROOMTOTAL'].values
        hub_last = hub_seq[-1]
       
        features['hub_critical'] = 1 if hub_last < 590 else 0
        features['hub_high'] = 1 if hub_last < 610 else 0
        features['hub_warning'] = 1 if hub_last < 620 else 0
        features['hub_decrease_rate'] = (hub_seq[0] - hub_last) / 30
       
        if 'CD_M163FSTORAGEUTIL' in recent_30.columns:
            storage_util_last = recent_30['CD_M163FSTORAGEUTIL'].iloc[-1]
            features['hub_storage_risk'] = 1 if (hub_last < 610 and storage_util_last >= 7) else 0
   
    inflow_sum = sum(recent_30[col].iloc[-1] for col in FEATURE_COLS['inflow'] if col in recent_30.columns)
    outflow_sum = sum(recent_30[col].iloc[-1] for col in FEATURE_COLS['outflow'] if col in recent_30.columns)
    features['net_flow'] = inflow_sum - outflow_sum
   
    cmd_sum = sum(recent_30[col].iloc[-1] for col in FEATURE_COLS['cmd'] if col in recent_30.columns)
    features['total_cmd'] = cmd_sum
    features['total_cmd_low'] = 1 if cmd_sum < 220 else 0
    features['total_cmd_very_low'] = 1 if cmd_sum < 200 else 0
   
    if 'HUBROOMTOTAL' in recent_30.columns:
        hub_last = recent_30['HUBROOMTOTAL'].iloc[-1]
        features['hub_cmd_bottleneck'] = 1 if (hub_last < 610 and cmd_sum < 220) else 0
   
    if 'M16A_3F_STORAGE_UTIL' in recent_30.columns:
        storage_util = recent_30['M16A_3F_STORAGE_UTIL'].iloc[-1]
        features['storage_util_critical'] = 1 if storage_util >= 205 else 0
        features['storage_util_high_risk'] = 1 if storage_util >= 207 else 0
   
    features['surge_risk_score'] = (
        features.get('hub_high', 0) * 3 +
        features.get('storage_util_critical', 0) * 2 +
        features.get('total_cmd_low', 0) * 1 +
        features.get('storage_util_high', 0) * 1
    )
   
    features['surge_imminent'] = 1 if (
        seq_target[-1] > 280 and
        features.get('target_acceleration', 0) > 0.5 and
        features.get('hub_high', 0) == 1
    ) else 0
   
    # Boolean features
    if 'M16HUB.QUE.ALL.CURRENTQCNT' in recent_30.columns:
        currentq = recent_30['M16HUB.QUE.ALL.CURRENTQCNT'].iloc[-1]
        features['currentq_high'] = 1 if currentq >= 1200 else 0
        features['currentq_critical'] = 1 if currentq >= 1400 else 0
    else:
        features['currentq_high'] = 0
        features['currentq_critical'] = 0
   
    if 'M16HUB.QUE.TIME.AVGTOTALTIME1MIN' in recent_30.columns:
        avgtime = recent_30['M16HUB.QUE.TIME.AVGTOTALTIME1MIN'].iloc[-1]
        features['avgtime1min_high'] = 1 if avgtime >= 4.0 else 0
        features['avgtime1min_critical'] = 1 if avgtime >= 4.5 else 0
    else:
        features['avgtime1min_high'] = 0
        features['avgtime1min_critical'] = 0
   
    if 'M16HUB.QUE.ALL.CURRENTQCNT' in recent_30.columns and 'M16HUB.QUE.TIME.AVGTOTALTIME1MIN' in recent_30.columns:
        currentq = recent_30['M16HUB.QUE.ALL.CURRENTQCNT'].iloc[-1]
        avgtime = recent_30['M16HUB.QUE.TIME.AVGTOTALTIME1MIN'].iloc[-1]
        features['que_severe_bottleneck'] = 1 if (currentq >= 1200 and avgtime >= 4.0) else 0
    else:
        features['que_severe_bottleneck'] = 0
   
    if 'M16HUB.QUE.OHT.OHTUTIL' in recent_30.columns:
        ohtutil = recent_30['M16HUB.QUE.OHT.OHTUTIL'].iloc[-1]
        features['m16hub_ohtutil_high'] = 1 if ohtutil >= 85.0 else 0
        features['m16hub_ohtutil_critical'] = 1 if ohtutil >= 90.0 else 0
    else:
        features['m16hub_ohtutil_high'] = 0
        features['m16hub_ohtutil_critical'] = 0
   
    if 'M16HUB.QUE.TIME.AVGTOTALTIME' in recent_30.columns:
        avgtime = recent_30['M16HUB.QUE.TIME.AVGTOTALTIME'].iloc[-1]
        features['m16hub_avgtime_high'] = 1 if avgtime >= 5.0 else 0
        features['m16hub_avgtime_critical'] = 1 if avgtime >= 6.0 else 0
    else:
        features['m16hub_avgtime_high'] = 0
        features['m16hub_avgtime_critical'] = 0
   
    if 'M16HUB.QUE.OHT.OHTUTIL' in recent_30.columns and 'M16HUB.QUE.TIME.AVGTOTALTIME' in recent_30.columns:
        ohtutil = recent_30['M16HUB.QUE.OHT.OHTUTIL'].iloc[-1]
        avgtime = recent_30['M16HUB.QUE.TIME.AVGTOTALTIME'].iloc[-1]
        features['m16hub_severe_bottleneck'] = 1 if (ohtutil >= 85.0 and avgtime >= 5.0) else 0
    else:
        features['m16hub_severe_bottleneck'] = 0
   
    if 'M16A.QUE.OHT.OHTUTIL' in recent_30.columns:
        ohtutil = recent_30['M16A.QUE.OHT.OHTUTIL'].iloc[-1]
        features['m16a_ohtutil_high'] = 1 if ohtutil >= 85.0 else 0
        features['m16a_ohtutil_critical'] = 1 if ohtutil >= 90.0 else 0
    else:
        features['m16a_ohtutil_high'] = 0
        features['m16a_ohtutil_critical'] = 0
   
    if 'M16A.QUE.LOAD.AVGLOADTIME1MIN' in recent_30.columns:
        loadtime = recent_30['M16A.QUE.LOAD.AVGLOADTIME1MIN'].iloc[-1]
        features['m16a_loadtime_high'] = 1 if loadtime >= 2.5 else 0
        features['m16a_loadtime_critical'] = 1 if loadtime >= 2.8 else 0
    else:
        features['m16a_loadtime_high'] = 0
        features['m16a_loadtime_critical'] = 0
   
    if 'M16A.QUE.ALL.TRANSPORT4MINOVERCNT' in recent_30.columns:
        transport4min = recent_30['M16A.QUE.ALL.TRANSPORT4MINOVERCNT'].iloc[-1]
        features['m16a_transport4min_high'] = 1 if transport4min >= 40 else 0
        features['m16a_transport4min_critical'] = 1 if transport4min >= 50 else 0
    else:
        features['m16a_transport4min_high'] = 0
        features['m16a_transport4min_critical'] = 0
   
    if 'M16A.QUE.ABN.QUETIMEDELAY' in recent_30.columns:
        delay = recent_30['M16A.QUE.ABN.QUETIMEDELAY'].iloc[-1]
        features['m16a_delay_warning'] = 1 if delay >= 1 else 0
        features['m16a_delay_critical'] = 1 if delay >= 3 else 0
    else:
        features['m16a_delay_warning'] = 0
        features['m16a_delay_critical'] = 0
   
    if 'M16A.QUE.OHT.OHTUTIL' in recent_30.columns and 'M16A.QUE.ALL.TRANSPORT4MINOVERCNT' in recent_30.columns:
        ohtutil = recent_30['M16A.QUE.OHT.OHTUTIL'].iloc[-1]
        transport4min = recent_30['M16A.QUE.ALL.TRANSPORT4MINOVERCNT'].iloc[-1]
        features['m16a_severe_bottleneck'] = 1 if (ohtutil >= 85.0 and transport4min >= 40) else 0
    else:
        features['m16a_severe_bottleneck'] = 0
   
    X_pred = pd.DataFrame([features])
   
    # 분류 예측
    pred_class = model.predict(X_pred)[0]
    pred_proba = model.predict_proba(X_pred)[0]
   
    class_name = get_class_name(pred_class)
   
    # 상태 판정
    if pred_class == 2:  # SURGE
        status = "WARNING"
        surge_alert = 1
    elif pred_class == 1:  # SMALL_RISE
        status = "CAUTION"
        surge_alert = 0
    else:  # DECLINE
        status = "NORMAL"
        surge_alert = 0
   
    return {
        'current_value': current_value,
        'pred_class': int(pred_class),
        'class_name': class_name,
        'prob_class0': pred_proba[0],
        'prob_class1': pred_proba[1],
        'prob_class2': pred_proba[2],
        'status': status,
        'surge_alert': surge_alert,
        'current_time': current_time.strftime('%Y-%m-%d %H:%M'),
        'prediction_time': prediction_time.strftime('%Y-%m-%d %H:%M')
    }, None

# ─────────────────────────────────────────────
#  로그프레소 저장 (test_table)
# ─────────────────────────────────────────────
# config.json 에서 설정 로드
_config_path = os.path.join(script_dir, "m16br_config.json")
with open(_config_path, encoding="utf-8") as _cf:
    _cfg = json.load(_cf)

# 접속 정보
INSERT_TABLE = _cfg["logpresso"]["insert_table"]
BASE = f"http://{_cfg['logpresso']['host']}:{_cfg['logpresso']['port']}/logpresso/httpexport/query.csv"

# 모델 메타 (config.json의 models.categorical_10m)
_model_cfg = _cfg["models"]["categorical_10m"]
FLOW               = _model_cfg["FLOW"]
MODEL              = _model_cfg["MODEL"]
MODEL_TYPE         = _model_cfg["MODEL_TYPE"]
PREDICTION_HORIZON = _model_cfg["PREDICTION_HORIZON"]

def _load_api_key():
    for p in [os.path.join(script_dir, "api_key.txt"),
              os.path.join(os.getcwd(), "api_key.txt")]:
        if os.path.exists(p):
            with open(p, encoding="utf-8") as f:
                return f.read().strip().splitlines()[0].strip()
    return os.environ.get("LOGPRESSO_API_KEY", "")

API_KEY = _load_api_key()

def save_to_logpresso(row: dict) -> bool:
    """row dict 한 건을 test_table 에 저장 (json + import)"""
    if not API_KEY:
        print("❌ API_KEY 없음")
        return False

    # dict → "{KEY = 'value', ...}" 형식
    parts = []
    for k, v in row.items():
        if v is None:
            parts.append(f"{k} = null")
        else:
            s = str(v).replace("'", "\\'")
            parts.append(f"{k} = '{s}'")
    literal = "{" + ", ".join(parts) + "}"
    escaped = literal.replace('"', '\\"')

    q = f'json "{escaped}" | import {INSERT_TABLE}'
    url = f"{BASE}?_apikey={API_KEY}&_q={urllib.parse.quote(q, safe='')}"

    try:
        r = requests.get(url, verify=False, timeout=30)
        if r.status_code == 200 and not r.text.strip().startswith("<"):
            print(f"✅ Logpresso 저장 ({INSERT_TABLE})")
            return True
        print(f"❌ HTTP {r.status_code} | {r.text[:200]}")
        return False
    except Exception as e:
        print(f"❌ {type(e).__name__}: {e}")
        return False

def predict_realtime():
    result, error = realtime_prediction()
   
    if result is None:
        row = {"EXCEPT": error}
        print([row])
    else:
        # 가장 높은 확률의 클래스 찾기
        probs = [
            (0, result['prob_class0'] * 100, "CLASS_0"),
            (1, result['prob_class1'] * 100, "CLASS_1"),
            (2, result['prob_class2'] * 100, "CLASS_2")
        ]
        max_class_num, max_prob, max_class_name = max(probs, key=lambda x: x[1])
       
        row = {
            "FLOW": FLOW,
            "CURRENT_TIME": result['current_time'],
            "PREDICTION_TIME": result['prediction_time'],
            "CURRENT_VALUE": round(result['current_value'], 2),
            "RESULT": f"{max_class_name}_({max_prob:.1f}%)",
            "PREDICT_CLASS": result['pred_class'],
            "PREDICT_CLASS_NAME": result['class_name'],
            "CLASS_0_PROB": round(result['prob_class0'] * 100, 1),
            "CLASS_0_NAME": "DECLINE (~0)",
            "CLASS_1_PROB": round(result['prob_class1'] * 100, 1),
            "CLASS_1_NAME": "SMALL_RISE (0~50)",
            "CLASS_2_PROB": round(result['prob_class2'] * 100, 1),
            "CLASS_2_NAME": "SURGE (50~)",
            "SURGE_ALERT": result['surge_alert'],
            "STATUS": result['status'],
            "MODEL": MODEL,
            "PREDICTION_HORIZON": PREDICTION_HORIZON,
            "MODEL_TYPE": MODEL_TYPE
        }
        print([row])
        save_to_logpresso(row)   # ← 이 한 줄만 추가

if __name__ == '__main__':
    predict_realtime()
